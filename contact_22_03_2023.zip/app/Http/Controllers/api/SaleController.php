<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Portal\Product;
use App\Models\Portal\Brand;
use App\Models\Portal\Unit;
use App\Models\Portal\Sale;
use App\Models\Portal\Customer;
use Illuminate\Support\Str;
use Validator;
use Carbon\Carbon;

class SaleController extends Controller
{
    public function __construct()
    {
        $this->middleware("auth:api");
    }
}
