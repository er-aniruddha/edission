<?php

namespace App\Http\Controllers\api\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Session;
use Validator;

class LoginController extends Controller
{
    public function login(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'email' => 'required|max:255|email',
            'password' => 'required|min:8',
        ]);
      
        if ($validator->fails())
        {
            return response()->json(['errors' => $validator->errors()]);
        }   

        if($validator->passes())
        {
            if(Auth::attempt(['email' => $request->email , 'password' => $request->password])) {

                $accessToken = Auth::User()->createToken('authToken')->accessToken;
                $success = array('success'=>'OK', 'user' => Auth::User(), 'access_token' => $accessToken);
                return response()->json($success);
                
            }      
            else{
                $user = User::where('email',$request->email)->first();
                if($user){
                    return response()->json(['errors' => array('password' => array('Wrong password.')) ]);
                }
                else{                
                    return response()->json(['errors' => array('email' => array('This email is not registered.')) ]);
                }                 
            }                   
        }
    }
}
