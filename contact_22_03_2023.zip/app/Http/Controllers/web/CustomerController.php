<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Customer;
use App\Models\Portal\CustomerRoute;
use App\Models\Portal\Product;
use App\Models\Portal\Brand;
use App\Models\Portal\Unit;
use App\Models\Portal\Stock;
use App\Models\Portal\PaymentIn;
use App\Models\Portal\Sale;
use App\Models\Portal\CustomerDiscount;
use App\Models\Portal\CreditNote;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Validator;

class CustomerController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function all()
    {        
        $customers = Customer::orderBy('f_name','ASC')
                                ->join('customer_routes','customers.customer_routes_id',"=",'customer_routes.customer_routes_id')->get(); 
        $routes = CustomerRoute::orderBy('route_name','ASC')->get(); 
        if(request()->ajax())
        {
            return datatables()->of($customers)
            ->addColumn('name', function($data){                  
                $name = '<a href="'.route('customer.details',$data->customer_id).'" class="item-company ajax h-1x text-capitalize" data-pjax-state="">'.$data->f_name.' '.$data->s_name.'</a>                        
                        <div class="hide">'.$data->route_name.'</div>'; 
              return $name;
            })  
            ->addColumn('phone', function($data){    
                if($data->phone_2){
                    $phone = '<small>'.$data->phone_1.' \ '.$data->phone_2.'</small>';
                }   
                else{
                     $phone = '<small>'.$data->phone_1.'</small>';
                }           
                
              return $phone;
            }) 
            ->addColumn('action', function($data){                  
                $action = '<div> <!-- Vied,Edit -->
                                <div class="item-action dropdown">
                                    <a href="#" data-toggle="dropdown" class="text-muted">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"
                                            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                            class="feather feather-more-vertical">
                                            <circle cx="12" cy="12" r="1"></circle>
                                            <circle cx="12" cy="5" r="1"></circle>
                                            <circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" role="menu">
                                        <a class="dropdown-item view" href="'.route('customer.details',$data->customer_id).'">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>View
                                        </a>
                                        <a class="dropdown-item edit" data-id="'.$data->customer_id.'" data-fname="'.$data->f_name.'" 
                                            data-sname="'.$data->s_name.'" data-shop="'.$data->shop_name.'" data-phone1="'.$data->phone_1.'" data-phone2="'.$data->phone_2.'" data-whatsapp="'.$data->whatsapp_no.'" data-email="'.$data->email.'" data-type="'.$data->customer_type.'" data-route="'.$data->customer_routes_id.'" data-locality="'.$data->locality.'" data-district="'.$data->district.'" data-pin="'.$data->pin.'" data-addline1="'.$data->addline_1.'" data-addline2="'.$data->addline_2.'" data-toggle="modal" data-target="#editModal">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"></path><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"></polygon></svg>Edit
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <delete class="dropdown-item trash" data-id="'.$data->customer_id.'" data-shop="'.$data->shop_name.'">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>
                                            </svg>Delete
                                        </delete>
                                    </div>
                                </div>
                            </div>'; 
                return $action;
            })   
            ->addIndexColumn()
            ->rawColumns(['action','name','phone'])  
            ->make(true);       
                    
        } 
        else{
            return view("portal.customer.all",["customers" => $customers, "routes" => $routes ]);
        }       
    }

    public function create(Request $request)
    {
        if($request->isMethod('post'))
        {
            $validator = \Validator::make($request->all(), [
                'f_name' => 'required|max:255',
                's_name' => 'required|max:255',
                'shop_name' => 'required|max:255',
                'phone_1' => 'required|min:10|numeric|regex:/[6-9][0-9]{9}/|unique:customers,phone_1',
                'email' => 'nullable|email|unique:customers,email',
                'customer_type' => 'required|not_in:0',
                'customer_routes_id' => 'required|not_in:0',
                'locality' => 'required|max:255',
                'district' => 'required|max:255',
                'pin' => 'required|min:6',
                ],[
                    'f_name.required' => 'Please enter first name.',
                    's_name.required' => 'Please enter surname.',

                    'phone_1.required' => 'Please enter valid phone number.',
                    'phone_1.min' => 'Please enter valid phone number.',
                    'phone_1.numeric' => 'Please enter valid phone number.',
                    'phone_1.regex' => 'Please enter valid phone number.',
                    'phone_1.unique' => 'Phone nuber already been taken.',

                    'customer_routes_id.required' => 'Please select route.',
                ]);
                if ($validator->fails())         
                {
                    return response()->json(['errors' => $validator->errors()]);
                }

                $customer = new Customer;
                $customer->f_name = Str::lower($request->f_name);
                $customer->s_name = Str::lower($request->s_name);
                $customer->shop_name = Str::lower($request->shop_name);
                $customer->phone_1 = $request->phone_1;
                $customer->phone_2 = $request->phone_2;
                $customer->whatsapp_no = $request->whatsapp_no;
                $customer->email = Str::lower($request->email);
                $customer->customer_type = $request->customer_type;
                $customer->customer_routes_id = $request->customer_routes_id;
                $customer->locality = Str::lower($request->locality);
                $customer->district = $request->district;
                $customer->state = $request->state;
                $customer->pin = $request->pin;
                $customer->addline_1 = Str::lower($request->addline_1);
                $customer->addline_2 = Str::lower($request->addline_2);                 
                $is_saved = $customer->save();

                if($is_saved)
                {
                    $success = array('success' => 'Customer added successfully');
                    return response()->json($success);
                }

        }
        /*
         * if condition end here 
         */
        else
        {
            $routes = CustomerRoute::orderBy('route_name','ASC')->get();
            return view('portal.customer.create',['routes' => $routes]);
        }  
    }

    public function details($customer_id)
    {
        $routes = CustomerRoute::orderBy('route_name','ASC')->get();
        $customer = Customer::find($customer_id);
        $customers = Customer::orderBy('customer_id','ASC')
                                ->join('customer_routes','customers.customer_routes_id',"=",'customer_routes.customer_routes_id')
                                ->get();

        $sales = Sale::where('sales.customer_id',$customer_id)
                            ->leftJoin('products','sales.item_name','=','products.product_id')
                            ->leftJoin('customers','sales.customer_id','=','customers.customer_id')
                            ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('units','sales.unit_id','=','units.unit_id')
                            ->select(array('sales.*','products.*','customers.*','units.*','brands.*'))
                            ->orderBy('sale_id','asc')
                            ->get();   
        $creditNotes = CreditNote::where('credit_notes.customer_id',$customer_id)
                                ->leftJoin('products','credit_notes.item_name','=','products.product_id')
                                ->leftJoin('customers','credit_notes.customer_id','=','customers.customer_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units','credit_notes.unit_id','=','units.unit_id')
                                ->select(array('credit_notes.*','products.*','customers.*','units.*','brands.*'))
                                ->orderBy('cr_note_id','asc')
                                ->get(); 
        $paymentIn = PaymentIn::where('payment_ins.customer_id',$customer_id)
                                ->leftJoin('customers','payment_ins.customer_id','=','customers.customer_id')
                                ->select(array('payment_ins.*','customers.*','payment_ins.date as order_date','payment_ins.date as delivery_date','payment_type as payment_type','prev_balance as total','prev_balance as prev_balance','received as received','payment_ins.balance as balance'))
                                ->orderBy('payment_ins.date','desc')
                                ->get();   
        $customerDiscount = CustomerDiscount::where('customer_discounts.customer_id',$customer_id)
                                ->leftJoin('customers','customer_discounts.customer_id','=','customers.customer_id')
                                ->select(array('customer_discounts.*','customers.*','customer_discounts.date as order_date','customer_discounts.date as delivery_date','payment_type as payment_type'))
                                ->orderBy('customer_discounts.date','desc')
                                ->get(); 

        $allTableData = $sales->concat($creditNotes)->concat($paymentIn)->concat($customerDiscount);

        return view('portal.customer.details',['allTableData' => $allTableData, 'routes' => $routes, 'customers' => $customers, 'customer' => $customer, 'sales' => $sales]);   
    }

    public function data_table_bill($customer_id)
    {
        $startDate = $_GET['startDate']; 
        $endDate = $_GET['endDate'];

        $sales = Sale::where('sale_order_date', '>=', $startDate)->where('sale_order_date', '<=', $endDate)
                        ->where('sales.customer_id',$customer_id)
                        ->select(array('sales.*','sale_order_date as order_date','sale_delivery_date as delivery_date','sale_payment_type as payment_type','sale_total as total','sale_prev_balance as prev_balance','sale_received as received','sale_balance as balance','sale_payment_status as payment_status'))
                        ->orderBy('sale_order_date','desc')
                        ->get()->unique('sale_trnx_id'); 
        $creditNotes = CreditNote::where('cr_order_date', '>=', $startDate)->where('cr_order_date', '<=', $endDate)
                                ->where('credit_notes.customer_id',$customer_id)
                                ->select(array('credit_notes.*','cr_order_date as order_date','cr_delivery_date as delivery_date','cr_payment_type as payment_type','cr_total as total','cr_prev_balance as prev_balance','cr_paid as received','cr_balance as balance','cr_payment_status as payment_status'))
                                ->orderBy('cr_order_date','desc')
                                ->get()->unique('cr_trnx_id'); 
        $paymentIn = PaymentIn::where('date', '>=', $startDate)->where('date', '<=', $endDate)
                                ->where('payment_ins.customer_id',$customer_id)
                                ->select(array('payment_ins.*','payment_ins.date as order_date','payment_ins.date as delivery_date','payment_type as payment_type','prev_balance as total','prev_balance as prev_balance','received as received','balance as balance'))
                                ->orderBy('payment_ins.date','desc')
                                ->get(); 
        $customerDiscount = CustomerDiscount::where('customer_discounts.customer_id',$customer_id)
                                ->leftJoin('customers','customer_discounts.customer_id','=','customers.customer_id')
                                ->select(array('customer_discounts.*','date as order_date','date as delivery_date','payment_type as payment_type','discount_amount as total','paid as received'))
                                ->orderBy('customer_discounts.date','desc')
                                ->get();

        $tableData = $sales->concat($creditNotes)->concat($paymentIn)->concat($customerDiscount)->sortByDesc('order_date');

        if(request()->ajax())
        {
            return datatables()->of($tableData)               
            
            ->addColumn('action', function($data){                  
                if($data->sale_trnx_id)
                {
                    $action = '<div class="item-action dropdown">
                                <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                    </svg>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right bg-light" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                    <a class="dropdown-item view" href="#" data-saletrnxid="'.$data->sale_trnx_id.'" data-status="'.$data->sale_status.'">See detail</a>                                    
                                </div>
                            </div>'; 
                }
                if($data->cr_trnx_id)
                {
                    $action = '<div class="item-action dropdown">
                                <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                    </svg>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right bg-light" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                    <a class="dropdown-item view" href="#" data-crtrnxid="'.$data->cr_trnx_id.'" data-status="'.$data->cr_status.'">See detail</a>                                    
                                </div>
                            </div>'; 
                }
                if($data->payment_in_trnx_id)
                {
                    $action = '<div class="item-action dropdown">
                                <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                    </svg>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right bg-light" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                    <a class="dropdown-item view" href="#" data-payintrnxid="'.$data->payment_in_trnx_id.'" data-status="1">See detail</a>                                    
                                </div>
                            </div>'; 
                }
                if($data->discount_id)
                {
                    $action = '<div class="item-action dropdown">
                                <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                    </svg>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right bg-light" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                    <a class="dropdown-item view" href="#" data-discountid="'.$data->discount_id.'" data-status="1">See detail</a>                                    
                                </div>
                            </div>'; 
                }
                return $action;
            })
            ->addColumn('trnxid', function($data){
                if( $data->sale_status == 1)
                {
                    $trnxid = '<span class="item-amount d-none d-sm-block text-sm text-success text-capitalize">INV-'.$data->sale_trnx_id.'</span>';  
                }
                elseif( $data->sale_status == 0 && !$data->cr_trnx_id && !$data->payment_in_trnx_id && !$data->discount_id)
                {
                    $trnxid = '<span class="item-amount d-none d-sm-block text-sm text-success text-capitalize">OD-'.$data->sale_trnx_id.'</span>';  
                }
                elseif( $data->cr_status == 1 )
                {
                    $trnxid = '<span class="item-amount d-none d-sm-block text-sm text-warning text-capitalize">CRN-'.$data->cr_trnx_id.'</span>';   
                }   
                elseif($data->cr_status == 0 && !$data->sale_trnx_id && !$data->payment_in_trnx_id && !$data->discount_id)
                {
                    $trnxid = '<span class="item-amount d-none d-sm-block text-sm text-warning text-capitalize">CRN-OD-'.$data->cr_trnx_id.'</span>';   
                }
                elseif($data->discount_id)
                {
                   $trnxid = '<span class="item-badge badge text-uppercase bg-danger">DISC-'.$data->discount_id.'</span>';  
                }
                else
                {
                    $trnxid = '<span class="item-amount d-none d-sm-block text-sm text-muted text-capitalize">PAY-IN-'.$data->payment_in_trnx_id.'</span>';   
                }

                return $trnxid;
            })
            ->addColumn('status', function($data){
                if( $data->sale_status == 1)
                {
                    $status = '<span class="item-badge badge text-uppercase bg-success">Order Complete</span>';  
                }
                elseif( $data->sale_status == 0 && !$data->cr_trnx_id && !$data->payment_in_trnx_id && !$data->discount_id)
                {
                    $status = '<a class="item-badge badge text-uppercase bg-secondary convert-to-sale" data-trnxid="'.$data->sale_trnx_id.'" data-date="'.$data->order_date.'">Convert to Sale</a>';
                }
                elseif( $data->cr_status == 1 )
                {
                    $status = '<span class="item-badge badge text-uppercase bg-success">Order Complete</span>';  
                }  
                elseif($data->cr_status == 0 && !$data->sale_trnx_id && !$data->payment_in_trnx_id && !$data->discount_id)
                {
                    $status = '<a class="item-badge badge text-uppercase bg-secondary convert-to-purchase" data-trnxid="'.$data->cr_trnx_id.'" data-date="'.$data->order_date.'">Convert to Purchase</a>';                      
                }
                elseif($data->discount_id)
                {
                    $status = '<span class="item-badge badge text-uppercase bg-danger">Payment Complete</span>';
                }
                else
                {
                    $status = '<span class="item-badge badge text-uppercase bg-success">Payment Complete</span>';
                }
                return $status;
            })
            ->addIndexColumn()    
            ->rawColumns(['action','trnxid','status'])                
            ->make(true); 
        }
        
    }

    public function data_table_product($customer_id)
    {
        $startDate = $_GET['startDate']; 
        $endDate = $_GET['endDate'];

        $sales = Sale::where('sale_order_date', '>=', $startDate)->where('sale_order_date', '<=', $endDate)
                        ->where('sales.sale_status',1)
                        ->where('sales.customer_id',$customer_id)
                        ->leftJoin('products','sales.item_name','=','products.product_id')
                        ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                        ->leftJoin('units','sales.unit_id','=','units.unit_id')
                        ->select(array('sales.*','products.*','units.*','brands.*','sale_order_date as order_date','sale_delivery_date as delivery_date','sale_qty as qty','sale_unit_price as mrp','sale_discount as discount','sale_amount as amount'))
                        ->orderBy('sale_order_date','desc')
                        ->get(); 
        $creditNotes = CreditNote::where('cr_order_date', '>=', $startDate)->where('cr_order_date', '<=', $endDate)
                            ->where('credit_notes.cr_status',1)
                            ->where('credit_notes.customer_id',$customer_id)
                            ->leftJoin('products','credit_notes.item_name','=','products.product_id')
                            ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('units','credit_notes.unit_id','=','units.unit_id')
                            ->select(array('credit_notes.*','products.*','units.*','brands.*','cr_order_date as order_date','cr_delivery_date as delivery_date','cr_qty as qty','cr_unit_price as mrp','cr_amount as amount'))
                            ->orderBy('cr_order_date','desc')
                            ->get();        

        $tableData = $sales->concat($creditNotes)->sortByDesc('order_date');

        if(request()->ajax())
        {
            return datatables()->of($tableData) 
            ->addColumn('action', function($data){                  
                if($data->sale_trnx_id)
                {
                    $action = '<div class="item-action dropdown">
                                <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                    </svg>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right bg-light" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                    <a class="dropdown-item view" href="#" data-saletrnxid="'.$data->sale_trnx_id.'" data-status="'.$data->sale_status.'">See detail</a>                                    
                                </div>
                            </div>'; 
                }
                elseif($data->cr_trnx_id)
                {
                    $action = '<div class="item-action dropdown">
                                <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                    </svg>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right bg-light" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                    <a class="dropdown-item view" href="#" data-crtrnxid="'.$data->cr_trnx_id.'" data-status="'.$data->cr_status.'">See detail</a>                                    
                                </div>
                            </div>'; 
                }
                return $action;
            })
            ->addColumn('product', function($data){
                $product = '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'.$data->product_name.' - '.$data->brand_name.'</span>';  

                return $product;
            })
            ->addColumn('trnxid', function($data){
                if( $data->sale_status == 1)
                {
                    $status = '<span class="item-amount d-none d-sm-block text-sm text-success text-capitalize">INV-'.$data->sale_trnx_id.'</span>';  
                }
                elseif( $data->cr_status == 1 )
                {
                    $status = '<span class="item-amount d-none d-sm-block text-sm text-warning text-capitalize">CRN-'.$data->cr_trnx_id.'</span>';   
                } 

                return $status;
            })
            ->addIndexColumn()    
            ->rawColumns(['action','trnxid','product'])                
            ->make(true); 
        }
        
    }

    public function update(Request $request)
    {
        $customer = Customer::find($request->customer_id);        
        $validator = \Validator::make($request->all(), [
        'f_name' => 'required|max:255',
        's_name' => 'required|max:255',
        'shop_name' => 'required|max:255',
        'phone_1' => ['required','min:10','numeric','regex:/[6-9][0-9]{9}/',
            Rule::unique('customers')->ignore($customer->phone_1,'phone_1'),
        ],
        'email' => ['email','nullable',
            Rule::unique('customers')->ignore($customer->email,'email'),
        ],
        'customer_routes_id' => 'required|not_in:0',
        'customer_type' => 'required|not_in:0',
        'locality' => 'required|max:255',
        'district' => 'required|max:255',
        'pin' => 'required|min:6',
        ],[
            'f_name.required' => 'Please enter first name.',
            's_name.required' => 'Please enter surname.',
            'phone_1.required' => 'Please enter valid phone number.',
            'phone_1.min' => 'Please enter valid phone number.',
            'phone_1.numeric' => 'Please enter valid phone number.',
            'phone_1.regex' => 'Please enter valid phone number.',
            'customer_routes_id.required' => 'Please select route.',
        ]);
        if ($validator->fails())         
        {
            return response()->json(['errors' => $validator->errors()]);
        }

        $customer->f_name = Str::lower($request->f_name);
        $customer->s_name = Str::lower($request->s_name);
        $customer->shop_name = Str::lower($request->shop_name);
        $customer->phone_1 = $request->phone_1;
        $customer->phone_2 = $request->phone_2;
        $customer->whatsapp_no = $request->whatsapp_no;
        $customer->email = Str::lower($request->email);
        $customer->customer_routes_id = $request->customer_routes_id;
        $customer->customer_type = $request->customer_type;
        $customer->locality = Str::lower($request->locality);
        $customer->district = $request->district;
        $customer->state = $request->state;
        $customer->pin = $request->pin;
        $customer->addline_1 = Str::lower($request->addline_1);
        $customer->addline_2 = Str::lower($request->addline_2);               
        $is_saved = $customer->update();
        if($is_saved)
        {
            $routes = CustomerRoute::orderBy('route_name','ASC')->get(); 
            $customers = Customer::orderBy('f_name','ASC')->get(); 
            $success = array('success' => 'Customer updated successfully', 'routes' => $routes, 'customers' => $customers);
            return response()->json($success);
        }        
        
    }

    public function destroy(Request $request)
    {
        $customer = Customer::find($request->id);               
        $sale = Sale::where('customer_id',$request->id)->first();
        if($sale)
        {
            $error = array('error' => "This customer can't be deleted.");
            return response()->json($error);
        }
        else
        {           
            $customer->delete();
            $success = array('success' => 'Customer deleted successfully');
            return response()->json($success);            
        }

    }

    /*
     * Customer Routes all function Strat here
     */
    public function createRoutes(Request $request)
    {
        // $data = $request->all();
        // return $data;Str::ucfirst

        $validator = \Validator::make($request->all(), [
        'route_name' => 'required|max:255|unique:customer_routes,route_name',
        ],[
        'route_name.unique' => 'Already exists',
        ]);
        if ($validator->fails())         
        {
            return response()->json(['errors' => $validator->errors()]);
        }

        $route = new CustomerRoute;
        $route->route_name = Str::ucfirst($request->route_name);
        $is_saved = $route->save();

        if($is_saved)
        {
            $routes = CustomerRoute::orderBy('route_name','ASC')->get(); 
            $success = array('success' => 'Route added successfully' , 'routes' => $routes);
            return response()->json($success);
        }

    }

    public function editRoutes(Request $request)
    {   
        $validator = \Validator::make($request->all(), [
            'route_name' => 'required|max:255|unique:customer_routes,route_name',
        ],[
            'route_name.unique' => 'Already exists',
        ]);
        if ($validator->fails())         
        {
            return response()->json(['errors' => $validator->errors()]);
        }

        $route = CustomerRoute::find($request->customer_routes_id);

        $route->route_name = $request->route_name;
        $is_saved = $route->update();

        if($is_saved)
        {
            $routes = CustomerRoute::orderBy('route_name','ASC')->get(); 
            $success = array('success' => 'Route added successfully' , 'routes' => $routes);
            return response()->json($success);
        }

    }

}
