<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Purchase;
use App\Models\Portal\Product;
use App\Models\Portal\Unit;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;

class PurchaseController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {  
        
        // return response()->json($allPurchaseBill);
        if(request()->ajax())
        {
            $startDate = $_GET['startDate']; 
            $endDate = $_GET['endDate'];
            $purchaseUnique = Purchase::where('order_date', '>=', $startDate)
                                ->where('order_date', '<=', $endDate)
                                ->leftJoin('products','purchases.item_name','=','products.product_id')
                                ->leftJoin('units', 'purchases.unit_id','=','units.unit_id') 
                                ->leftJoin('suppliers','purchases.supplier_id','=','suppliers.supplier_id')
                                ->select(array('purchases.balance as PO_balance','purchases.*','products.*','units.*','suppliers.*'))
                                ->orderBy('purchase_id','desc')
                                ->where('purchases.status',1)
                                ->get()->unique('po_id'); 
            return datatables()->of($purchaseUnique)
                ->editColumn('date', function ($data) {
                    return date('d-m-Y', strtotime($data->date));
                })
                ->addColumn('action', function($data){
                    $button = '<button type="button" id="'.$data->po_id.'" data-date="'.$data->date.'" class="view btn btn-outline-info  btn-sm">View</button>';
                    $button .= '&nbsp;';                  
                    return $button;
                })
                ->addColumn('status', function($data){                  
                    $status = '<span class="item-badge badge text-uppercase bg-success">Order Complete</span>';  
                    return $status;
                })
                ->addIndexColumn()
                ->rawColumns(['action' , 'status'])                
                ->make(true); 
        } 
        else{   
            $allPurchase = Purchase::leftJoin('products','purchases.item_name','=','products.product_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units', 'purchases.unit_id','=','units.unit_id') 
                                ->leftJoin('suppliers','purchases.supplier_id','=','suppliers.supplier_id')
                                ->select(array('purchases.balance as PO_balance','purchases.*','products.*','units.*','suppliers.*','brands.*'))
                                ->orderBy('purchase_id','asc')
                                ->where('purchases.status',1)
                                ->get();         
            return view('portal.purchase.index',['allPurchase' => $allPurchase]);
        }    
    }

    public function dateRange()
    {
        $startDate = $_GET['startDate']; 
        $endDate = $_GET['endDate'];
        // $x = Carbon::now()->subDays(30);
        $purchases = Purchase::where('order_date', '>=', $startDate)->where('order_date', '<=', $endDate)->where('status',1)->get()->unique('po_id');     
        $total = 0;
        foreach ($purchases as $purchase) {
            $total = $total+ $purchase->total;
        }
        return response()->json($total);
    }
}
