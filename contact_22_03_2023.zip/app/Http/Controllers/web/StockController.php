<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Product;
use App\Models\Portal\Stock;
use App\Models\Portal\Brand;
use App\Models\Portal\Unit;
use App\Models\Portal\ProductionCost;
use App\Models\Portal\Supplier;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;


class StockController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {    	
        $products = Product::join('brands','products.brand_id','brands.brand_id')
                            ->orderBy('in_hand_stock_primary', 'desc')
                            ->get();  
        $stocks = Stock::leftJoin('products','stocks.item_name','products.product_id')
                        ->leftJoin('units','stocks.unit_id','units.unit_id')
                        ->leftJoin('customers','stocks.customer_id','customers.customer_id')
                        ->leftJoin('suppliers','stocks.supplier_id','=','suppliers.supplier_id')
                        ->select(array('stocks.*','products.*','units.*','suppliers.*','customers.*'))
                        ->latest('stocks.created_at','asc')->get();            
        return view('portal.stock.index',['products' => $products, 'stocks' => $stocks ]);        
    }

}
