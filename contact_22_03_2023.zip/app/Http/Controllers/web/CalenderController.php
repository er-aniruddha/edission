<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use App\Models\Portal\RoutePlan;
use Illuminate\Http\Request;

class CalenderController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index(Request $request)
    {
    	if($request->ajax())
    	{
    		$data = RoutePlan::all();
        	return response()->json($data);
    	}
    	
    	return view('portal.calender.index');
    }
}
