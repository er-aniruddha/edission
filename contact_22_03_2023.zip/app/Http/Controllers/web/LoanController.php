<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\LoanAccount;
use Illuminate\Support\Str;
use Validator;
use Carbon\Carbon;

class LoanController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $loanaccounts = LoanAccount::orderBy('date','asc')->get();
        return view('portal.loan.index',['loanaccounts' => $loanaccounts]);
    }

    public function compute(Request $request)
    {
         if(request()->ajax())
        {
            if($request->date)
            {
              $date = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
              $validator_date = \Validator::make($date, [
                'date' => 'required|date|before:tomorrow',         
              ],[
                  'date.before' => 'The date mustbe today or before.',
                  'date.unique' => 'Can not add two item on same date',
              ]);
              if ($validator_date->fails())         
              {
                return response()->json(['errors' => $validator_date->errors()]);
              }
            }

            $validator = \Validator::make($request->all(), [
              'date' => 'required|date|before:tomorrow',         
              'account_name' => 'required',
              'loan_amount' => 'required|numeric',
              'interest_rate' => 'required|numeric',
              'year' => 'required|integer',
              'month' => 'required|integer|not_in:0',
            ],[
                'date.before' => 'The date mustbe today or before.',
                'month.required' => 'The tenure field is required.',
                'month.not_in' => 'The tenure field is required.',
            ]);
            if ($validator->fails())         
            {
              return response()->json(['errors' => $validator->errors()]);
            }

            if($validator->passes())
            {
                $principal = $request->loan_amount; 
                $eRate = $request->interest_rate / (12*100);
                $time = $request->month;                 
      
                $emi = ($principal * $eRate * pow(1 + $eRate, $time)) / 
                  (pow(1 + $eRate, $time) - 1);

                $startDate = $request->date;
                
                $totalInt = 0;
                $totalPayment = 0;
                for($i=0; $i < $time; $i++)
                {
                    $principalPaid = $emi - ($principal * $eRate);
                    $monthlyInt = $principal * $eRate;
                    $principalPaid = $emi - $monthlyInt;
                    $endingBal = $principal - $principalPaid;
                    $paymentMonth = Carbon::createFromFormat('d-m-Y', $request->date)->addMonth($i+1);

                    $billDate = Carbon::createFromFormat('d-m-Y', $request->date)->endOfMonth();
                    $paymentDate = Carbon::createFromFormat('d-m-Y', $request->date)->endOfMonth();

                    
                    $totalInt = $totalInt + $monthlyInt;
                    $totalPayment = $totalPayment + $emi;

                    $loanTableData[$i] = array(
                        'month'=> $i+1,
                        'billDate' => $billDate->addDay(1),
                        'paymentDate'=> $paymentDate->addDay(10),
                        'interest'=>number_format($monthlyInt,2,'.',','),
                        'principalPaid'=> number_format($principalPaid,2,'.',','),
                        'totalPayment'=> number_format($emi,2,'.',','),
                        'endingBalance'=> number_format($endingBal,2,'.',','),
                    );
                    $principal = $endingBal;
                }

                $success = array('accountName' => $request->account_name,'loanAmount' => $request->loan_amount,'intRate' => $request->interest_rate,'month' => $request->month,'startDate' => $request->date, 'emi' => $emi,'totalInt' => $totalInt,'totalPayment' => $totalPayment,'loanTableData' => $loanTableData);

                return response()->json($success);
            }
            
        }
    }
    public function create(Request $request)
    {
        $uuid = Str::uuid();
        if(request()->ajax())
        {
            if($request->date)
            {
              $date = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
              $validator_date = \Validator::make($date, [
                'date' => 'required|date|before:tomorrow',         
              ],[
                  'date.before' => 'The date mustbe today or before.',
                  'date.unique' => 'Can not add two item on same date',
              ]);
              if ($validator_date->fails())         
              {
                return response()->json(['errors' => $validator_date->errors()]);
              }
            }

            $validator = \Validator::make($request->all(), [
              'date' => 'required|date|before:tomorrow',         
              'account_name' => 'required',
              'loan_amount' => 'required|numeric',
              'interest_rate' => 'required|numeric',
              'year' => 'required|integer',
              'month' => 'required|integer|not_in:0',
            ],[
                'date.before' => 'The date mustbe today or before.',
                'month.required' => 'The tenure field is required.',
                'month.not_in' => 'The tenure field is required.',
            ]);
            if ($validator->fails())         
            {
              return response()->json(['errors' => $validator->errors()]);
            }

            if($validator->passes())
            {
                $loan = new LoanAccount;
                $loan->loan_ac_id = $uuid;
                $loan->account_name = Str::lower($request->account_name);
                $loan->loan_amount = $request->loan_amount;
                $loan->interest_rate = $request->interest_rate;
                $loan->year = $request->year;
                $loan->month = $request->month;
                $loan->loan_balance = $request->loan_amount;
                $loan->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
                $loan->remarks = $request->remarks;
                $is_save = $loan->save();

                // $bankTrns = new BankTransaction;
                // $bankTrns->bank_trnx_id = "BT-".(8000000000+strtotime("now"));
                // $bankTrns->baccount_id = $uuid;
                // $bankTrns->trnx_type = 0;
                // $bankTrns->amount = $request->opening_balance;
                // $bankTrns->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
                // $bankTrns->remarks = $request->remarks;
                // $is_save = $bankTrns->save();

                $loanaccounts = LoanAccount::orderBy('date','asc')->get();
                $success = array('success' => 'Loan account created successfully.','loanaccounts'=> $loanaccounts);
                return response()->json($success);
            }
            
        }
    }
}
