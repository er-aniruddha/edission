<div id="content" class="flex">
    <!-- ############ Main START-->
    <div class="page-content page-container" id="page-content">
        <div class="padding">
            <div class="row row-sm sr">
                <div class="col-md-12 col-lg-12">
                    <div class="row row-sm">
                        <div class="col-md-4 d-flex" style="width: 50%;">
                            <div class="card flex card-home" data-url="<?php echo e(route('brand.index')); ?>">
                                <div class="card-body text-center">
                                    <div style="margin: 10px;">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="32px" height="32px" style="color:rgb(68, 139, 255);" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
                                    </div>
                                    <span class="text-dark mr-2">Brand</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex" style="width: 50%;">
                            <div class="card flex card-home" data-url="<?php echo e(route('product.list')); ?>">
                                <div class="card-body text-center">
                                    <div style="margin: 10px;">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="32px" height="32px" style="color:rgb(68, 139, 255);" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-list mx-2"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3" y2="6"></line><line x1="3" y1="12" x2="3" y2="12"></line><line x1="3" y1="18" x2="3" y2="18"></line></svg>
                                    </div>
                                    <span class="text-dark mr-2">Products</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex" style="width: 50%;">
                            <div class="card flex card-home" data-url="<?php echo e(route('sku.index')); ?>">
                                <div class="card-body text-center">
                                    <div style="margin: 10px;">
                                       <svg xmlns="http://www.w3.org/2000/svg" width="32px" height="32px" style="color:rgb(68, 139, 255);" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg>
                                    </div>
                                    <span class="text-dark mr-2">SKU</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex" style="width: 50%;">
                            <div class="card flex card-home" data-url="#">
                                <div class="card-body text-center">
                                    <div style="margin: 10px;">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="32px" height="32px" style="color:rgb(68, 139, 255);" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-dollar-sign"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                                    </div>
                                    <span class="text-dark mr-2">Production Cost</span>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ############ Main END-->
</div>
<script>
    $(document).ready(function (){

       $(document).on('click','.card-home',function(){
          window.location.href = $(this).data('url')
       })
    });
</script><?php /**PATH C:\xampp\htdocs\contact\resources\views/portal/product/admin/index.blade.php ENDPATH**/ ?>