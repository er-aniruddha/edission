<form id="newSkuAddForm">
    <?php echo csrf_field(); ?>
    <div id="newModal" class="modal fade modal-open-aside show" data-backdrop="true" style="display: none; padding-right: 17px;" aria-hidden="true" data-class="modal-open-aside">
        <div class="modal-dialog modal-right w-xl">
            <div class="modal-content h-100 no-radius">
                <div class="modal-header">
                    <div class="modal-title text-md">Add Stock</div>
                    <button class="close" data-dismiss="modal">×</button>
                </div>
                <div class="modal-body">
                    <div class="row row-sm">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="text-muted">Product Name</label>
                                <select class="form-control select2" name="product_id" id="product_id" tabindex="-1" aria-hidden="true" required="">
                                    <option selected="" value="">Select an option</option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product->product_id); ?>" >
                                        <?php echo e($product->product_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger mr-2" id="product_id_error"></span>
                            </div>
                            <div class="form-group">
                                <label class="text-muted">Maker</label>
                                <select class="form-control select2" id="maker_name" name="maker_name" required="" tabindex="-1" aria-hidden="true" required="">
                                    <option selected="" value="0">Select an option</option>
                                    <option value="OWN">OWN</option>
                                </select>
                                <span class="text-danger mr-2" id="maker_name_error"></span>
                            </div>
                            <div class="form-group">
                                <label class="text-muted">Date</label>
                                <input type="text" class="form-control date" data-provide="datepicker" id="date" name="date" value="" required="">
                                <span class="text-danger mr-2" id="date_error"></span>
                            </div>
                            <div class="form-group">
                                <label class="text-muted">SKU Code</label>
                                <input type="text" class="form-control" value="" id="sku_code" name="sku_code" readonly="">
                                <span class="text-danger mr-2" id="sku_code_error"></span>
                            </div>
                            <div class="form-group">
                                <label class="text-muted">Cost</label>
                                <select class="form-control select2" name="cost_id" id="cost_id" tabindex="-1" aria-hidden="true" required="">
                                    <option selected="" value="">Select an option</option>
                                    <?php $__currentLoopData = $costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
                                        <?php if($cost->cost_stat == 1): ?>
                                            <option value="<?php echo e($cost->cost_id); ?>"><?php echo e($cost->cost_name); ?> / INR - <?php echo e($cost->cost_total); ?></option> 
                                        <?php else: ?>
                                            <option value="<?php echo e($cost->cost_id); ?>" disabled=""><?php echo e($cost->cost_name); ?> / INR - <?php echo e($cost->cost_total); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger mr-2" id="cost_id_error"></span>
                            </div>
                            <div class="form-group">
                                <label class="text-muted">Quantity</label>
                                <input type="number" class="form-control" value="" id="sku_qty" name="sku_qty" placeholder="Enter stock quantity"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                <span class="text-danger mr-2" id="stock_qty_error"></span>
                            </div>
                            <div class="form-group">
                                <label class="text-muted">Publication Status</label>
                                <label class="ui-switch ui-switch-md info m-t-xs" style="top:5px;">
                                    <input type="checkbox" id="checkbox"> <i></i>
                                    <input type="hidden" name="stock_stat" id="stock_stat" value="0">
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-dark" data-dismiss="modal">Close</button>
                    <button class="btn btn-primary" id="addBtn">Save Changes</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
    </div>
</form>
<script>
    $(document).ready(function(){
        /* This part for HTML */
        $('input[type="checkbox"]').click(function(event) {
            /* Act on the event */
            if($('#checkbox').is(':checked')){
                $("#stock_stat").val(1)
            }
            else{
                $("#stock_stat").val(0)
            }
        })//set publication status 
    })
</script><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/stock/newModal.blade.php ENDPATH**/ ?>