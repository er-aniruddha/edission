<div id="content" class="flex">
    <!-- ############ Main START-->
    <div class="d-flex flex fixed-content">
        <?php echo $__env->make('portal.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="d-flex flex" id="content-body">
            <div class="d-flex flex-column flex" id="user-list">
                <div class="p-3">
                    <div class="toolbar">
                        <div class="btn-group">
                            <a  href="<?php echo e(route('customer.create')); ?>" class="btn btn-raised btn-wave blue text-white" data-toggle="tooltip" 
                            data-original-title="Add Customer">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user-plus mx-2">
                                <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                <circle cx="8.5" cy="7" r="4"></circle>
                                <line x1="20" y1="8" x2="20" y2="14"></line>
                                <line x1="23" y1="11" x2="17" y2="11"></line>
                            </svg>    
                        </a>

                    </div>

                    <form class="flex">
                        <div class="input-group">
                            <input type="text" class="form-control form-control-theme form-control-sm search"
                            placeholder="Search" id="searchUser">

                            <span class="input-group-append">
                                <button class="btn btn-white no-border btn-sm" type="button">
                                    <span class="d-flex text-muted">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round"
                                        class="feather feather-search">
                                        <circle cx="11" cy="11" r="8"></circle>
                                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                    </svg>
                                </span>
                            </button>
                        </span>
                    </div>
                </form>
                <button data-toggle="modal" data-target="#content-aside" data-modal=""
                class="btn btn-sm btn-icon btn-white d-md-none">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                stroke-linejoin="round" class="feather feather-menu">
                <line x1="3" y1="12" x2="21" y2="12"></line>
                <line x1="3" y1="6" x2="21" y2="6"></line>
                <line x1="3" y1="18" x2="21" y2="18"></line>
            </svg>
        </button>
    </div>
</div>
<!-- User List Start -->
<div class="scroll-y mx-3 mb-0 card">
    <div class="list list-row" id="userList">

        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="list-item" data-id="7" data-sr-id="2"
        style="visibility: visible; transform: none; opacity: 1; transition: transform 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0s, opacity 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0s;">
            <div>
                <label class="ui-check m-0">
                    <input type="checkbox" name="id" value="3">
                    <i></i>
                </label>
            </div>
            <div>
                <a href="#" data-toggle-class="">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                        fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round"
                        class="feather feather-bookmark active-primary text-muted">
                        <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
                    </svg>
                </a>
            </div>
            <div class="flex">
                <a href="<?php echo e(route('customer.details',$customer->customer_id)); ?>" class="item-author"><?php echo e($customer->shop_name); ?> 
                    <span class="text-dark mr-2">(<?php echo e($customer->f_name); ?> <?php echo e($customer->s_name); ?>)</span>
                </a>
                <div class="item-mail text-muted h-1x d-none d-sm-block"><?php echo e($customer->phone_1); ?></div> 
                <div style="display: none;"><?php echo e($customer->route_name); ?></div>
            </div>
            <div class="item-action dropdown">
                <a href="#" data-toggle="dropdown" class="text-muted">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                    viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                    stroke-linecap="round" stroke-linejoin="round"
                    class="feather feather-more-vertical">
                    <circle cx="12" cy="12" r="1"></circle>
                    <circle cx="12" cy="5" r="1"></circle>
                    <circle cx="12" cy="19" r="1"></circle>
                    </svg>
                </a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="no-result" style="display: none;">
    <div class="p-4 text-center">No Results</div>
</div>
</div>
  </div>
</div>
</div><!-- ############ Main END-->
</div>

<form id="permissionForm" method="POST">
    <?php echo csrf_field(); ?>
    <div id="uPermisiionModal" class="modal fade show" data-backdrop="true" style="display: none; padding-right: 17px;"
    aria-modal="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title text-md">Chnage User Permission</div><button class="close"
                data-dismiss="modal">×</button>
            </div>
            <div class="modal-body">
                <div class="p-4 text-center">
                    <div id="nameModal"></div>
                    <div class="form-group row">
                        <label for="user_permission" class="col-sm-4 col-form-label"> Chnage Permission</label>
                        <div class="col-sm-8">
                            <select class="custom-select" id="user_permission" name="user_permission">
                                <option value="1">Admin</option>
                                <option value="2">User</option>
                                <option value="0">Blocked</option>
                            </select>
                            <div class="errorSelect"></div>
                        </div>
                    </div>
                </div>
                <input type="hidden" name="user_id" id="user_id">
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-light"
                data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" id="saveBtn">Save Changes</button>
            </div>
        </div><!-- /.modal-content -->
    </div>
</div>
</form>
<?php echo $__env->make('portal.layouts.deleteModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(function () {        
        $("#searchUser").on("keyup", function () {

            $(this).attr("placeholder", "Search");

            var value = $(this).val().toLowerCase();

            $("#userList .list-item").filter(function () {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1) //this to show if there is value

                //$(".no-result").toggle($(this).text().toLowerCase().indexOf(value) === -1) //if no values then show this div
            });
        });//search function end here

        /* Edit User Permission Modal Start*/
        $(document).on('click', '.editUser', function () {
            let name = $(this).data('name');
            let permission = $(this).data('userpermission');
            $("select").val(permission);
            $("#user_id").val($(this).data('id'))
            $("#nameModal").html('<div class="form-group row ">'
                + '<label class="col-sm-4 col-form-label"> Name</label>'
                + '<div class="col-sm-8">'
                + '<p>' + name + '</p>'
                + '</div>'
                + '</div>');

            $("#uPermisiionModal").modal('show')
        })//edit User Permission Modal End here

        /* Edit User Permission Submit Form Start*/
        $("#permissionForm").on('click', '#saveBtn', function (event) {
            console.log("clic")
            event.preventDefault()
            let postData = new FormData($('#permissionForm')[0])
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('user.permission.chnage')); ?>",
                contentType: false,
                cache: false,
                processData: false,
                dataType: "json",
                data: postData,
                success: function (response) {
                    if (response.errors) {
                        $(".errorSelect").append('<p class="text-danger">' + response.errors.user_permission[0] + '</p>')
                    }
                    if (response.success) {
                        $("#uPermisiionModal").modal('hide')
                        let message = response.success;
                        success(message);
                        $("#permissionForm")[0].reset();
                        $("#userList").load(window.location + " #userList");
                    }
                },//ajax success end
                error: function (error) {
                    if (error.status == 500) {
                        let message = "Something went wrong !!"
                        danger(message)
                    }
                }//ajax error end
            })//ajax end 
        })// Edit User Permission Submit Form Function End

        /*Product Remove Start*/
        $(document).on('click', '.trash', function (event) {
            event.preventDefault()
            let id = $(this).data("id");
            let name = $(this).data("name");
            $("#del_id").val(id);
            $(".modal-title").text(name);
        })//Product Remove ID valuye set to modal

        /*User Delete Function Start */
        $("#proDelForm").on('click', "#delProBtn", function (event) {
            event.preventDefault()
            console.log($("#product_id").val())
            let formData = new FormData($("#proDelForm")[0])
            $.ajax({
                method: 'POST',
                url: "<?php echo e(route('user.remove')); ?>",
                contentType: false,
                cache: false,
                processData: false,
                dataType: "json",
                data: formData,
                beforeSend: function () {
                    $('#delProBtn').text('Deleting...');
                },
                success: function (response) {
                    if (response.success) {
                        let message = response.success;
                        warning(message);
                        $("#proDelForm")[0].reset();
                        $('#delProBtn').text('Delete');
                        $("#userList").load(window.location + " #userList");
                    }
                },//ajax success end
                error: function (error) {
                    $('#delProBtn').text('Delete');
                    if (error.status == 500) {
                        let message = "Something went wrong !!"
                        danger(message)
                    }
                }//ajax error end
            })//ajax end
        })//User delete function end here


    })
</script><?php /**PATH C:\xampp\htdocs\contact\resources\views/portal/customer/admin/index.blade.php ENDPATH**/ ?>