<div id="editModal" class="modal fade" aria-modal="true" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog text-dark modal-lg" style="max-width: 95%;">
        <div class="modal-content">
            <form id="editCustomerForm">
                <?php echo csrf_field(); ?>
                <div class="modal-header bg-primary">
                    <h5 class="modal-title text-white">Edit Customer</h5>
                </div>
                <div class="modal-body p-4">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="md-form-group float-label">
                                    <input type="text" class="md-input text-capitalize" value="" name="f_name" id="f_name" onkeyup="this.setAttribute('value', this.value);" required=""><label>First Name *</label>
                                    <span class="text-danger mr-2" id="f_name_error"></span>
                                </div>
                                <div class="md-form-group float-label">
                                    <input type="text" class="md-input text-capitalize" value="" name="s_name" id="s_name" onkeyup="this.setAttribute('value', this.value);" required=""><label>Last Name*</label>
                                    <span class="text-danger mr-2" id="s_name_error"></span>
                                </div>
                                <div class="md-form-group float-label">
                                    <input type="text" class="md-input text-capitalize" value="" name="shop_name" id="shop_name" onkeyup="this.setAttribute('value', this.value);" required=""><label>Shop Name *</label>
                                    <span class="text-danger mr-2" id="shop_name_error"></span>
                                </div>
                                <div class="md-form-group float-label">
                                    <input type="number" class="md-input" value="" name="phone_1" id="phone_1" onkeyup="this.setAttribute('value', this.value);" required="" onkeypress="if(this.value.length==10) return false;"><label>Phone 1 *</label>
                                    <span class="text-danger mr-2" id="phone_1_error"></span>
                                </div>
                                <div class="md-form-group float-label">
                                    <input type="number" class="md-input" value="" name="phone_2" id="phone_2" onkeyup="this.setAttribute('value', this.value);" required="" onkeypress="if(this.value.length==10) return false;"><label>Phone 2</label>
                                    <span class="text-danger mr-2" id="phone_2_error"></span>
                                </div>
                                <div class="md-form-group float-label">
                                    <input type="number" class="md-input" value="" name="whatsapp_no" id="whatsappno" onkeyup="this.setAttribute('value', this.value);" required=""><label>Whats App</label>
                                    <span class="text-danger mr-2" id="whatsapp_no_error"></span>
                                </div>
                                <div class="md-form-group float-label">
                                    <input type="email" class="md-input" value="" name="email" id="email" onkeyup="this.setAttribute('value', this.value);" required=""><label>E-mail ID</label>
                                    <span class="text-danger mr-2" id="email_error"></span>
                                </div>
                            </div><!-- div col-md-6 -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="text-muted">Type of Customer</label>
                                    <select class="form-control select2" name="customer_type" id="customer_type" tabindex="-1" aria-hidden="true">
                                        <option value="0" selected>Select Type</option>
                                        <option value="1">Retail</option>
                                        <option value="2">Distributor</option>
                                    </select>
                                    <span class="text-danger mr-2" id="customer_type_error"></span>
                                </div>
                                <div class="form-group">
                                    <label class="text-muted">Routes</label>
                                    <select class="form-control select2" name="customer_routes_id" id="route" tabindex="-1" aria-hidden="true">
                                        <option value="" selected>Select Route</option>
                                        <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($route->customer_routes_id); ?>"><?php echo e($route->route_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="text-danger mr-2" id="route_error"></span>
                                </div>
                                <div class="md-form-group float-label">
                                    <input type="text" class="md-input text-capitalize" value="" name="locality" id="locality" onkeyup="this.setAttribute('value', this.value);" required=""><label>Locality *</label>
                                    <span class="text-danger mr-2" id="locality_error"></span>
                                </div>
                                <div class="form-group">
                                    <label class="text-muted">District</label>
                                    <select class="form-control select2 text-capitalize" name="district" id="district" tabindex="-1" aria-hidden="true">
                                        <option value="" selected>Select District</option>
                                        <optgroup label="West Bengal">
                                            <option value="North 24 Parganas">North 24 Parganas</option>
                                            <option value="Nadia">Nadia</option>
                                        </optgroup>
                                    </select>
                                    <span class="text-danger mr-2" id="district_error"></span>
                                </div>
                                <div class="md-form-group float-label">
                                    <input type="number" class="md-input" value="" name="pin" id="pin" onkeyup="this.setAttribute('value', this.value);" required="" onKeyPress="if(this.value.length==6) return false;"><label>PIN *</label>
                                    <span class="text-danger mr-2" id="pin_error"></span>
                                </div>
                                <div class="md-form-group float-label">
                                    <input type="text" class="md-input text-capitalize" value="West Bengal" name="state" id="state" onkeyup="this.setAttribute('value', this.value);" readonly><label>State *</label>
                                </div>
                                <div class="md-form-group float-label">
                                    <input type="text" class="md-input text-capitalize" value="" name="addline_1" id="addline_1" onkeyup="this.setAttribute('value', this.value);" required="" formnovalidate>
                                    <label>Address 1</label>
                                    <span class="text-danger mr-2" id="addline_1_error"></span>
                                </div>
                                <div class="md-form-group float-label">
                                    <input type="text" class="md-input text-capitalize" value="" name="addline_2" id="addline_2" onkeyup="this.setAttribute('value', this.value);" required><label>Address 2</label>
                                    <span class="text-danger mr-2" id="addline_2_error"></span>
                                </div>
                            </div> <!-- div col-md-6 -->
                        </div><!-- row -->
                    </div>
                    <div class="dropdown-divider"></div>
                    <div class="modal-footer">
                        <input type="hidden" name="customer_id" id="edit_customer_id" value="">
                        <button type="button" class="btn btn-outline-dark" data-dismiss="modal">Close</button>
                        <button class="btn btn-primary" id="editBtn">Update</button>
                    </div>
            </form>
        </div>
    </div>
    <!-- /.modal-content -->
</div>
</div><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/customer/editModal.blade.php ENDPATH**/ ?>