<!-- Sidebar START-->
<div id="aside" class="page-sidenav no-shrink bg-light nav-dropdown fade sticky" aria-hidden="true" data-class="bg-light">
	<div class="sidenav h-100 modal-dialog bg-light">
		<!-- sidenav top -->
		<div class="navbar">
			<!-- brand -->
			<a href="<?php echo e(route('dashboard')); ?>" class="navbar-brand" data-pjax-state="">
				<img src="<?php echo e(asset('public/portal/images/logo.png')); ?>" alt="...">
			</a>
		<!-- / brand -->
	</div>
	<!-- Flex nav content -->
	<div class="flex scrollable hover">
		<div class="nav-stacked nav-active-primary auto-nav" data-nav="">
			<ul class="nav bg">
				<li class="nav-header hidden-folded">
                    <span class="text-muted"></span>
                </li>

				<li class="<?php echo e(Route::is('dashboard') ? 'active' : null); ?>">
					<a href="<?php echo e(route('dashboard')); ?>" data-pjax-state="load">
						<span class="nav-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather eather-home">
								<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
								<polyline points="9 22 9 12 15 12 15 22"></polyline>
							</svg>
						</span> 
						<span class="nav-text">Dashboard</span>
					</a>
				</li>
				
				<li class="<?php echo e(Route::is('product.index') || Route::is('product.create') ? 'active' : null); ?>">
					<a href="<?php echo e(route('product.index')); ?>" data-pjax-state="load">
						<span class="nav-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-package mx-2"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line><line x1="7" y1="3.5" x2="17" y2="8.5"></line></svg>
						</span> 
						<span class="nav-text">Product</span>
					</a>
				</li>
				<li class="<?php echo e(Route::is('user.index') ? 'active' : null); ?>">
					<a href="<?php echo e(route('user.index')); ?>" data-pjax-state="load">
						<span class="nav-icon text-success">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
							</svg>
						</span> 
						<span class="nav-text">Users</span>
					</a>
				</li>
			</ul>

		</div>
	</div>
	<!-- sidenav bottom -->
</div>
</div>
    <!-- Sidebar END--><?php /**PATH C:\xampp\htdocs\anwesh\portal\resources\views/portal/layouts/sidebar.blade.php ENDPATH**/ ?>