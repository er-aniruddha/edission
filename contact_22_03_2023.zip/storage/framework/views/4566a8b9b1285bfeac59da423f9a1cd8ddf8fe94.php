<!-- Confirm modal -->
<form method="POST" id="confirmform">
    <?php echo csrf_field(); ?>
<div id="confirmModal" class="modal fade"  aria-modal="true" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header red">
                <div class="modal-title text-md text-capitalize"></div><button class="close" data-dismiss="modal">×</button></div>
            <div class="modal-body">
                <div class="p-4 text-center">
                    <p>Are you sure you want to remove this data?</p>
                </div>
            </div>
             <input type="hidden" name="id" id="id">
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-danger" id="ok_button">OK</button></div>
        </div>
        <!-- /.modal-content -->
    </div>
</div>
</form>
<!-- Confirm modal -->


   <?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/layouts/deleteModal.blade.php ENDPATH**/ ?>