<snackbar></snackbar>
<script src="<?php echo e(asset('public/portal/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/portal/js/parsley.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/portal/js/list.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/portal/js/user.js')); ?>"></script>
<!-- DataTables JavaScript -->
<script type="text/javascript" src="<?php echo e(asset('public/portal/dataTables/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/portal/dataTables/dataTables.bootstrap4.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/portal/dataTables/dataTables.buttons.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/portal/dataTables/jszip.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/portal/dataTables/pdfmake.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/portal/dataTables/vfs_fonts.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/portal/dataTables/buttons.html5.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/portal/dataTables/buttons.print.min.js')); ?>"></script>
<!-- <script type="text/javascript" src="https://cdn.datatables.net/plug-ins/1.10.24/filtering/row-based/range_dates.js"></script> -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/list.js/1.5.0/list.min.js"></script> -->
<!-- Select2 JavaScript -->
<script type="text/javascript" src="<?php echo e(asset('public/portal/js/select2.min.js')); ?>"></script>
<!-- Datepicker JavaScript -->
<script type="text/javascript" src="<?php echo e(asset('public/portal/js/bootstrap-datepicker.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/portal/js/moment.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/portal/js/daterangepicker.min.js')); ?>"></script>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.js"></script> -->
<script type="text/javascript" src="<?php echo e(asset('public/portal/js/moment-with-locales.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/portal/js/fullcalendar.min.js')); ?>"></script>
<script>
    // In your Javascript (external .js resource or <script> tag)
    $("#image").change(function() {
        readURL(this);
    });

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#show-img').attr('src', e.target.result);
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
    //showing successfull message
    function snacbar(data) {
        let message = data;
        let snackbar = new SnackBar;
        snackbar.make("message",
            [
                data,
                null,
                "bottom",
                "center"
            ], 5000);
    }
    /* Date Picker Start*/
    $('.date').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
        width: "100%",
        endDate: "0d",
        todayHighlight: true,
    })
    /* Date Picker End*/

    $('form').on('focus', 'input[type=number]', function(e) {
        $(this).on('wheel.disableScroll', function(e) {
            e.preventDefault()
        })
    })
    
    /*------- Multi Decimal Input Check -------*/
    $('.number').keypress(function(event){        
        var $this = $(this);
        if ((event.which != 46 || $this.val().indexOf('.') != -1) &&
           ((event.which < 48 || event.which > 57) &&
           (event.which != 0 && event.which != 8))) {
               event.preventDefault();
        }
        var text = $(this).val();
        if ((event.which == 46) && (text.indexOf('.') == -1)) {
            setTimeout(function() {
                if ($this.val().substring($this.val().indexOf('.')).length > 3) {
                    $this.val($this.val().substring(0, $this.val().indexOf('.') + 3));
                }
            }, 1);
        }

        if ((text.indexOf('.') != -1) &&
            (text.substring(text.indexOf('.')).length > 2) &&
            (event.which != 0 && event.which != 8) &&
            ($(this)[0].selectionStart >= text.length - 2)) {
                event.preventDefault();
        }     
    })
    $('.number').bind("paste", function(e) {
        var text = e.originalEvent.clipboardData.getData('Text');
        if ($.isNumeric(text)) {
            if ((text.substring(text.indexOf('.')).length > 3) && (text.indexOf('.') > -1)) {
                e.preventDefault();
                $(this).val(text.substring(0, text.indexOf('.') + 3));
           }
        }
        else{
            e.preventDefault();
        }
    });
    /*------- Multi Decimal Input Check -------*/
    var startDate,endDate
    startDate = moment().subtract(1,'year')
    endDate = moment();

    function cb(start, end) {
        startDate = start
        endDate = end
        $(this).val(start.format('DD-MM-YYYY') + ' - ' + end.format('DD-MM-YYYY'));       
    }

    $('.date-range').daterangepicker({
        startDate: startDate,
        endDate: endDate,
        locale: {
            format: 'DD-MM-YYYY',
            separator: " to "
        },
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
           'This Month': [moment().startOf('month'), moment().endOf('month')],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb);

    cb(startDate, endDate);
    

</script>

<script type="text/javascript">
    $(document).ready(function(){
         $("#loader").hide()
    })
</script>
</body>

</html><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/layouts/footer.blade.php ENDPATH**/ ?>