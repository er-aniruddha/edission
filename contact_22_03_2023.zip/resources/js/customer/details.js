$(document).ready(function(){
    var trnxDataTable
    
    load_product_wise_table(startDate,endDate);
    load_bill_table(startDate,endDate);
	/*-------- Sales DataTable Start Here --------*/  
    function load_bill_table(startDate, endDate){
        trnxDataTable = $("#sale_table").DataTable({
            processing: true,
            responsive: true,
            serverSide: true,
            lengthMenu: [
                [10, 25, 50, -1],
                [10, 25, 50, 'All'],
            ],
            buttons: [
                { extend: 'excel', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7,8,9,10]},title: function(){ return getExportTitle()},filename: function(){ return getExportFileName()}},
                { extend: 'pdf', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7,8,9,10 ]},title: function(){ return getExportTitle()},filename: function(){ return getExportFileName()}},
                
            ],
            ajax: {
                url: routes.table_bill,
                dataType: "json",
                data:{ startDate: startDate.format('YYYY-MM-DD'), endDate: endDate.format('YYYY-MM-DD')},
            },
            columns: [{
                data: "DT_RowIndex",
                name: "DT_RowIndex",
                render: function(data){
                    return '<small class="text-muted">'+data+'</small>'
                }
                }, {
                    data: "order_date",
                    name: "order_date",
                    render: function(data, type, full, meta) {
                        return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+moment(data).format('DD-MM-YYYY')+'</span>'
                    },      
                }, {
                    data: "delivery_date",
                    name: "delivery_date",
                    render: function(data, type, full, meta) {
                        if(data){
                            return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+moment(data).format('DD-MM-YYYY')+'</span>'
                        }
                        if(!data){
                            return '<span class="item-badge badge text-uppercase bg-warning">Not Deliverd</span>';     
                        }
                    },      
                }, {
                    data: "trnxid",
                    name: "trnxid",
                },{
                    data: "payment_type",
                    name: "payment_type",
                    render: function(data){
                        if(data == 1){
                            return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Cash</span>'
                        }
                        if(data == 2){
                            return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Online</span>'
                        }
                        if(data == 3){
                            return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Cheque</span>'
                        }
                        if(data == 4){
                            return '<span class="item-amount d-none d-sm-block text-sm text-danger">No Payment</span>'
                        }
                        if(data == 5){
                            return '<span class="item-amount d-none d-sm-block text-sm text-danger">On Bill</span>'
                        }
                    }
                },{
                    data: "total",
                    name: "total",
                    render: function(data){
                        return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                },{
                    data: "prev_balance",
                    name: "prev_balance",
                    render: function(data){
                        return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                },{
                    data: "received",
                    name: "received",
                    render: function(data){
                        return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                }, {
                    data: "balance",
                    name: "balance",
                    render: function(data){
                        return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                },{
                    data: "payment_status",
                    name: "payment_status",
                    render: function(data){
                        if(data == 0){
                            return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-danger">Unpaid</span>'
                        }
                        if(data == 1){
                            return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-warning">Partial</span>'
                        }
                        if(data == 2){
                            return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-success">Paid</span>'
                        }
                        // for PaymentIN 
                        if(!data){
                            return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-success">Paid</span>'
                        }
                    }
                },{
                    data: "status",
                    name: "status",
                },{
                    data: "action",
                    name: "action"
            }],

        }); 
    }      
    /*------ Sale dataTable end here ------*/
    /*------ Product wise dataTable start here ------*/
    function load_product_wise_table(startDate, endDate){
        productWiseTable = $("#product_wise_table").DataTable({
            processing: true,
            responsive: true,
            serverSide: true,
            lengthMenu: [
                [10, 25, 50,100, -1],
                [10, 25, 50,100, 'All'],
            ],
            buttons: [
                { extend: 'excel', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7,8,9]},title: function(){ return getExportTitle()},filename: function(){ return getExportFileName()}},
                { extend: 'pdf', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7,8,9 ]},title: function(){ return getExportTitle()},filename: function(){ return getExportFileName()}},
            ],
            ajax: {
                url: routes.table_product,
                dataType: "json",
                data:{ startDate: startDate.format('YYYY-MM-DD'), endDate: endDate.format('YYYY-MM-DD')},
            },
            columns: [{
                    data: "DT_RowIndex",
                    name: "DT_RowIndex",
                    render: function(data){
                        return '<small class="text-muted" style="padding-left: 10px;">'+data+'</small>'
                    }
                }, {
                    data: "order_date",
                    name: "order_date",
                    render: function(data, type, full, meta) {
                        return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+moment(data).format('DD-MM-YYYY')+'</span>'
                    },      
                }, {
                    data: "delivery_date",
                    name: "delivery_date",
                    render: function(data, type, full, meta) {
                        if(data){
                            return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+moment(data).format('DD-MM-YYYY')+'</span>'
                        }
                        if(!data){
                            return '<span class="item-badge badge text-uppercase bg-warning">Not Deliverd</span>';     
                        }
                    },      
                }, {
                    data: "trnxid",
                    name: "trnxid",
                },{
                    data: "product",
                    name: "product",
                },{
                    data: "qty",
                    name: "qty",
                    render: function(data){
                        return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'
                    }
                },{
                    data: "unit_name",
                    name: "unit_name",
                    render: function(data){
                        return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'
                    }
                },{
                    data: "mrp",
                    name: "mrp",
                    render: function(data){
                        return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'
                    }
                }, {
                    data: "discount",
                    name: "discount",
                    render: function(data){                        
                        if(data == 0){
                            return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">0</span>'   
                        }
                        if(data){
                            return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'   
                        }
                        if(!data){
                            return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">NA</span>'   
                        }
                        
                    }
                },{
                    data: "amount",
                    name: "amount",
                    render: function(data){
                        return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'
                    }
                },{
                    data: "action",
                    name: "action"
            }],

        }); 
    }
    let tabId = "Bill";
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    //show selected tab / active
        tabId = $(e.target).attr('id');
    });
    /*------ Export Start ------*/
    $(document).on('click',".export",function(){
        var btn = $(this).attr('id').toString()
        if(tabId == "Bill"){
            trnxDataTable.button(btn).trigger();
        }
        if(tabId == "Product-Wise"){
            productWiseTable.button(btn).trigger();
        }        
    })
    function getExportFileName() {
        let name = customer.f_name.charAt(0).toUpperCase() + customer.f_name.slice(1)+' '+customer.s_name.charAt(0).toUpperCase() + customer.s_name.slice(1)
        let shop_name = customer.shop_name.toLowerCase().replace(/\b[a-z]/g, function(letter) {
                            return letter.toUpperCase();
                        });

        return name+' | '+shop_name+' | '+tabId.charAt(0).toUpperCase() + tabId.slice(1);
    }

    function getExportTitle(argument) {
        let name = customer.f_name.charAt(0).toUpperCase() + customer.f_name.slice(1)+' '+customer.s_name.charAt(0).toUpperCase() + customer.s_name.slice(1)
        let shop_name = customer.shop_name.toLowerCase().replace(/\b[a-z]/g, function(letter) {
                            return letter.toUpperCase();
                        });

        return name+' | '+shop_name+' | '+tabId.charAt(0).toUpperCase() + tabId.slice(1);
    }
    /*------ Export End -------*/  
    /*------ Product wise dataTable end here ------*/
    $(document).on('change','input[name="date_range"]',function(event){
        trnxDataTable.destroy();
        productWiseTable.destroy();
        load_bill_table(startDate,endDate);
        load_product_wise_table(startDate,endDate);
    }) 
    /*------ Payment-IN start here --------*/
    var customerId
    $(document).on('click',"#paymentin",function(event){
        event.preventDefault()
        $("#payMentModal .modal-title").text('Add Payment')
        $("#payment-form .text-danger").html("") 
        $("#payment-form")[0].reset()
        customerId = $(this).data('cid')
        $("#c_id").val(customerId)
        let thisCustomer = customers.filter(elem => {
            return elem.customer_id == customerId;
        })
        $("#prev_balance").val(thisCustomer[0].balance)
        $("#customer_name").val(thisCustomer[0].f_name+' '+thisCustomer[0].s_name+' '+'('+thisCustomer[0].shop_name+')')
        $("#payMentModal").modal("show")
        $('input').prop('disabled',false)
        $('textarea').prop('disabled',false)
        $('select').prop('disabled',false)
        $("#savePayBtn").show()
    })

    /* Add Product Start */
    $('#payment-form').on('click', '#savePayBtn', function (event) {
        event.preventDefault();
        $("#payment-form .text-danger").html("") 
        var formData = new FormData($('#payment-form')[0]);
        $.ajax({
            method: 'POST',
            url: routes.paymentIn,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function (response) {
                if(response.errors){
                    if(response.errors.received){
                        $("#payMentModal #received_error").text(response.errors.received[0])
                    }
                    if(response.errors.date){
                        $("#payMentModal #date_error").text(response.errors.date[0])
                    } 
                    if(response.errors.payment_type){
                        $("#payMentModal #payment_type_error").text(response.errors.payment_type[0])
                    }                                    
                }
                //on success
                else{
                    $('#sale_table').DataTable().ajax.reload();
                    $('#balance-show').load(window.location + ' #balance-show')
                    $("#payMentModal").modal('hide')
                    $("#payment-form")[0].reset()
                    $('input.md-input').attr('value' , '')               
                    let message = response.success;
                    snacbar(message)
                }
            },
            error:function(error){
                snacbar(error.statusText)
            }
        })//ajax end here
    })//Add product function end here
    /*Add Product End*/

    /*------ Payment-IN end here --------*/

    /*------ check mul;tiple decimnl value start ------*/
    $('#received').keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /*------ check mul;tiple decimnl value end ------*/

    /*------ Toatal calculation -------*/
    $('.modal-body').delegate('#received', 'keyup', function() {
        let prev_balance = $("#prev_balance").val()
        let received = $("#received").val()
        let balance = parseFloat(prev_balance) - parseFloat(received)
        $("#balance").val(balance.toFixed(2))
    });
    /*----- Toatal calculation -------*/


    var totalSale = 0;
    function totalSaleAmount(){
        for(let count=0; count < sales.length; count++){
            if(sales[count].customer_id == customer.customer_id){
                totalSale = totalSale + sales[count].sale_amount
            }
        }
        $("#totalSaleAmount").html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(totalSale))

        $("#totalSaleAmount").html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(totalSale))
    }
    totalSaleAmount()
})