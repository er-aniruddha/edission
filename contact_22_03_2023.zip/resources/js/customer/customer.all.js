$(document).ready(function () { 
   routelist(customer_routes,customers)  
    /*-------- Sales DataTable Start Here --------*/    
    var customrDataTable = $("#customer_table").DataTable({
        processing: true,
        responsive: true,
        serverSide: true,  
        "lengthChange": false,
        dom:'ltip',
        buttons: [
            { extend: 'csv', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'excel', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7]}},
            { extend: 'pdf', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'print', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}}
        ],
        ajax: {
            url: routes.all
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex",
            render: function(data){
                return '<small class="text-muted" style="padding-left: 10px;">'+data+'</small>'
            }
        }, {
            data: "name",
            name: "name",  

        },{
            data: "shop_name",
            name: "shop_name",  
            render: function(data){
                return '<small class="text-capitalize">'+data+'</small>'
            }
                
        }, {
            data: "locality",
            name: "locality", 
            render: function(data){
                return '<small class="text-capitalize">'+data+'</small>'
            } 
                
        }, {
            data: "phone",
            name: "phone",  
                
        },{
            data: "whatsapp_no",
            name: "whatsapp_no",  
                
        },{
            data: "balance",
            name: "balance", 
            render: function(data){
                if(data <= 0){
                    return '<small class="text-capitalize text-muted inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</small>'
                }
                else{
                    return '<small class="text-capitalize text-danger inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</small>'
                }
                
            }  
                
        },{
            data: "action",
            name: "action"
        }],

    });
    /*------ Sale dataTable end ------*/

    /*------- Search function start ----------*/
    $("#searchUser").on("keyup", function () {
        $(this).attr("placeholder", "Search");        
        var value = $(this).val().toLowerCase();
        customrDataTable.search(value).draw();
        // $("#userList .list-item").filter(function () {
        //     $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1) //this to show if there is value
        //     //$(".no-result").toggle($(this).text().toLowerCase().indexOf(value) === -1) //if no values then show this div
        // });
    });
    /*------- Search function end ----------*/
    /*------- Select table lenght start -------*/
    $("select.paging").on('change',function(event){
        event.preventDefault()
        if($(this).val() == 'all'){
            customrDataTable.page.len( -1 ).draw();
        }
        else{
            customrDataTable.page.len( $(this).val() ).draw();
        }
    })
    /*------- Select table lenght end -------*/

    /*------- on select route draw table start ------*/
    $(document).on('click','#_routeSelect',function(event){
        event.preventDefault()
        var value = $(this).data('name').toLowerCase();
        customrDataTable.search(value).draw();
    })
    /*------- on select route draw table end ------*/

    /* Edit Customer Modal Start*/
    $(document).on('click', '.edit', function (event) {
        event.preventDefault()
        $("#edit_customer_id").val($(this).data('id'))
        $("#f_name").val($(this).data('fname'))
        $("#s_name").val($(this).data('sname'))
        $("#shop_name").val($(this).data('shop'))
        $("#phone_1").val($(this).data('phone1'))
        $("#phone_2").val($(this).data('phone2'))
        $("#whatsapp_no").val($(this).data('whatsapp'))
        $("#email").val($(this).data('email'))
        $("#customer_type").val($(this).data('type'));
        $("#route").select2({width:"100%"}).val($(this).data('route')).trigger("change");
        $("#locality").val($(this).data('locality'))
        $("#district").select2({width:"100%"}).val($(this).data('district')).trigger("change");
        $("#pin").val($(this).data('pin'))
        $("#addline_1").val($(this).data('addline1'))
        $("#addline_2").val($(this).data('addline2'))
        $('.select2').select2({ 
            width:"100%", tags:true, dropdownParent: $('#editModal')
        });
        $("#editModal").modal('show')
    })
    /*Edit Customer Modal End here*/
    /* Edit Customer Form Start*/
    $("#editCustomerForm").on('click', '#editBtn', function (event) {
        event.preventDefault()
        $( '.text-danger' ).html( "" );
        let postData = new FormData($('#editCustomerForm')[0])
        $.ajax({
            type: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: postData,
            success: function (response) {
                if(response.errors){
                    if(response.errors.f_name){
                        $("#f_name_error").text(response.errors.f_name[0])
                    }
                    if(response.errors.s_name){
                        $("#s_name_error").text(response.errors.s_name[0])
                    }
                    if(response.errors.shop_name){
                        $("#shop_name_error").text(response.errors.shop_name[0])
                    }
                    if(response.errors.phone_1){
                        $("#phone_1_error").text(response.errors.phone_1[0])
                    }
                    if(response.errors.phone_2){
                        $("#phone_2_error").text(response.errors.phone_2[0])
                    }
                    if(response.errors.whatsapp_no){
                        $("#whatsapp_no_error").text(response.errors.whatsapp_no[0])
                    }
                    if(response.errors.customer_type){
                        $("#customer_type_error").text(response.errors.customer_type[0])
                    }
                    if(response.errors.customer_routes_id){
                        $("#route_error").text(response.errors.customer_routes_id[0])
                    }
                    if(response.errors.locality){
                        $("#locality_error").text(response.errors.locality[0])
                    }
                    if(response.errors.district){
                        $("#district_error").text(response.errors.district[0])
                    }
                    if(response.errors.pin){
                        $("#pin_error").text(response.errors.pin[0])
                    }
                    if(response.errors.email){
                        $("#email_error").text(response.errors.email[0])
                    }
                }
                //on success
                else{
                    $("#customer_table").DataTable().ajax.reload()
                	$("#editModal").modal('hide')
                    let customer_routes = response.routes; 
                    let customers = response.customers;            
                    routelist(customer_routes,customers) 
                    let message = response.success;
                    snacbar(message)
                }
                
            },//ajax success end
            error: function (error) {
                snacbar(error.statusText)
            }//ajax error end
        })//ajax end 
    })
    /*Edit Customer Form Function End*/

    /*Customer Remove Start*/
    $(document).on('click', '.trash', function (event) {
        event.preventDefault()
        $("#id").val($(this).data("id"))
        $(".modal-title").text("Shop : " + $(this).data("shop")) 
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })//Customer Remove ID valuye set to modal

    //ajax call function
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $("#customer_table").DataTable().ajax.reload()
                    $("#confirmModal").modal("hide");
                    let message = response.success;
                    snacbar(message)
                }
                if (response.error) {
                    $("#ok_button").text("Yes")
                    let message = response.error;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end here
    })//form end here
    /*Customer Remove End*/
    
})
