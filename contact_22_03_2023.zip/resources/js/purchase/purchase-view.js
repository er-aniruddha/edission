$(document).ready(function(){
    /*------ PurchaseOrder View Start ------*/
    $(document).on("click", "button.view", function(event) {
        let po_id = $(this).attr('id');
        $("#viewModal .modal-title").text("Purchase Order Details #CPO-" + po_id)
        $('#view tbody').empty().append();
        viewModal(po_id)
    })
    /*------ PurchaseOrder View End ------*/
    function viewModal(po_id) {
    	for (var count = 0; count < allPoItem.length; count++){
    		if(po_id == allPoItem[count].po_id){
    			var tr = '<tr class="">' +
			            '<td>' +
			            	'<input class="form-control text-capitalize" value="' + allPoItem[count].product_name + ' - '+allPoItem[count].brand_name+' " readonly>' +
			            '</td>' +
			            '<td>' +
			            	'<input class="form-control text-capitalize" value="'+allPoItem[count].unit_name+'" readonly">' +
			            '</td>' +
			            '<td class="td-qty">' +
			            	'<input type="number" value="' + allPoItem[count].qty + '"  class="form-control" readonly>' +
			            '</td>' +
			            '<td>' +
			            	'<input type="number" value="' + allPoItem[count].unit_price + '"  class="form-control" readonly>' +	            
			            '</td>' +
			            '<td>' +
			            	'<input type="number" value="' + allPoItem[count].amount + '"  class="form-control" readonly>' +
			            '</td>' +
			            '</tr>';
			        $('#view tbody').append(tr);

			$("#c2p_order_date").val(moment(allPoItem[count].order_date, 'YYYY-MM-DD').format("DD-MM-YYYY"))
			$("#c2p_delivery_date").val(moment(allPoItem[count].delivery_date, 'YYYY-MM-DD').format("DD-MM-YYYY"))
            $('#supplier_name').val(allPoItem[count].supplier_name);
            $('#c2p_payment_type').val(allPoItem[count].payment_type);
            $("#c2p_round_off").val(allPoItem[count].round_off)
            $("#c2p_delivery_charges").val(allPoItem[count].delivery_charges)
            $("#c2p_gst_amount").val(allPoItem[count].gst_amount)
            $("#c2p_total").val(allPoItem[count].total)
            $("#c2p_advance").val(allPoItem[count].advance)
            prevBalance = allPoItem[count].prev_balance
            $(".prev_bal").text('Previous Balance: '+prevBalance)
            $("#c2p_prev_balance").val(parseFloat(prevBalance).toFixed(2))//this is to store
            $("#c2p_balance").val(parseFloat(allPoItem[count].PO_balance).toFixed(2))//this is to store
            $("#c2p_remarks").val(allPoItem[count].remarks)

    		}
    	}
    	$("#viewModal").modal('show')
    }
	
})