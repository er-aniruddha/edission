$(document).ready(function(){
	/*-------- B-C transfer start ------*/
    $(document).on('click', '.b-c-trns', function(event) {
        event.preventDefault()
        $('.select2').select2({
            initSelection: function(element, callback) {},
            width: "100%",
            tags: true,
            dropdownParent: $('#b2cModal')
        });
        $("#b2cTrnsferForm")[0].reset()
    })

    $("#b2cTrnsferForm").on('click', '#cashTrnsBtn', function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        var formData = new FormData($("#b2cTrnsferForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.b2c,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if (response.errors.baccount_id) {
                        $("#b2c_baccount_id_error").text(response.errors.baccount_id[0])
                    }
                    if (response.errors.amount) {
                        $("#b2c_amount_error").text(response.errors.amount[0])
                    }
                    if (response.errors.date) {
                        $("#b2c_date_error").text(response.errors.date[0])
                    }
                } else {
                    $("#b2cTrnsferForm")[0].reset()
                    $("#bank_trnx_table").DataTable().ajax.reload()
                    $("#b2cModal").modal("hide")
                    let message = response.success;
                    bankaccounts = response.bankaccounts;
                    bankAcList()
                    snacbar(message)
                }

            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })
    })
    /*-------- B-C transfer end ------*/

    /*-------- C-B transfer start ------*/
    $(document).on('click', '.c-b-trns', function(event) {
        event.preventDefault()
        $('.select2').select2({
            initSelection: function(element, callback) {},
            width: "100%",
            tags: true,
            dropdownParent: $('#c2bModal')
        });
        $("#c2bTrnsferForm")[0].reset()
    })

    $("#c2bTrnsferForm").on('click', '#cashTrnsBtn', function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        var formData = new FormData($("#c2bTrnsferForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.c2b,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if (response.errors.baccount_id) {
                        $("#c2b_baccount_id_error").text(response.errors.baccount_id[0])
                    }
                    if (response.errors.amount) {
                        $("#c2b_amount_error").text(response.errors.amount[0])
                    }
                    if (response.errors.date) {
                        $("#c2b_date_error").text(response.errors.date[0])
                    }
                } else {
                    $("#c2bTrnsferForm")[0].reset()
                    $("#bank_trnx_table").DataTable().ajax.reload()
                    $("#c2bModal").modal("hide")
                    let message = response.success;
                    bankaccounts = response.bankaccounts;
                    bankAcList()
                    snacbar(message)
                }

            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })
    })
    /*-------- C-B transfer end ------*/

    /*-------- B-B transfer start ------*/
    $(document).on('click', '.b-b-trns', function(event) {
        event.preventDefault()
        console.log("b-b")
    })
    /*-------- B-B transfer end ------*/

    /*-------- edit transfer start ------*/
    $(document).on('click','a.edit',function(event){
        event.preventDefault()      
        $('.to-element, .from-element').empty().append()
        let trnxtype = $(this).data('trnxtype')
        let trnxid = $(this).data('trnxid')
        let bank_id = $(this).data('bacid')
        let name = $(this).data('name')
        // b2c transaction
        if(trnxtype == 1){
            $("#editModal .modal-header, .update-btn").removeClass('bg-success')
            $("#editModal .modal-header, #_upDateBtn").addClass('red')
            $("#editModal .modal-title").text('Bank to Cash transfer edit: #'+trnxid)
            $("#_upDateBtn").prop('value','Cash Withdraw Update')
            $('.from-element').append('<input type="text" value="'+name+'" class="form-control text-capitalize" readonly>')
            $('.to-element').append('<select class="form-control" disabled id="edit_cash" name="cash"><option selected="" value="cash">Cash</option></select>')

        }
        // c2b transaction
        if(trnxtype == 2){
            $("#editModal .modal-header, .update-btn").removeClass('red')
            $("#editModal .modal-header, .update-btn").addClass('bg-success')
            $("#editModal .modal-title").text('Cash to Bank transfer edit: #'+trnxid)
            $("#_upDateBtn").prop('value','Cash Deposite Update')
            $('.from-element').append('<select class="form-control" disabled id="edit_cash" name="cash"><option selected="" value="cash">Cash</option></select>')
            $('.to-element').append('<input type="text" value="'+name+'" class="form-control text-capitalize" readonly>')
        }
        $("#edit_id").val($(this).data('id'))
        $("#edit_amount").val($(this).data('amount'))
        $("#edit_date").val(moment($(this).data('date')).format('DD-MM-YYYY') )
        $("#edit_remarks").val($(this).data('remarks'))
        bankAcList()
        $("#editModal").modal('show')
    })

     $("#editTransactionForm").on('click', '#_upDateBtn', function(event) {
        event.preventDefault()
        $("#editTransactionForm .text-danger").html("")
        var formData = new FormData($("#editTransactionForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.trnxUpdate,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if (response.errors.amount) {
                        $("#edit_amount_error").text(response.errors.amount[0])
                    }
                    if (response.errors.date) {
                        $("#edit_date_error").text(response.errors.date[0])
                    }
                } else {
                    $("#editTransactionForm")[0].reset()
                    $("#bank_trnx_table").DataTable().ajax.reload()
                    $("#editModal").modal("hide")
                    let message = response.success;
                    bankaccounts = response.bankaccounts;
                    bankAcList()
                    snacbar(message)
                }

            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })
    })
    /*-------- edit transfer end ------*/

    /*-------- Delete transaction -------*/    
    $(document).on("click", "a.delete", function() {
        $("#id").val($(this).data("id")) 
        $(".modal-title").text("Transaction ID : #" + $(this).data("trnxid"))
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.trnxDelete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $("#bank_trnx_table").DataTable().ajax.reload()
                    $("#confirmModal").modal("hide");
                    bankaccounts = response.bankaccounts;
                    bankAcList()
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end
    })
    /*-------- Delete transaction -------*/  
})