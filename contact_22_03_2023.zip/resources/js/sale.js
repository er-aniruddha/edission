$(document).ready(function() {
	var base_url = "https://varneyatechnologies.com";
    $('.select2').select2({
        dropdownParent: $('#modal'),
        width:"100%",
    });//to initiatate select2  
    
    /*Form modal Html Part Start*/
    $('.addRow').on('click', function() {
        var item = {};
        item.item_name = '';
        item.unit_name = '';
        item.qty = '';
        item.unit_price = '';
        item.total_price = '';
        item.purchase_id = '';
        addRow(item)
    })
    /* Add input row into Purchase Order Form Start */
    var tdFormRowIndex = 0;
    function addRow(item) {
        var tr = '<tr class="addedRow row_'+tdFormRowIndex+'">' +
            '<td>' +
            '<select class="form-control select2 proChng productList'+tdFormRowIndex+'" name="item_name[' +tdFormRowIndex+ ']" id="item_name' +tdFormRowIndex+ '" value="' + item.item_name + '" tabindex="-1" aria-hidden="true">' +
            '</select>' +
            '<span class="text-danger item_name_error_' +tdFormRowIndex+ '"></span> ' +
            '</td>' +
            '<td class="unit-td">' +
            '<select class="form-control select2 unitList'+tdFormRowIndex+'" name="unit_name[' +tdFormRowIndex+ ']" id="unit_name' +tdFormRowIndex+ '" value="' + item.unit_name + '" tabindex="-1" aria-hidden="true">' +
            '</select>' +
            '<div class="text-danger unit_name_error_' +tdFormRowIndex+ '"></div> ' +
            '</td>' +

            '<td>' +
            '<input type="number" name="qty[' +tdFormRowIndex+ ']" id="qty" value="' + item.qty + '"  class="form-control qty" placeholder="Quantity" oninput="this.value = Math.round(this.value);">' +
            '<span class="text-danger qty_error_' +tdFormRowIndex+ '"></span> ' +
            '</td>' +

            '<td>' +
            '<input type="number" name="unit_price[' +tdFormRowIndex+ ']" id="unit_price" value="' + item.unit_price + '"  class="form-control unitPrice" placeholder="Price">' +
            '<span class="text-danger unit_price_error_' +tdFormRowIndex+ '"></span> ' +
            '</td>' +
            '<td>' +
            '<input type="number" name="amount[' +tdFormRowIndex+ ']" id="amount" value="' + item.amount + '"  class="form-control amount" placeholder="Total" onchange="(function(el){el.value=parseFloat(el.value).toFixed(2);})(this)"readonly>' +
            '<span class="text-danger amount_error_' +tdFormRowIndex+ '"></span> ' +
            '</td>' +
            '<td><a href="javascript:void(0)" class="btn btn-icon remove" id="'+item.purchase_order_id+'" id="remove'+tdFormRowIndex+'" style="border: 1px solid #f54394">' +
            '<svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="color: red;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
            '</a>' +
            '</td>' +
            '</tr>';
        window.rowCount = tdFormRowIndex;
        tdFormRowIndex++;
        $('#tdFormRow tbody').append(tr);
        productsList(products)
        unitList(units)
    }//Add row into purchase modal form end
    
    function productsList(products) {
        $(".productList"+window.rowCount).empty().append('<option selected="" value="">Select an option</option>');
        for (count = 0; count < products.length; count++) {
            $(".productList"+window.rowCount).append('<option value="' + products[count][1].product_id + '">' + products[count][1].product_name + '</option>')
        }
        // $('#item_name' + window.rowCount).off('productList:select');
        $('#item_name' + window.rowCount).select2({ width: "100%", tags: true }); //to initiatate select2  
    }//Product lsit end here

    function unitList(units) {
        $('.unitList'+window.rowCount).empty().append('<option selected="" value="">Select an option</option>');

        for (countUnit = 0; countUnit < units.length; countUnit++) {
            $(".unitList"+window.rowCount).append('<option value="' + units[countUnit][1].unit_name + '">' + units[countUnit][1].unit_name + '</option>')
        }
        $('#unit_name' + window.rowCount).select2({ width: "100%", tags: true }); //to initiatate select2  
    }//unit list end here   

    $("#tdFormRow").on('change','select.proChng',function(){
        for (count = 0; count < products.length; count++) {
            if(products[count][1].product_id == $(this).val()){
                $(this).parents('.addedRow').children('.unit-td').children('.select2').select2({ width: "100%" }).val(products[count][1].primary_unit).trigger("change");
            }
        }
    })//Onchange product show primary unit

    /*Remove row start of FORM*/
    $(document).on('click', '.remove', function() {        
        $(this).parent().parent().remove()
        // $(this).closest('table').children('tr').addClass('xxx');
        // $(this).closest('td').parent('tr').parent()[0].sectionRowIndex
        totalCalculation()
        let id = $(this).attr('id')
        let data = {};
        data =
        {  
            id : id,
        }  
        
        singleItemDel.push(data)
        
    });
    /*Remove row end of FORM*/

    /* Date Picker Start*/
    $('.date').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
        width: "100%",
        startDate: "01-04-2021",
        endDate: "0d",
        todayHighlight: true,
    })
    /* Date Picker End*/

    /* To prevent multi decimal input start */
    $('#unit_price').keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /* To prevent multi decimal input edn */

    /* Toatal calculation*/
    var total = 0;
    $('tbody').delegate('.qty, .unitPrice', 'keyup', function() {
        var tr = $(this).parent().parent();
        var qty = tr.find('.qty').val();
        var unitPrice = tr.find('.unitPrice').val();
        var amount = qty * unitPrice;
        tr.find('.amount').val(parseFloat(amount).toFixed(2));
        // var roundOff = $("#round_off").val()
        // total = total + amount - roundOff
        // $('#total').val(parseFloat(total).toFixed(2));
        // $('#advance').val(parseFloat(total).toFixed(2));
        totalCalculation()
    });

    $("#advance").on('keyup',function(){
        if($("#advance").val() != ''){
            totalCalculation()
        }   
        else{
            $("#advance").val(0)
        }     
    })
    $("#round_off").on('keyup',function(){
        if($("#round_off").val() != ''){
            totalCalculation()
        }  
    })
    $("#gst_amount").on('keyup',function(){
        if($("#gst_amount").val() != ''){
            totalCalculation()
        }
    })
    
    function totalCalculation() {
        var subTotal = 0;
        var advance = $("#advance").val()
        var roundOff = $("#round_off").val()
        var gstAmount = $("#gst_amount").val()

        $('.amount').each(function(i, e) {
            var amount = $(this).val() - 0;
            subTotal += amount;  
        });
        total = parseFloat(subTotal) + parseFloat(gstAmount);    
        total = parseFloat(total) - parseFloat(roundOff);    
        var balance = parseFloat(total) - parseFloat(advance);
        $("#total").val(total)
        $("#balance").val(balance)     
    }//Toatal calculation  
    /*Form modal Html Part end*/
	/* Sales DataTable Start Here*/
    var dataTable = $("#sale_table").DataTable({
        processing: true,
        serverSide: true,
        buttons: [{ extend: 'csv', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'excel', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7]}},
            { extend: 'pdf', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'print', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}}
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex",
            render: function(data){
                return '<small class="text-muted">'+data+'</small>'
            }
        }, {
            data: "date",
            name: "date",
            render: function(data, type, full, meta) {
                return '<a href="#" class="item-company ajax h-1x" data-pjax-state="">'+data+'</a>'
            },      
        }, {
            data: "invoice_id",
            name: "invoice_id",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        },{
            data: "f_name",
            name: "f_name",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        },{
            data: "payment_type",
            name: "payment_type",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        },{
            data: "amount",
            name: "amount",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        },{
            data: "received",
            name: "received",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        }, {
            data: "balance",
            name: "balance",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        },{
            data: "action",
            name: "action"
        }]
    });
    /*------ Sale dataTable end here ------*/
    /*------ Export Start ------*/
    $(document).on('click',".export",function(){
        var btn = $(this).attr('id').toString()
        dataTable.button(btn).trigger();
    })
    /*------ Export End -------*/ 

})