$(document).ready(function() {
    /*------ Status Chage Form -------*/
    $('input[type="checkbox"]').click(function(event) {
        /* Act on the event */
        if($('#checkbox').is(':checked')){
            $("#brand_stat").val(1)
        }
        else{
            $("#brand_stat").val(0)
        }
    })
    /*------ Status Change Form -------*/

    /*------ Brand DataTable Start -------*/
    $("#brand_table").DataTable({
        processing: true,
        serverSide: true,
        autoWidth: false,
        lengthMenu: [
            [10, 25, 50,100, -1],
            [10, 25, 50,100, 'All'],
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex"
        }, {
            data: "image",
            name: "image",
            
            orderable: true
        }, {
            data: "brand_name",
            name: "brand_name",
            className:"text-capitalize"
        }, {
            data: "status",
            name: "status"
        }, {
            data: "action",
            name: "action"
        }]
    });
    /*------- Brand DataTable End ------*/

    /*------- Brand Add Start -------*/
    $(document).on("click", "button.add", function() {
        $(".modal-title").text("Add Brand")
         $('#show-img').removeAttr('src')
         $('#brandForm')[0].reset()
         $("#brand_name").removeClass('text-capitalize')
         $("#brand_desc").removeClass('text-capitalize')
         $("#brand_id").val("")
         $("#addBtn").show()
         $(".text-danger").html("")
         $("#editBtn").hide()
    })//to show modal for add
    $("#brandForm").on("click", "#addBtn", function(event) {
        event.preventDefault()
        $(".text-danger").html("") 
        var formData = new FormData($("#brandForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if(response.errors.brand_name){
                        $("#brand_name_error").text(response.errors.brand_name[0])
                    }
                    if(response.errors.brand_desc){
                        $("#brand_desc_error").text(response.errors.brand_desc[0])
                    }
                    if(response.errors.image){
                        $("#image_error").text(response.errors.image[0])
                    }
                }                    
                else {
                    $("#brandForm")[0].reset() 
                    $('input.md-input').attr('value' , '')
                    $("#brand_table").DataTable().ajax.reload()
                    $("#modal").modal("hide")
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                console.log(error)
                snacbar(error.statusText)
            }
        })
    })
    /*------ Brand Add End ------*/

    /*------ Brand View Start ------*/
    $(document).on("click", "button.view", function() {        
        $(".modal-title").text("Brand Details")
        $("#addBtn").hide()
        $("#editBtn").hide()
        $("#image").hide()
        showBrand($(this).data())
    })
    /*------ Brand View End ------*/

    /*------ Brand Edit Start ------*/
    $(document).on("click", "button.edit", function() {   
        $(".modal-title").text("Edit Brand") 
        $("#brand_id").val($(this).attr("id"))
        $("#addBtn").hide() 
        $("#editBtn").show()
        showBrand($(this).data())
    })
    $("#brandForm").on("click", "#editBtn", function(event) {
        event.preventDefault()
        $(".text-danger").html("") 
        var formData = new FormData($("#brandForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors){
                    if(response.errors.brand_name){
                        $("#brand_name_error").text(response.errors.brand_name[0])
                    } 
                    if(response.errors.brand_desc){
                        $("#brand_desc_error").text(response.errors.brand_desc[0])
                    }
                    if(response.errors.image){
                        $("#image_error").text(response.errors.image[0]);
                    }                     
                }
                else{
                    $("#brandForm")[0].reset() 
                    $("#brand_desc").removeClass("text-capitalize")
                    $('input.md-input').attr('value' , '')
                    $("#brand_table").DataTable().ajax.reload()
                    $("#modal").modal("hide");
                    let message = response.success;
                    snacbar(message)
                }
            },//success end
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end here
    })
    /*------ Brand Edit End ------*/

    /*------ Brand Status Change Start -----*/
    $(document).on("click", "a.status", function(event) {
        event.preventDefault()
        $.ajax({
            type: "GET",
            url: $(this).data("url"),
            success: function(response) {
                if (response.success) {
                    $("#brand_table").DataTable().ajax.reload();
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })
    })
    /*----- Brand Status Change End ------*/

    /*----- Brand Delete Start -----*/
    $(document).on("click", "button.delete", function() {
        $("#id").val($(this).data("id")) 
        $(".modal-title").text("Brand Name : " + $(this).data("name"))
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $("#brand_table").DataTable().ajax.reload()
                    $("#confirmModal").modal("hide");
                    let message = response.success;
                    snacbar(message)
                }
                if (response.error) {
                    $("#ok_button").text("Yes")
                    let message = response.error;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end
    })
    /*------ Brand Delete End ------*/

    /*------ View and Show Brand function Start ----*/
    function showBrand(data) {
        if(data.status == 1){
            $('input[type="checkbox"]').prop("checked", true)
            $("#brand_stat").val(1)
        }
        else{
            $('input[type="checkbox"]').prop("checked", false)
            $("#brand_stat").val(0)
        }
        $("#modal").modal("show") 
        $("#brand_name").val(data.name)
        $("#brand_desc").val(data.desc)
        $("#supplier_id").val(data.company);
        $("#show-img").attr("src", data.image)
        $(".text-danger").html("") 
    }
    /*------ View and Show Brand function End ----*/
    
});