$(document).ready(function(){
	/*------- View Start Here -------------*/
    $(document).on('click','a.view', function(event){
        event.preventDefault()
        let trnxId = $(this).data('trnxid')
        $('#viewRow tbody').empty().append();       
        $('#viewAndConvertModal .modal-title').text("Cr. Note Details: #CRN-"+trnxId);
        $('.delivery-date').hide()
        $('#convertDueBtn').hide()
        $('#viewAndConvertForm input').prop('readonly',true)
        $('#viewAndConvertForm textarea').prop('readonly',true)
        viewModal(trnxId)
    })
    /*------- View End Here -------------*/

    /*------- Convert to sale Start Here -------------*/
    $(document).on('click','.over-due', function(event){
        event.preventDefault()
        let trnxId = $(this).data('trnxid')
        $("#convert_cr_trnx_id").val(trnxId)
        $('#viewRow tbody').empty().append();       
        $('#viewAndConvertModal .modal-title').text("Cr. Note Details: #CRN-"+trnxId);
        $('.delivery-date').show()
        $('#convertDueBtn').show()
        $('#viewAndConvertForm input').prop('readonly',true)
        $('#viewAndConvertForm textarea').prop('readonly',true)
        $('#delivery_date').prop('readonly',false)
        viewModal(trnxId)
    })
    $("#viewAndConvertForm").on("click", "#convertDueBtn", function(event) {
        event.preventDefault()
        $("#loader").show()
        $("#viewAndConvertForm .text-danger").html("")
        var formData = new FormData($("#viewAndConvertForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.convert,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                console.log(response)
                $("#loader").hide()
            	if (response.errors) {
                    if (response.errors.delivery_date) {
                        $("#delivery_date_error").text(response.errors.delivery_date[0])
                    }
                }
                //on success
                else{
                	$('#credit_note_table').DataTable().ajax.reload();
	                $("#viewAndConvertModal").modal('hide')
	                $("#viewAndConvertForm")[0].reset()
	                $('.select2').select2({
                        initSelection: function(element, callback) {},
                        width: "100%"
                    });
                    creditNotes = response.creditNotes
                    customers = response.customers
                    products = response.products
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                $("#loader").hide()
                snacbar(error.statusText)
            }
        })
    })    /*------- Convert to sale End Here -------------*/

    function viewModal(trnxId) {
    	for (var count = 0; count < creditNotes.length; count++){
    		if(trnxId == creditNotes[count].cr_trnx_id){
    			var tr = '<tr class="">' +
			            '<td>' +
			            	'<input type="text" class="form-control text-capitalize" value="' + creditNotes[count].product_name+' - '+creditNotes[count].brand_name+ '" readonly>' +
			            '</td>' +
			            '<td>' +
			            	'<input type="text" class="form-control text-capitalize" value="'+creditNotes[count].unit_name+'" readonly>' +
			            '</td>' +
			            '<td class="td-qty">' +
			            	'<input type="number" value="' + creditNotes[count].cr_qty + '"  class="form-control" readonly>' +
			            '</td>' +
			            '<td>' +
			            	'<input type="number" value="' + creditNotes[count].cr_unit_price + '"  class="form-control" readonly>' +	            
			            '</td>' +
                        '<td>' +
			            	'<input type="number" value="' + creditNotes[count].cr_amount + '"  class="form-control" readonly>' +
			            '</td>' +
			            '</tr>';
			        $('#viewRow tbody').append(tr);

			$("#view_customer_name").val(creditNotes[count].f_name+' '+creditNotes[count].s_name+' ('+creditNotes[count].phone_1+') ('+creditNotes[count].shop_name+') ('+creditNotes[count].locality+')')
            $("#view_order_date").val(moment(creditNotes[count].cr_order_date, 'YYYY-MM-DD').format("DD-MM-YYYY"))
			$("#view_delivery_date").val(moment(creditNotes[count].cr_delivery_date, 'YYYY-MM-DD').format("DD-MM-YYYY"))
            $('#view_payment_type').val(creditNotes[count].cr_payment_type);
            $("#view_round_off").val(creditNotes[count].cr_round_off)
            $("#view_delivery_charges").val(creditNotes[count].cr_delivery_charges )
            $("#view_gst_amount").val(creditNotes[count].cr_gst_amount)
            $("#view_total").val(creditNotes[count].cr_total)
            $("#view_paid").val(creditNotes[count].cr_paid)
            let prevBalance = creditNotes[count].cr_prev_balance
            $(".prev_bal").text('Previous Balance: '+prevBalance)
            $("#view_prev_balance").val(parseFloat(prevBalance))//this is to store
            $("#view_balance").val(parseFloat(creditNotes[count].cr_balance))//this is to store
            $("#view_remarks").val(creditNotes[count].cr_remarks)
            $("input[type='text']").addClass("text-capitalize")
    		}
    	}
    	$("#viewAndConvertModal").modal('show')
    }
    
})