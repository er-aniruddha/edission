@section('page_title','Customer Details')
<div id="content" class="flex">
    <div class="">
        <div class="mx-3 mb-3 card customer-profile">
            <div class="p-4 d-sm-flex no-shrink b-b profile-top">
                <div>
                    <a href="#" class="w-96" data-pjax-state="">
                        <span class="w-96 avatar gd-info text-uppercase" style="height: 96px; font-size: 45px;">
                            <img src="{{ asset(Auth::User()->user_img) }}" alt="{{ $customer->f_name[0] }}{{ $customer->s_name[0] }}" style="margin-bottom: 9px">
                        </span>
                    </a>
                </div>
                <div class="px-sm-4 flex" style="padding-right: 0px !important;">
                    <div>
                       <!--  <button class="btn btn-raised btn-wave mb-2 cyan text-white" style="float: right;" id="addSalesFromCustomerBtn" data-cid="{{$customer->customer_id}}" data-toggle="modal" data-target="#createAndEditModal">Add Sale
                        </button> -->
                        <button class="btn btn-raised btn-wave mb-2 blue text-white" style="float: right;" id="paymentin" data-cid="{{$customer->customer_id}}">Add Payment-In
                        </button>  
                        <h2 class="text-md text-capitalize">{{$customer->f_name}} {{$customer->s_name}}</h2>
                    </div>
                    
                    <small class="d-block text-fade text-capitalize">{{$customer->shop_name}}</small>
                    <div>
                        <button class="btn btn-raised btn-wave btn-outline-primary" data-toggle="dropdown" style="float: right;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-download-cloud">
                                <polyline points="8 17 12 21 16 17"></polyline>
                                <line x1="12" y1="12" x2="12" y2="21"></line>
                                <path d="M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29"></path>
                            </svg>
                            Export
                        </button>
                        <div class="dropdown-menu" role="menu" x-placement="bottom-start">
                            <a class="dropdown-item export" id=".buttons-excel">
                                <i class="badge badge-circle text-primary"></i> EXCEL
                            </a>
                            <a class="dropdown-item export" id=".buttons-pdf">
                                <i class="badge badge-circle text-primary"></i> PDF
                            </a>
                        </div>                             
                    </div>
                    <div class="my-3">
                        <a href="#" data-pjax-state="">
                            <span class="text-muted">Total Purchase Amount: </span>
                            <strong id="totalSaleAmount" class="inr-sign"></strong>                                    
                        </a>
                        <br>
                        <a href="#" data-pjax-state="" id="balance-show">
                            <span class="text-muted">Balance: </span>                                  
                            <strong class="inr-sign">{{number_format($customer->balance, 2)}}</strong>                                     
                        </a>
                    </div>
                </div>
            </div>
            <!-- table start -->
            <div class="customer-profile-table">
                <div class="card">
                    <div class="b-b">
                        <div class="nav-active-border b-primary bottom" style="float: left; padding-left: 1%; padding-top: 9px;">
                            <div class="row">
                                <div class="col-md-5 pt-1">
                                    <span style="font-weight: 600; color: #535c78;">Transaction Table</span>
                                </div>
                                <div class="col-md-7 mb-2">
                                    <div class="input-group input-group-sm" style="width: 122%; ">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="inputGroup-sizing-sm">Date filter</span>
                                        </div>
                                        <input type="text" class="form-control date-range" aria-label="Filter Using Date" aria-describedby="inputGroup-sizing-sm" id="date_range" name="date_range" >
                                    </div>
                                </div>
                            </div>
                            

                        </div>    
                        <div class="nav-active-border b-primary bottom" style="float: right; ">
                             <ul class="nav" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active cart" id="Bill" data-toggle="tab" href="#bill" role="tab" aria-controls="bill" aria-selected="true">Bills</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="Product-Wise" data-toggle="tab" href="#product-wise" role="tab" aria-controls="product-wise" aria-selected="false">Product Wise</a>
                                </li>
                            </ul>
                        </div>                            
                    </div>
                    <div class="tab-content p-3">
                        <!-- Bill Start -->
                        <div class="tab-pane fade active show" id="bill" role="tabpanel" aria-labelledby="bill-tab">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered" id="sale_table" style="width: 100%;">
                                    <thead>
                                        <tr>
                                            <th style="width: 26px;"><span class="text-muted">#</span></th>                                
                                            <th><span class="text-muted">Order Date</span></th>
                                            <th><span class="text-muted">Delivery Date</span></th>
                                            <th><span class="text-muted">Invoice No</span></th>
                                            <th><span class="text-muted">Payment Type</span></th>
                                            <th><span class="text-muted">Amount</span></th>
                                            <th><span class="text-muted">Prev. Due</span></th>
                                            <th><span class="text-muted">Paid/Received</span></th>
                                            <th><span class="text-muted">Balance Due</span></th>
                                            <th><span class="text-muted">Payment Status</span></th>
                                            <th><span class="text-muted">Status</span></th>
                                            <th style="width:50px;"><span class="text-muted">Action</span></th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                        <!-- Bill End -->
                        <!-- Show Product Start -->
                        <div class="tab-pane fade" id="product-wise" role="tabpanel" aria-labelledby="product-wise-tab">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered" id="product_wise_table" style="width: 100%;">
                                    <thead>
                                        <tr>
                                            <th style="width: 26px;"><span class="text-muted">#</span></th>                            
                                            <th style="width: 35px;"><span class="text-muted">Order Date</span></th>
                                            <th style="width: 35px;"><span class="text-muted">Delivery Date</span></th>
                                            <th><span class="text-muted">Trnx Id</span></th>
                                            <th><span class="text-muted">Product Name</span></th>
                                            <th style="width: 35px;"><span class="text-muted">Qty</span></th>
                                            <th style="width: 35px;"><span class="text-muted">Unit Name</span></th>
                                            <th><span class="text-muted">MRP</span></th>
                                            <th><span class="text-muted">Discount</span></th>
                                            <th><span class="text-muted">Amount</span></th>
                                            <th style="width:25px;"></th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div> <!-- Show Product end -->
                    </div>
                </div>
            </div> <!-- customer profile end -->
        </div>
    </div>
</div>
@include('portal.customer.transaction-details-view-modal')
@include('portal.customer.paymentModal')
</div>
<script>
// global app configuration object
var routes = {
    table_bill: "{{ route('customer.data.table.bill',$customer->customer_id) }}",
    table_product: "{{ route('customer.data.table.product',$customer->customer_id) }}",
    payments: "{{ route('customer.payments',$customer->customer_id) }}",
    paymentIn: "{{ route('payment.in.create') }}",
    create: "{{ route('sale.order.create') }}",
};
var customer_routes = @json($routes);
var customers = @json($customers);
var customer = @json($customer);
var allTableData = @json($allTableData);
var sales = @json($sales);
</script>
<script type="text/javascript" src="{{asset('resources/js/customer/details.js')}}"></script>
<script type="text/javascript" src="{{asset('resources/js/customer/table_transaction_details.js')}}"></script>
<!-- <script type="text/javascript" src="{{asset('resources/js/sale/sale-order.js')}}"></script>
<script type="text/javascript" src="{{asset('resources/js/sale/view-convert.js')}}"></script> -->