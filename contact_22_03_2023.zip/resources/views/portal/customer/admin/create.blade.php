@section('page_title','Add New Customer')
<form id="addCustomerForm" method="POST">
    @csrf
<div class="col-md-12">
    <div class="card">
        <div class="card-header"><strong>Add Customer</strong></div>
        <div class="card-body">            
            <div class="row row-sm">
                <div class="col-md-6">
                    <div class="col-sm-12">
                        <div class="md-form-group float-label">
                            <input type="text" class="md-input" value="" name="f_name" id="f_name" 
                            onkeyup="this.setAttribute('value', this.value);" required=""><label>First Name *</label>
                            <span class="text-danger mr-2" id="f_name_error"></span>
                        </div>                            
                    </div>
                    <div class="col-sm-12">
                        <div class="md-form-group float-label">
                            <input type="text" class="md-input" value="" name="s_name" id="s_name"
                                onkeyup="this.setAttribute('value', this.value);"  required=""><label>Last Name*</label>
                            <span class="text-danger mr-2" id="s_name_error"></span>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="md-form-group float-label">
                            <input type="text" class="md-input" value="" name="shop_name" id="shop_name" 
                            onkeyup="this.setAttribute('value', this.value);" required=""><label>Shop Name *</label>
                            <span class="text-danger mr-2" id="shop_name_error"></span>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="md-form-group float-label">
                            <input type="number" class="md-input" value="" name="phone_1" id="phone_1" 
                            onkeyup="this.setAttribute('value', this.value);" required="" 
                            onKeyPress="if(this.value.length==10) return false;"><label>Phone 1 *</label>
                            <span class="text-danger mr-2" id="phone_1_error"></span>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="checkbox" id="check_1">
                            <label class="ui-check"><input type="checkbox" class="custom-control-input" value="1"><i
                                    class="dark-white"></i>
                                same as whats app</label>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="md-form-group float-label">
                            <input type="number" class="md-input" value="" name="phone_2" id="phone_2" 
                            onkeyup="this.setAttribute('value', this.value);" required="" 
                            onKeyPress="if(this.value.length==10) return false;"><label>Phone 2</label>
                            <span class="text-danger mr-2" id="phone_2_error"></span>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="checkbox" id="check_2">
                            <label class="ui-check"> <input type="checkbox" class="custom-control-input" value="2">
                                <i class="dark-white"></i>
                                same as whats app</label>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="md-form-group float-label">
                            <input type="number" class="md-input" value="" name="whatsapp_no" id="whatsapp_no" 
                            onkeyup="this.setAttribute('value', this.value);" required=""><label>Whats App</label>
                            <span class="text-danger mr-2" id="whatsapp_no_error"></span>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="md-form-group float-label">
                            <input type="email" class="md-input" value="" name="email" id="email"
                                onkeyup="this.setAttribute('value', this.value);" required=""><label>E-mail ID</label>
                            <span class="text-danger mr-2" id="email_error"></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="col-sm-12">
                        <label class="text-muted">Type of Customer</label>
                        <select class="form-control select2" name="customer_type" id="customer_type" 
                        tabindex="-1" aria-hidden="true">
                            <option value="0" selected>Select Type</option>
                            <option value="1">Retail</option>                
                            <option value="2">Distributor</option>                
                            <option value="3">End User</option>                
                        </select>
                        <span class="text-danger mr-2" id="customer_type_error"></span>

                    </div>
                    <div class="col-sm-12">
                        <label class="text-muted">Routes</label>
                        <select class="form-control select2" name="customer_routes_id" id="customer_routes_id" 
                        tabindex="-1" aria-hidden="true">
                            <option value="0" selected>Select Route</option>
                            @foreach($routes as $route)
                                <option value="{{$route->customer_routes_id}}">{{$route->route_name}}</option>
                            @endforeach                    
                        </select>
                        <span class="text-danger mr-2" id="route_error"></span>

                    </div>
                    <div class="col-sm-12">
                        <div class="md-form-group float-label">
                            <input type="text" class="md-input" value="" name="locality" id="locality" 
                                onkeyup="this.setAttribute('value', this.value);" required=""><label>Locality *</label>
                                <span class="text-danger mr-2" id="locality_error"></span>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <label class="text-muted">District</label>
                        <select class="form-control select2" name="district" id="district" 
                        tabindex="-1" aria-hidden="true">
                            <option value="" selected>Select District</option>
                            <optgroup label="West Bengal">
                                <option value="North 24 Parganas">North 24 Parganas</option>
                                <option value="Nadia">Nadia</option>
                            </optgroup>                            
                        </select>
                        <span class="text-danger mr-2" id="district_error"></span>

                    </div>
                    <div class="col-sm-12">
                        <div class="md-form-group float-label">
                            <input type="number" class="md-input" value="" name="pin" id="pin" 
                            onkeyup="this.setAttribute('value', this.value);" required=""
                                onKeyPress="if(this.value.length==6) return false;"><label>PIN *</label>
                            <span class="text-danger mr-2" id="pin_error"></span>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="md-form-group float-label">
                            <input type="text" class="md-input" value="West Bengal" name="state" id="state"
                                onkeyup="this.setAttribute('value', this.value);" readonly><label>State *</label>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="md-form-group float-label">
                            <input type="text" class="md-input" value="" name="addline_1" id="addline_1" 
                            onkeyup="this.setAttribute('value', this.value);" required="" formnovalidate>
                            <label>Address 1</label>
                                <span class="text-danger mr-2" id="addline_1_error"></span>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="md-form-group float-label">
                            <input type="text" class="md-input" value="" name="addline_2" id="addline_2" 
                            onkeyup="this.setAttribute('value', this.value);" required><label>Address 2</label>
                            <span class="text-danger mr-2" id="addline_2_error"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="footer-form">
    <div class="flex">
        <!-- ############ Main START-->
        <div class="row">
            <div class="col-md-4 d-flex justify-content-center" style="width: 50%;">
                <a href="{{ url()->previous()}}" class="btn btn-raised btn-wave mb-2 w-xs btn-outline-dark">Cancel</a>
            </div>
            <div class="col-md-4 d-flex justify-content-center" style="width: 50%;">
                <button class="btn btn-raised btn-wave mb-2 w-xs blue text-white" id="addCustomerBtn">Save</button>
            </div>
        </div>
    </div>
</div>
</form>
<script>
// global app configuration object
var routes = {
    create: "{{ route('customer.create') }}",
};
</script>
<script type="text/javascript" src="{{asset('resources/js/customer/customer.create.js')}}"></script>