@extends('portal.layouts.main')
@section('content')
<div id="content" class="flex">
    <div class="">
        <div class="b-b">
            <div class="d-flex padding">
                <div>
                    <h2 class="text-md text-highlight">Calendar</h2>
                    <small class="text-muted">Saturday, 28 July 2018</small> 
                    <a class="badge badge-sm badge-pill b-a mx-1" id="todayview">Today</a>
                </div>
                <span class="flex"></span>
                <div>
                	<button id="btn-new" class="btn btn-sm box-shadows btn-rounded gd-primary text-white"data-toggle="modal" data-target="#newEvent">Add Event
                	</button>
                </div>
            </div>
            <div class="nav-active-border b-success px-3">
                <ul class="nav text-sm" role="tablist">
                    <li class="nav-item"><a class="nav-link" id="dayview" data-toggle="tab">Day</a></li>
                    <li class="nav-item"><a class="nav-link active" id="weekview" data-toggle="tab">Week</a></li>
                    <li class="nav-item"><a class="nav-link" id="monthview" data-toggle="tab">Month</a></li>
                </ul>
            </div>
        </div>
        <!-- modal -->
       
        <!-- / .modal -->
        <div id="fullcalendar"  class="fc fc-unthemed fc-ltr" data-sr-id="29" style="; visibility: visible;  -webkit-transform: translateX(0) scale(1); opacity: 1;transform: translateX(0) scale(1); opacity: 1;-webkit-transition: -webkit-transform 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0.01s, opacity 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0.01s; transition: transform 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0.01s, opacity 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0.01s; ">        
    	</div>
	</div>
</div>
<div id="newEvent" class="modal fade show" style="padding-right: 17px;" aria-modal="true">
    <div class="modal-dialog text-dark">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white">Event</h5><button class="close" data-dismiss="modal">×</button></div>
            <div class="modal-body">
                <form id="newEventForm">
                	@csrf
                    <div class="form-group row">
                    	<label class="col-sm-3 col-form-label">Title</label>
                        <div class="col-sm-9">
                        	<input id="event-title" type="text" class="form-control" placeholder="Title">
                        </div>
                    </div>
                    <div class="form-group row"><label class="col-sm-3 col-form-label">Event type</label>
                        <div class="col-sm-9">
                            <div class="mt-2" id="event-type">
                                <div class="form-check form-check-inline">
                                	<label class="form-check-label">
                                		<input class="form-check-input" type="radio" name="type" value="Appointment"> Appointment
                                	</label>
                                </div>
                                <div class="form-check form-check-inline">
                                	<label class="form-check-label">
                                		<input class="form-check-input" type="radio" name="type" value="Meeting"> 
                                		Meeting
                                	</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row row-sm">
                    	<label class="col-sm-3 col-form-label">Start</label>
                        <div class="col-sm-5">
                        	<input id="event-start-date" type="date" class="form-control" placeholder="Date">
                        </div>
                        <div class="col-sm-4">
                        	<input id="event-start-time" type="time" class="form-control" placeholder="Time">
                        </div>
                    </div>
                    <div class="form-group row row-sm">
                    	<label class="col-sm-3 col-form-label">End</label>
                        <div class="col-sm-5">
                        	<input id="event-end-date" type="date" class="form-control" placeholder="Date">
                        </div>
                        <div class="col-sm-4">
                        	<input id="event-end-time" type="time" class="form-control" placeholder="Time">
                        </div>
                    </div>
                    <div class="form-group row">
                    	<label class="col-sm-3 col-form-label">Participate</label>
                        <div class="col-sm-9">
                            <div class="d-flex">
                                <div id="event-participant" class="avatar-group">
                                	
                                </div>
                                <a href="#" class="btn btn-icon btn-rounded btn-primary ml-1">
                                	<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                    	<label class="col-sm-3 col-form-label">Description</label>
                        <div class="col-sm-9">
                        	<textarea id="event-desc" class="form-control" rows="6"></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                    	<label class="col-sm-3"></label>
                        <div class="col-sm-9">
                        	<button type="button" id="btn-save" class="btn gd-primary text-white btn-rounded">Save</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
</div>
<script>

$(document).ready(function () {

    var e
    var option = $('#fullcalendar').fullCalendar({
        header:{
            left: 'title, prev, next',
      		center: '',
      		right: ''
        },
        contentHeight: 'auto',
   		defaultView: 'agendaWeek',
    	defaultDate: moment().format('YYYY-MM-DD'),
    	editable: true,
    	eventLimit: false,
        viewRender: function (view, element) {
	      // style
	      element.find('th.fc-day-header.fc-widget-header').each(function () {
	        if($(this).data('date')){
	          var date = moment($(this).data('date'));

	          $(this).html('<span>' + date.format('D') + '</span><span class="fc-week-title">' + date.format('dddd') + '</span>');
	        }
	      })
	    },
	    eventRender: function(event, element) {
	      // render
	      console.warn(event.description)
	      element.find('.fc-content').append('<div class="mt-1 text-muted">'+event.description+'</div>');
	      element.find('.fc-content').append( '<div class="d-flex my-3 avatar-group">' + getParticipant(event, 24) + '</div>');
	    },
	    eventClick: function(event, jsEvent) {
	      $('#newEvent').modal('show');
	      e = event;
	      getEvent(event);
	    }
	  });

      function setupEvents(){
    $(document).on('click', '#dayview', function() {
      calendar.fullCalendar('changeView', 'agendaDay');
      sr.sync();
    });

    $(document).on('click', '#weekview', function() {
      calendar.fullCalendar('changeView', 'agendaWeek');
      sr.sync();
    });

    $(document).on('click', '#monthview', function() {
      calendar.fullCalendar('changeView', 'month');
      sr.sync();
    });

    $(document).on('click', '#todayview', function() {
      calendar.fullCalendar('today');
      sr.sync();
    });

    $(document).on('click', '#btn-new', function() {
      $('#newEvent').modal('show');
      e = {title:'', description:'', start:moment(), end:moment().add(4, 'h'), participant:'1', type:'', className: 'block b-t b-t-2x b-primary'};
      getEvent(e);
    });

    $(document).on('click', '#btn-save', function() {
      var e = getEvent();
      if(e.id){
        calendar.fullCalendar( 'updateEvent', e );
      }else{
        e.id = moment().toDate();
        calendar.fullCalendar( 'renderEvent', e );
      }
      $('#newEvent').modal('hide');
    });
  }
  	

  	function getEvent(event){
	    var el_title = $('#event-title'),
	        el_desc = $('#event-desc'),
	        el_type = $('#event-type'),
	        el_start_date = $('#event-start-date'),
	        el_start_time = $('#event-start-time'),
	        el_end_date = $('#event-end-date'),
	        el_end_time = $('#event-end-time'),
	        el_participant = $('#event-participant');
	    // set date to form
	    if(event){
	      el_title.val(event.title);
	      el_desc.val(event.description);
	      console.log(event.type);
	      el_type.find('input[value="'+event.type+'"]').prop('checked', true);
	      el_participant.html( getParticipant(event, 32) );
	      el_start_date.val(moment(event.start).format("YYYY-MM-DD"));
	      el_start_time.val(moment(event.start).format("HH:mm"));
	      el_end_date.val(moment(event.end).format("YYYY-MM-DD"));
	      el_end_time.val(moment(event.end).format("HH:mm"));
	    // get data from form
	    }else{
	      e.title = el_title.val();
	      e.type = el_type.find('input:checked').val();
	      e.start = moment(el_start_date.val() +' '+ el_start_time.val());
	      e.end = moment(el_end_date.val() +' '+ el_end_time.val());
	      e.description = el_desc.val();
	    }
	    return e;
	}

    function getParticipant(event, size){
	    var participant = '';
	    var size = size || 24;
	    $.each(event.participant.split(','), function (index, value) {
	      participant += '<a href="#" class="avatar w-'+size+'"><img src="../assets/img/a'+value+'.jpg"></a>';
	    });
	    return participant;
	}

	

	$.ajax('http://localhost/edission/contact/calender').done(function(data){
      // make up the start / end date
      $.each(data, function(index,item){
      	
        item.start = moment().startOf('week').add(index, 'd').add(Math.floor((Math.random() * 10) + 1) - index, 'h').add(index*5,'m');
        item.end = moment(item.start).add(Math.floor((Math.random() * 10) + 3) + index/3, 'h');
      });

      console.warn(data)

      option.events = data;
      calendar = $('#fullcalendar').fullCalendar(option);

    
    });


});
  
</script>
@endsection

