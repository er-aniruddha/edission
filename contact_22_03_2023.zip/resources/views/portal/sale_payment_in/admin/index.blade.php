@section('page_title','Payment-In')
<!-- CONTENT START -->
<div id="content" class="flex">
    <div class="d-flex flex fixed-content">
        <div class="aside aside-sm" id="content-aside">
            <div class="d-flex flex-column w-xl modal-dialog bg-body" id="chat-nav">
                <div class="navbar">
                    <div class="input-group flex bg-light rounded">                        
                        <input type="text" class="form-control no-bg no-border no-shadow search" placeholder="Search" required="" id="searchCustomer">
                        <span class="input-group-append">
                            <button class="btn no-bg no-shadow" type="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search text-fade">
                                    <circle cx="11" cy="11" r="8"></circle>
                                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                </svg>
                            </button>
                        </span>
                    </div>
                </div>
                <div class="scrollable hover">
                    <div class="sidenav p-2">
                        <nav class="nav-active-text-primary" >
                            <ul class="nav" id="customerList">
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex flex pr-md-3" id="content-body">
            <div class="d-flex flex-column flex m-0 mb-md-3" id="chat-list">
                <div class="row" style="padding-top: 50px;">
                    <div class="mb-md-3" style="padding-left: 83.5%;">
                        <button class="btn btn-raised btn-wave mb-2 blue text-white"  id="paymentin">Add Payment-In</button>
                    </div>                    
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="payments_table">
                        <thead>
                            <tr>
                                <th style="width: 26px;"><span class="text-muted">#</span></th>
                                <th><span class="text-muted">Date</span></th>
                                <th><span class="text-muted">Invoice No</span></th>
                                <th><span class="text-muted">Customer Name</span></th>
                                <th><span class="text-muted">Payment Type</span></th>
                                <th><span class="text-muted">Prev. Due</span></th>
                                <th><span class="text-muted">Received/Paid</span></th>
                                <th><span class="text-muted">Balance</span></th>
                                <th style="width:50px"></th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- CONTENT END -->
@include('portal.sale_payment_in.paymentModal')
@include('portal.layouts.deleteModal')
</div>
<script>
// global app configuration object
var routes = {
    index: "{{ route('payment.in.index') }}",
    create: "{{ route('payment.in.create') }}",
    update: "{{ route('payment.in.update') }}",
    delete: "{{ route('payment.in.delete') }}",
};
var customer = @json($customers);
// All the vaiables are required for end
</script>
<script type="text/javascript" src="{{asset('resources/js/sale/payment-in.js')}}"></script>