<div id="modal" class="modal fade" aria-modal="true" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog text-dark">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white text-capitalize"></h5><button class="close" data-dismiss="modal">×</button>
            </div>
            <div class="modal-body">
                <div class="modal-body p-4">
                    <form id="brandForm" method="POST">
                        @csrf
                        <div class="form-group mb-3">
                            <label class="text-muted">Brand Name</label>
                            <input class="form-control text-capitalize" type="text" id="brand_name" name="brand_name">
                            <span class="text-danger" id="brand_name_error"></span>
                        </div>
                        <div class="form-group mb-3">
                            <label class="text-muted">Brand Description</label>
                            <input class="form-control text-capitalize" type="text" id="brand_desc" name="brand_desc">
                            <span class="text-danger" id="brand_desc_error"></span>
                        </div>
                        <div class="form-group mb-3">
                            <label class="text-muted">Company</label>
                            <select class="form-control select2" name="supplier_id" id="supplier_id" tabindex="-1" aria-hidden="true">
                                <option value="0" selected>Select company</option>
                                @foreach($suppliers as $supplier)                                   
                                <option value="{{$supplier->supplier_id}}">{{ ucwords(trans($supplier->supplier_name))}}</option>
                                @endforeach
                            </select>
                            <span class="text-danger" id="supplier_id_error"></span>
                        </div>
                        <div class="form-group mb-3">
                            <label class="text-muted">Brand Image</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="image" name="image">
                                <span class="text-danger mr-2" id="image_error"></span>
                                <label class="custom-file-label" for="image">Choose file</label>
                            </div>
                            <img id="show-img" style="padding: 10px; width: 100px;" />
                        </div>
                        
                        <div class="form-group mb-3">
                            <label class="text-muted" style="margin-right: 50px;">Publication Status</label>
                            <label class="ui-switch ui-switch-md info m-t-xs" style="top:5px;">
                                <input type="checkbox" id="checkbox"> <i></i>
                                <input type="hidden" name="brand_stat" id="brand_stat" value="0">
                            </label>
                        </div>
                        <div class="modal-footer">
                            <input type="hidden" name="brand_id" id="brand_id" />
                            <button class="btn btn-outline-dark" data-dismiss="modal" onclick=" 
                        document.getElementById('show-img').removeAttribute('src'); this.form.reset()">Close</button>
                            <button class="btn btn-primary" id="addBtn">Save Changes</button>
                            <button class="btn btn-primary hide" id="editBtn">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
</div>