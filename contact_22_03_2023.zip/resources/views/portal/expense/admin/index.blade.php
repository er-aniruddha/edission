@section('page_title','Expenses')
<!-- CONTENT START -->
<div id="content" class="flex">
    <div class="">
        <div class="page-hero b-b" id="page-hero">
            <div style="padding-right: 2rem; padding-left: 2rem;">
                <div class="card flex">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-9">
                                <div class="row row-sm">
                                    <div class="col-4">
                                        <div class="text-highlight text-md y-expence text-warning">00</div><small>LAST 1 YEAR</small>
                                    </div>
                                    <div class="col-4">
                                        <div class="text-highlight text-md m-expence text-success">00</div><small>LAST 1 MONTH</small>
                                    </div>
                                    <div class="col-4">
                                        <div class="text-highlight text-md d-expence text-info">00</div><small>LAST 7 DAYS</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3" style="float: right;">
                                <button class="btn btn-raised btn-wave blue text-white add" data-toggle="modal" data-target="#modal">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus">
                                        <line x1="12" y1="5" x2="12" y2="19"></line>
                                        <line x1="5" y1="12" x2="19" y2="12"></line>
                                    </svg>
                                    Add
                                </button>
                                <button class="btn btn-raised btn-wave btn-outline-primary" data-toggle="dropdown">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-download-cloud">
                                        <polyline points="8 17 12 21 16 17"></polyline>
                                        <line x1="12" y1="12" x2="12" y2="21"></line>
                                        <path d="M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29"></path>
                                    </svg>
                                    Export
                                </button>
                                <div class="dropdown-menu" role="menu" x-placement="bottom-start">
                                    <a class="dropdown-item export" id=".buttons-csv">
                                        <i class="badge badge-circle text-primary"></i> CSV
                                    </a>
                                    <a class="dropdown-item export" id=".buttons-excel">
                                        <i class="badge badge-circle text-primary"></i> EXCEL
                                    </a>
                                    <a class="dropdown-item export" id=".buttons-pdf">
                                        <i class="badge badge-circle text-primary"></i> PDF
                                    </a>
                                    <a class="dropdown-item export" id=".buttons-print">
                                        <i class="badge badge-circle text-primary"></i> Print
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="page-content" id="page-content">
            <div class="padding">
                <div class="table-responsive">
                    <table id="expense_table" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 26px;"><span class="text-muted">SL No</span></th>
                                <th style="width: 40px;"><span class="text-muted">Date</span></th>
                                <th><span class="text-muted">Fuel</span></th>
                                <th><span class="text-muted">Travelling</span></th>
                                <th><span class="text-muted">Transport</span></th>
                                <th><span class="text-muted">Tiffin</span></th>
                                <th><span class="text-muted">Room Rent</span></th>
                                <th><span class="text-muted">Salary</span></th>
                                <th><span class="text-muted">Other Exp.</span></th>
                                <th><span class="text-muted">Total</span></th>
                                <th style="width: 16%;"><span class="text-muted">Action</span></th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- CONTENT END -->
@include('portal.expense.modal')
@include('portal.layouts.deleteModal')
</div>
<script>
// global app configuration object
var routes = {
    index: "{{ route('expense.index') }}",
    create: "{{ route('expense.create') }}",
    update: "{{ route('expense.update') }}",
    delete: "{{ route('expense.delete') }}",
    details: "{{ route('expense.details') }}",
};
</script>
<script type="text/javascript" src="{{asset('resources/js/expense.js')}}"></script>