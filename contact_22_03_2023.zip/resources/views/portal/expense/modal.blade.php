<div id="modal" class="modal fade"  aria-modal="true" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog text-dark">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white"></h5><button class="close" data-dismiss="modal">×</button>
            </div>
            <div class="modal-body">
                <form id="expenseForm" method="POST">  
                    @csrf
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Date</label>
                        <div class="col-sm-9">
                            <input data-provide="datepicker" id="date" name="date" type="text" class="form-control date" placeholder="Date">
                            <span class="text-danger" id="date_error"></span>
                        </div>                        
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 text-muted">Fuel</label>
                        <div class="col-sm-9">
                            <input class="form-control" type="text" name="fuel" id="fuel" placeholder="Fuel">  
                            <span class="text-danger" id="fuel_error"></span>   
                        </div>      
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Travelling</label>
                        <div class="col-sm-9">
                            <input id="travelling" name="travelling" type="text" class="form-control" placeholder="Travelling">
                            <span class="text-danger" id="travelling_error"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Transport</label>
                        <div class="col-sm-9">
                            <input id="transport" name="transport" type="text" class="form-control" placeholder="Transport">
                            <span class="text-danger" id="transport_error"></span>
                        </div>                        
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Tiffin</label>
                        <div class="col-sm-9">
                            <input  id="tiffin" name="tiffin"  type="text" class="form-control" placeholder="Tiffin">
                            <span class="text-danger" id="tiffin_error"></span>
                        </div>                   
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Room Rent</label>
                        <div class="col-sm-9">
                            <input  id="room_rent" name="room_rent"  type="text" class="form-control" placeholder="Room Rent">
                            <span class="text-danger" id="room_rent_error"></span>
                        </div>                   
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Salary</label>
                        <div class="col-sm-9">
                            <input  id="salary" name="salary"  type="text" class="form-control" placeholder="Salary">
                            <span class="text-danger" id="salary_error"></span>
                        </div>                   
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Other Expnses</label>
                        <div class="col-sm-9">
                            <input id="extra_exp" name="extra_exp" type="text" class="form-control" placeholder="Other Expnses">
                            <span class="text-danger" id="extra_exp_error"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Total Price</label>
                        <div class="col-sm-9">
                            <input id="total" name="total" type="text" class="form-control" placeholder="Total Price" readonly="">
                            <span class="text-danger" id="total_error"></span>
                        </div>                        
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Remarks</label>
                        <div class="col-sm-9">
                            <textarea id="remarks" name="remarks" class="form-control" rows="6"></textarea>
                            <span class="text-danger" id="remarks_error"></span>
                        </div>
                    </div>  
                    <div class="modal-footer">
                        <input type="hidden" name="expense_id" id="expense_id"/>
                        <button class="btn gd-primary text-white btn-rounded" id="addBtn">Save</button>
                        <button class="btn gd-warning text-white btn-rounded hide" id="editBtn">Update</button>
                    </div>   
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
</div>