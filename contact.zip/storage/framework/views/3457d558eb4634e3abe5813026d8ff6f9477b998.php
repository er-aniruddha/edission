<div id="viewModal" class="modal fade show" data-backdrop="true" style="display: none;" aria-modal="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" style="padding: 1rem; width: 115%;">
        	<div class="modal-header">
            	<div class="modal-title text-md">Edit Customer</div>
        	</div>
            <div class="modal-body">
            	<div class="row">                		
            		<div class="col-md-6">
            			<div class="col-6">
            				<small class="text-primary">Name</small>
            				<div class="mt-2 font-weight-500" id="name"></div>
            			</div>
            			
						<div class="md-form-group float-label">
                            <input type="text" class="md-input" value="" name="s_name" id="s_name" onkeyup="this.setAttribute('value', this.value);" required=""><label>Last Name*</label>
                            <span class="text-danger mr-2" id="s_name_error"></span>
                        </div>
						<div class="md-form-group float-label">
                            <input type="text" class="md-input" value="" name="shop_name" id="shop_name" onkeyup="this.setAttribute('value', this.value);" required=""><label>Shop Name *</label>
                            <span class="text-danger mr-2" id="shop_name_error"></span>
                        </div>
                        <div class="md-form-group float-label">
                            <input type="number" class="md-input" value="" name="phone_1" id="phone_1" onkeyup="this.setAttribute('value', this.value);" required="" onkeypress="if(this.value.length==10) return false;"><label>Phone 1 *</label>
                            <span class="text-danger mr-2" id="phone_1_error"></span>
                        </div>
                        <div class="md-form-group float-label">
                            <input type="number" class="md-input" value="" name="phone_2" id="phone_2" onkeyup="this.setAttribute('value', this.value);" required="" onkeypress="if(this.value.length==10) return false;"><label>Phone 2</label>
                            <span class="text-danger mr-2" id="phone_2_error"></span>
                        </div>
                        <div class="md-form-group float-label">
                            <input type="number" class="md-input" value="" name="whatsapp_no" id="whatsapp_no" onkeyup="this.setAttribute('value', this.value);" required=""><label>Whats App</label>
                            <span class="text-danger mr-2" id="whatsapp_no_error"></span>
                        </div>
                        <div class="md-form-group float-label">
                            <input type="email" class="md-input" value="" name="whatsapp_no" id="whatsapp_no" onkeyup="this.setAttribute('value', this.value);" required=""><label>E-mail ID</label>
                            <span class="text-danger mr-2" id="email_error"></span>
                        </div>
                	</div><!-- div col-md-6 -->
            		<div class="col-md-6">
            			<div class="form-group">
	                        <label class="text-muted">Routes</label>
	                        <select class="form-control" name="route_id" id="route" 
	                        tabindex="-1" aria-hidden="true">
	                            <option value="" selected>Select Route</option>
	                            <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                <option value="<?php echo e($route->route_id); ?>"><?php echo e($route->route_name); ?></option>
	                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
	                        </select>
	                        <span class="text-danger mr-2" id="route_error"></span>

	                    </div>
						<div class="md-form-group float-label">
                            <input type="text" class="md-input" value="" name="locality" id="locality" 
                                onkeyup="this.setAttribute('value', this.value);" required=""><label>Locality *</label>
                                <span class="text-danger mr-2" id="locality_error"></span>
                        </div>
						<div class="form-group">
	                        <label class="text-muted">District</label>
	                        <select class="form-control" name="district" id="district" 
	                        tabindex="-1" aria-hidden="true">
	                            <option value="" selected>Select District</option>
	                            <optgroup label="West Bengal">
	                                <option value="North 24 Parganas">North 24 Parganas</option>
	                                <option value="Nadia">Nadia</option>
	                            </optgroup>                            
	                        </select>
	                        <span class="text-danger mr-2" id="district_error"></span>
            			</div>
            			<div class="md-form-group float-label">
                            <input type="number" class="md-input" value="" name="pin" id="pin" 
                            onkeyup="this.setAttribute('value', this.value);" required=""
                                onKeyPress="if(this.value.length==6) return false;"><label>PIN *</label>
                            <span class="text-danger mr-2" id="pin_error"></span>
                        </div>
                        <div class="md-form-group float-label">
                            <input type="text" class="md-input" value="West Bengal" name="state" id="state"
                                onkeyup="this.setAttribute('value', this.value);" readonly><label>State *</label>
                        </div>
                        <div class="md-form-group float-label">
                            <input type="text" class="md-input" value="" name="addline_1" id="addline_1" 
                            onkeyup="this.setAttribute('value', this.value);" required="" formnovalidate>
                            <label>Address 1</label>
                                <span class="text-danger mr-2" id="addline_1_error"></span>
                        </div>
                        <div class="md-form-group float-label">
                            <input type="text" class="md-input" value="" name="addline_2" id="addline_2" 
                            onkeyup="this.setAttribute('value', this.value);" required><label>Address 2</label>
                            <span class="text-danger mr-2" id="addline_2_error"></span>
                        </div>
                	</div> <!-- div col-md-6 -->
            	</div><!-- row -->					
            </div>
        	<div class="dropdown-divider"></div>
            <div class="modal-footer">
            	<button type="button" class="btn btn-outline-dark" data-dismiss="modal">Close</button> 
            	<button type="button" class="btn btn-primary" id="editBtn">Update</button>
            </div>
	    </div>
    </div>
        <!-- /.modal-content -->
    </div>
</div><?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/customer/viewModal.blade.php ENDPATH**/ ?>