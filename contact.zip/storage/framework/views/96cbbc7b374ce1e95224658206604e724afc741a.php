<form id="costForm" method="POST">
<?php echo csrf_field(); ?>
<div id="modal" class="modal fade" data-backdrop="true" style="display: none; padding-right: 17px;" aria-modal="true">
    <div class="modal-dialog modal-lg-size">
        <div class="modal-content box-shadow mb-4">
            <div class="modal-header">
                <h5 class="modal-title">Production\Purchase Cost</h5>
                <div class="form-group">
                	<input type="text" class="form-control" name="cost_name" id="cost_name"
                	style="padding-right: 50px;" placeholder="Give a Name">
                	<span class="text-danger mr-2" id="cost_name_error"></span>
                </div>

            </div>
            <div class="modal-body p-4">
                
                	<table class="table table-bordered">
                		<thead>
                			<tr>
                				<th>Cost Name</th>
                				<th>Quantity</th>
                				<th>Price</th>
                				<th>Total</th>
                				<th>
                					<a href="javascript:void(0)" class="addRow">
                						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
                					</a>
                				</th>
                			</tr>
                		</thead>
                	
                	<tbody>
                		<tr>
                			<td>                				
	                			<input type="text" class="form-control" name="cost_item_name[]"
	                			id="cost_item_name" placeholder="Enter Item Name"> 
	                			<span class="text-danger mr-2" id="cost_item_name_error_0"></span>
                			</td>
                			<td>	                				
	                			<input type="number" class="form-control qty" name="cost_qty[]" 
	                			id="cost_qty" placeholder="Enter Quantity"> 
	                			<span class="text-danger mr-2" id="cost_qty_error_0"></span>
                			</td>
                			<td>
                				<input type="number" class="form-control price" name="cost_price[]" 
                				id="cost_price" placeholder="Enter Price"> 
                				<span class="text-danger mr-2" id="cost_price_error_0"></span> 
                			</td>
                			<td>
                				<input type="number" class="form-control subTotal" name="cost_sub_total[]"
                				id="cost_sub_total" placeholder="Total" readonly>  
                			</td>
                			<td>
                				<a href="javascript:void(0)" class="btn btn-icon" style="border: 1px solid #f54394" onclick="alert('You can not remove last row');">
                					<svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="color: red;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>
                					</svg>
                				</a>
                			</td>
                		</tr>
                	</tbody>
                	<tfoot>
                		<td style="border: none"></td>
                        <td>
                        	<label class="text-muted" style="margin-right: 10px">Publication Status</label>
                        	<label class="ui-switch ui-switch-md info m-t-xs" style="top:5px;">
								<input type="checkbox" id="checkbox"> <i></i>
	                            <input type="hidden" name="cost_stat" id="cost_stat" value="0">
							</label>		
                        </td>
                        
                        <td style="text-align: right; padding-top: 15px;">Total</td>
                        <td>
                        	<input type="number" class="form-control" name="cost_total" id="cost_total" aria-describedby="emailHelp" placeholder="Total" readonly=""></td>
                	</tfoot>
                	</table>

                    <div class="modal-footer">          
                    	<button class="btn btn-outline-dark" data-dismiss="modal" onclick="this.form.reset()">Close</button> 
                    	<button class="btn btn-primary" id="addBtn">Save</button>
                    	<button class="btn btn-primary hide" id="editBtn">Update</button>
                    </div>
            </div>
        </div>
    </div>
    <!-- /.modal-content -->
</div>
</form><?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/cost/modal.blade.php ENDPATH**/ ?>