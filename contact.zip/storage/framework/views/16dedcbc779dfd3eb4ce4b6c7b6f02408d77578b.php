<form id="productForm" method="POST">
    <?php echo csrf_field(); ?>
    <div id="modal" class="modal fade" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog">
            <div class="modal-content box-shadow mb-4">
                <div class="modal-header bg-primary">
                    <h5 class="modal-title text-white"></h5>
                </div>
                <div class="modal-body p-4">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="text-muted">Brand</label>
                                <select class="form-control select2 brand" name="brand_id" id="brand_id" tabindex="-1" aria-hidden="true">
                                    <option value="0" selected>Select Brand</option>
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($brand->brand_stat == 1): ?>
                                    <option value="<?php echo e($brand->brand_id); ?>"><?php echo e(ucwords(trans($brand->brand_name))); ?></option>
                                    <?php else: ?>
                                    <option value="<?php echo e($brand->brand_id); ?>" disabled="disabled"><?php echo e(ucwords(trans($brand->brand_name))); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger" id="brand_id_error"></span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="text-muted">Product Type</label>
                                <select class="form-control select2" name="pro_type" id="production" tabindex="-1" aria-hidden="true">
                                    <option value="0" selected>Select Product Type</option>
                                    <option value="Manufacturing">Manufacturing</option>
                                    <option value="Purchasing">Purchasing</option>
                                </select>
                            </div>
                            <span class="text-danger" id="pro_type_error"></span>
                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label class="text-muted">Product Name</label>
                        <select class="form-control productList select2" name="product_name" id="product_name">
                            <option value="0" selected="">Product Name</option>
                        </select>
                        <span class="text-danger" id="product_name_error"></span>
                    </div>
                    <div class="form-group mb-3">
                        <label class="text-muted">Product Description</label>
                        <input type="text" class="form-control" id="product_desc" name="product_desc" placeholder="Product description">
                        <span class="text-danger" id="product_desc_error"></span>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="text-muted">Primry Unit</label>
                                <select class="form-control select2 priUnit" name="primary_unit" id="primary_unit" tabindex="-1" aria-hidden="true">
                                    <option value="" selected>Select Unit</option>
                                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($unit->unit_id); ?>" data-name=""><?php echo e(ucwords(trans($unit->unit_name))); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger" id="primary_unit_error"></span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="text-muted">Secondary Unit</label>
                                <select class="form-control select2 secUnit" name="secondary_unit" id="secondary_unit" tabindex="-1" aria-hidden="true">
                                    <option value="" selected>Select Unit</option>
                                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($unit->unit_id); ?>"><?php echo e(ucwords(trans($unit->unit_name))); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger" id="secondary_unit_error"></span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <button type="button" class="btn btn-sm btn-primary disabled mb-3" id="convBtn">
                                <span class="mx-1">Add Conversion Rate</span>
                            </button>
                        </div>
                        <div class="col-sm-12 conversion" style="display: none;">
                            <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="selectedPriUnit"></span>
                                </div>
                                <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" type="number" name="no_of_pcs" id="no_of_pcs" autocorrect="off" autofocus="autofocus" autocomplete="off" animate="true" autocomplete="off" autocapitalize="off" spellcheck="false" oninput="this.value = Math.round(this.value);" placeholder="Enter value">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="selectedSecUnit"></span>
                                </div>
                            </div>
                            <span class="text-danger" id="no_of_pcs_error"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="text-muted">Product Image</label>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="image" name="image">
                                    <span class="text-danger" id="image_error"></span>
                                    <label class="custom-file-label" for="image">Choose file</label>
                                </div>
                                <img id="show-img" style="padding: 10px; width: 100px;" />
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="text-muted">Product Retail MRP</label>
                                <input class="form-control number" type="text" value="" name="product_r_mrp" id="product_r_mrp" required="" placeholder="MRP" disabled="disabled">
                                <span class="text-danger" id="product_mrp_r_error"></span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="text-muted">Product Distributor MRP</label>
                                <input class="form-control number" type="text" value="" name="product_d_mrp" id="product_d_mrp" required="" placeholder="MRP" disabled="disabled">
                                <span class="text-danger" id="product_mrp_d_error"></span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="unitpricer" style="display: none;">
                                <div class="input-group input-group-sm mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="selectedPriUnit2R"></span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" id="priUnit_price_r" disabled="">
                                </div>
                                <div class="input-group input-group-sm mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="selectedSecUnit2R"></span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" id="secUnit_price_r" disabled="">
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="unitpriced" style="display: none;">
                                <div class="input-group input-group-sm mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="selectedPriUnit2D"></span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" id="priUnit_price_d" disabled="">
                                </div>
                                <div class="input-group input-group-sm mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="selectedSecUnit2D"></span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" id="secUnit_price_d" disabled="">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label class="text-muted">Publication Status</label></br>
                        <label class="ui-switch ui-switch-md success m-t-xs" style="top:5px;">
                            <input type="checkbox" id="checkbox"> <i></i>
                        </label>
                        <input type="hidden" name="product_stat" id="product_stat" value="0">
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="product_id" id="product_id" />
                        <button class="btn btn-outline-dark" data-dismiss="modal" onclick=" 
                        document.getElementById('show-img').removeAttribute('src');">Close</button>
                        <button type="submit" class="btn btn-primary" id="addBtn">Save Changes</button>
                        <button type="submit" class="btn btn-primary hide" id="editBtn">Update</button>
                    </div>
</form>
</div>
</div>
</div>
<!-- /.modal-content -->
</div><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/product/modal.blade.php ENDPATH**/ ?>