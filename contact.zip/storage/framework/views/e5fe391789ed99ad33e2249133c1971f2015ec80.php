<!-- Confirm Modal -->
<form method="POST" id="proDelForm">
    <?php echo csrf_field(); ?>
    <div id="delModal" class="modal fade" data-backdrop="true" style="padding-right: 17px;"
        aria-modal="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title text-md"></div>
                    <button class="close" data-dismiss="modal">×</button>
                </div>
                <div class="modal-body">
                    <div class="p-4 text-center">
                        Are you sure you want to remove this data?
                    </div>
                </div>
                    <input type="hidden" name="del_id" id="del_id">
                    <div class="modal-footer"><button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal" id="delProBtn">Delete</button>
                </div>
            </div><!-- /.modal-content -->
        </div>
    </div>
</form><?php /**PATH C:\xampp\htdocs\contact\resources\views/portal/layouts/deleteModal.blade.php ENDPATH**/ ?>