<?php echo $__env->make('portal.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('pageTitle','Register'); ?>
<div class="flex">
    <div class="w-xl w-auto-sm mx-auto py-5">
        <div class="p-4 d-flex flex-column h-100">
            <!-- brand --> 
            <a href="<?php echo e(url('/')); ?>" class="navbar-brand align-self-center">
                <img src="<?php echo e(asset('public/portal/images/logo-01.png')); ?>" alt="..."> 
                <!-- span class="hidden-folded d-inline l-s-n-1x align-self-center">Omnipresenceway</span> --> 
            </a>
            <!-- / brand -->
        </div>
        <div class="card">
            <div id="content-body">
                <div class="p-3 p-md-5">
                    <h5>Register</h5>
                    <p><small class="text-muted">Register to access your account</small></p>

                    <form role="form" method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="md-form-group float-label">    
                            <input type="text" class="md-input <?php $__errorArgs = ['f_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            onkeyup="this.setAttribute('value', this.value);" name="f_name" id="f_name" value="<?php echo e(old('f_name')); ?>" required>
                            <label>First name</label>
                            <?php $__errorArgs = ['f_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="md-form-group float-label">
                            <input type="text" class="md-input <?php $__errorArgs = ['s_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            onkeyup="this.setAttribute('value', this.value);" name="s_name" id="s_name" value="<?php echo e(old('s_name')); ?>" required>
                            <label>Surname</label>

                            <?php $__errorArgs = ['s_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="md-form-group float-label">
                            <input type="email" class="md-input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                             onkeyup="this.setAttribute('value', this.value);" name="email" id="email" value="<?php echo e(old('email')); ?>" required>
                             <label>Email</label>

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="md-form-group float-label">
                            <input type="password" class="md-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="password" id="password" value="<?php echo e(old('password')); ?>" required>
                             <label>Password</label>
                            
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="md-form-group float-label">
                            <input type="password" class="md-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                             name="password_confirmation" id="password-confirm" autocomplete="new-password" required>
                            <label>Confirm Password</label>
                        </div>
                        <div style="border-top: 1px solid #ccc;
                        padding-bottom: 20px;
                        margin-top: 30px;
                        width: 100%;"></div>
                        <button type="submit" class="btn btn-raised btn-wave mb-4 green text-white">Sign Up</button>
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-raised btn-wave mb-4 blue text-white" style="float: right;">Sign In</a>
                    </form>
                    
                </div>
            </div>
        </div>
        <div class="text-center text-muted">© Copyright. Edission</div>
    </div>
</div>
<?php echo $__env->make('portal.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/auth/register.blade.php ENDPATH**/ ?>