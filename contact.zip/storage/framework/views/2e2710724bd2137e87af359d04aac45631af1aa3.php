<div id="payMentModal" class="modal fade show"  aria-modal="true">
    <div class="modal-dialog text-dark" style="max-width:38%;">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white">Add Payment</h5><button class="close" data-dismiss="modal">×</button>
            </div>
            <div class="modal-body">
                <form id="payment-form" method="POST">  
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Date</label>
                        <div class="col-sm-9">
                            <input data-provide="datepicker" id="date" name="date" type="text" class="form-control date" placeholder="Date">
                            <span class="text-danger" id="date_error"></span>
                        </div>                        
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Customer Name</label>
                        <div class="col-sm-9">
                            <select class="form-control select2 customer" name="customer_id" id="c_id">
                                <option selected="" value="">Select customer</option>
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($customer->customer_id); ?>" data-prevbal="<?php echo e($customer->balance); ?>"><?php echo e($customer->f_name); ?> <?php echo e($customer->s_name); ?> (<?php echo e($customer->shop_name); ?>) (<?php echo e($customer->phone_1); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                     <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Previous Due</label>
                        <div class="col-sm-9">
                            <input id="prev_balance" name="prev_balance" type="number" class="form-control" value="" readonly="">
                        </div>
                    </div>
                     <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Received/Paid</label>
                        <div class="col-sm-9">
                            <input id="received" name="received" type="number" class="form-control" placeholder="Received/Paid">
                            <span class="text-danger" id="received_error"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Balance</label>
                        <div class="col-sm-9">
                            <input id="balance" name="balance" type="number" class="form-control" value="0" readonly="">
                            <span class="text-danger" id="balance_error"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Payment type</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="payment_type" id="payment_type" tabindex="-1" aria-hidden="true">
                                <option value="" selected="">Select an option</option>
                                <option value="cash">Cash</option>
                                <option value="online">Online</option>
                            </select>
                        <span class="text-danger text-sm" id="payment_type_error"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Remarks</label>
                        <div class="col-sm-9">
                            <textarea id="remarks" name="remarks" class="form-control" rows="6"></textarea>
                            <span class="text-danger" id="remarks_error"></span>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button class="btn btn-raised btn-wave mb-2 w-xs blue text-white" id="savePayBtn">Save</button>
                        <button class="btn gd-warning text-white btn-rounded hide">Update</button>
                    </div>   
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
</div><?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/sale_payment_in/paymentModal.blade.php ENDPATH**/ ?>