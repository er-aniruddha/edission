<div id="modal" class="modal fade" data-backdrop="true" style="display: none; padding-right: 17px;" aria-modal="true">
    <div class="modal-dialog modal-lg-size">
        <div class="modal-content box-shadow mb-4">
            <div class="modal-header">
                <h5 class="modal-title">Form</h5><button class="close" data-dismiss="modal">×</button></div>
            <div class="modal-body p-4">
                <form id="brandForm" method="POST">
                	<?php echo csrf_field(); ?>
                    <div class="md-form-group float-label">
                    	<input class="md-input" value="" id="brand_name" name="brand_name" onkeyup="this.setAttribute('value', this.value);" required="">
                    	<label>Brand Name</label>
                    	<span class="text-danger mr-2" id="brand_name_error"></span>
                    </div>

                    <div class="md-form-group float-label">
                    	<input class="md-input" value="" id="brand_desc" name="brand_desc" onkeyup="this.setAttribute('value', this.value);" required="">
                    	<label>Brand Description</label>
                    	<span class="text-danger mr-2" id="brand_desc_error"></span>
                    </div>

                    <div class="form-group">
                    	<label class="text-muted">Brand Image</label>                    	
                		<div class="custom-file">
                			<input type="file" class="custom-file-input" id="image" name="image">
                			<label class="custom-file-label" for="image">Choose file</label>
                		</div> 
                		<img id="show-img" style="padding: 10px; width: 100px;" />  
                		<span class="text-danger mr-2" id="image_error"></span>                 	
                    </div>	

                    <div class="form-group">
						<label class="text-muted" style="margin-right: 50px;">Publication Status</label>
						<label class="ui-switch ui-switch-md info m-t-xs" style="top:5px;">
							<input type="checkbox" name="brand_stat" id="brand_stat" value="0"> <i></i>
						</label>						
					</div>

                    <div class="modal-footer">
                    	<button class="btn btn-outline-dark" data-dismiss="modal">Close</button> 
                    	<button class="btn btn-primary" id="addBtn">Save Changes</button>
                    	<button class="btn btn-primary hide" id="editBtn">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.modal-content -->
</div><?php /**PATH C:\xampp\htdocs\contact\resources\views/portal/brand/modal.blade.php ENDPATH**/ ?>