<div id="content" class="flex">
    <div class="">
        <div class="page-hero page-container" id="page-hero">
            <div class="padding d-flex">
                <div class="page-title">
                    <h2 class="text-md text-highlight">Products</h2>
                    <!-- <small class="text-muted">Products</small> -->
                </div>
                <div class="flex"></div>
                <div>
                    <a href="<?php echo e(route('product.create')); ?>" class="createPro btn btn-white">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                        Add
                    </a>
                </div>
                <div class="loadCreatBtn btn btn-white" style="display: none;">
                    <div class="loading" style="width: 20px; height: 20px;"></div>
                </div>
                
            </div>
        </div>
        <script>    
            $(".createPro").click(function name() {
                $('.createPro').hide();
                $('.loadCreatBtn').show();
            })
        </script>
        <div class="page-content page-container" id="page-content">
            <div class="padding">
                <div class="table-responsive">
                    <div id="datatable_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                        <div class="row">   
                            <div class="col-sm-12 col-md-6">
                                <div class="dataTables_length"  style="display: inline;">
                                    <label>Show </label>
                                        <select name="product_table_length" aria-controls="product_table" 
                                        class="custom-select custom-select-sm form-control form-control-sm" id="product_table_length">
                                            <option value="10">10</option>
                                            <option value="25">25</option>
                                            <option value="50">50</option>
                                            <option value="100">100</option>
                                        </select> entries

                                </div>
                            </div>
                            <div class="col-sm-12 col-md-6">
                                <div class="dataTables_filter" style="float: right; display: inline;">
                                    <label>Search:</label>
                                    <input type="search" class="form-control form-control-sm" placeholder="" aria-controls="product_table" id="dataTableSearch">
                                </div>
                            </div>
                        </div>
                    </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <table class="table table-theme table-row v-middle dataTable no-footer" role="grid"
                                    aria-describedby="datatable_info" id="product_table">
                                    <thead>
                                        <tr role="row">
                                            <th class="sorting_asc" tabindex="0" aria-controls="datatable" rowspan="1"
                                                colspan="1" style="width: 26px;" aria-sort="ascending"
                                                aria-label="ID: activate to sort column descending"><span
                                                    class="text-muted">SL No</span></th>
                                            <th class="sorting" tabindex="0" aria-controls="datatable" rowspan="1"
                                                colspan="1" style="width: 34px;"
                                                aria-label="Owner: activate to sort column ascending"><span
                                                    class="text-muted">Image</span></th>
                                            <th class="sorting" tabindex="0" aria-controls="datatable" rowspan="1"
                                                colspan="1" style="width: 692px;"
                                                aria-label="Project: activate to sort column ascending"><span
                                                    class="text-muted">Product Name</span></th>
                                            <th class="sorting_disabled" rowspan="1" colspan="1" style="width: 28px;"
                                                aria-label="Tasks"><span class="text-muted d-none d-sm-block">Category
                                                    Name</span></th>
                                            <th class="sorting_disabled" rowspan="1" colspan="1" style="width: 31px;"
                                                aria-label="Finish"><span
                                                    class="text-muted d-none d-sm-block">Status</span></th>
                                            <th class="sorting_disabled" rowspan="1" colspan="1" style="width: 16px;"
                                                aria-label=""></th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('portal.product.descriptionModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('portal.layouts.deleteModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(function () {
        /* Show Product Table Start */
        var base_url = window.location.origin;
        var dataTable = $('#product_table').DataTable({
            processing: true,
            serverSide: true,
            
            reponsive:true,
            ajax: {
                url: "<?php echo e(route('product.index')); ?>",
            },
            columns: [
                { data: 'DT_RowIndex', name: 'DT_RowIndex' },
                {
                    data: 'product_img', name: 'product_img', render: function (data, type, full, meta) {
                        return '<span class="w-32 avatar gd-primary"><img src=" '+ base_url + "/anwesh/portal/" + data + '" alt="."></span>';
                    }, orderable: false
                },
                { data: 'product_name', name: 'product_name' },
                { data: 'category_name', name: 'category_name' },
                { data: 'status', name: 'status', },
                { data: 'action', name: 'action', },
            ]
        });
        /* Show Product Table End */
        $("#dataTableSearch").keyup(function() {
            // dataTable.fnFilter(this.value);
            dataTable.search(this.value).draw();
        });  
        $('#product_table_length').change(function(){
            console.log(this.value)
            //column.search( this.value ).draw();
            dataTable.page.len( $(this).val() ).draw();
            // dataTable.search(this.value).draw();
            // dataTable.rows(this.value).invalidate().draw();
        });

        // $.fn.dataTable.ext.classes.sLengthSelect = 'myClass';
        // $('.xx').append("<select><option>10</option><option>50</option></select>");

        /*Product Status Change Start*/
        $(document).on('click','.badge',function(event){
            event.preventDefault()
            let url = $(this).data('url');
            $.ajax({
                method:'GET',
                url:url,
                dataType:'json',
                success:function(response){
                    if(response.offline){
                        let message = response.offline;
                        warning(message);
                        $("#product_table").DataTable().ajax.reload();
                    }
                    if(response.online){
                        let message = response.online;
                        info(message);
                        $("#product_table").DataTable().ajax.reload();
                    }
                },//ajax success end
                error:function(error){
                    if (error.status == 500) {
                        let message = "Something went wrong !!"
                        danger(message)
                    }
                }//ajax error end
            })//ajax end
        })//Product Status Change Function end

        /*Product Remove Start*/
        $(document).on('click','.trash',function(event){
            event.preventDefault()
            let id = $(this).data("id");
            let name = $(this).data("name");
            $("#del_id").val(id);
            $(".modal-title").text(name);
        })//Product Remove ID valuye set to modal
        
        /*Product Delete Function Start */
        $("#proDelForm").on('click',"#delProBtn", function(event){
            event.preventDefault()
            console.log($("#product_id").val())
            let formData = new FormData($("#proDelForm")[0])
            $.ajax({
                method:'POST',
                url:"<?php echo e(route('product.remove')); ?>",
                contentType: false,
                cache: false,
                processData: false,
                dataType: "json",
                data: formData,
                beforeSend:function(){
                    $('#delProBtn').text('Deleting...');
                },
                success:function(response){
                    if(response.success){
                        let message = response.success;
                        warning(message);
                        $("#proDelForm")[0].reset();   
                        $('#delProBtn').text('Delete');
                        $("#product_table").DataTable().ajax.reload();
                    }
                },//ajax success end
                error:function(error){
                    $('#delProBtn').text('Delete');
                    if (error.status == 500) {
                        let message = "Something went wrong !!"
                        danger(message)
                    }
                }//ajax error end
            })//ajax end
        })//porduct delete function end here

    })
</script><?php /**PATH C:\xampp\htdocs\anwesh\portal\resources\views/portal/product/adminIndex.blade.php ENDPATH**/ ?>