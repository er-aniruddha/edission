<!-- CONTENT START -->
<div id="content" class="flex">
    <div class="d-flex flex fixed-content">
        <div class="aside aside-sm" id="content-aside">
            <div class="d-flex flex-column w-xl modal-dialog bg-body" id="chat-nav">
                <div class="navbar">
                    <div class="input-group flex bg-light rounded">
                        <input type="text" class="form-control no-bg no-border no-shadow search" placeholder="Search" required="" id="searchProduct">
                        <span class="input-group-append">
                            <button class="btn no-bg no-shadow" type="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search text-fade">
                                    <circle cx="11" cy="11" r="8"></circle>
                                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                </svg>
                            </button>
                        </span>
                    </div>
                </div>
                <div class="scrollable hover">
                    <div class="sidenav p-2">
                        <nav class="nav-active-text-primary" data-nav="">
                            <ul class="nav" id="productList">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="active list-item">
                                    <a href="javascript:void(0);" data-pjax-state="anchor" class="mb-2 product" id="<?php echo e($pro->product_id); ?>">
                                        <img src="<?php echo e(asset($pro->product_img)); ?>" alt="..." class="w-40 r">
                                        <span class="nav-text text-capitalize"><?php echo e($pro->product_name); ?></span>
                                        <span class="nav-badge">
                                            <span class="badge bg-primary-lt"><?php echo e($pro->in_hand_stock); ?></span>
                                        </span>
                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex flex pr-md-3" id="content-body">
            <div class="d-flex flex-column flex card m-0 mb-md-3" id="chat-list">
                <div class="navbar b-b">
                    <div class="card-body">
                        <div class="row row-sm">
                            <div class="col-sm-12">
                                <div class="mb-2"><div class="mt-2 font-weight-500"><h3 class="text-info product-name text-capitalize">Product Name</h3></div></div>
                                <div class="row row-sm">
                                    <div class="col-3">
                                        <div class="text-highlight text-md sale-price">00</div><small>SALE PRICE</small>
                                    </div>
                                    <div class="col-3">
                                        <div class="text-danger text-md purchase-price">00</div><small>PURCHASE PRICE</small>
                                    </div>
                                    <div class="col-3">
                                        <div class="text-md stock-qty">00</div><small>STOCK QUANTITY</small>
                                    </div>
                                    <div class="col-3">
                                        <div class="text-md stock-val">00</div><small>STOCK VALUE</small>
                                    </div>
                                </div>
                            </div>                            
                        </div>
                    </div>
                </div>
                <div class="table-responsive" style="background-color:#f9f9fa;">
                    <table class="table table-theme table-row v-middle" id="transaction_table">
                        <thead>
                            <tr>
                                <th class="text-muted sortable" data-toggle-class="asc">Type</th>
                                <th class="text-muted sortable" data-toggle-class="asc">Party</th>
                                <th class="text-muted sortable" data-toggle-class="asc">Date</th>
                                <th class="text-muted sortable" data-toggle-class="asc">Quantity</th>
                                <th class="text-muted sortable" data-toggle-class="asc">Unit Name</th>
                                <th class="text-muted sortable" data-toggle-class="asc">Unit Price</th>
                                <th class="text-muted sortable" data-toggle-class="asc">Amount</th>
                                <th class="text-muted sortable" data-toggle-class="asc">Satus</th>
                                <th style="width:50px"></th>
                            </tr>
                        </thead>
                        <tbody>
                                                     
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- CONTENT END -->
</div>
<script>
// global app configuration object
var routes = {
    index: "<?php echo e(route('stock.index')); ?>",
};
var stocksObj = <?php echo json_encode($stocks, 15, 512) ?>;
var stocks = Object.keys(stocksObj).map((key) => [Number(key), stocksObj[key]]);
var productsObj = <?php echo json_encode($products, 15, 512) ?>;
var products = Object.keys(productsObj).map((key) => [Number(key), productsObj[key]]);
// All the vaiables are required for end
</script>
<script type="text/javascript" src="<?php echo e(asset('resources/js/stock.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/stock/admin/index.blade.php ENDPATH**/ ?>