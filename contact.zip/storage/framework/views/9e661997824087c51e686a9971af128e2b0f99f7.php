<form id="newSkuAddForm">
    <?php echo csrf_field(); ?>
    <div id="newModal" class="modal fade modal-open-aside show" data-backdrop="true" style="display: none; padding-right: 17px;" aria-hidden="true" data-class="modal-open-aside">
        <div class="modal-dialog modal-right w-xl">
            <div class="modal-content h-100 no-radius">
                <div class="modal-header">
                    <div class="modal-title text-md">Add SKU</div>
                    <button class="close" data-dismiss="modal">×</button>
                </div>
                <div class="modal-body">
                    <div class="row row-sm">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="text-muted">Product Name</label>
                                <select class="form-control proSelect" name="product_name" id="product_name" tabindex="-1" aria-hidden="true" required="">
                                    <option selected="" value="">Select an option</option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product->product_id); ?>" >
                                    <?php echo e($product->product_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger mr-2" id="product_name_error"></span>
                            </div>
                            <div class="form-group">
                                <label class="text-muted">Maker</label>
                                <select class="form-control proSelect" id="maker_name" name="maker_name" required="" tabindex="-1" aria-hidden="true" required="">
                                    <option selected="" value="0">Select an option</option>
                                    <option value="OWN">OWN</option>
                                </select>
                                <span class="text-danger mr-2" id="maker_name_error"></span>
                            </div>
                            <div class="form-group">
                                <label class="text-muted">Date</label>
                                <input type="text" class="form-control date" data-provide="datepicker" id="date" name="date" value="<?php echo date('d-m-Y') ?>" required="">
                                <span class="text-danger mr-2" id="date_error"></span>
                            </div>
                            <div class="form-group">
                                <label class="text-muted">SKU Code</label>
                                <input type="text" class="form-control" value="" id="sku_code" name="sku_code" readonly="">
                                <span class="text-danger mr-2" id="sku_code_error"></span>
                            </div>
                            <div class="form-group">
                                <label class="text-muted">Cost</label>
                                <select class="form-control proSelect" name="cost_id" id="cost_id" tabindex="-1" aria-hidden="true" required="">
                                    <option selected="" value="">Select an option</option>
                                    <?php $__currentLoopData = $costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
                                        <?php if($cost->cost_stat == 1): ?>
                                            <option value="<?php echo e($cost->cost_id); ?>"><?php echo e($cost->cost_name); ?> / INR - <?php echo e($cost->cost_total); ?></option> 
                                        <?php else: ?>
                                            <option value="<?php echo e($cost->cost_id); ?>" disabled=""><?php echo e($cost->cost_name); ?> / INR - <?php echo e($cost->cost_total); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger mr-2" id="cost_id_error"></span>
                            </div>
                            <div class="form-group">
                                <label class="text-muted">Quantity</label>
                                <input type="number" class="form-control" value="" id="stock_qty" name="stock_qty" placeholder="Enter stock quantity">
                                <span class="text-danger mr-2" id="stock_qty_error"></span>
                            </div>
                            <div class="form-group">
                                <label class="text-muted">Publication Status</label>
                                <label class="ui-switch ui-switch-md info m-t-xs" style="top:5px;">
                                    <input type="checkbox" id="checkbox"> <i></i>
                                    <input type="hidden" name="stock_stat" id="stock_stat" value="0">
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                    <button class="btn btn-primary" id="addBtn">Save Changes</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
    </div>
</form>


<script type="text/javascript">
$(document).ready(function() {
    /* This part for HTML */
    $('input[type="checkbox"]').click(function(event) {
        /* Act on the event */
        if($('#checkbox').is(':checked')){
            $("#stock_stat").val(1)
        }
        else{
            $("#stock_stat").val(0)
        }
    })//set publication status    
    var getAllData=[];
    $('.proSelect').select2({
        width: "288px;"
    });
    $("#product_name").change(function(){        
        getAllData[0] = $("#product_name option:selected").text();
        codeCreate()
    })
    $("#maker_name").change(function(){
        $(this).val($(this).val().toUpperCase());
        getAllData[1] = $("#maker_name").val();
        codeCreate()
    })
    months = [ "JAN", "FEB", "MAR", "APR", "MAY", "JUN","JUL", "AUG", "SEP", "OCT", "NOV", "DEC" ];
    $('.date').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
        width: "100%",
        startDate: "01-03-2021",
        endDate: "0d",
        todayHighlight: true,
    }).on('change',function(){
        var month = months[$(this).datepicker('getDate').getMonth()]   
        getAllData[2] = month;
        codeCreate()
    });
    function codeCreate(){  
        let productName;
        let makerName = getAllData[1];
        let month = getAllData[2];
        if(getAllData[0]){
            productName = getAllData[0].split(/\s/).reduce((response, word) => response += word.slice(0, 2), '');
        }
        // if(getAllData[1]){
        //     makerName = getAllData[1].split(/\s/).reduce((response, word) => response += word.slice(0, 2), '');
        // }
        let code = productName+'-'+makerName+'-'+month;
        $("#sku_code").val(code.toUpperCase())
    }  
    /* This part for HTML */

    /* Add Production Cost Start */ 
    $('#newSkuAddForm').on('click', '#addBtn', function(event) {
        event.preventDefault();
        $("#product_name_error").html(" ")
        $("#maker_name_error").html(" ")
        $("#month_error").html(" ")
        $("#date_error").html(" ")
        $("#sku_code_error").html(" ")
        $("#cost_id_error").html(" ")
        $("#stock_qty_error").html(" ")       
        var formData = new FormData($('#newSkuAddForm')[0]);
        $.ajax({
            method: 'POST',
            url: routes.createNew,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                console.log(response.errors)
                if (response.errors) {
                    if(response.errors.product_name){
                        $("#product_name_error").text(response.errors.product_name[0])
                    }
                    if(response.errors.maker_name){
                        $("#maker_name_error").text(response.errors.maker_name[0])
                    }
                    if(response.errors.month){
                        $("#month_error").text(response.errors.month[0])
                    }
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.sku_code){
                        $("#sku_code_error").text(response.errors.sku_code[0])
                    }
                    if(response.errors.cost_id){
                        $("#cost_id_error").text(response.errors.cost_id[0])
                    }
                    if(response.errors.stock_qty){
                        $("#stock_qty_error").text(response.errors.stock_qty[0])
                    }                    
                }
                else{
                    $("#newSkuAddForm")[0].reset();  
                    $('#modal').modal('hide');  
                    $(" #cost_table").load(window.location + " #cost_table");
                    
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })
    })
    /* Add Production Cost End */ 
});
</script><?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/sku/newModal.blade.php ENDPATH**/ ?>