<?php echo $__env->make('portal.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('pageTitle','Verify'); ?>


<div class="page-content page-container" id="page-content">
    <div class="flex">
        <div class="w-xl w-auto-sm mx-auto py-5">
            <div class="p-4 d-flex flex-column h-100">
                <!-- brand -->
                <a href="<?php echo e(url('/')); ?>" class="navbar-brand align-self-center">
                    <img src="<?php echo e(asset('public/portal/images/logo.png')); ?>" alt="...">
                    <!-- span class="hidden-folded d-inline l-s-n-1x align-self-center">Omnipresenceway</span> -->
                </a>
                <!-- / brand -->
            </div>
            
        </div>
    </div>
    <div class="padding">
        <div class="row">
            <div class="col-12">
                <div class="alert bg-success mb-5 py-4" role="alert">
                    <div class="d-flex"><svg xmlns="http://www.w3.org/2000/svg" width="32" height="32"
                            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                            stroke-linecap="round" stroke-linejoin="round" class="feather feather-check-circle">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                        </svg>
                        <div class="px-3">
                            <h5 class="alert-heading">Well done!</h5>
                            <?php if(session('resent')): ?>
                                <p>A fresh verification link has been sent to your email address.</p>
                            <?php endif; ?>
                            <p>Before proceeding, please check your email for a verification link.
                                If you did not receive the email</p>
                                
                                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();" class="btn w-sm mb-1 btn-outline-dark">Log Out
                                </a> 
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                                <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-white mx-1">
                                        Click here to request another
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                                        
                                    </button>.
                                </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="text-center text-muted">© Copyright. Omnipresence Overseas</div>
</div>
<?php echo $__env->make('portal.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\anwesh\portal\resources\views\auth\verify.blade.php ENDPATH**/ ?>