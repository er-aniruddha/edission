<div class="main-content-container container-fluid px-4">
    <!-- Page Header -->
    <div class="page-header row no-gutters py-4">
        <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
            <span class="text-uppercase page-subtitle">Add Product</span>
            <!-- <h3 class="page-title">Add New Post</h3> -->
        </div>
    </div>
    <!-- End Page Header -->
    <div class="row">
        <div class="col-lg-9 col-md-12">
            <!-- Add New Post Form -->
            <div class="card" style="height: 100%;">
                <div class="card-header">Product Details</div>
                <div class="card-body">
                    <form class="add-new-post" id="addNewProductForm" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <!-- Title here -->
                        <div class="form-group row">
                            <div class="col-sm-12">
                                <label class="text-muted">Product Name/Title :</label>
                                <input type="text" class="form-control circle" placeholder="Your Product Name\Title"
                                    name="product_name" id="product_name">
                            </div>
                        </div>
                        <!-- Text Description Area -->
                        <div class="form-group row">
                            <div class="col-sm-12">
                                <label class="text-muted">Product Description :</label>
                                <textarea name="product_desc" id="product_desc" rows="10" cols="80"
                                    placeholder="Write Product description in here.">
                                </textarea>
                            </div>
                        </div>
                        <input type="hidden" name="product_stat" id="product_stat" />
                        <input type="hidden" name="category_id" id="category_id" />
                </div>
            </div>
            <!-- / Add New Post Form -->
        </div>
        <div class="col-lg-3 col-md-12">
            <!-- Post Overview -->
            <div class="card card-small mb-3">
                <div class="card-header border-bottom">
                    <h6 class="m-0">Actions</h6>
                </div>
                <div class="card-body p-0">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item p-3">
                            <span class="d-flex mb-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="feather feather-flag mx-2">
                                    <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path>
                                    <line x1="4" y1="22" x2="4" y2="15"></line>
                                </svg>
                                <strong class="mr-1">Status:</strong> Draft
                                <a class="ml-auto" href="#">Edit</a>
                            </span>
                            <span class="d-flex mb-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="feather feather-eye mx-2">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                    <circle cx="12" cy="12" r="3"></circle>
                                </svg>
                                <strong class="mr-1">Visibility:</strong>
                                <strong class="text-success">Public</strong>
                                <a class="ml-auto" href="#">Edit</a>
                            </span>
                            <span class="d-flex mb-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="feather feather-calendar mx-2">
                                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                    <line x1="16" y1="2" x2="16" y2="6"></line>
                                    <line x1="8" y1="2" x2="8" y2="6"></line>
                                    <line x1="3" y1="10" x2="21" y2="10"></line>
                                </svg>
                                <strong class="mr-1">Schedule:</strong> Now
                                <a class="ml-auto" href="#">Edit</a>
                            </span>
                            <span class="d-flex">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="feather feather-book-open mx-2">
                                    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                                    <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
                                </svg>
                                <strong class="mr-1">Readability:</strong>
                                <strong class="text-warning">Ok</strong>
                            </span>
                        </li>
                        <li class="list-group-item d-flex px-3">
                            <button class="btn w-sm mb-1 btn-outline-primary" style="margin: 2px;" id="productSaved"
                                type="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="feather feather-save mx-2">
                                    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                                    <polyline points="17 21 17 13 7 13 7 21"></polyline>
                                    <polyline points="7 3 7 8 15 8"></polyline>
                                </svg>
                                Save
                            </button>
                            <button class="btn w-sm mb-1 blue text-white" style="margin: 2px;" id="productPublished"
                                type="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="feather feather-send mx-2">
                                    <line x1="22" y1="2" x2="11" y2="13"></line>
                                    <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                                </svg>
                                Publish
                            </button>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- / Post Overview -->

            <!-- Image Overview -->
            <div class="card card-small mb-3" style="height: 250px;">
                <div class="card-header border-bottom">
                    <h6 class="m-0">Upload Image</h6>
                </div>
                <div class="input-group" style="padding: 10px;">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="image" name="image">
                        <label class="custom-file-label" for="image">Choose file</label>
                    </div>
                    <!-- <div class="input-group-append">
                        <button class="btn btn-outline-secondary" type="button">Button</button>
                    </div> -->
                </div>
                <img id="show-img" style="padding: 10px;" />

            </div>
            <!-- / Image Overview -->
            </form> <!-- / Add Product form end here -->
            <!-- Category Overview -->
            <div class="card card-small mb-3">
                <div class="card-header border-bottom">
                    <h6 class="m-0">Categories</h6>
                </div>
                <div class="card-body p-0">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item px-3 pb-2">
                            <div id="_categoriesDiv">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="custom-control custom-checkbox mb-1">
                                    <input type="checkbox" class="custom-control-input" name="category"
                                        id="<?php echo e($category->category_id); ?>" value="<?php echo e($category->category_id); ?>">
                                    <label class="custom-control-label" style="margin-bottom: 2px;"
                                        for="<?php echo e($category->category_id); ?>"><?php echo e($category->category_name); ?></label>
                                        
                                    <a href="javascript:void(0);" style="line-height: inherit; float: right; color: #f44336;" 
                                        data-url="<?php echo e(route('category.remove', $category->category_id)); ?>" id="_delCat">
                                        <svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="line-height: inherit;margin-bottom: 6px;">
                                            <line x1="18" y1="6" x2="6" y2="18"></line>
                                            <line x1="6" y1="6" x2="18" y2="18"></line>
                                        </svg>
                                    </a>
                                </div>                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <div class="loading" style="margin-left: 50%;display: none;"></div>
                            <!-- input category -->
                        <li class="list-group-item d-flex px-3">
                            <form id="addNewCategoryForm" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="New category"
                                        name="category_name" id="category_name">
                                    <div class="input-group-append">
                                        <button class="btn btn-white px-2" type="button" id="addCategoryBtn">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                                stroke-linecap="round" stroke-linejoin="round"
                                                class="feather feather-plus mx-2">
                                                <line x1="12" y1="5" x2="12" y2="19"></line>
                                                <line x1="5" y1="12" x2="19" y2="12"></line>
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- / Category Overview -->
        </div>
    </div>
</div>

<?php echo $__env->make('portal.product.JsProCreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\anwesh\portal\resources\views\portal\product\adminCreate.blade.php ENDPATH**/ ?>