<div id="content" class="flex">
    <!-- ############ Main START-->
    <div class="d-flex flex fixed-content">
        <?php echo $__env->make('portal.customer.route_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="d-flex flex" id="content-body">
            <div class="d-flex flex-column flex">
                <div class="p-3">
                    <div class="toolbar">
                        <a href="<?php echo e(route('customer.all')); ?>" class="btn btn-sm btn-white" data-pjax-state="">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline>
                            </svg>
                        </a>
                        <button class="btn btn-sm no-bg ml-auto" data-toggle="tooltip" data-original-title="Edit Customer">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"></path><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"></polygon></svg>
                        </button>
                        <button data-toggle="modal" data-target="#content-aside" data-modal="" class="btn btn-sm btn-white d-md-none">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-menu">
                                <line x1="3" y1="12" x2="21" y2="12"></line>
                                <line x1="3" y1="6" x2="21" y2="6"></line>
                                <line x1="3" y1="18" x2="21" y2="18"></line>
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="mx-3 mb-3 card customer-profile">
                    <div class="p-4 d-sm-flex no-shrink b-b profile-top">
                        <div>                        
                            <a href="#"  class="w-96" data-pjax-state="">      
                                <span class="w-96 avatar gd-info" style="height: 96px; font-size: 45px;">
                                    <img src="<?php echo e(asset(Auth::User()->user_img)); ?>" alt="<?php echo e($customer->f_name[0]); ?><?php echo e($customer->s_name[0]); ?>" style="margin-bottom: 9px">
                                </span>
                            </a>
                        </div>
                        <div class="px-sm-4 flex" style="padding-right: 0px !important;">
                            <div> 
                                <button id="orderTable" class="btn btn-icon btn-rounded btn-raised btn-wave" style="float: right;" 
                                 data-pjax-state="" data-toggle="tooltip" data-original-title="Orders">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-cart orderTable"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg> 

                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-list hide"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3" y2="6"></line><line x1="3" y1="12" x2="3" y2="12"></line><line x1="3" y1="18" x2="3" y2="18"></line></svg> 
                                </button>                       
                                <h2 class="text-md"><?php echo e($customer->f_name); ?> <?php echo e($customer->s_name); ?></h2>  
                            </div>                        
                            <small class="d-block text-fade"><?php echo e($customer->shop_name); ?></small>
                            <div class="my-3">
                                <a href="#" data-pjax-state="">
                                    <strong>561</strong>
                                    <span class="text-muted">Orders</span> 
                                </a>
                                <a href="#" class="mx-2" data-pjax-state="">
                                    <strong>4,000</strong> 
                                    <span class="text-muted">Delivered</span>
                                </a>
                                <a href="#" data-pjax-state="">
                                    <strong>500</strong> 
                                    <span class="text-muted">Amount</span>
                                </a>
                            </div>
                        </div>
                    </div>                    
                    <!-- table start -->
                    <div class="customer-profile-table">
                        <div class="table-responsive hide">
                            <table class="table table-theme table-row v-middle" id="xxt">
                            <thead>
                                <tr>
                                    <th class="text-muted" style="width:60px">Name</th>
                                    <th class="text-muted"></th>
                                    <td></td>
                                    <th class="text-muted" style="width:50px">Light</th>
                                    <th class="text-muted" style="width:110px">Circle</th>
                                    <th class="text-muted" style="width:30px">xs</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-primary text-uppercase">Primary</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-primary-lt">14</span></td>
                                    <td><span class="badge badge-circle text-primary"></span> <small class="text-muted">Primary</small></td>
                                    <td><span class="badge badge-circle xs text-primary"></span></td>
                                </tr>
                             
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-success text-uppercase">Success</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-success-lt">75</span></td>
                                    <td><span class="badge badge-circle text-success"></span> <small class="text-muted">Success</small></td>
                                    <td><span class="badge badge-circle xs text-success"></span></td>
                                </tr>
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-warning text-uppercase">Warning</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-warning-lt">30</span></td>
                                    <td><span class="badge badge-circle text-warning"></span> <small class="text-muted">Warning</small></td>
                                    <td><span class="badge badge-circle xs text-warning"></span></td>
                                </tr>
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-primary text-uppercase">Primary</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-primary-lt">14</span></td>
                                    <td><span class="badge badge-circle text-primary"></span> <small class="text-muted">Primary</small></td>
                                    <td><span class="badge badge-circle xs text-primary"></span></td>
                                </tr>
                             
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-success text-uppercase">Success</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-success-lt">75</span></td>
                                    <td><span class="badge badge-circle text-success"></span> <small class="text-muted">Success</small></td>
                                    <td><span class="badge badge-circle xs text-success"></span></td>
                                </tr>
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-warning text-uppercase">Warning</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-warning-lt">30</span></td>
                                    <td><span class="badge badge-circle text-warning"></span> <small class="text-muted">Warning</small></td>
                                    <td><span class="badge badge-circle xs text-warning"></span></td>
                                </tr>
                                 <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-primary text-uppercase">Primary</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-primary-lt">14</span></td>
                                    <td><span class="badge badge-circle text-primary"></span> <small class="text-muted">Primary</small></td>
                                    <td><span class="badge badge-circle xs text-primary"></span></td>
                                </tr>
                             
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-success text-uppercase">Success</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-success-lt">75</span></td>
                                    <td><span class="badge badge-circle text-success"></span> <small class="text-muted">Success</small></td>
                                    <td><span class="badge badge-circle xs text-success"></span></td>
                                </tr>
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-warning text-uppercase">Warning</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-warning-lt">30</span></td>
                                    <td><span class="badge badge-circle text-warning"></span> <small class="text-muted">Warning</small></td>
                                    <td><span class="badge badge-circle xs text-warning"></span></td>
                                </tr>
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-primary text-uppercase">Primary</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-primary-lt">14</span></td>
                                    <td><span class="badge badge-circle text-primary"></span> <small class="text-muted">Primary</small></td>
                                    <td><span class="badge badge-circle xs text-primary"></span></td>
                                </tr>
                             
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-success text-uppercase">Success</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-success-lt">75</span></td>
                                    <td><span class="badge badge-circle text-success"></span> <small class="text-muted">Success</small></td>
                                    <td><span class="badge badge-circle xs text-success"></span></td>
                                </tr>
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-warning text-uppercase">Warning</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-warning-lt">30</span></td>
                                    <td><span class="badge badge-circle text-warning"></span> <small class="text-muted">Warning</small></td>
                                    <td><span class="badge badge-circle xs text-warning"></span></td>
                                </tr>
                                 <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-primary text-uppercase">Primary</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-primary-lt">14</span></td>
                                    <td><span class="badge badge-circle text-primary"></span> <small class="text-muted">Primary</small></td>
                                    <td><span class="badge badge-circle xs text-primary"></span></td>
                                </tr>
                             
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-success text-uppercase">Success</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-success-lt">75</span></td>
                                    <td><span class="badge badge-circle text-success"></span> <small class="text-muted">Success</small></td>
                                    <td><span class="badge badge-circle xs text-success"></span></td>
                                </tr>
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-warning text-uppercase">Warning</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-warning-lt">30</span></td>
                                    <td><span class="badge badge-circle text-warning"></span> <small class="text-muted">Warning</small></td>
                                    <td><span class="badge badge-circle xs text-warning"></span></td>
                                </tr>
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-primary text-uppercase">Primary</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-primary-lt">14</span></td>
                                    <td><span class="badge badge-circle text-primary"></span> <small class="text-muted">Primary</small></td>
                                    <td><span class="badge badge-circle xs text-primary"></span></td>
                                </tr>
                             
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-success text-uppercase">Success</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-success-lt">75</span></td>
                                    <td><span class="badge badge-circle text-success"></span> <small class="text-muted">Success</small></td>
                                    <td><span class="badge badge-circle xs text-success"></span></td>
                                </tr>
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-warning text-uppercase">Warning</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-warning-lt">30</span></td>
                                    <td><span class="badge badge-circle text-warning"></span> <small class="text-muted">Warning</small></td>
                                    <td><span class="badge badge-circle xs text-warning"></span></td>
                                </tr>
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-primary text-uppercase">Primary</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-primary-lt">14</span></td>
                                    <td><span class="badge badge-circle text-primary"></span> <small class="text-muted">Primary</small></td>
                                    <td><span class="badge badge-circle xs text-primary"></span></td>
                                </tr>
                             
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-success text-uppercase">Success</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-success-lt">75</span></td>
                                    <td><span class="badge badge-circle text-success"></span> <small class="text-muted">Success</small></td>
                                    <td><span class="badge badge-circle xs text-success"></span></td>
                                </tr>
                                <tr class="v-middle">
                                    <td><a href="#"><span class="badge badge-warning text-uppercase">Warning</span></a></td>
                                    <td class="flex">
                                        <div class="bg-light r r-3 py-1 my-1"></div>
                                        <div class="bg-light r r-3 py-1 my-1 col-6"></div>
                                    </td>
                                    <td></td>
                                    <td><span class="badge bg-warning-lt">30</span></td>
                                    <td><span class="badge badge-circle text-warning"></span> <small class="text-muted">Warning</small></td>
                                    <td><span class="badge badge-circle xs text-warning"></span></td>
                                </tr>
                                
                            </tbody>
                            </table>
                        </div>
                        <?php echo $__env->make('portal.customer.sub-admin.cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>
                </div> <!-- customer profile end -->
            </div>
        </div>
    </div>
</div>
</div>
<script type="text/javascript">
$(document).ready(function(){
        //  $("#xxt").DataTable({
        // //     "scrollY":        "200px",
        // // "scrollCollapse": true,
        // // "paging":         true
        // })
        /* This script use for in details balde */
    $("#xxt").DataTable()
    
    $("#orderTable").click(function() {
        $(".feather-shopping-cart.orderTable, .feather-list").toggle() 
        $(".table-responsive, .invoice").toggle() 
        if ($('.feather-shopping-cart.orderTable').is(":visible")) {
            $(this).attr('data-original-title', 'Orders');
        } else {
            $(this).attr('data-original-title', 'Table');
        }     
    });
    /* Above script use for in details balde */    
    $(document).on('click',"a.cart",function(){
            if(window.allCartProducts.length == 0){ 
                $(".hascartproduct").hide()
                $(".nocartproduct").show()
            }
            else{
                $(".nocartproduct").hide()
                $(".hascartproduct").show()                
            }
        }) 
}); 
</script>
<?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/customer/admin/details.blade.php ENDPATH**/ ?>