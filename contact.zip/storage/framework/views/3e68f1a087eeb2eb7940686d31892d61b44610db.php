<div class="cart"> 
<div class="card">
    <div class="b-b">
        <div class="nav-active-border b-primary bottom" style="float: right;">
            <ul class="nav" id="myTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="cart-tab" data-toggle="tab" href="#cart" role="tab" aria-controls="cart" aria-selected="true">Cart</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="product-tab" data-toggle="tab" href="#products" role="tab" aria-controls="product" aria-selected="false">Product</a>
                </li>
            </ul>
        </div>
    </div>
    <div class="tab-content p-3">
        <!-- Invoice Start -->
        <div class="tab-pane fade active show" id="cart" role="tabpanel" aria-labelledby="cart-tab">
            <div class="table-banner hide">
                <div class="d-flex align-items-center py-4">
                    <div>
                        <div class="d-flex align-items-center hide">
                            <svg width="48" height="48" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><g class="loading-spin" style="transform-origin: 256px 256px"><path d="M200.043 106.067c-40.631 15.171-73.434 46.382-90.717 85.933H256l-55.957-85.933zM412.797 288A160.723 160.723 0 0 0 416 256c0-36.624-12.314-70.367-33.016-97.334L311 288h101.797zM359.973 134.395C332.007 110.461 295.694 96 256 96c-7.966 0-15.794.591-23.448 1.715L310.852 224l49.121-89.605zM99.204 224A160.65 160.65 0 0 0 96 256c0 36.639 12.324 70.394 33.041 97.366L201 224H99.204zM311.959 405.932c40.631-15.171 73.433-46.382 90.715-85.932H256l55.959 85.932zM152.046 377.621C180.009 401.545 216.314 416 256 416c7.969 0 15.799-.592 23.456-1.716L201.164 288l-49.118 89.621z"></path></g></svg>               
                            <span class="text-md mx-2">Basik Corp</span>
                        </div>
                    </div>
                    <div class="flex"></div>
                    <div class="text-right">
                        <div class="text-sm text-fade">INVOICE</div>
                        <div class="text-highlight">#1002006789</div>
                        <div class="text-sm text-muted">11 Nov, 18</div>
                    </div>
                </div>
            </div>
            <div class="table-banner" style="padding-right:10px; padding-left: 10px;">
                <div class="d-flex py-2">
                    <div>
                        <div class="text-muted">Billing to</div>
                        <div style="color: #5e676f; font-size: .875rem; font-weight: 600;" ><?php echo e($customer->shopname); ?></div>
                        <div style="color: #5e676f; font-size: .875rem; font-weight: 600;"> <?php echo e(ucwords(strtolower($customer->fname))); ?> <?php echo e(ucwords(strtolower($customer->sname))); ?></div>
                        <?php if($customer->addline1 || $customer->addline1): ?>
                        <div style="color: #5e676f; font-size: .875rem;" ><?php echo e(ucwords(strtolower($customer->addline1))); ?></div>
                        <div style="color: #5e676f; font-size: .875rem;" ><?php echo e(ucwords(strtolower($customer->addline2))); ?></div>
                        <?php endif; ?>
                        <div style="color: #5e676f; font-size: .875rem;" ><?php echo e(ucwords(strtolower($customer->locality))); ?>, <?php echo e(ucwords(strtolower($customer->district))); ?></div>
                        <div style="color: #5e676f; font-size: .875rem;" ><?php echo e(ucwords(strtolower($customer->state))); ?>, Pin : <?php echo e(ucwords(strtolower($customer->pin))); ?></div>
                        </div>
                    <div class="flex"></div>
                    <div class="text-right">
                        <div class="text-muted text-right">Billing date</div>
                        <input data-provide="datepicker" id="orderdate" name="orderdate" type="text"
                        class="form-control text-right date" placeholder="Date" style="width: 99px;font-size: 12px;">
                        <span class="text-danger text-right" id="orderdateerror"></span>
                        
                    </div>
                </div>
            </div>            
            <table class="table table-theme table-rows v-middle" id="cartTable">
                <thead>
                    <tr style="border-bottom: 1px solid rgba(32, 133, 200, 0.07);">
                        <th>#</th>
                        <th class="text-muted">Items</th>
                        <th class="text-muted text-right">Qty.</th>
                        <th class="text-muted text-right">Amount</th>
                        <th class="text-muted text-right" style="width:2%;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- <tr style="border-bottom: 1px solid rgba(32, 133, 200, 0.07);">
                        <td>1</td>
                        <td>Night Lamp<div class="text-muted" style="font-size:11px;">Price : &#8377;14</div>
                            <div style="font-size:11px; color: #ff5722;">Discount : &#8377;10</div>
                            <div style="font-size:.75rem; color: #535c78;">Discounted Price : &#8377;4</div>
                        </td>
                        <td class="text-right">
                            75
                        </td>
                        <td class="text-right ctotalColumn">
                            <div class="text-dark"> ₹<span class="csubTotal">1050.35</span></div>
                            <div style="font-size:.875rem; color: #ff5722;">₹<span class="cdiscount">750</span></div>
                            <div style="border-bottom: 1px solid rgba(32, 133, 200, 0.11); margin-left:50%;"></div>
                            <div style="font-size:.75rem; color: #535c78;">
                                Discounted Price = &#8377;<span class="cdiscounted">300</span>
                            </div>
                        </td>
                        <td class="text-right">
                            <a href="javascript:void(0)" class="remove" id="" data-count=""><span class="badge badge-danger text-uppercase">x</span></a>
                        </td>
                    </tr>
                    <tr style="border-bottom: 1px solid rgba(32, 133, 200, 0.07);">
                        <td>2</td>
                        <td>9watt 3month<div class="text-muted" style="font-size:11px;">Price : &#8377;25</div>
                        </td>
                        <td class="text-right">
                            30
                        </td>
                        <td class="text-right ctotalColumn">
                            <div class="text-dark"> ₹<span class="csubTotal">750</span></div>
                        </td>
                        <td class="text-right">
                            <a href="javascript:void(0)" class="remove" id="" data-count=""><span class="badge badge-danger text-uppercase">x</span></a>
                        </td>
                    </tr> -->
                </tbody>
                                
            </table>
            
            <div class="row" style="margin-bottom:20px; margin-right: 10px;">
                <table class="col-md-3 ml-auto text-right" id="cartTotaltable">
                    <tbody>
                        <tr>
                            <th><div class="text-muted">Sub-Total:</div></th>
                            <td style="width:28%;">
                                <div class="text-dark" style="margin-left:5px">&#8377;<span class="tsubTotal"></span></div>
                            </td>
                        </tr>
                        <tr>
                            <th><div class="text-muted">Discount:</div></th>
                            <td style="width:28%;">
                                <div class="text-dark" style="margin-left:5px">&#8377;<span class="tdiscount"></span></div>
                            </td>
                        </tr>
                        <tr>
                            <th><div class="text-muted">Discounted Price:</div></th>
                            <td style="width:28%;">
                                <div class="text-dark" style="margin-left:5px">&#8377;<span class="tdiscounted"></span></div>
                            </td>
                        </tr>
                        <tr>
                            <th><div class="text-muted">Shipping:</div></th>
                            <td style="width:28%;">
                                <div class="text-dark" style="margin-left:5px">&#8377;<span class="tshipping"></span></div>
                            </td>
                        </tr>
                        <tr>  
                            <th><div class="text-muted">Total:</div></th>
                            <td style="width:28%;">
                                <div class="text-dark" style="margin-left:5px">&#8377;<span class="tTotal"></span></div>
                            </td>
                        </tr>
                    </tbody>
                </table>  
            </div>
          
            <!-- <div class="row py-3" style="padding-right:10px; padding-left: 10px;">
                <div class="col-md-4 py-2">
                    <div class="text-muted">Due date</div>
                    <div>11 Nov, 18</div>
                </div>
                <div class="col-md-4 py-2">
                    <div class="text-muted">Billing to</div>
                    <div>Calle Pasteur 13 dcha.</div>
                </div>
                <div class="col-md-4 py-2">
                    <div class="text-muted">Billing date</div>
                    <div>12 Aug, 18</div>
                </div>
            </div> -->
            <div class="row" style="margin-left: 20px; margin-right: 20px">
                <button type="button" class="btn btn-outline-dark btn-block">Cancel</button>
                <button type="button" class="btn red btn-block" style="margin-bottom:8px;" id="orderBtn">Order</button>
            </div>
            <!-- <div class="d-flex py-3">
                <div class="flex"></div>
                <a href="#" class="btn btn-sm btn-primary d-print-none" onclick="window.print();">Print</a>
            </div> -->
        </div>
        <!-- Invoice End -->
        <!-- Show Product Start -->
        <div class="tab-pane fade" id="products" role="tabpanel" aria-labelledby="product-tab">
            <table class="table table-theme table-rows v-middle">
                <thead>
                    <tr>
                        <th class="text-muted">SL No</th>
                        <th class="text-muted">Product</th>
                        <!-- <th class="text-muted text-right">In Hand Stock</th> -->
                        <th class="text-muted text-right">MRP</th>
                        <th class="text-muted text-right">Action</th>
                    </tr>
                </thead>
                <tbody class="list">
                    <?php $i = 0; ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($pro->productstat == 1): ?>
                    <tr class="v-middle">
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($pro->productname); ?>

                            <!-- <div class="text-sm text-muted">Stock : <?php echo e($pro->productname); ?></div>    -->                     
                        </td>
                        <td class="text-right"><?php echo e($pro->productmrp); ?></td>
                        <td class="text-right">
                            <button class="btn btn-dark text-white btn-sm buy" id="<?php echo e($pro->productid); ?>" data-name="<?php echo e($pro->productname); ?>">BUY</button>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>                
            </table>
        </div>
        <!-- Show Product end -->
    </div>
</div>
</div>
<?php echo $__env->make('portal.customer.modals.add_to_cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('portal.customer.modals.order_confirm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript">
    window.stocks = <?php echo json_encode($stocks, 15, 512) ?>;
</script>
<script type="text/javascript" src="<?php echo e(asset('resources/js/customer/cart.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('resources/js/customer/order.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/customer/admin/cart.blade.php ENDPATH**/ ?>