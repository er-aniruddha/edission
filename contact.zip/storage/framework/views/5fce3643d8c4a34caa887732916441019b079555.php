

<?php $__env->startSection('content'); ?>

    <?php switch(Auth::User()->user_permission): 

        case ('1'): ?>
            <?php echo $__env->make('portal.user.adminIndex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('2'): ?>
            <?php echo $__env->make('portal.layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php default: ?>
            <?php echo $__env->make('portal.layouts.blocked', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

    <?php endswitch; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('portal.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\anwesh\portal\resources\views\portal\user\index.blade.php ENDPATH**/ ?>