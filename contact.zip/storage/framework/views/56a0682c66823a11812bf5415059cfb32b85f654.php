<?php echo $__env->make('portal.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('pageTitle','Verify'); ?>

<div id="ajax-content" class="dark h-v d-flex flex align-items-center">
    <div class="mx-auto w-xl w-auto-xs animate fadeIn text-center">
        <div class="p-4 d-flex flex-column h-100">
            <!-- brand --> 
            <a href="<?php echo e(url('/')); ?>" class="navbar-brand align-self-center">
                <img src="<?php echo e(asset('public/portal/images/logo.png')); ?>" alt="..."> 
                <!-- span class="hidden-folded d-inline l-s-n-1x align-self-center">Omnipresenceway</span> --> 
            </a>
            <!-- / brand -->
        </div>
        <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>
            <div class="md-form-group">
                <input type="email" class="md-input text-center <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email"
                    name="email" value="<?php echo e($email ?? old('email')); ?>" autocomplete="email" autofocus>
                <label class="d-block w-100">Enter email</label>
    
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mt-3">
                <button type="submit" class="btn btn-rounded btn-primary">Send Password Reset Link</button>                
            </div>
            <div class="mt-3">
                <a href="<?php echo e(route('login')); ?>" class="btn btn-rounded btn-dark">Login</a>                
            </div>
        </form>
        <?php if(session('status')): ?>
            <p class="text-primary" style="margin-top:20px;">
                <?php echo e(session('status')); ?>

            </p>
        <?php endif; ?>
    </div>
</div>


<?php echo $__env->make('portal.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/auth/passwords/email.blade.php ENDPATH**/ ?>