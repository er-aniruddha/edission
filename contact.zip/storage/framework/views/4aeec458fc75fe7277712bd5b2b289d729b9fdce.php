<!-- Add to Cart Modal Start  -->
<div id="addToCart" class="modal fade show" data-backdrop="true" aria-modal="true">
    <div class="modal-dialog modal-bottom text-dark" style="height:70%;">
        <div class="modal-content" style="height:100%;">
            <div class="modal-header bg-primary">
                <div class="modal-title text-white"></div>                
            </div>
            <div class="modal-body">
                <form id="addToCartForm">                        
                    <div class="row">
                        <div class="col-md-6">
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="text-muted">Discount</label>
                                <input type="number" class="form-control" name="discount" id="discount" placeholder="Discount price" 
                                autocorrect="off" autofocus="autofocus" autocomplete="off" animate="true" autocomplete="off" 
                                autocapitalize="off" spellcheck="false" required="">
                            </div>
                        </div>
                    </div>                          
                    <table class="table-bordered table table-theme table-row v-middle" id="cartInputTable">
                        <thead>
                            <tr>
                                <th>SL No</th>
                                <th style="width:52%;">SKU</th>
                                <th style="width:30%">Quantity</th>                               
                                <th >
                                    <button type="button" class="text-primary addRow" id="_addRow" style="background-color: #a4191900;border: 0px solid transparent;" value="1">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
                                    </button>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody> 
                    </table>  
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-dark btn-block" id="cancelCartBtn" >Cancel</button> 
                <button class="btn red btn-block" style="margin-bottom:8px;" id="addToCartBtn">Add to cart</button>
            </div>
            </form>
        </div>
        <!-- /.modal-content -->
    </div>
</div>
<!-- Add to Cart Modal End<?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/customer/modals/add_to_cart.blade.php ENDPATH**/ ?>