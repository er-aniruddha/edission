<div id="content" class="flex">
    <div class="">
        <div class="page-hero page-container" id="page-hero">
            <div class="padding d-flex">
                <div class="page-title">
                    <h2 class="text-md text-highlight">All Brands</h2>
                    <!-- <small class="text-muted">Products</small> -->
                </div>
                <div class="flex"></div>
                <div>
                    <button class="btn btn-raised btn-wave blue text-white add" 
                    data-toggle="modal" data-target="#modal">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                        Add
                    </button>
                </div>                
            </div>
        </div>
        <div class="page-content page-container" id="page-content">
            <div class="padding">
                <div class="table-responsive">
                    <div id="datatable_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                        <div class="row">   
                            <div class="col-sm-12 col-md-6">
                                <div class="dataTables_length"  style="display: inline;">
                                    <label>Show </label>
                                        <select name="brand_table_length" aria-controls="brand_table" 
                                        class="custom-select custom-select-sm form-control form-control-sm" id="brand_table_length">
                                            <option value="10">10</option>
                                            <option value="25">25</option>
                                            <option value="50">50</option>
                                            <option value="100">100</option>
                                        </select> entries
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-6">
                                <div class="dataTables_filter" style="float: right; display: inline;">
                                    <label>Search:</label>
                                    <input type="search" class="form-control form-control-sm" placeholder="" aria-controls="brand_table" id="dataTableSearch">
                                </div>
                            </div>
                        </div>
                    </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <table class="table table-theme table-row v-middle dataTable no-footer" role="grid" aria-describedby="datatable_info" id="brand_table">
                                    <thead>
                                        <tr role="row">
                                            <th class="sorting_asc" tabindex="0" aria-controls="datatable" rowspan="1"
                                                colspan="1" style="width: 26px;" aria-sort="ascending"
                                                aria-label="ID: activate to sort column descending"><span
                                                    class="text-muted">SL No</span></th>
                                            <th class="sorting" tabindex="0" aria-controls="datatable" rowspan="1"
                                                colspan="1" style="width: 34px;"
                                                aria-label="Owner: activate to sort column ascending"><span
                                                    class="text-muted">Image</span></th>
                                            <th class="sorting" tabindex="0" aria-controls="datatable" rowspan="1"
                                                colspan="1" style="width: 680px;"
                                                aria-label="Project: activate to sort column ascending">
                                                <span class="text-muted">Brand Name</span></th>

                                            <th class="sorting_disabled" rowspan="1" colspan="1" style="width: 35px;"
                                                aria-label="Tasks"><span class="text-muted d-none d-sm-block">Status</span></th>
                                            <th class="sorting_disabled" rowspan="1" colspan="1" aria-label="Finish" style="width: 150px;">
                                                <span class="text-muted d-none d-sm-block">Action</span>
                                            </th>
                                            <th class="sorting_disabled" rowspan="1" colspan="1" 
                                                aria-label=""></th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('portal.brand.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('portal.layouts.deleteModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<script>
    // global app configuration object
    var routes = {
            index: "<?php echo e(route('brand.index')); ?>",
            create: "<?php echo e(route('brand.create')); ?>",
            update: "<?php echo e(route('brand.update')); ?>",
            delete: "<?php echo e(route('brand.delete')); ?>",
        };
</script>
<script type="text/javascript" src="<?php echo e(asset('resources/js/mini/brand.min.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/brand/admin/index.blade.php ENDPATH**/ ?>