<div id="viewModal" class="modal fade" aria-modal="true" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog text-dark modal-lg" style="max-width: 95%;">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white"></h5>                
            </div>
            <div class="modal-body p-4">
                <form id="" method="">                    
                    <div class="form-group row mb-3">
                        <label class="col-sm-2 col-form-label">Customer</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control text-capitalize" id="view_customer_name" readonly>
                        </div>
                    </div>
                    <table class="table-bordered table table-theme table-row v-middle" id="viewRow">
                        <thead>
                            <tr>
                                <th style="width: 30%;">Item Name</th>
                                <th style="width: 10%;">Unit Name</th>
                                <th style="width: 10%;">Quantity</th>
                                <th style="width: 20%;">MRP</th>
                                <th style="width: 10%;">Discount</th>
                                <th style="width: 20%;">Amount</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group mb-3">
                                <label class="text-muted">Payment Type</label>
                                <select class="form-control col-sm-8" id="view_payment_type" tabindex="-1" aria-hidden="true" disabled>
                                    <option value="" selected="">Select an option</option>
                                    <option value="1">Cash</option>
                                    <option value="2">Online</option>
                                    <option value="3">Cheque</option>
                                </select>
                                <span class="text-danger text-sm" id="payment_type_error"></span>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Order Date</label>
                                <div class="col-sm-9">
                                    <input id="view_order_date" name="order_date" type="text" class="form-control" placeholder="Date">
                                    <span class="text-danger text-sm" id="order_date_error"></span>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Delivery Date</label>
                                <div class="col-sm-9">
                                    <input id="view_delivery_date" name="delivery_date" type="text" class="form-control" placeholder="Date">
                                    <span class="text-danger text-sm" id="delivery_date_error"></span>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Remarks</label>
                                <div class="col-sm-9">
                                    <textarea id="view_remarks" name="view_remarks" class="form-control" rows="3" readonly></textarea>
                                    <span class="text-danger text-sm" id="remarks_error"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4" style="left: 50%;">
                            <div class="input-group mb-3" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">Round Off</span>
                                </div>
                                <input type="number" class="form-control" placeholder="0.00" name="round_off" id="view_round_off" value="0.00" >
                            </div>
                            <div class="input-group mb-3" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">Delivery Charges</span>
                                </div>
                                <input type="number" class="form-control" placeholder="0.00" name="delivery_charges" id="view_delivery_charges" value="0.00" >
                            </div>
                            <div class="input-group mb-3" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">GST Amount</span>
                                </div>
                                <input type="number" class="form-control" min="0" placeholder="0.00" name="gst_amount" id="view_gst_amount" value="0.00" >
                            </div>
                            <div class="input-group mb-3" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">Total</span>
                                </div>
                                <input type="number" class="form-control total" min="0" placeholder="0.00" name="total" id="view_total"  value="0.00" readonly="">
                            </div>
                            <div class="input-group mb-3" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">Received</span>
                                </div>
                                <input type="number" class="form-control received" min="0" placeholder="0.00" name="received" id="view_received" value="0.00" >
                            </div>
                            <div class="input-group" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">Balance</span>
                                </div>
                                <input type="number" class="form-control" min="0" placeholder="0.00" name="balance" id="view_balance"  value="0.00" readonly="">
                            </div>
                            <span class="text-sm prev_bal" style="color: #f44336; font-weight:600;"></span>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-outline-dark" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.modal-content -->
</div><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/sale/viewModal.blade.php ENDPATH**/ ?>