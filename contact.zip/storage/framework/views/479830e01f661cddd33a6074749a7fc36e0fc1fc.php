 	<!-- ############ Footer START-->
        <!-- <div class="page-footer">
            <div class="d-flex p-3"><span class="text-sm text-muted flex">© Copyright. Omnipresence Overseas</span>
                <div class="text-sm text-muted">Version 1.0</div>
            </div>
        </div> -->
        <!-- ############ Footer END-->
        <snackbar></snackbar>
    <script src="<?php echo e(asset('public/portal/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/portal/js/notification/jnoty.js')); ?>"></script> 
    <script type="text/javascript" src="<?php echo e(asset('public/portal/js/list.js')); ?>"></script>      
    <script type="text/javascript" src="<?php echo e(asset('public/portal/js/user.js')); ?>"></script>  
    <!-- DataTables JavaScript -->
    <script src="<?php echo e(asset('public/portal/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/portal/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/portal/js/parsley.min.js')); ?>"></script>
    <!-- Select2 JavaScript -->
    <script type="text/javascript" src="<?php echo e(asset('public/portal/js/select2.min.js')); ?>"></script>
    <!-- Datepicker JavaScript -->
    <script type="text/javascript" src="<?php echo e(asset('public/portal/js/bootstrap-datepicker.min.js')); ?>"></script>
    
    <script>
    // In your Javascript (external .js resource or <script> tag)
    $("#image").change(function(){
        readURL(this);
    });  
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#show-img').attr('src', e.target.result);
            };
            reader.readAsDataURL(input.files[0]);
        }
    } 
    //showing successfull message
    function snacbar(data){
        let message = data;
        let snackbar  = new SnackBar;
        snackbar.make("message",
        [
            data,
            null,
            "bottom",
            "center"
        ], 4000);
    }
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\contact\resources\views/portal/layouts/footer.blade.php ENDPATH**/ ?>