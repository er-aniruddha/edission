<script>
	$(document).ready(function() {			  
		$("#brand_stat").click(function(event) {
			/* Act on the event */
			if($('#brand_stat').is(':checked')){
				$("#brand_stat").val(1)
			}
			else{
				$("#brand_stat").val(0)
			}
		})// barnd status checkbox change action

		$('#brandForm').on('click', '#addBtn', function (e) {
            e.preventDefault();
            $( '#brand_name_error' ).html( "" );
            $( '#brand_desc_error' ).html( "" );
            $( '#image_error' ).html( "" );           

            var formData = new FormData($('#brandForm')[0]);

            $.ajax({
                method: 'POST',
                url: "<?php echo e(route('brand.create')); ?>",
                contentType: false,
                cache: false,
                processData: false,
                dataType: "json",
                data: formData,
                success: function (response) {
                	console.log(response)
                    if(response.errors){
                        if(response.errors.brand_name){
                            $("#brand_name_error").text(response.errors.brand_name[0])
                        }
                        if(response.errors.brand_desc){
                            $("#brand_desc_error").text(response.errors.brand_desc[0])
                        }
                        if(response.errors.image){
                            $("#image_error").text(response.errors.image[0])
                        }
                    }
                    //on success
                    else{
                        let message = response.success;
                        snacbar(message)
                    }
                },
                error:function(error){
                	console.warn(error)
                    snacbar(error.statusText)
                }
            })
        })		
	});
</script><?php /**PATH C:\xampp\htdocs\contact\resources\views/portal/brand/js.blade.php ENDPATH**/ ?>