
<form method="POST" action="<?php echo e(route('stock.view')); ?>">
	<?php echo csrf_field(); ?>
	<div id="modal-sm" class="modal fade" data-backdrop="true" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title text-md">Modal title</div><button class="close" data-dismiss="modal">×</button></div>
            <div class="modal-body">
                <!-- <div class="col-sm-12">
                    <label class="text-muted">Start Date</label>
                    <input type="text" class="form-control mb-3 date" data-provide="datepicker" 
                    id="start_date" name="start_date" value="">
                </div>

                <div class="col-sm-12">
                    <label class="text-muted">End Date</label>
                    <input type="text" class="form-control mb-3 date" data-provide="datepicker" 
                    id="end_date" name="end_date" value="">
                </div> -->


                <div class="input-group input-daterange mb-3">
                    <input type="text" class="form-control" name="start" id="start">
                    <div class="input-group-prepend">
                        <span class="input-group-text">to</span>
                    </div>
                    <input type="text" class="form-control" name="end" id="end">
                </div>

            </div>
            <div class="modal-footer">
            	<button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
            	<button type="submit" class="btn btn-primary">Save Changes</button></div>
        </div>
        <!-- /.modal-content -->
    </div>
</div>
</form>
<script type="text/javascript">
    // In your Javascript (external .js resource or <script> tag)
$(document).ready(function() {
 

    $('.input-daterange').each(function() {
        $(this).datepicker({
            format: "dd/mm/yyyy",
            autoclose: true,      
        }).on('changeDate', function(){
            console.log($("#start").val() , "end :" +$("#end").val())
        });
    });

});
</script><?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/sku/modalview.blade.php ENDPATH**/ ?>