<script>
	$(document).ready(function() {		
        var base_url = window.location.origin;	  
		$("#brand_stat").click(function(event) {
			/* Act on the event */
			if($('#brand_stat').is(':checked')){
				$("#brand_stat").val(1)
			}
			else{
				$("#brand_stat").val(0)
			}
		})// barnd status checkbox change action
    /* Add Modal Start */
    $(document).on('click','button.add',function(){  
        $('.modal-title').text("Add Brand");
        $('#brand_id').val("");        
        $('#addBtn').show();
        $('#editBtn').hide();
     });
    /* Add Modal end */
    /* Show Brand Table Start */ 
    $('#brand_table').DataTable({
        processing: true,
        serverSide: true,
        ajax:{
            url: "<?php echo e(route('brand.index')); ?>",
        },
        columns:[
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},
            {data: 'brand_img', name: 'brand_img', render: function(data, type, full, meta){
                return "<img src="+base_url+'/edission'+data+ " width='70' class='img-thumbnail' />";
            },orderable: false},
            {data: 'brand_name', name: 'brand_name' },
            {data: 'status', name: 'status', },
            {data: 'action', name: 'action', }, 
        ]
    });
    /* Show Brand Table End */
		$('#brandForm').on('click', '#addBtn', function (e) {
      e.preventDefault();
      $( '#brand_name_error' ).html( "" );
      $( '#brand_desc_error' ).html( "" );
      $( '#image_error' ).html( "" );  
      var formData = new FormData($('#brandForm')[0]);
      $.ajax({
          method: 'POST',
          url: "<?php echo e(route('brand.create')); ?>",
          contentType: false,
          cache: false,
          processData: false,
          dataType: "json",
          data: formData,
          success: function (response) {
              if(response.errors){
                  if(response.errors.brand_name){
                      $("#brand_name_error").text(response.errors.brand_name[0])
                  }
                  if(response.errors.brand_desc){
                      $("#brand_desc_error").text(response.errors.brand_desc[0])
                  }
                  if(response.errors.image){
                      $("#image_error").text(response.errors.image[0])
                  }
              }
              //on success
              else{
                  $("#brandForm")[0].reset();  
                  $('#brand_table').DataTable().ajax.reload(); 
                  $('#modal').modal('hide');          
                  let message = response.success;
                  snacbar(message)
              }
          },
          error:function(error){
              snacbar(error.statusText)
          }//error end here
      })//ajax end here
  })//create brand function end here

  /* Show Brand Details Start */
  $(document).on('click','button.view', function(){
      $('.modal-title').text("Brand Details");
      $('#modal').modal('show');
      $('#brand_name').val($(this).data('name'));
      $('#brand_desc').val($(this).data('desc'));
      $('#show-img').attr("src", $(this).data('image'));  
      $('#addBtn').hide();
      $('#editBtn').hide();
      $('#image').hide();
  });
  /* Show Brand Details Start */

        /* Show modal for Edit Start */
        $(document).on('click', 'button.edit', function(){  
            alert("ok")
          $('.modal-title').text("Edit Brand"); 
          $('#brand_id').val($(this).attr('id'));
          $('#brand_name').val($(this).data('name'));
          $('#brand_desc').val($(this).data('desc'));
          $('#image-update').val($(this).data('image')); 
          $('#show-img').attr("src", base_url+'/edission'+$(this).data('image'));    
          $('#addBtn').hide();
          $('#editBtn').show();
          $('#image').show();
          $('#modal').modal('show');
          var i = $(this).attr('id');
          confirmUrl = "<?php echo e(url('/')); ?>"+'/brand/'+i;   
        });
        /* Show modal for Edit End */

        $('#brandForm').on('click', '#editBtn', function (e) {
            e.preventDefault();
            $( '#brand_name_error' ).html( "" );
            $( '#brand_desc_error' ).html( "" );
            $( '#image_error' ).html( "" );           

            var formData = new FormData($('#brandForm')[0]);

            $.ajax({
                method: 'POST',
                url: "<?php echo e(route('brand.update')); ?>",
                contentType: false,
                cache: false,
                processData: false,
                dataType: "json",
                data: formData,
                success: function (response) {
                    if(response.errors){
                        if(response.errors.brand_name){
                            $("#brand_name_error").text(response.errors.brand_name[0])
                        }
                        if(response.errors.brand_desc){
                            $("#brand_desc_error").text(response.errors.brand_desc[0])
                        }
                        if(response.errors.image){
                            $("#image_error").text(response.errors.image[0])
                        }
                    }
                    //on success
                    else{
                        $("#brandForm")[0].reset();    
                        let message = response.success;
                        snacbar(message)
                    }
                },
                error:function(error){
                    snacbar(error.statusText)
                }//error end here
            })//ajax end here
        })//create brand function end here  

        /* Status Update Strat*/
        $(document).on('click','a.status',function(event){
          event.preventDefault() 
          $.ajax({
            type:'GET',
            url: $(this).data("url"), 
            success:function(response) {  
                if(response.success){
                  $('#brand_table').DataTable().ajax.reload();
                  let message = response.success;
                  snacbar(message)
                }                 
              }, 
              error:function(error){
                snacbar(error.statusText)
              }//error end here
            }); 
        });
        /* Status Update End*/
        /* Delete Brand Table Start */
        $(document).on('click', 'button.delete', function(){
          $('#id').val($(this).data('id'));
          $('.modal-title').text('Brand Name : '+$(this).data('name'));
          $('#ok_button').text('YES');
          $('#confirmModal').modal('show');
        });
        $('#confirmModal').on('click', '#ok_button', function(event){
          event.preventDefault() 
          var confirm = new FormData($("#confirmform")[0]);    
          $.ajax({
           type:'POST',
           url:"<?php echo e(route('brand.delete')); ?>",
           processData: false,
           contentType: false,
           data : confirm,
           beforeSend:function(){
            $('#ok_button').text('Deleting...');
           },
            success:function(response) {
              if(response.success){
                $('#brand_table').DataTable().ajax.reload();
                $('#confirmModal').modal('hide');     
                let message = response.success;
                snacbar(message)
              }                   
            }, 
            error:function(error){
              snacbar(error.statusText)
            }  
          });   
        });
        /* Delete Brand Table End */ 	
	});
</script><?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/brand/js.blade.php ENDPATH**/ ?>