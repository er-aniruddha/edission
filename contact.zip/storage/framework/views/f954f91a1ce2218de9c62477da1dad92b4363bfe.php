<div id="content" class="flex">
    <!-- ############ Main START-->
    <div class="page-content page-container" id="page-content">
        <div class="padding">
            <div class="row row-sm sr">
                <div class="col-md-12 col-lg-12">
                    <div class="row row-sm">
                        <a href="<?php echo e(route('customer.create')); ?>" class="col-md-4 d-flex" style="width: 50%;">
                            <div class="card flex card-home">
                                <div class="card-body text-center">
                                    <div style="margin: 10px;">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="32px" height="32px"
                                            style="color:rgb(68, 139, 255);" viewBox="0 0 24 24" fill="none"
                                            stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                            stroke-linejoin="round" class="feather feather-user-plus mx-2">
                                            <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                            <circle cx="8.5" cy="7" r="4"></circle>
                                            <line x1="20" y1="8" x2="20" y2="14"></line>
                                            <line x1="23" y1="11" x2="17" y2="11"></line>
                                        </svg>
                                    </div>
                                    <span class="text-dark mr-2">Add Customer</span>
                                </div>
                            </div>
                        </a>
                        <a href="<?php echo e(route('customer.all')); ?>" class="col-md-4 d-flex" style="width: 50%;">
                            <div class="card flex card-home">
                                <div class="card-body text-center">
                                    <div style="margin: 10px;">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="32px" height="32px"
                                            style="color:rgb(68, 139, 255);" viewBox="0 0 24 24" fill="none"
                                            stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                            stroke-linejoin="round" class="feather feather-users mx-2">
                                            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                            <circle cx="9" cy="7" r="4"></circle>
                                            <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                                            <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                                        </svg>
                                    </div>
                                    <span class="text-dark mr-2">All Customer</span>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ############ Main END-->
</div>
<?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/customer/admin/index.blade.php ENDPATH**/ ?>