<?php $__env->startSection('content'); ?>

<div class="text-center p-5 w-100" style="margin-top: 14%;">
    <h1 class="display-5 my-5 text-theme">Coming Soon.</h1>
    <p>Go back to <a href="<?php echo e(url('/')); ?>" class="b-b b-white">Dashboard</a> 
        <!-- <a href="#" class="b-b b-white">contactus</a> about a problem.</p> -->
    <p class="my-5 text-muted h4">-- 404 --</p>
</div>

<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('portal.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/layouts/comingsoon.blade.php ENDPATH**/ ?>