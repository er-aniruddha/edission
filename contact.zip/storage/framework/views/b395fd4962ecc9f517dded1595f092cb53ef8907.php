<?php echo $__env->make('portal.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('pageTitle','Login'); ?>


<div class="flex">
    <div class="w-xl w-auto-sm mx-auto py-5">
        <div class="p-4 d-flex flex-column h-100">
            <!-- brand -->
            <a href="<?php echo e(url('/')); ?>" class="navbar-brand align-self-center">
                <img src="<?php echo e(asset('public/portal/images/logo-01.png')); ?>" alt="...">
                <!-- span class="hidden-folded d-inline l-s-n-1x align-self-center">Omnipresenceway</span> -->
            </a>
            <!-- / brand -->
        </div>
         <!-- Card View Start -->
        <div  style="display: none;" id="cardView">
            <div class="card">
                <div id="content-body">
                    <div class="p-3 p-md-5">
                        <h5>Welcome back</h5>
                        <p><small class="text-muted">Login to manage your account</small></p>
    
                        <form role="form" method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="md-form-group float-label">
                                <input type="email" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> md-input" name="email" id="email" value="<?php echo e(old('email')); ?>" required
                                    onkeyup="this.setAttribute('value', this.value);">
                                <label>Email</label>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger" style="font-size: 11px;"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="md-form-group float-label">
                                <input type="password" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> md-input"
                                    name="password" id="password" required value=""
                                    onkeyup="this.setAttribute('value', this.value);">
                                <label>Password</label>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger" style="font-size: 11px;"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php if(Route::has('password.request')): ?>
                                <div class="my-3 text-right">
                                    <a href="<?php echo e(route('password.request')); ?>" class="text-muted" data-pjax-state=""><?php echo e(__('Forgot Password?')); ?></a>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="checkbox mb-3">
                                <label class="ui-check">
                                    <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>><i></i> <?php echo e(__('Remember Me')); ?>

                                </label>
                            </div>
                            <div style="border-top: 1px solid #ccc;
                            padding-bottom: 20px;
                            margin-top: 30px;
                            width: 100%;"></div>
                            <button type="submit" class="btn btn-raised btn-wave mb-4 blue text-white">Sign In</button>
                            <a href="<?php echo e(route('register')); ?>" class="btn btn-raised btn-wave mb-4 green text-white"
                                style="float: right;">Sign Up</a>
                        </form>
    
                    </div>
                </div>
            </div>
        </div>
        <!-- Card View End -->
        <!-- Locak View Start -->
        <div  id="lockView">
            <div id="ajax-content" class="dark d-flex flex align-items-center" style="margin-top: 60%; margin-bottom: 15%;">
                <div class="mx-auto w-xl w-auto-xs animate fadeIn text-center">
                    <div class="mb-3">

                            <div id="userImg" style="display: inline-block;"></div>

                        <div class="mt-3 font-bold" id="name" ></div>
                    </div>
                    <form role="form" method="POST" id="loginForm">
                        <?php echo csrf_field(); ?>
                        <div class="md-form-group">
                            <input type="password" class="md-input text-center <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" type="password" 
                            name="password" autocomplete="current-password">
                            <label class="d-block w-100">Your Password</label>

                            <p class="text-danger mb-4" id="pass-error" style="font-size: 11px; margin-top: 5px;" ></p>
                        </div>
                        <input type="hidden" name="email" id="_email">

                        <div class="mt-3">
                            <button type="button" class="btn btn-rounded btn-primary unlock">Unlock</button>
                        </div>
                    </form>
                    <div class="mt-3">
                        <button type="button" class="btn btn-rounded btn-dark" id="chngUserBtn">Change User</button>
                    </div>
                    <div class="mt-3">
                        <a href="<?php echo e(route('register')); ?>" class="text-muted">Register</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Locak View End -->
        <div class="text-center text-muted">© Copyright. Edission</div>
    </div>
</div>
<script>
    $(document).ready( function () {
        var f_name = localStorage.getItem('f_name')
        var s_name = localStorage.getItem('s_name')
        var email = localStorage.getItem('email')
        var image = localStorage.getItem('image')
        if(f_name && s_name && email){
            $("#lockView").show()
            $("#cardView").hide()            
            $("#_email").val(email)
            $("#name").html(f_name+" "+s_name)
            $("#userImg").html('<span class="w-72 avatar gd-primary">'
                            +'<img  src="'+image+'" style="font-size:37px;" alt="'+f_name[0]+s_name[0]+'"></span>')
            // $('#image').attr('src', image);
        }
        else{
            $("#lockView").hide()
            $("#cardView").show() 
        }

        $("#loginForm").on('click','.unlock',function(){
            $("#pass-error").html(" ");
            var formData = new FormData($("#loginForm")[0])
            $.ajax({
                method: 'POST',
                    url: "<?php echo e(route('login')); ?>",
                    contentType: false,
                    cache: false,
                    processData: false,
                    dataType: "json",
                    data: formData,
                    success:function(res){
                        window.location.href = "<?php echo e(route('dashboard')); ?>"
                    },
                    error:function(error){
                        if (error.status == 500) {
                            let message = "Something went wrong !!"
                            danger(message)
                        }
                        console.log(error)
                        //$("#pass-error").html(error.responseJSON.errors.password[0]);
                        
                    }//ajax error end here
            })//ajax end here
        })//login form function end here

        /*Change User Function*/
        $(document).on('click','#chngUserBtn',function(){

            localStorage.removeItem("f_name")
            localStorage.removeItem("s_name")
            localStorage.removeItem("email")
            localStorage.removeItem("image")
            $("#lockView").hide()
            $("#cardView").show() 
        })

    })
</script>
<?php echo $__env->make('portal.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/auth/login.blade.php ENDPATH**/ ?>