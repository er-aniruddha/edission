  <script>
    function success(message){
        $.jnoty(message, {
            header: 'Success',
            theme: 'jnoty-success',
            icon: 'fa fa-check-circle fa-2x',
            life:3000
          });   
    }
    function warning(message){
        $.jnoty(message, {
            header: 'Warning',
            theme: 'jnoty-warning',
            icon: 'fa fa-info-circle fa-2x',
            position:           'center',
            life:30000000000
          }); 
    }
    function info(message){
        $.jnoty(message, {
            header: 'Information',
            theme: 'jnoty-info',
            icon: 'fa fa-info-circle fa-2x',
            life:3000
          });
    }
    function danger(message){
        $.jnoty(message, {
            header: 'Danger',
            theme: 'jnoty-danger',
            icon: 'fa fa-info-circle fa-2x',
            life:3000
          });
    }       
  </script><?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/layouts/notification.blade.php ENDPATH**/ ?>