<div class="card">
    <div class="b-b">
        <div class="nav-active-border b-primary bottom" style="float: left; padding-left: 1%; padding-top: 9px;">
            <span style="font-weight: 600; color: #535c78;">Transaction Table</span>
        </div>
        <div class="nav-active-border b-primary bottom" style="float: right;">
            <ul class="nav" id="myTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active cart" id="bill-tab" data-toggle="tab" href="#bill" role="tab" aria-controls="bill" aria-selected="true">Bills</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="payment-tab" data-toggle="tab" href="#payment" role="tab" aria-controls="payment" aria-selected="false">Payment</a>
                </li>
            </ul>
        </div>
    </div>
    <div class="tab-content p-3">
        <!-- Invoice Start -->
        <div class="tab-pane fade active show" id="bill" role="tabpanel" aria-labelledby="bill-tab">
            <div class="hascartproduct">
                <div class="table-responsive">
                    <!-- <table class="table table-theme table-row v-middle" id="payment_table">
                        <thead>
                            <tr>
                                <th style="width: 26px;"><span class="text-muted">#</span></th>                                
                                <th><span class="text-muted">Date</span></th>
                                <th><span class="text-muted">Payment Type</span></th>
                                <th><span class="text-muted">Prev. Due</span></th>
                                <th><span class="text-muted">Received/Paid</span></th>
                                <th><span class="text-muted">Balance</span></th>
                                <th><span class="text-muted">Remarks</span></th>
                                <th style="width:50px"></th>
                            </tr>
                        </thead>
                    </table> -->
                    <table class="table table-theme table-row v-middle" id="trnx_table">
                        <thead>
                            <tr>
                                <th style="width: 26px;"><span class="text-muted">#</span></th>                                
                                <th><span class="text-muted">Date</span></th>
                                <th><span class="text-muted">Invoice No</span></th>
                                <th><span class="text-muted">Customer Name</span></th>
                                <th><span class="text-muted">Payment Type</span></th>
                                <th><span class="text-muted">Amount</span></th>
                                <th><span class="text-muted">Prev. Due</span></th>
                                <th><span class="text-muted">Paid/Received</span></th>
                                <th><span class="text-muted">Balance Due</span></th>
                                <th style="width:50px"></th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
            <div class="nocartproduct show">
                <div class="no-product-cart-banner">
                    <div style="padding:20px;"><span class="text-dark"><h5>No transaction</h5></span></div>
                </div>   
            </div>
        </div>        
        <!-- Invoice End -->
        <!-- Show Product Start -->
        <div class="tab-pane fade" id="payment" role="tabpanel" aria-labelledby="payment-tab">
            <table class="table table-theme table-rows v-middle" id="productsTable">
                <thead>
                    <tr>
                        <th class="text-muted">SL No</th>
                        <th class="text-muted">Product</th>
                        <!-- <th class="text-muted text-right">In Hand Stock</th> -->
                        <th class="text-muted text-right">MRP</th>
                        <th class="text-muted text-right">Action</th>
                    </tr>
                </thead>
                <tbody class="list">                    
                </tbody>                
            </table>
        </div>
        <!-- Show Product end -->
    </div>
    <?php echo $__env->make('portal.customer.order.add_to_cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<script type="text/javascript">

</script>
<script type="text/javascript" src="<?php echo e(asset('resources/js/customer/details.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('resources/js/customer/order.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/customer/sub-admin/cart.blade.php ENDPATH**/ ?>