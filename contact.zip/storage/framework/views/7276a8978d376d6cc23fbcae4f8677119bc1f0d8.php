<div id="content" class="flex">
    <!-- ############ Main START-->
    <div class="page-content page-container" id="page-content">
        <div class="padding">
            <div class="row row-sm sr">
                <div class="col-md-12 col-lg-12">
                    <div class="row row-sm">
                        <a href="<?php echo e(route('purchase.index')); ?>" class="col-md-4 d-flex" style="width: 50%;">
                            <div class="card flex card-home">
                                <div class="card-body text-center">
                                    <div style="margin: 10px;">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="32px" height="32px" style="color:rgb(68, 139, 255);" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-cart mx-2"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
                                    </div>
                                    <span class="text-dark mr-2">Raw Material</span>
                                </div>
                            </div>
                        </a>
                    
                        <a href="<?php echo e(route('purchase.index')); ?>" class="col-md-4 d-flex" style="width: 50%;">
                            <div class="card flex card-home">
                                <div class="card-body text-center">
                                    <div style="margin: 10px;">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="32px" height="32px" style="color:rgb(68, 139, 255);" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-cart mx-2"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
                                    </div>
                                    <span class="text-dark mr-2">Product</span>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ############ Main END-->
</div><?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/inventory/admin/index.blade.php ENDPATH**/ ?>