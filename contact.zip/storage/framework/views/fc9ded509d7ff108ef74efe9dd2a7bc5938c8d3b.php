<h1>This is Dashboard </h1>
<script>
    var loginUser = <?php echo json_encode($user, 15, 512) ?>;
    localStorage.setItem('f_name',loginUser.f_name)
    localStorage.setItem('s_name',loginUser.s_name)
    localStorage.setItem('email',loginUser.email)
    localStorage.setItem('image',loginUser.user_img)
</script><?php /**PATH C:\xampp\htdocs\anwesh\portal\resources\views/portal/dashboard/admin.blade.php ENDPATH**/ ?>