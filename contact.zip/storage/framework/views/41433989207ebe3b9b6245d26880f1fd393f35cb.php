<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>My Portal <?php echo $__env->yieldContent('pageTitle'); ?></title>
	<meta name="description" content="Responsive, Bootstrap, BS4">
	<meta name="_token" content="<?php echo e(csrf_token()); ?>" />
	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
	<!-- style -->
	<link rel="stylesheet" href="<?php echo e(asset('public/portal/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('public/portal/css/notification/jnoty.css')); ?>">
	<script src="<?php echo e(asset('public/portal/js/jquery-3.5.1.min.js')); ?>"></script>

	<script src="<?php echo e(asset('public/tinymce/tinymce.min.js')); ?>"></script>
	<!-- DataTables CSS -->
    <link href="<?php echo e(asset('public/portal/css/dataTables/dataTables.bootstrap.css')); ?>" rel="stylesheet">
    <!-- DataTables Responsive CSS -->
    <link href="<?php echo e(asset('public/portal/css/dataTables/dataTables.responsive.css')); ?>" rel="stylesheet">
</head>
<body class="layout-row">
<?php /**PATH C:\xampp\htdocs\anwesh\portal\resources\views/portal/layouts/header.blade.php ENDPATH**/ ?>