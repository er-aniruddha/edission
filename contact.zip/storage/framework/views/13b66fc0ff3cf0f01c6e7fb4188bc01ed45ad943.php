<div id="modal" class="modal fade show" aria-modal="true">
    <div class="modal-dialog text-dark">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white"></h5><button class="close" data-dismiss="modal">×</button>
            </div>
            <div class="modal-body">
                <div class="modal-body p-4">
                    <form id="unitForm" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mb-3">
                            <label class="text-muted">Unit Name</label>
                            <input class="form-control" type="text" id="unit_name" name="unit_name" placeholder="Enter Unit Name">
                            <span class="text-danger" id="unit_name_error"></span>
                        </div>
                        <div class="form-group mb-3">
                            <label class="text-muted">Unit Code</label>
                            <input class="form-control" type="text" id="unit_code" name="unit_code" placeholder="Enter Unit Code">
                            <span class="text-danger" id="unit_code_error"></span>
                        </div>
                        <div class="modal-footer">
                            <input type="hidden" name="unit_id" id="unit_id" />
                            <button class="btn btn-outline-dark" data-dismiss="modal" onclick="this.form.reset()">Close</button>
                            <button class="btn btn-primary" id="addBtn">Save</button>
                            <button class="btn btn-primary hide" id="editBtn">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
</div><?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/unit/modal.blade.php ENDPATH**/ ?>