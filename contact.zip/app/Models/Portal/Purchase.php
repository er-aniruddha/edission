<?php

namespace App\Models\Portal;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Purchase extends Model
{
    use HasFactory;
    protected $primaryKey = 'purchase_id';
    protected $table = 'purchases';
    protected $fillable = [
        'item_name',
        'unit_name',
        'qty',
        'unit_price',
    ];
}
