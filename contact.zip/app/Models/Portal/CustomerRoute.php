<?php

namespace App\Models\Portal;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerRoute extends Model
{
    use HasFactory;
    protected $primaryKey = 'customer_routes_id';
    protected $table = 'customer_routes';
}
