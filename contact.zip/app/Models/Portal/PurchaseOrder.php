<?php

namespace App\Models\Portal;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PurchaseOrder extends Model
{
    use HasFactory;
    // protected $primaryKey = 'purchase_order_id';
    protected $table = 'purchase_orders';
}
