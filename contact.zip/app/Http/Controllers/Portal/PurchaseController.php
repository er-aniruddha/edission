<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Purchase;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;

class PurchaseController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
      $purchase = Purchase::orderBy('purchase_id','DESC')->get();
    	if(request()->ajax())
        {
          return datatables()->of($purchase)                
                ->editColumn('date', function ($data) {
                    return date('d-m-Y', strtotime($data->date));
                })
                ->addIndexColumn()
                ->rawColumns(['date'])
                ->make(true);       
                    
        }        
        return view('portal.purchase.index',['purchase' => $purchase]);
    }

    public function create(Request $request)
    {
      // $data = $request->all();
      // return $data;
      if(request()->ajax())
      {
        if($request->date)
        {
          $date = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
          $validator_date = \Validator::make($date, [
            'date' => 'required|date|before:tomorrow|unique:purchases,date',         
          ],[
              'date.before' => 'The date mustbe today or before.',
              'date.unique' => 'Can not add two item on same date',
          ]);
          if ($validator_date->fails())         
          {
            return response()->json(['errors' => $validator_date->errors()]);
          }
        }
        $validator = \Validator::make($request->all(), [
          'date' => 'required|date|before:tomorrow',     
          'item_name.*' => 'required|max:255',
          'unit_name.*' => 'required|max:255',
          'qty.*' => 'required|integer|not_in:0',
          'unit_price.*' => 'required|not_in:0',
          'total_price.*' => 'required|not_in:0',
          'remarks' => 'required|max:255', 
          ],[
              'date.before' => 'The date mustbe today or before.',
              'item_name.*.required' => 'Item name required.',
              'unit_name.*.required' => 'Unit Name required.',
              'qty.*.required' => 'Quantity required.',
              'unit_price.*.required' => 'Unit price required.',
              'total_price.*.required' => 'Price required.',
        ]);
        if ($validator->fails())         
        {
          return response()->json(['errors' => $validator->errors()]);
        }
        
        if($validator->passes())
        {
          $data = $request->all();
          $New_start_index = 0;          
          $length = count($data['unit_price']);
          
          $item_name = array_combine(range($New_start_index,  count($request->item_name) + ($New_start_index-1)),
                array_values($request->item_name)); 

          $unit_name = array_combine(range($New_start_index,  count($request->unit_name) + ($New_start_index-1)),
                array_values($request->unit_name)); 

          $qty = array_combine(range($New_start_index,  count($request->qty) + ($New_start_index-1)),
                array_values($request->qty)); 

          $unit_price = array_combine(range($New_start_index,  count($request->unit_price) + ($New_start_index-1)),
                array_values($request->unit_price)); 

          $total_price = array_combine(range($New_start_index,  count($request->total_price) + ($New_start_index-1)),
                array_values($request->total_price)); 
          
          for($i=0; $i < $length; $i++)
          {
            $purchase = new Purchase;
            $purchase->item_name = Str::upper($item_name[$i]);
            $purchase->unit_name = Str::upper($unit_name[$i]);
            $purchase->qty = $qty[$i];                
            $purchase->unit_price = $unit_price[$i];
            $purchase->total_price = $total_price[$i];
            $purchase->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
            $purchase->remarks = Str::upper($request->remarks);
            $purchase->save();
          }
        }
          $purchaseUpdate =  Purchase::orderBy('purchase_id','DESC')->get();
          $success = array('success' => "Item added successfully." , 'purchase' => $purchaseUpdate);
          return response()->json($success);  
        }              
            
    }

    public function update(Request $request)
    {
      $data = $request->all();       
      $delete = json_decode($data['delete'], true);
      if(request()->ajax())
      {
        if(count($delete) != 0 )
        {
          for($i=0; $i < count($delete) ; $i++)
          {
            $item = Purchase::find($delete[$i]['id']);
            $item->delete();
            // return $item;          
          } 
          
        }// If there is a item to delete
        $collection = collect($request->all());
        $filter = $collection->except(['item_name.0','unit_name.0','qty.0','unit_price.0','total_price.0']); 
        if($filter['item_name'])
        {
          // anything need to be edit strat here 
          $purchase = Purchase::where('date',Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d'))->get();  

          if($request->date)
          {
            $reqDate = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
            if($purchase[0]['date'] != Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d'))
            {
              $validator_date = \Validator::make($reqDate, [
                'date' => 'required|date|before:tomorrow|unique:purchases,date',         
              ],[
                  'date.before' => 'The date mustbe today or before.',
                  'date.unique' => 'Can not add two item on same date',
              ]);
              if ($validator_date->fails())         
              {
                return response()->json(['errors' => $validator_date->errors()]);
              }
            }
          } 

          $validator = \Validator::make($filter->all(), [
          'date' => 'required|date|before:tomorrow',     
          'item_name.*' => 'required|max:255',
          'unit_name.*' => 'required|max:255',
          'qty.*' => 'required|integer|not_in:0',
          'unit_price.*' => 'required|not_in:0',
          'total_price.*' => 'required|not_in:0',
          'remarks' => 'required|max:255', 
          ],[
            'date.before' => 'The date mustbe today or before.',
            'item_name.*.required' => 'Item name required.',
            'unit_name.*.required' => 'Unit Name required.',
            'qty.*.required' => 'Quantity required.',
            'unit_price.*.required' => 'Unit price required.',
            'total_price.*.required' => 'Price required.',
          ]);

          if ($validator->fails())         
          {
            return response()->json(['errors' => $validator->errors()]);
          }
          $New_start_index = 1;          
          $length = count($data['unit_price']);
          
          $item_name = array_combine(range($New_start_index,  count($filter['item_name']) + ($New_start_index-1)),
                array_values($filter['item_name'])); 

          $unit_name = array_combine(range($New_start_index,  count($filter['unit_name']) + ($New_start_index-1)),
                array_values($filter['unit_name'])); 

          $qty = array_combine(range($New_start_index,  count($filter['qty']) + ($New_start_index-1)),
                array_values($filter['qty'])); 

          $unit_price = array_combine(range($New_start_index,  count($filter['unit_price']) + ($New_start_index-1)),
                array_values($filter['unit_price'])); 

          $total_price = array_combine(range($New_start_index,  count($filter['total_price']) + ($New_start_index-1)),
                array_values($filter['total_price'])); 
          if($validator->passes())
          {          
            
            $length = count($filter['unit_price']);  
                    
            for($i=1; $i < ($length+1); $i++)
            {                
              $purchase[$length-$i]['item_name'] = Str::upper($item_name[$i]);
              // $purchase[$length-$i]['unit_name'] = Str::upper($filter['unit_name'][$i]);
              $purchase[$length-$i]['unit_name'] = Str::upper($unit_name[$i]);
              $purchase[$length-$i]['qty'] = $qty[$i];                
              $purchase[$length-$i]['unit_price'] = $unit_price[$i];
              $purchase[$length-$i]['total_price'] = $total_price[$i];
              $purchase[$length-$i]['date'] = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
              $purchase[$length-$i]['remarks'] = Str::upper($request->remarks);
              $purchase[$length-$i]->update();
            }              
          }           
          
        }
        $purchaseUpdate =  Purchase::orderBy('purchase_id','DESC')->get();
        $success = array('success' => "Item updated successfully." , 'purchase' => $purchaseUpdate);
        return response()->json($success); 
              
      }//ajax request end
    }

    public function destroy(Request $request)
    {
      $date = $request->id; //here id refer for date because delete modal is common for all
      $data = Purchase::where('date', $date)->get();
      foreach ($data as $del) 
      {
        $del->delete();
      }
      $success = array('success' => "Item deleted successfully.");
      return response()->json($success);
    }
}

// $poUpdate = PurchaseOrder::where('purchase_orders_id',$purchaseOrder[$i]['purchase_orders_id'])->first();

//                 $poUpdate->party_id = Str::lower($request->party_id);
//                 $poUpdate->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');            
//                 $poUpdate->item_name = Str::lower($item_name[$i]);
//                 $poUpdate->unit_name = Str::lower($unit_name[$i]);
//                 $poUpdate->qty = $qty[$i];                
//                 $poUpdate->unit_price = $unit_price[$i];
//                 $poUpdate->amount = $amount[$i];
//                 $poUpdate->payment_type = Str::lower($request->payment_type);
//                 $poUpdate->round_off = $request->round_off;
//                 $poUpdate->gst_amount = $request->gst_amount;
//                 $poUpdate->total = $request->total;
//                 $poUpdate->advance = $request->advance;
//                 $poUpdate->balance = $request->balance;
//                 $poUpdate->remarks = $request->remarks;
//                 $poUpdate->update();