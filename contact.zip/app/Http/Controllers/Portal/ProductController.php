<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Product;
use App\Models\Portal\Brand;
use App\Models\Portal\Unit;
use Illuminate\Support\Str;
use DB;
use Validator;
use Image;  

class ProductController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {                            
        return view('portal.product.index');
    }

    public function list()
    {  
        $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                            ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                            ->select(array('products.*','p.unit_id as primary_unit_id','p.unit_name as primary_unit_name','s.unit_id as secondary_unit_id','s.unit_name as secondary_unit_name','brands.*'))
                            ->orderBy('product_id','DESC')
                            ->get();
        $brands = Brand::orderBy('brand_id','ASC')->get();
        $units = Unit::orderBy('unit_id','ASC')->get();
        if(request()->ajax())
        {
          return datatables()->of($products)
                ->addColumn('action', function($data){
                  $button = '<button type="button" name="view" id="'.$data->product_id.'" data-name="'.$data->product_name.'" data-desc="'.$data->product_desc.'" data-brand="'.$data->brand_id.'" data-punitid="'.$data->primary_unit_id.'" data-punitname="'.$data->primary_unit_name.'" data-primaryunitrate="'.$data->pri_unit_rate.'"data-secondaryunitrate="'.$data->sec_unit_rate.'" data-sunitid="'.$data->secondary_unit_id.'" data-sunitname="'.$data->secondary_unit_name.'" data-mrp="'.$data->product_mrp.'" data-noofpcs="'.$data->no_of_pcs.'" data-image="'.asset($data->product_img).'" data-production="'.$data->pro_type.'" data-status="'.$data->product_stat.'" class="view btn btn-outline-info  btn-sm">View</button>';
                  $button .= '&nbsp;';
                  $button .= '<button type="button" name="edit" id="'.$data->product_id.'" data-name="'.$data->product_name.'" data-desc="'.$data->product_desc.'" data-brand="'.$data->brand_id.'" data-punitid="'.$data->primary_unit_id.'" data-punitname="'.$data->primary_unit_name.'" data-primaryunitrate="'.$data->pri_unit_rate.'"data-secondaryunitrate="'.$data->sec_unit_rate.'" data-sunitid="'.$data->secondary_unit_id.'" data-sunitname="'.$data->secondary_unit_name.'" data-mrp="'.$data->product_mrp.'" data-noofpcs="'.$data->no_of_pcs.'" data-image="'.$data->product_img.'" data-production="'.$data->pro_type.'" data-status="'.$data->product_stat.'" class="edit btn btn-outline-primary btn-sm">Edit</button>';
                  $button .= '&nbsp;';
                  $button .= '<button type="button" name="delete" data-id="'.$data->product_id.'" data-name="'.$data->product_name.'" data-url="' . route('product.delete') .'"  class="delete btn btn-outline-danger btn-sm">Del</button>';
                  return $button;
                })
                ->addColumn('status', function($data){
                  if( $data->product_stat == 1)
                  {
                    $status = '<a id="'.$data->product_id.'" data-url="' . route('product.status',$data->product_id) .'" class="status badge badge-primary">Active</a>';  
                  }
                  else
                  {
                    $status = '<a id="'.$data->product_id.'" data-url="' . route('product.status',$data->product_id) .'" class="status badge badge-secondary" style="color: #fff">Deactive</a>';   
                  }
                  return $status;
                })
                ->addIndexColumn()
                ->rawColumns(['action' , 'status'])
                ->make(true);       
                    
        } 
        else{
            return view('portal.product.list',['brands' => $brands, 'units' => $units]);
        }           
        
    }

    public function create(Request $request)
    {   
        // $data = $request->all();
        // return response()->json($data);
        if(request()->ajax())
        {
            $validator = \Validator::make($request->all(), [
                'product_name' => 'required|max:255|unique:products,product_name',
                'product_desc' => 'required|max:255',
                'brand_id' => 'required|not_in:0',
                'pro_type' => 'required|not_in:0',
                'primary_unit' => 'required|not_in:0',
                'secondary_unit' => 'required|not_in:0',
                'no_of_pcs' => 'required|max:255',
                'product_mrp' => 'required|integer',
                'image' => 'required|mimes:jpeg,png,jpg,gif,svg|max:2048', 
            ],[
                'image.required'=>'Image format should be in jpeg,png,jpg,gif,svg|max:2048',
                'image.upload'=>'Image format should be in jpeg,png,jpg,gif,svg|max:2048',  
                'brand_id.required'=>'Please select brand.',    
                'pro_type.required'=>'Please select product type.',    
                'brand_id.not_in'=>'Please select brand.',    
                'pro_type.not_in'=>'Please select product type.',              
            ]);

            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }

            $product = new Product;
            $image = $request->file('image');
            if ($image){
                $image_name=Str::uuid();
                $ext=strtolower($image->getClientOriginalExtension());
                $image_full_name=$image_name.'.'.$ext;
                $upload_path='../img-file-manager/portal/product/';
                $image_url=$upload_path.$image_full_name;
                $resize_image = Image::make($image->getRealPath());
                $success = $resize_image->resize(270, 240)->save($upload_path . $image_full_name);
                if($success){
                    $product->product_img=$image_url;
                }
            }
            $product->product_name =Str::lower($request->product_name);
            $product->product_desc =Str::lower($request->product_desc);
            $product->brand_id = $request->brand_id;
            $product->pro_type = $request->pro_type;
            $product->primary_unit = $request->primary_unit;
            $product->secondary_unit = $request->secondary_unit;
            $product->no_of_pcs = $request->no_of_pcs;
            $product->product_mrp = $request->product_mrp;
            $product->pri_unit_rate = $request->product_mrp;
            $product->sec_unit_rate = $request->product_mrp/$request->no_of_pcs;
            $product->product_stat = $request->product_stat;
            $is_saved = $product->save();

            if($is_saved)
            {
                $success = array('success' => 'Product saved successfully');
                return response()->json($success);
            }
        }
    }
    /*
     * Update
     */
    public function update(Request $request)
    {
        // $data = $request->all();
        // return response()->json($data);
        $image = $request->file('image');
        $product = Product::find($request->product_id);

        if( $product->product_name == $request->product_name )
        {
            $validator = \Validator::make($request->all(), [
                'product_name' => 'required|max:255',
                'product_desc' => 'required|max:255',
                'brand_id' => 'required|not_in:0',
                'product_mrp' => 'required|integer',
                'pro_type' => 'required|not_in:0',                
            ],[               
                'brand_id.required'=>'Please select brand.',     
                'pro_type.required'=>'Please select product type.',                  
            ]);

            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }
        }
        else
        {
            $validator = \Validator::make($request->all(), [
                'product_name' => 'required|max:255|unique:products,product_name',
                'product_desc' => 'required|max:255',
                'brand_id' => 'required|not_in:0',
                'product_mrp' => 'required|integer',
                'pro_type' => 'required|not_in:0',
            ],[
                'brand_id.required'=>'Please select brand.',     
                'pro_type.required'=>'Please select product type.',                  
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }

        }
         if($image)
        {
            $validator = \Validator::make($request->all(), [          
                'image' => 'required|mimes:jpeg,png,jpg,gif,svg|max:2048|image'     
            ],[
                'image.required'=>'Image format should be in jpeg,png,jpg,gif,svg',
                'image.uploaded'=>'Image format should be in jpeg,png,jpg,gif,svg|max:2048', 
            ]); 

            if ($validator->fails())
            {          
                return response()->json(['errors' => $validator->errors()]);
            }
        }
        if($validator->passes())
        {
            if($image)
            {  
                if(file_exists($product->product_img)){
                    unlink($product->product_img);
                }
                /*$image_name=$required->product_id.$image->getClientOriginalExtension();
                $upload_path='public/image/';
                $image_url=$upload_path.$image_name;*/

                $image_name=Str::uuid();;
                $ext=strtolower($image->getClientOriginalExtension());
                $image_full_name=$image_name.'.'.$ext;
                $upload_path='../img-file-manager/portal/product/';
                $image_url=$upload_path.$image_full_name;
                $success=$image->move($upload_path,$image_full_name);
                if($success){
                    $product->product_img = $image_url;
                }
                $product->product_name =Str::lower($request->product_name);
                $product->product_desc =Str::lower($request->product_desc);
                $product->brand_id = $request->brand_id;
                $product->pro_type = $request->pro_type;
                $product->primary_unit = $request->primary_unit;
                $product->secondary_unit = $request->secondary_unit;
                $product->no_of_pcs = $request->no_of_pcs;
                $product->product_mrp = $request->product_mrp;
                $product->pri_unit_rate = $request->product_mrp;
                $product->sec_unit_rate = $request->product_mrp/$request->no_of_pcs;
                $product->product_stat = $request->product_stat;
                $is_saved = $product->update();

                if($is_saved)
                {
                    $success = array('success' => 'Product updated successfully');
                    return response()->json($success);   
                }
                           
            }
            else
            {
                $product->product_img = $request->image_update;       
                $product->product_name =Str::lower($request->product_name);
                $product->product_desc =Str::lower($request->product_desc);
                $product->brand_id = $request->brand_id;
                $product->pro_type = $request->pro_type;
                $product->primary_unit = $request->primary_unit;
                $product->secondary_unit = $request->secondary_unit;
                $product->no_of_pcs = $request->no_of_pcs;
                $product->product_mrp = $request->product_mrp;
                $product->pri_unit_rate = $request->product_mrp;
                $product->sec_unit_rate = $request->product_mrp/$request->no_of_pcs;
                $product->product_stat = $request->product_stat;
                $is_saved = $product->update();
                // $brands->timestamps = now();
                if($is_saved)
                {
                    $success = array('success' => 'Product updated successfully');
                    return response()->json($success);   
                }
            } 
        } 
           
    }
    /*
     * Change Status
     */
    public function status($product_id)
    {
        $product = Product::find($product_id);
        if($product->product_stat == 1)
        {
            Product::where('product_id',$product_id)->update(['product_stat' => 0]);
            $success = array('success' => 'Product status change successfullly');
            return response()->json($success);
        }
        else
        {
            Product::where('product_id',$product_id)->update(['product_stat' => 1]);
            $success = array('success' => 'Product status change successfullly');
            return response()->json($success);
        }
    }

    /*
     * Remove Product
     */
    public function destroy(Request $request)
    {
        $product = Product::find($request->id);

        if(file_exists($product->product_img))
        {
            unlink($product->product_img);
            $product->delete();
            $success = array('success' => 'Product deleted successfully');
            return response()->json($success);
        }
        else
        {
            $product->delete();
            $success = array('success' => 'Product deleted successfully');
            return response()->json($success);
        }
       
    }
}
