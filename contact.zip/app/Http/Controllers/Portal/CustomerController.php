<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Customer;
use App\Models\Portal\Routes;
use App\Models\Portal\Product;
use App\Models\Portal\Sale;
use App\Models\Portal\Unit;
use App\Models\Portal\Stock;
use App\Models\Portal\PaymentIn;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Validator;

class CustomerController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function all()
    {        
        $customers = Customer::orderBy('f_name','ASC')
                                ->join('routes','customers.route_id',"=",'routes.route_id')->get(); 
        $routes = Routes::orderBy('route_id','ASC')->get();       

        if(request()->ajax())
        {
            return datatables()->of($customers)
            ->addColumn('name', function($data){                  
                $name = '<a href="page.invoice.detail.html" class="item-company ajax h-1x" data-pjax-state="">'.$data->f_name.' '.$data->s_name.'</a>
                        <div class="item-mail text-muted h-1x d-none d-sm-block">'.$data->shop_name.'</div>
                        <div class="item-mail text-muted h-1x d-none d-sm-block hide">'.$data->route_name.'</div>'; 
              return $name;
            })  
            ->addColumn('action', function($data){                  
                $action = '<div> <!-- Vied,Edit -->
                                <div class="item-action dropdown">
                                    <a href="#" data-toggle="dropdown" class="text-muted">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"
                                            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                            class="feather feather-more-vertical">
                                            <circle cx="12" cy="12" r="1"></circle>
                                            <circle cx="12" cy="5" r="1"></circle>
                                            <circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" role="menu">
                                        <a class="dropdown-item view" href="'.route('customer.details',$data->customer_id).'">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>View
                                        </a>
                                        <a class="dropdown-item edit" data-id="'.$data->customer_id.'" data-fname="'.$data->f_name.'" 
                                            data-sname="'.$data->s_name.'" data-shop="'.$data->shop_name.'" data-phone1="'.$data->phone_1.'" data-phone2="'.$data->phone_2.'" data-whatsapp="'.$data->whatsapp_no.'" data-email="'.$data->email.'" data-route="'.$data->route_id.'" data-locality="'.$data->locality.'" data-district="'.$data->district.'" data-pin="'.$data->pin.'" data-addline1="'.$data->addline_1.'" data-addline2="'.$data->addline_2.'" data-toggle="modal" data-target="#editModal">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"></path><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"></polygon></svg>Edit
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <delete class="dropdown-item trash" data-id="'.$data->customer_id.'" data-shop="'.$data->shop_name.'">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>
                                            </svg>Delete
                                        </delete>
                                    </div>
                                </div>
                            </div>'; 
              return $action;
            })   
            ->addIndexColumn()
            ->rawColumns(['action','name'])  
            ->make(true);       
                    
        } 
        else{
            return view("portal.customer.all",["customers" => $customers, "routes" => $routes ]);
        }       
    }

    public function create(Request $request)
    {
        if($request->isMethod('post'))
        {
            $validator = \Validator::make($request->all(), [
                'f_name' => 'required|max:255',
                's_name' => 'required|max:255',
                'shop_name' => 'required|max:255',
                'phone_1' => 'required|min:10|numeric|regex:/[6-9][0-9]{9}/|unique:customers,phone_1',
                'email' => 'nullable|email|unique:customers,email',
                'route_id' => 'required|not_in:0',
                'locality' => 'required|max:255',
                'district' => 'required|max:255',
                'pin' => 'required|min:6',
                ],[
                    'f_name.required' => 'Please enter first name.',
                    's_name.required' => 'Please enter surname.',

                    'phone_1.required' => 'Please enter valid phone number.',
                    'phone_1.min' => 'Please enter valid phone number.',
                    'phone_1.numeric' => 'Please enter valid phone number.',
                    'phone_1.regex' => 'Please enter valid phone number.',
                    'phone_1.unique' => 'Phone nuber already been taken.',

                    'route_id.required' => 'Please select route.',
                ]);
                if ($validator->fails())         
                {
                    return response()->json(['errors' => $validator->errors()]);
                }

                $customer = new Customer;
                $customer->f_name = $request->f_name;
                $customer->s_name = $request->s_name;
                $customer->shop_name = $request->shop_name;
                $customer->phone_1 = $request->phone_1;
                $customer->phone_2 = $request->phone_2;
                $customer->whatsapp_no = $request->whatsapp_no;
                $customer->email = $request->email;
                $customer->route_id = $request->route_id;
                $customer->locality = $request->locality;
                $customer->district = $request->district;
                $customer->state = $request->state;
                $customer->pin = $request->pin;
                $customer->addline_1 = $request->addline_1;
                $customer->addline_2 = $request->addline_2;               
                $is_saved = $customer->save();

                if($is_saved)
                {
                    $success = array('success' => 'Customer added successfully');
                    return response()->json($success);
                }

        }
        /*
         * if condition end here 
         */
        else
        {
            $routes = Routes::orderBy('route_id','ASC')->get();
            return view('portal.customer.create',['routes' => $routes]);
        }  
    }

    public function details($customer_id)
    {
        $routes = Routes::orderBy('route_id','ASC')->get();
        $customer = Customer::find($customer_id);
        $customers = Customer::orderBy('customer_id','ASC')
                                ->join('routes','customers.route_id',"=",'routes.route_id')
                                ->get();
        $saleTable = Sale::where('sales.customer_id',$customer_id)
                                ->leftJoin('products','sales.item_name','=','products.product_id')
                                ->leftJoin('customers','sales.customer_id','=','customers.customer_id')
                                ->leftJoin('units','sales.unit_id','=','units.unit_id')
                                ->select(array('sales.*','products.*','customers.*','units.*','sales.balance'))
                                ->orderBy('sales.date','desc')
                                ->get()->unique('invoice_id'); 
        if(request()->ajax())
        {
          return datatables()->of($saleTable)
                ->editColumn('date', function ($data) {
                    return date('d-m-Y', strtotime($data->date));
                })        
                ->addColumn('action', function($data){                  
                    $action = '<div class="item-action dropdown">
                                    <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right bg-black" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                        <a class="dropdown-item view" href="#" id="'.$data->invoice_id.'">See detail </a>
                                        <a class="dropdown-item edit">Edit</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item trash">Delete item</a>
                                    </div>
                                </div>'; 
                  return $action;
                })
                ->addIndexColumn()    
                ->rawColumns(['action','balance'])                   
                ->make(true); 
        }

        else{

            $sales = Sale::leftJoin('products','sales.item_name','=','products.product_id')
                                ->leftJoin('customers','sales.customer_id','=','customers.customer_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units','sales.unit_id','=','units.unit_id')
                                ->select(array('sales.*','products.*','customers.*','units.*'))
                                ->orderBy('sale_id','desc')
                                ->get();             
            return view('portal.customer.details',['sales' => $sales, 'routes' => $routes, 'customers' => $customers, 'customer' => $customer]);
        }    
    }

    public function payments($customer_id)
    {
        $payments = PaymentIn::where('payment_ins.customer_id',$customer_id)
                            ->leftJoin('customers','payment_ins.customer_id','customers.customer_id')
                            ->select(array('payment_ins.*','customers.*','payment_ins.balance'))
                            ->orderBy('payment_ins.date','desc')
                            ->get();
        if(request()->ajax())
        {
          return datatables()->of($payments)
                ->editColumn('date', function ($data) {
                    return date('d-m-Y', strtotime($data->date));
                })          
                ->addColumn('action', function($data){                  
                    $action = '<div class="item-action dropdown">
                                    <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right bg-black" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                        <a class="dropdown-item view" href="#" id="'.$data->invoice_id.'">See detail </a>
                                        <a class="dropdown-item edit">Edit</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item trash">Delete item</a>
                                    </div>
                                </div>'; 
                  return $action;
                })
                ->addIndexColumn()    
                ->rawColumns(['action'])                   
                ->make(true); 
        }
    }

    public function update(Request $request)
    {
        $customer = Customer::find($request->customer_id);

        if($customer->phone_1 == $request->phone_1 && $customer->email == $request->email)
        {
            $validator = \Validator::make($request->all(), [
            'f_name' => 'required|max:255',
            's_name' => 'required|max:255',
            'shop_name' => 'required|max:255',
            'phone_1' => 'required|min:10|numeric|regex:/[6-9][0-9]{9}/',
            'email' => 'nullable|email',
            'route_id' => 'required|not_in:0',
            'locality' => 'required|max:255',
            'district' => 'required|max:255',
            'pin' => 'required|min:6',
            ],[
                'f_name.required' => 'Please enter first name.',
                's_name.required' => 'Please enter surname.',
                'phone_1.required' => 'Please enter valid phone number.',
                'phone_1.min' => 'Please enter valid phone number.',
                'phone_1.numeric' => 'Please enter valid phone number.',
                'phone_1.regex' => 'Please enter valid phone number.',
                'route_id.required' => 'Please select route.',
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }

            
            $customer->f_name = $request->f_name;
            $customer->s_name = $request->s_name;
            $customer->shop_name = $request->shop_name;
            $customer->phone_1 = $request->phone_1;
            $customer->phone_2 = $request->phone_2;
            $customer->whatsapp_no = $request->whatsapp_no;
            $customer->email = $request->email;
            $customer->route_id = $request->route_id;
            $customer->locality = $request->locality;
            $customer->district = $request->district;
            $customer->state = $request->state;
            $customer->pin = $request->pin;
            $customer->addline_1 = $request->addline_1;
            $customer->addline_2 = $request->addline_2;               
            $is_saved = $customer->update();

            if($is_saved)
            {
                $success = array('success' => 'Customer updated successfully');
                return response()->json($success);
            }
        } //if condition end here
        else
        {
            $validator = \Validator::make($request->all(), [
            'f_name' => 'required|max:255',
            's_name' => 'required|max:255',
            'shop_name' => 'required|max:255',
            'phone_1' => 'required|min:10|numeric|regex:/[6-9][0-9]{9}/|unique:customers,phone_1',
            'email' => 'nullable|email|unique:customers,email',
            'route_id' => 'required|not_in:0',
            'locality' => 'required|max:255',
            'district' => 'required|max:255',
            'pin' => 'required|min:6',
            ],[
                'f_name.required' => 'Please enter first name.',
                's_name.required' => 'Please enter surname.',
                'phone_1.required' => 'Please enter valid phone number.',
                'phone_1.min' => 'Please enter valid phone number.',
                'phone_1.numeric' => 'Please enter valid phone number.',
                'phone_1.regex' => 'Please enter valid phone number.',
                'phone_1.unique' => 'Phone nuber already been taken.',
                'route_id.required' => 'Please select route.',
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }

            
            $customer->f_name = $request->f_name;
            $customer->s_name = $request->s_name;
            $customer->shop_name = $request->shop_name;
            $customer->phone_1 = $request->phone_1;
            $customer->phone_2 = $request->phone_2;
            $customer->whatsapp_no = $request->whatsapp_no;
            $customer->email = $request->email;
            $customer->route_id = $request->route_id;
            $customer->locality = $request->locality;
            $customer->district = $request->district;
            $customer->state = $request->state;
            $customer->pin = $request->pin;
            $customer->addline_1 = $request->addline_1;
            $customer->addline_2 = $request->addline_2;               
            $is_saved = $customer->update();

            if($is_saved)
            {
                $success = array('success' => 'Customer updated successfully');
                return response()->json($success);
            }

        }//else condition end here
        
    }

    public function destroy(Request $request)
    {
        $customer = Customer::find($request->id);
        $is_saved = $customer->delete();

        if($is_saved)
        {
            $success = array('success' => 'Customer deleted successfully');
            return response()->json($success);
        }

    }

    /*
     * Customer Routes all function Strat here
     */
    public function createRoutes(Request $request)
    {
        // $data = $request->all();
        // return $data;Str::ucfirst

        $validator = \Validator::make($request->all(), [
            'route_name' => 'required|max:255|unique:routes,route_name',
            ],[
            'route_name.unique' => 'Already exists',
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }

        $route = new Routes;
        $route->route_name = Str::ucfirst($request->route_name);
        $is_saved = $route->save();

        if($is_saved)
        {
            $success = array('success' => 'Route added successfully');
            return response()->json($success);
        }

    }

    public function editRoutes(Request $request)
    {   
        $validator = \Validator::make($request->all(), [
            'route_name' => 'required|max:255|unique:routes,route_name',
        ],[
            'route_name.unique' => 'Already exists',
        ]);
        if ($validator->fails())         
        {
            return response()->json(['errors' => $validator->errors()]);
        }

        $route = Routes::find($request->route_id);

        $route->route_name = $request->route_name;
        $is_saved = $route->update();

        if($is_saved)
        {
            $success = array('success' => 'Route updated successfully');
            return response()->json($success);
        }

    }

}
