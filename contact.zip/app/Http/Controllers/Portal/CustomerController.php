<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Customer;
use App\Models\Portal\Routes;
use App\Models\Portal\Product;
use App\Models\Portal\Stock;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Validator;

class CustomerController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {   
        return view("portal.customer.index");
    }

    public function all()
    {        
        $customers = Customer::orderBy('customer_id','ASC')
                                ->join('routes','customers.route_id',"=",'routes.route_id')->get(); 
        $routes = Routes::orderBy('route_id','ASC')->get();       
        return view("portal.customer.all",['customers' => $customers , "routes" => $routes ]);
    }

    public function create(Request $request)
    {
        if($request->isMethod('post'))
        {
            $validator = \Validator::make($request->all(), [
                'f_name' => 'required|max:255',
                's_name' => 'required|max:255',
                'shop_name' => 'required|max:255',
                'phone_1' => 'required|min:10|numeric|regex:/[6-9][0-9]{9}/|unique:customers,phone_1',
                'email' => 'nullable|email|unique:customers,email',
                'route_id' => 'required|not_in:0',
                'locality' => 'required|max:255',
                'district' => 'required|max:255',
                'pin' => 'required|min:6',
                ],[
                    'f_name.required' => 'Please enter first name.',
                    's_name.required' => 'Please enter surname.',

                    'phone_1.required' => 'Please enter valid phone number.',
                    'phone_1.min' => 'Please enter valid phone number.',
                    'phone_1.numeric' => 'Please enter valid phone number.',
                    'phone_1.regex' => 'Please enter valid phone number.',
                    'phone_1.unique' => 'Phone nuber already been taken.',

                    'route_id.required' => 'Please select route.',
                ]);
                if ($validator->fails())         
                {
                    return response()->json(['errors' => $validator->errors()]);
                }

                $customer = new Customer;
                $customer->f_name = $request->f_name;
                $customer->s_name = $request->s_name;
                $customer->shop_name = $request->shop_name;
                $customer->phone_1 = $request->phone_1;
                $customer->phone_2 = $request->phone_2;
                $customer->whatsapp_no = $request->whatsapp_no;
                $customer->email = $request->email;
                $customer->route_id = $request->route_id;
                $customer->locality = $request->locality;
                $customer->district = $request->district;
                $customer->state = $request->state;
                $customer->pin = $request->pin;
                $customer->addline_1 = $request->addline_1;
                $customer->addline_2 = $request->addline_2;               
                $is_saved = $customer->save();

                if($is_saved)
                {
                    $success = array('success' => 'Customer added successfully');
                    return response()->json($success);
                }

        }
        /*
         * if condition end here 
         */
        else
        {
            $routes = Routes::orderBy('route_id','ASC')->get();
            return view('portal.customer.create',['routes' => $routes]);
        }  
    }

    public function details($customer_id)
    {
        $customer = Customer::find($customer_id);
        $routes = Routes::orderBy('route_id','ASC')->get();
        $customers = Customer::orderBy('customer_id','ASC')
                                ->join('routes','customers.route_id',"=",'routes.route_id')
                                ->get();
        $products = Product::join('brands','products.brand_id','=','brands.brand_id')                              
                              ->orderBy('product_id','DESC')->get();
        $stocks = Stock::orderBy('stock_id','DESC')
                        ->join('production_costs','stocks.cost_id','=','production_costs.cost_id') 
                        ->join('products','stocks.product_id','=','products.product_id') 
                        ->where('stock_stat',1)->get();

        return view('portal.customer.details',['customer' => $customer, 'routes' => $routes, 'customers' => $customers ,'products' => $products, 'stocks' => $stocks]);
    }

    public function update(Request $request)
    {
        $customer = Customer::find($request->customer_id);

        if($customer->phone_1 == $request->phone_1 && $customer->email == $request->email)
        {
            $validator = \Validator::make($request->all(), [
            'f_name' => 'required|max:255',
            's_name' => 'required|max:255',
            'shop_name' => 'required|max:255',
            'phone_1' => 'required|min:10|numeric|regex:/[6-9][0-9]{9}/',
            'email' => 'nullable|email',
            'route_id' => 'required|not_in:0',
            'locality' => 'required|max:255',
            'district' => 'required|max:255',
            'pin' => 'required|min:6',
            ],[
                'f_name.required' => 'Please enter first name.',
                's_name.required' => 'Please enter surname.',
                'phone_1.required' => 'Please enter valid phone number.',
                'phone_1.min' => 'Please enter valid phone number.',
                'phone_1.numeric' => 'Please enter valid phone number.',
                'phone_1.regex' => 'Please enter valid phone number.',
                'route_id.required' => 'Please select route.',
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }

            
            $customer->f_name = $request->f_name;
            $customer->s_name = $request->s_name;
            $customer->shop_name = $request->shop_name;
            $customer->phone_1 = $request->phone_1;
            $customer->phone_2 = $request->phone_2;
            $customer->whatsapp_no = $request->whatsapp_no;
            $customer->email = $request->email;
            $customer->route_id = $request->route_id;
            $customer->locality = $request->locality;
            $customer->district = $request->district;
            $customer->state = $request->state;
            $customer->pin = $request->pin;
            $customer->addline_1 = $request->addline_1;
            $customer->addline_2 = $request->addline_2;               
            $is_saved = $customer->update();

            if($is_saved)
            {
                $success = array('success' => 'Customer updated successfully');
                return response()->json($success);
            }
        } //if condition end here
        else
        {
            $validator = \Validator::make($request->all(), [
            'f_name' => 'required|max:255',
            's_name' => 'required|max:255',
            'shop_name' => 'required|max:255',
            'phone_1' => 'required|min:10|numeric|regex:/[6-9][0-9]{9}/|unique:customers,phone_1',
            'email' => 'nullable|email|unique:customers,email',
            'route_id' => 'required|not_in:0',
            'locality' => 'required|max:255',
            'district' => 'required|max:255',
            'pin' => 'required|min:6',
            ],[
                'f_name.required' => 'Please enter first name.',
                's_name.required' => 'Please enter surname.',
                'phone_1.required' => 'Please enter valid phone number.',
                'phone_1.min' => 'Please enter valid phone number.',
                'phone_1.numeric' => 'Please enter valid phone number.',
                'phone_1.regex' => 'Please enter valid phone number.',
                'phone_1.unique' => 'Phone nuber already been taken.',
                'route_id.required' => 'Please select route.',
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }

            
            $customer->f_name = $request->f_name;
            $customer->s_name = $request->s_name;
            $customer->shop_name = $request->shop_name;
            $customer->phone_1 = $request->phone_1;
            $customer->phone_2 = $request->phone_2;
            $customer->whatsapp_no = $request->whatsapp_no;
            $customer->email = $request->email;
            $customer->route_id = $request->route_id;
            $customer->locality = $request->locality;
            $customer->district = $request->district;
            $customer->state = $request->state;
            $customer->pin = $request->pin;
            $customer->addline_1 = $request->addline_1;
            $customer->addline_2 = $request->addline_2;               
            $is_saved = $customer->update();

            if($is_saved)
            {
                $success = array('success' => 'Customer updated successfully');
                return response()->json($success);
            }

        }//else condition end here
        
    }

    public function destroy(Request $request)
    {
        $customer = Customer::find($request->id);
        $is_saved = $customer->delete();

        if($is_saved)
        {
            $success = array('success' => 'Customer deleted successfully');
            return response()->json($success);
        }

    }

    /*
     * Customer Routes all function Strat here
     */
    public function createRoutes(Request $request)
    {
        // $data = $request->all();
        // return $data;Str::ucfirst

        $validator = \Validator::make($request->all(), [
            'route_name' => 'required|max:255|unique:routes,route_name',
            ],[
            'route_name.unique' => 'Already exists',
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }

        $route = new Routes;
        $route->route_name = Str::ucfirst($request->route_name);
        $is_saved = $route->save();

        if($is_saved)
        {
            $success = array('success' => 'Route added successfully');
            return response()->json($success);
        }

    }

    public function editRoutes(Request $request)
    {   
        $validator = \Validator::make($request->all(), [
            'route_name' => 'required|max:255|unique:routes,route_name',
        ],[
            'route_name.unique' => 'Already exists',
        ]);
        if ($validator->fails())         
        {
            return response()->json(['errors' => $validator->errors()]);
        }

        $route = Routes::find($request->route_id);

        $route->route_name = $request->route_name;
        $is_saved = $route->update();

        if($is_saved)
        {
            $success = array('success' => 'Route updated successfully');
            return response()->json($success);
        }

    }

}
