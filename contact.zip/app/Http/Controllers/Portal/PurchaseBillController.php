<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\PurchaseOrder;
use App\Models\Portal\Product;
use App\Models\Portal\Unit;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;

class PurchaseBillController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {  
        $purchaBillUnique = PurchaseOrder::leftJoin('products','purchase_orders.item_name','=','products.product_id')
                                ->leftJoin('units', 'purchase_orders.unit_id','=','units.unit_id') 
                                ->select(array('purchase_orders.*','products.*','units.*'))
                                ->orderBy('purchase_order_id','desc')
                                ->where('purchase_orders.status',1)
                                ->get()->unique('po_id'); 
        // return response()->json($allPurchaseBill);
        if(request()->ajax())
        {
          return datatables()->of($purchaBillUnique)
                ->editColumn('date', function ($data) {
                    return date('d-m-Y', strtotime($data->date));
                })
                ->addColumn('action', function($data){
                    $button = '<button type="button" id="'.$data->po_id.'" data-date="'.$data->date.'" class="view btn btn-outline-info  btn-sm">View</button>';
                    $button .= '&nbsp;';                  
                    return $button;
                })
                ->addColumn('status', function($data){                  
                    $status = '<span class="item-badge badge text-uppercase bg-success">Order Complete</span>';  
                    return $status;
                })
                ->addIndexColumn()
                ->rawColumns(['action' , 'status'])                
                ->make(true); 
        } 
        else{   
            $allPurchaseBill = PurchaseOrder::leftJoin('products','purchase_orders.item_name','=','products.product_id')
                                ->leftJoin('units', 'purchase_orders.unit_id','=','units.unit_id') 
                                ->select(array('purchase_orders.*','products.*','units.*'))
                                ->orderBy('purchase_order_id','desc')
                                ->where('purchase_orders.status',1)
                                ->get();         
            return view('portal.purchase_bill.index',['allPurchaseBill' => $allPurchaseBill]);
        }    
    }
}
