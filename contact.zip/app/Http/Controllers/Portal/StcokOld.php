<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Product;
use App\Models\Portal\Stock;
use App\Models\Portal\ProductionCost;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;


class StockController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
    	$products = Product::orderBy('product_id','DESC')->get();
    	$costs = ProductionCost::orderBy('cost_id','DESC')->get()->unique('cost_name');
        $allStocks = Stock::join('products','stocks.product_id','=','products.product_id')
                  ->join('production_costs','stocks.cost_id','=','production_costs.cost_id')     
                  ->select(array('products.product_id','products.product_img','products.product_name','production_costs.cost_name','production_costs.cost_total','stocks.sku_code','stocks.maker_name','stocks.date','stocks.in_hand_stock','stocks.sku_count','stocks.stock_stat','stocks.stock_id'))
                  ->orderBy('stocks.stock_id','DESC')->get();
        $stocks = Stock::orderBy('stocks.stock_id','DESC')->get()->unique('sku_code');   
        if(request()->ajax())
        {
            return Datatables()->of($allStocks)
                ->addColumn('action', function($data){
                    $button = '<a type="button" data-proName="'.$data->product_name.'"  data-maker="'.$data->maker_name.'" data-date="'.date('d-m-Y', strtotime($data->date)).'" data-code="'.$data->sku_code.'" data-cost="'.$data->cost_total.'" data-qty="'.$data->in_hand_stock.'" data-stat="'.$data->stock_stat.'"class="view btn btn-outline-info  btn-sm">View</a>';
                    $button .= '&nbsp;';
                    $button .= '<a type="button" data-id="'.$data->stock_id.'"  data-maker="'.$data->maker_name.'" data-date="'.date('d-m-Y', strtotime($data->date)).'" data-code="'.$data->sku_code.'" data-cost="'.$data->cost_total.'" data-qty="'.$data->in_hand_stock.'" data-stat="'.$data->stock_stat.'" class="edit btn btn-outline-primary btn-sm">Edit</a>';
                    $button .= '&nbsp;';
                    $button .= '<button type="button" data-id="'.$data->stock_id.'"  data-code="'.$data->sku_code.'" data-url="' . route('stock.delete', $data->stock_id) .'" class="delete btn btn-outline-danger btn-sm">Del</button>';
                  return $button;
                })
                ->addColumn('sku', function($data){
                    if($data->sku_count < 10)
                    {
                        $sku = $data->sku_code.'-0'.$data->sku_count; 
                    }
                    else
                    {
                        $sku = $data->sku_code.'-'.$data->sku_count; 
                    }
                      
                   
                    return $sku;
                })
                ->addColumn('status', function($data){
                    if( $data->stock_stat == 1)
                    {
                        $status = '<a id="'.$data->stock_id.'" data-url="' . route('stock.status', $data->stock_id) .'" class="status badge badge-primary">Active</a>';  
                    }
                    else
                    {
                        $status = '<a id="'.$data->stock_id.'" data-url="' . route('stock.status', $data->stock_id) .'" class="status badge badge-secondary" style="color: #fff">Deactive</a>';   
                    }
                    return $status;
                })
                ->editColumn('date', function ($data) {
                    return date('d-m-Y', strtotime($data->date));
                })
                ->addIndexColumn()              
                ->rawColumns(['action','status','date','sku'])
                ->make(true);     
        }        
        return view('portal.stock.index',['costs' => $costs , 'products' => $products, 'stocks' => $stocks]);        
    }

    public function createNew(Request $request)
    {
    	$validator = \Validator::make($request->all(), [
            'product_id' => 'required',
            'maker_name' => 'required|not_in:0',
            'date' => 'required|date|before:tomorrow',
            'sku_code' => 'required|max:255|unique:stocks,sku_code',
            'cost_id' => 'required|not_in:0',
            'sku_qty' => 'required',

            ],[
                'date.before' => 'The date mustbe today or before.',
                'cost_id.required' => 'The cost field is required',
                'sku_qty.required' => 'The stock quantity field is required',
        ]);

        if ($validator->fails())         
        {
            return response()->json(['errors' => $validator->errors()]);
        }

        if($validator->passes())
        {
            //$stock = $request->all();
            $stock = new Stock;
            $stock->product_id = $request->product_id;
            $stock->maker_name = $request->maker_name;
            $stock->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
            $stock->sku_code = $request->sku_code;
            $stock->cost_id = $request->cost_id;
            $stock->in_hand_stock = $request->sku_qty;
            $stock->sku_count = 1;
            $stock->stock_stat = $request->stock_stat;
            $is_save = $stock->save();

            if($is_save)
            {
                $stocks = Stock::orderBy('stocks.stock_id','DESC')->get()->unique('sku_code');   
                $success = array('success' => 'Stock saved successfully' , 'stocks' => $stocks);
                return response()->json($success);
            }
            
        }
    }	

    public function updateExs(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'sku_code' => 'required|not_in:0',
            'date' => 'required|date|before:tomorrow',
            'cost_id' => 'required|not_in:0',
            'sku_qty' => 'required',

            ],[
                'date.before' => 'The date mustbe today or before.',
                'cost_id.required' => 'The cost field is required',
                'sku_qty.required' => 'The stock quantity field is required',
        ]);

        if ($validator->fails())         
        {
            return response()->json(['errors' => $validator->errors()]);
        }

        if($validator->passes())
        {
            //$stock = $request->all();
            $skuCount = Stock::where('sku_code',$request->sku_code)->count();
            $data = Stock::where('sku_code',$request->sku_code)->first();

            $stock = new Stock;
            $stock->product_id = $data->product_id;
            $stock->maker_name = $data->maker_name;
            $stock->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
            $stock->sku_code = $request->sku_code;
            $stock->cost_id = $request->cost_id;
            $stock->in_hand_stock = $request->sku_qty;
            $stock->sku_count = $skuCount+1; 
            $stock->stock_stat = $request->stock_stat;
            $is_save = $stock->save();

            if($is_save)
            {
                $success = array('success' => 'Stock saved successfully');
                return response()->json($success);
            }
            
        }
    }


    // public function view(Request $request)
    // {	
    // 	$start_date = Carbon::createFromFormat('d/m/Y', $request->start_date)->format('Y/m/d');
    // 	$end_date = Carbon::createFromFormat('d/m/Y', $request->end_date)->format('Y/m/d');

    // 	$data = Stock::where('date', '>=', $start_date)
    // 					->where('date' , '<=' ,$end_date)
    // 					->get();
    // 	// $data = $request->all();
    // 	return $data;
    // }

    public function status($stock_id)
    {
        $stock = Stock::find($stock_id);

        if($stock->stock_stat == 1)
        {
            Stock::where('stock_id',$stock_id)->update(['stock_stat' => 0]);
            $success = array('success' => 'Stock status change successfullly');
            return response()->json($success);
        }
        else
        {
            Stock::where('stock_id',$stock_id)->update(['stock_stat' => 1]);
            $success = array('success' => 'Stock status change successfullly');
            return response()->json($success);
        }

    }

    public function destroy(Request $request)
    {
        $stock = Stock::find($request->id);
        $is_delete = $stock->delete();
        $stocks = Stock::orderBy('stocks.stock_id','DESC')->get()->unique('sku_code');  
        if($is_delete)
        {
            $allStocks = Stock::orderBy('stocks.stock_id','DESC')->get()->unique('sku_code');   
            $success = array('success' => 'Stock deleted successfullly' , 'stocks' => $stocks);
            return response()->json($success);
        }
        
    }
}
