<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\ProductionCost;
use Illuminate\Support\Str;
use Validator;

class ProductionCostController extends Controller
{
    public function index()
    {
    	$cost = ProductionCost::orderBy('cost_id','DESC')->get();
    	$data = $cost->unique('cost_name');
        // $data = $costName->unique('cost_qty');

    	if(request()->ajax())
        {
          return datatables()->of($data)
                ->addColumn('action', function($data){
                  $button = '<button type="button" name="view" id="'.$data->cost_id.'" data-name="'.$data->cost_name.'" class="view btn btn-outline-info btn-sm">View</button>';
                  $button .= '&nbsp;';
                  $button .= '<button type="button" name="edit" id="'.$data->cost_id.'" class="edit btn btn-outline-primary btn-sm">Edit</button>';
                  $button .= '&nbsp;';
                  $button .= '<button type="button" name="delete" data-id="'.$data->cost_id.'" data-name="'.$data->cost_name.'" data-url="' . route('productionCost.delete') .'"  class="delete btn btn-outline-danger btn-sm">Del</button>';
                  return $button;
                })
                ->addColumn('amount', function($data){                  
                    $amount = $data->cost_total;
                  return $amount;
                })
                ->addColumn('status', function($data){
                  if( $data->cost_stat == 1)
                  {
                    $status = '<a id="'.$data->cost_id.'" data-url="' . route('productionCost.status', $data->cost_id) .'" class="status badge badge-primary">Active</a>';  
                  }
                  else
                  {
                    $status = '<a id="'.$data->cost_id.'" data-url="' . route('productionCost.status', $data->cost_id) .'" class="status badge badge-secondary" style="color: #fff">Deactive</a>';   
                  }
                  return $status;
                })
                ->addIndexColumn()
                ->rawColumns(['action' , 'status','amount',])
                ->make(true);       
                    
        }        
    	
      //$costs = ProductionCost::orderBy('cost_id','DESC')->get();
      		 
    	return view('portal.production_cost.index');
    }

    public function create(Request $request)
    {
    	$validator = \Validator::make($request->all(), [
	        'cost_name' => 'required|max:255|unique:production_costs,cost_name',
	        'cost_item_name.*' => 'required|max:255',
	        'cost_qty.*' => 'required|max:255',
	        'cost_price.*' => 'required|max:255',
	        ],[
	        	'cost_item_name.*.required' => 'Item name required.',
	        	'cost_qty.*.required' => 'Quantity required.',
	        	'cost_price.*.required' => 'Price required.',

	        ]);

	    if ($validator->fails())         
        {
        	return response()->json(['errors' => $validator->errors()]);
        }

        if($validator->passes())
        {
        	$data = $request->all();
	    	$length = count($data['cost_price']);

	    	for($i=0; $i < $length; $i++)
	    	{
	    		$cost = new ProductionCost;

	    		$cost->cost_name = Str::upper($request->cost_name);
	    		$cost->cost_item_name = $data['cost_item_name'][$i];
	    		$cost->cost_qty = $data['cost_qty'][$i];
	    		$cost->cost_price = $data['cost_price'][$i];
	    		$cost->cost_sub_total = $data['cost_sub_total'][$i];
	    		$cost->cost_total =  $request->cost_total;
	    		$cost->cost_stat =  $request->cost_stat;
	    		$cost->save();
	    	}

	    	$success = array('success' => 'Cost saved successfully.');
	        return response()->json($success); 
        }
    }

    public function status($cost_id)
    {
        $cost = ProductionCost::find($cost_id);

        if($cost->cost_stat == 1)
        {        	
            $status = ProductionCost::where('cost_name', $cost->cost_name)->get();

            foreach($status as $stat)
            {
            	$stat->cost_stat = 0;
            	$stat->update(); 
            }
            $success = array('success' => 'Cost status change successfullly.');
            return response()->json($success);
        }
        else
        {
            $status = ProductionCost::where('cost_name', $cost->cost_name)->get();

            foreach($status as $stat)
            {
            	$stat->cost_stat = 1;
            	$stat->update(); 
            }
            $success = array('success' => 'Cost status change successfullly.');
            return response()->json($success);
        }

    }

    public function destroy(Request $request)
    {
        $cost = ProductionCost::find($request->id);
        $delete = ProductionCost::where('cost_name', $cost->cost_name)->get();

        foreach($delete as $d)
        {
        	$d->delete(); 
        }
        
        $success = array('success' => 'Cost deleted successfullly.');
        return response()->json($success);
        
        
    }
}
