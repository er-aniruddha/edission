<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Brand;
use Illuminate\Support\Str;
use Validator;
use Image;  

class BrandController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
    	if(request()->ajax())
        {
          return datatables()->of(Brand::orderBy('brand_id','DESC')->get())
                ->addColumn('action', function($data){
                  $button = '<button type="button" name="view" id="'.$data->brand_id.'" data-name="'.$data->brand_name.'" data-desc="'.$data->brand_desc.'" data-image="'.asset($data->brand_img).'" data-status="'.$data->brand_stat.'" class="view btn btn-outline-info  btn-sm">View</button>';
                  $button .= '&nbsp;';
                  $button .= '<button type="button" name="edit" id="'.$data->brand_id.'" data-name="'.$data->brand_name.'" data-desc="'.$data->brand_desc.'" data-image="'.$data->brand_img.'"
                    data-status="'.$data->brand_stat.'" class="edit btn btn-outline-primary btn-sm">Edit</button>';
                  $button .= '&nbsp;';
                  $button .= '<button type="button" data-id="'.$data->brand_id.'" data-name="'.$data->brand_name.'" data-url="' . route('brand.delete') .'"  class="delete btn btn-outline-danger btn-sm">Del</button>';
                  return $button;
                })
                ->addColumn('status', function($data){
                  if( $data->brand_stat == 1)
                  {
                    $status = '<a id="'.$data->brand_id.'" data-url="' . route('brand.status', $data->brand_id) .'" class="status badge badge-primary">Active</a>';  
                  }
                  else
                  {
                    $status = '<a id="'.$data->brand_id.'" data-url="' . route('brand.status', $data->brand_id) .'" class="status badge badge-secondary" style="color: #fff">Deactive</a>';   
                  }
                  return $status;
                })
                ->addIndexColumn()
                ->rawColumns(['action' , 'status'])
                ->make(true);       
                    
        }        
        return view('portal.brand.index');
    }

    public function create(Request $request)
    {
    	if(request()->ajax())
        {
            $validator = \Validator::make($request->all(), [
            'brand_name' => 'required|max:255|unique:brands,brand_name',
            'brand_desc' => 'required|max:255',
            'image' => 'required|mimes:jpeg,png,jpg,gif,svg|max:2048', 
            ],[
                'image.required'=>'Image format should be in jpeg,png,jpg,gif,svg|max:2048',
                'image.upload'=>'Image format should be in jpeg,png,jpg,gif,svg|max:2048',                
            ]);

            if ($validator->fails())         
            {
            	return response()->json(['errors' => $validator->errors()]);
            }

            $brand = new Brand;
            $image = $request->file('image');
            if ($image){
                $image_name=Str::uuid();
                $ext=strtolower($image->getClientOriginalExtension());
                $image_full_name=$image_name.'.'.$ext;
                $upload_path='../img-file-manager/portal/brand/';
                $image_url=$upload_path.$image_full_name;
                $resize_image = Image::make($image->getRealPath());
                $success = $resize_image->resize(270, 240)->save($upload_path . $image_full_name);
                if($success){
                    $brand->brand_img=$image_url;
                }
            }
            $brand->brand_name = Str::lower($request->brand_name);
            $brand->brand_desc = Str::lower($request->brand_desc);
            $brand->brand_stat = $request->brand_stat;
            $is_saved = $brand->save();

            if($is_saved)
            {
                $success = array('success' => 'Brand saved successfully');
                return response()->json($success);
            }
        }
    }

    public function update(Request $request)
    {
        $image = $request->file('image');
        $brands = Brand::find($request->brand_id);

        if($brands->brand_name == $request->brand_name)
        {
            $validator = \Validator::make($request->all(), [
                'brand_name' => 'required|max:255',
                'brand_desc' => 'required|max:255',  
                'brand_stat' => 'required'           
            ]);
            if ($validator->fails())
            {          
                return response()->json(['errors' => $validator->errors()]);
            }
        }
        else
        {
            $validator = \Validator::make($request->all(), [
                'brand_name' => 'required|max:255|unique:brands',
                'brand_desc' => 'required|max:255',
                'brand_stat' => 'required'
            ]);
            if ($validator->fails())
            {          
                return response()->json(['errors' => $validator->errors()]);
            }
        }  
        if($image)
        {
            $validator = \Validator::make($request->all(), [          
                'image' => 'required|mimes:jpeg,png,jpg,gif,svg|max:2048|image'     
            ],[
                'image.required'=>'Image format should be in jpeg,png,jpg,gif,svg',
                'image.uploaded'=>'Image format should be in jpeg,png,jpg,gif,svg|max:2048', 
            ]); 

            if ($validator->fails())
            {          
                return response()->json(['errors' => $validator->errors()]);
            }
        }

        if($validator->passes())
        {
            if($image)
            {  
                if(file_exists($brands->brand_img)){
                    unlink($brands->brand_img);
                }
                /*$image_name=$required->product_id.$image->getClientOriginalExtension();
                $upload_path='public/image/';
                $image_url=$upload_path.$image_name;*/

                $image_name=Str::uuid();;
                $ext=strtolower($image->getClientOriginalExtension());
                $image_full_name=$image_name.'.'.$ext;
                $upload_path='../img-file-manager/brand/';
                $image_url=$upload_path.$image_full_name;
                $success=$image->move($upload_path,$image_full_name);
                if($success){
                    $brands->brand_img = $image_url;
                }
                $brand->brand_name = Str::lower($request->brand_name);
                $brand->brand_desc = Str::lower($request->brand_desc);
                $brands->brand_stat = $request->brand_stat;
                // $brands->timestamps = now();
                $is_saved = $brands->update();

                if($is_saved)
                {
                    $success = array('success' => 'Brand updated successfully');
                    return response()->json($success);   
                }
                           
            }
            else
            {
                $brands->brand_img = $request->image_update;       
                $brand->brand_name = Str::lower($request->brand_name);
                $brand->brand_desc = Str::lower($request->brand_desc);
                $brands->brand_stat = $request->brand_stat;
                $is_saved = $brands->update();
                // $brands->timestamps = now();
                if($is_saved)
                {
                    $success = array('success' => 'Brand updated successfully');
                    return response()->json($success);   
                }
            } 
        }
    }

    public function status($brand_id)
    {
        $brand = Brand::where('brand_id',$brand_id)->first();
        if($brand->brand_stat == 1)
        {
            Brand::where('brand_id',$brand_id)->update(['brand_stat' => 0]);
            $success = array('success' => 'Brand status change successfullly');
            return response()->json($success);
        }
        else
        {
            Brand::where('brand_id',$brand_id)->update(['brand_stat' => 1]);
            $success = array('success' => 'Brand status change successfullly');
            return response()->json($success);
        }

    }

    public function destroy(Request $request)
    {
        $brand = Brand::find($request->id);
        
        if(file_exists($brand->brand_img))
        {
            unlink($brand->brand_img);
            $brand->delete();
            $success = array('success' => 'Brand deleted successfullly');
            return response()->json($success);
        }
        else
        {
            $brand->delete();
            $success = array('success' => 'Brand deleted successfullly');
            return response()->json($success);
        }
    }
}
