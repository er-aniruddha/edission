<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\PurchaseOrder;
use App\Models\Portal\Product;
use App\Models\Portal\Unit;
use App\Models\Portal\Stock;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;

class PurchaseOrderController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                            ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                            ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*'))
                            ->orderBy('product_id','DESC')
                            ->get();
        $units = Unit::orderBy('unit_id','DESC')->get();
        $purchaseOrder = PurchaseOrder::leftJoin('products','purchase_orders.item_name','=','products.product_id')
                                ->leftJoin('units','purchase_orders.unit_id','=','units.unit_id')
                                ->select(array('purchase_orders.*','products.*','units.*'))
                                ->orderBy('date','desc')
                                ->get()->unique('po_id');        

        if(request()->ajax())
        {
          return datatables()->of($purchaseOrder)
                ->editColumn('date', function ($data) {
                    return date('d-m-Y', strtotime($data->date));
                })
                ->addColumn('action', function($data){
                  $button = '<button type="button" id="'.$data->po_id.'" data-date="'.$data->date.'" class="view btn btn-outline-info  btn-sm">View</button>';
                  $button .= '&nbsp;';
                  if($data->status == 0){
                  $button .= '<button type="button" id="'.$data->po_id.'" data-date="'.$data->date.'" class="edit btn btn-outline-primary btn-sm">Edit</button>';
                  $button .= '&nbsp;';                  
                    $button .= '<button type="button" data-poid="'.$data->po_id.'" class="delete btn btn-outline-danger btn-sm">Del</button>';
                    
                  }
                  return $button;
                })
                ->addColumn('status', function($data){
                  if( $data->status == 1)
                  {
                    $status = '<span class="item-badge badge text-uppercase bg-success">Order Complete</span>';  
                  }
                  else
                  {
                    $status = '<a href="javscript:void(0)" class="item-badge badge text-uppercase bg-secondary over-due" id="'.$data->po_id.'" data-date="'.$data->date.'">Over Due</a>';   
                  }
                  return $status;
                })
                ->addIndexColumn()
                ->rawColumns(['action' , 'status'])                
                ->make(true);       
                    
        } 
        else{
            $allPoItem = PurchaseOrder::leftJoin('products','purchase_orders.item_name','=','products.product_id')
                                ->leftJoin('units','purchase_orders.unit_id','=','units.unit_id')
                                ->select(array('purchase_orders.*','products.*','units.*'))
                                ->orderBy('purchase_order_id','asc')
                                ->get(); 
            return view('portal.purchase_order.index',['products'=>$products, 'units' => $units , 'allPoItem' => $allPoItem]);
        }    
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        // $data =  $request->all();
        // return response()->json($data);

        if(request()->ajax())
        {
            if($request->date)
            {
                $date = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
                $validator_date = \Validator::make($date, [
                    'date' => 'required|date|before:tomorrow',         
                ],[
                    'date.before' => 'The date mustbe today or before.',
                    'date.unique' => 'Can not add two item on same date',
                ]);
                if ($validator_date->fails())         
                {
                    return response()->json(['errors' => $validator_date->errors()]);
                }
            }
            $validator = \Validator::make($request->all(), [
                'party_id' => 'required|not_in:0',
                'date' => 'required|date|before:tomorrow',     
                'item_name.*' => 'required|max:255',
                'unit_id.*' => 'required|max:255',
                'qty.*' => 'required|integer|not_in:0',
                'unit_price.*' => 'required',
                'amount.*' => 'required',
                'payment_type' => 'required|not_in:0',
                ],[
                  'date.before' => 'The date mustbe today or before.',
                  'party_id.required' => 'Party name required.',
                  'item_name.*.required' => 'Item name required.',
                  'unit_id.*.required' => 'Unit Name required.',
                  'qty.*.required' => 'Quantity required.',
                  'qty.*.not_in' => 'Quantity required.',
                  'unit_price.*.required' => 'Unit price required.',
                  'amount.*.required' => 'Price required.',
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }
            
            if($validator->passes())
            {
                $data = $request->all();
                $New_start_index = 0;          
                $length = count($data['unit_price']);
              
                $item_name = array_combine(range($New_start_index,  count($request->item_name) + ($New_start_index-1)),
                    array_values($request->item_name)); 

                $unit_id = array_combine(range($New_start_index,  count($request->unit_id) + ($New_start_index-1)),
                    array_values($request->unit_id)); 

                $qty = array_combine(range($New_start_index,  count($request->qty) + ($New_start_index-1)),
                    array_values($request->qty)); 

                $primary_qty = array_combine(range($New_start_index,  count($request->primary_qty) + ($New_start_index-1)),
                    array_values($request->primary_qty)); 

                $secondary_qty = array_combine(range($New_start_index,  count($request->secondary_qty) + ($New_start_index-1)),
                    array_values($request->secondary_qty)); 

                $unit_price = array_combine(range($New_start_index,  count($request->unit_price) + ($New_start_index-1)),
                    array_values($request->unit_price)); 

                $amount = array_combine(range($New_start_index,  count($request->amount) + ($New_start_index-1)),
                    array_values($request->amount)); 
              
                for($i=0; $i < $length; $i++)
                {
                    $purchaseOrder = new PurchaseOrder;
                    $purchaseOrder->po_id = "PO-".strtotime(date('Y-m-d H:m:s')); 
                    $purchaseOrder->party_id = Str::lower($request->party_id);
                    $purchaseOrder->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');            
                    $purchaseOrder->item_name = Str::lower($item_name[$i]);
                    $purchaseOrder->unit_id = Str::lower($unit_id[$i]);
                    $purchaseOrder->qty = $qty[$i];                
                    $purchaseOrder->primary_qty = $primary_qty[$i];                
                    $purchaseOrder->secondary_qty = $secondary_qty[$i];                
                    $purchaseOrder->unit_price = $unit_price[$i];
                    $purchaseOrder->amount = $amount[$i];
                    $purchaseOrder->payment_type = Str::lower($request->payment_type);
                    $purchaseOrder->round_off = $request->round_off;
                    $purchaseOrder->gst_amount = $request->gst_amount;
                    $purchaseOrder->total = $request->total;
                    $purchaseOrder->advance = $request->advance;
                    $purchaseOrder->balance = $request->balance;
                    $purchaseOrder->remarks = $request->remarks;
                    $purchaseOrder->save();
                }
                $allPoItem = PurchaseOrder::leftJoin('products','purchase_orders.item_name','=','products.product_id')
                                            ->leftJoin('units','purchase_orders.unit_id','=','units.unit_id')
                                            ->select(array('purchase_orders.*','products.*','units.*'))
                                            ->orderBy('purchase_order_id','asc')
                                            ->get(); 
                $success = array('success' => "Item updated successfully.", 'allPoItem' => $allPoItem);
                return response()->json($success);
                
            }
             
        }   
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($po_id)
    {
         $editData = PurchaseOrder::where('po_id','=',$po_id)
                                ->leftJoin('products','purchase_orders.item_name','=','products.product_id')
                                ->select(array('purchase_order_id.*','products.*'))
                                ->orderBy('purchaseOrders_id','desc')
                                ->get();
        return $editData;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $data = $request->all();       
        $delete = json_decode($data['delete'], true);
        if(request()->ajax())
        { 
            if(count($delete) != 0 )
            {
                for($i=0; $i < count($delete) ; $i++)
                {
                    $item = PurchaseOrder::where('purchase_order_id',$delete[$i]['id']);
                    $item->delete();           
                } 
              
            }// If there is a item to delete  
            $collection = collect($request->all());
            // $filter = $collection->except(['item_name.0','unit_name.0','qty.0','unit_price.0','amount.0']);
            // anything need to be edit strat here            
            if($request->date)
            {
                $date = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
                $validator_date = \Validator::make($date, [
                    'date' => 'required|date|before:tomorrow',         
                ],[
                    'date.before' => 'The date mustbe today or before.',
                    'date.unique' => 'Can not add two item on same date',
                ]);
                if ($validator_date->fails())         
                {
                    return response()->json(['errors' => $validator_date->errors()]);
                }
            }
            $validator = \Validator::make($request->all(), [
                'party_id' => 'required|not_in:0',
                'date' => 'required|date|before:tomorrow',     
                'item_name.*' => 'required|max:255',
                'unit_id.*' => 'required|max:255',
                'qty.*' => 'required|integer|not_in:0',
                'unit_price.*' => 'required',
                'amount.*' => 'required',
                'payment_type' => 'required|not_in:0',
                ],[
                  'date.before' => 'The date mustbe today or before.',
                  'party_id.required' => 'Party name required.',
                  'item_name.*.required' => 'Item name required.',
                  'unit_id.*.required' => 'Unit Name required.',
                  'qty.*.required' => 'Quantity required.',
                  'unit_price.*.required' => 'Unit price required.',
                  'amount.*.required' => 'Price required.',
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }
            if($validator->passes())
            {
                $New_start_index = 0;          
                $reqArrayCount = count($data['unit_price']);
          
                $item_name = array_combine(range($New_start_index,  count($request->item_name) + ($New_start_index-1)),
                    array_values($request->item_name)); 

                $unit_id = array_combine(range($New_start_index,  count($request->unit_id) + ($New_start_index-1)),
                    array_values($request->unit_id)); 

                $qty = array_combine(range($New_start_index,  count($request->qty) + ($New_start_index-1)),
                    array_values($request->qty));

                $primary_qty = array_combine(range($New_start_index,  count($request->primary_qty) + ($New_start_index-1)),
                    array_values($request->primary_qty)); 
                
                $secondary_qty = array_combine(range($New_start_index,  count($request->secondary_qty) + ($New_start_index-1)),
                    array_values($request->secondary_qty)); 

                $unit_price = array_combine(range($New_start_index,  count($request->unit_price) + ($New_start_index-1)),
                    array_values($request->unit_price)); 

                $amount = array_combine(range($New_start_index,  count($request->amount) + ($New_start_index-1)),
                    array_values($request->amount)); 

                $poUpdate = PurchaseOrder::where('po_id','=',$request->po_id)->get();  
                $existsArrayLenth = count($poUpdate);
                // if nothing is added more then
                if( $existsArrayLenth == $reqArrayCount)
                {
                    for($i=0; $i < $reqArrayCount; $i++)
                    {
                        $poUpdate[$i]['party_id'] = Str::lower($request->party_id);
                        $poUpdate[$i]['date'] = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');            
                        $poUpdate[$i]['item_name'] = Str::lower($item_name[$i]);
                        $poUpdate[$i]['unit_id'] = Str::lower($unit_id[$i]);
                        $poUpdate[$i]['qty'] = $qty[$i];                
                        $poUpdate[$i]['primary_qty'] = $primary_qty[$i];                
                        $poUpdate[$i]['secondary_qty'] = $secondary_qty[$i];                 
                        $poUpdate[$i]['unit_price'] = $unit_price[$i];
                        $poUpdate[$i]['amount'] = $amount[$i];
                        $poUpdate[$i]['payment_type'] = Str::lower($request->payment_type);
                        $poUpdate[$i]['round_off'] = $request->round_off;
                        $poUpdate[$i]['gst_amount'] = $request->gst_amount;
                        $poUpdate[$i]['total'] = $request->total;
                        $poUpdate[$i]['advance'] = $request->advance;
                        $poUpdate[$i]['balance'] = $request->balance;
                        $poUpdate[$i]['remarks'] = $request->remarks;
                        $poUpdate[$i]->update();                
                    }
                }  
                // // // if something added more then
                if( $reqArrayCount > $existsArrayLenth )
                {
                    for($i=0; $i < $reqArrayCount - ($reqArrayCount - $existsArrayLenth); $i++)
                    {
                        $poUpdate[$i]['party_id'] = Str::lower($request->party_id);
                        $poUpdate[$i]['date'] = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');            
                        $poUpdate[$i]['item_name'] = Str::lower($item_name[$i]);
                        $poUpdate[$i]['unit_id'] = Str::lower($unit_id[$i]);
                        $poUpdate[$i]['qty'] = $qty[$i];                
                        $poUpdate[$i]['primary_qty'] = $primary_qty[$i];                
                        $poUpdate[$i]['secondary_qty'] = $secondary_qty[$i];        
                        $poUpdate[$i]['unit_price'] = $unit_price[$i];
                        $poUpdate[$i]['amount'] = $amount[$i];
                        $poUpdate[$i]['payment_type'] = Str::lower($request->payment_type);
                        $poUpdate[$i]['round_off'] = $request->round_off;
                        $poUpdate[$i]['gst_amount'] = $request->gst_amount;
                        $poUpdate[$i]['total'] = $request->total;
                        $poUpdate[$i]['advance'] = $request->advance;
                        $poUpdate[$i]['balance'] = $request->balance;
                        $poUpdate[$i]['remarks'] = $request->remarks;
                        $poUpdate[$i]->update();                
                    }

                    for($j=$reqArrayCount-1; $j > ($reqArrayCount - $existsArrayLenth) ; $j--)
                    { 
                        $purchaseOrder = new PurchaseOrder;
                        $purchaseOrder->po_id = $request->po_id; 
                        $purchaseOrder->party_id = Str::lower($request->party_id);
                        $purchaseOrder->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');            
                        $purchaseOrder->item_name = Str::lower($item_name[$j]);
                        $purchaseOrder->unit_id = Str::lower($unit_id[$j]);
                        $purchaseOrder->qty = $qty[$i];                
                        $purchaseOrder->primary_qty = $primary_qty[$i];                
                        $purchaseOrder->secondary_qty = $secondary_qty[$i];          
                        $purchaseOrder->unit_price = $unit_price[$j];
                        $purchaseOrder->amount = $amount[$j];
                        $purchaseOrder->payment_type = Str::lower($request->payment_type);
                        $purchaseOrder->round_off = $request->round_off;
                        $purchaseOrder->gst_amount = $request->gst_amount;
                        $purchaseOrder->total = $request->total;
                        $purchaseOrder->advance = $request->advance;
                        $purchaseOrder->balance = $request->balance;
                        $purchaseOrder->remarks = $request->remarks;
                        $purchaseOrder->save();              
                    }
                }                  
           
                $allPoItem = PurchaseOrder::leftJoin('products','purchase_orders.item_name','=','products.product_id')
                                            ->leftJoin('units','purchase_orders.unit_id','=','units.unit_id')
                                            ->select(array('purchase_orders.*','products.*','units.*'))
                                            ->orderBy('purchase_order_id','asc')
                                            ->get(); 
                $success = array('success' => "Item updated successfully.", 'allPoItem' => $allPoItem);
                return response()->json($success);

            } 
            
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $po_id = $request->id; //here id refer for date because delete modal is common for all
        $delData = PurchaseOrder::where('po_id', $po_id)->where('status',0)->get();
        foreach ($delData as $del) 
        {
            $del->delete();
        }
        $allPoItem = PurchaseOrder::leftJoin('products','purchase_orders.item_name','=','products.product_id')
                                ->select(array('purchase_orders.*','products.*'))
                                ->orderBy('purchase_order_id','asc')
                                ->get(); 
        $success = array('success' => "Item updated successfully.", 'allPoItem' => $allPoItem);
        return response()->json($success);
    }

    public function status(Request $request)
    {
        $po_id = $request->po_id; //here id refer for date because delete modal is common for all
        $data = PurchaseOrder::where('po_id', $po_id)->get();
        /*
            Before status change product sholud be in stock
        */
        foreach($data as $d)
        {
            $findStock = Stock::where('item_name', $d->item_name)->first();
            $newStock = New Stock;
            $newStock->stock_type = "Purchase";
            $newStock->trnx_id  = $d->po_id;
            $newStock->item_name  = Str::lower($d->item_name);
            $newStock->party_id  = $d->party_id;
            $newStock->date  = $d->date;
            $newStock->qty = $d->qty;            
            $newStock->primary_qty = $d->primary_qty;            
            $newStock->secondary_qty = $d->secondary_qty;
            $newStock->qty  = $d->qty;
            $newStock->unit_id  = $d->unit_id;
            $newStock->unit_price  = $d->unit_price;
            $newStock->amount  = $d->amount;
            $newStock->in_hand_stock  = $newStock->in_hand_stock + $d->qty;
            $newStock->stock_value  = $d->stock_value + ($d->qty*$d->unit_price);
            if($d->advance <= 0)
            {
                $newStock->stock_stat  = 0;
            }
            elseif($d->balance <= 0)
            {
                $newStock->stock_stat  = 2;                    
            }
            else
            {
                $newStock->stock_stat  = 1;  
            }
            $newStock->save();

            $findProduct = Product::find($d->item_name);
            if($findProduct)
            {
                if($d->qty == $d->secondary_qty)
                {
                    $purchase_price = $findProduct->no_of_pcs*$d->unit_price;
                 
                $findProduct->purchase_price = $purchase_price;                  
                } 
                $stockSecond = $findProduct->in_hand_stock_second + $d->secondary_qty;
                $findProduct->in_hand_stock_primary = (int)($stockSecond/$findProduct->no_of_pcs);
                $findProduct->in_hand_stock_second = $stockSecond;
                $findProduct->update();
            }

        } 
        $statData = PurchaseOrder::where('po_id', $po_id)->update(['status' => 1]);
        $allPoItem = PurchaseOrder::leftJoin('products','purchase_orders.item_name','=','products.product_id')
                                ->select(array('purchase_orders.*','products.*'))
                                ->orderBy('purchase_order_id','asc')
                                ->get(); 
        $success = array('success' => "Item updated successfully.", 'allPoItem' => $allPoItem);
        return response()->json($success);
    }
}
