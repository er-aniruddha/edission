<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\PurchaseOrder;
use App\Models\Portal\Product;
use App\Models\Portal\Unit;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;

class PurchaseOrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::orderBy('product_id','DESC')->get();
        $units = Unit::orderBy('unit_id','DESC')->get();
        $purchaseOrder = PurchaseOrder::leftJoin('products','purchase_orders.item_name','=','products.product_id')
                                ->select(array('purchase_orders.*','products.*'))
                                ->orderBy('purchase_orders_id','desc')
                                ->get()->unique('po_id');        

        if(request()->ajax())
        {
          return datatables()->of($purchaseOrder)
                ->editColumn('date', function ($data) {
                    return date('d-m-Y', strtotime($data->date));
                })
                ->addColumn('action', function($data){
                  $button = '<button type="button" name="view" id="'.$data->po_id.'" data-date="'.$data->date.'" class="view btn btn-outline-info  btn-sm">View</button>';
                  $button .= '&nbsp;';
                  $button .= '<a href=' . route('purchase.order.edit', $data->po_id) .' type="button" class="edit btn btn-outline-primary btn-sm">Edit</a>';
                  $button .= '&nbsp;';
                  if($data->status == 0){
                    $button .= '<button type="button" data-id="'.$data->po_id.'" class="delete btn btn-outline-danger btn-sm">Del</button>';
                    
                  }
                  return $button;
                })
                ->addColumn('status', function($data){
                  if( $data->status == 1)
                  {
                    $status = '<span class="item-badge badge text-uppercase bg-success">Order Complete</span>';  
                  }
                  else
                  {
                    $status = '<span class="item-badge badge text-uppercase bg-secondary">Over Due</span>';   
                  }
                  return $status;
                })
                ->addIndexColumn()
                ->rawColumns(['action' , 'status'])                
                ->make(true);       
                    
        } 
        else{
            $porder = PurchaseOrder::leftJoin('products','purchase_orders.item_name','=','products.product_id')
                                ->select(array('purchase_orders.*','products.*'))
                                ->orderBy('purchase_orders_id','asc')
                                ->get(); 
            return view('portal.purchase_order.index',['products'=>$products, 'units' => $units , 'purchaseOrder' => $porder]);
        }    
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        // $data =  $request->all();
        // return response()->json($data);

    if(request()->ajax())
    {
        if($request->date)
        {
            $date = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
            $validator_date = \Validator::make($date, [
                'date' => 'required|date|before:tomorrow',         
            ],[
                'date.before' => 'The date mustbe today or before.',
                'date.unique' => 'Can not add two item on same date',
            ]);
            if ($validator_date->fails())         
            {
                return response()->json(['errors' => $validator_date->errors()]);
            }
        }
        $validator = \Validator::make($request->all(), [
            'party_id' => 'required|not_in:0',
            'date' => 'required|date|before:tomorrow',     
            'item_name.*' => 'required|max:255',
            'unit_name.*' => 'required|max:255',
            'qty.*' => 'required|integer|not_in:0',
            'unit_price.*' => 'required|not_in:0',
            'amount.*' => 'required|not_in:0',
            'payment_type' => 'required|not_in:0',
            ],[
              'date.before' => 'The date mustbe today or before.',
              'party_id.required' => 'Party name required.',
              'item_name.*.required' => 'Item name required.',
              'unit_name.*.required' => 'Unit Name required.',
              'qty.*.required' => 'Quantity required.',
              'unit_price.*.required' => 'Unit price required.',
              'amount.*.required' => 'Price required.',
        ]);
        if ($validator->fails())         
        {
            return response()->json(['errors' => $validator->errors()]);
        }
        
        if($validator->passes())
        {
            $data = $request->all();
            $New_start_index = 0;          
            $length = count($data['unit_price']);
          
            $item_name = array_combine(range($New_start_index,  count($request->item_name) + ($New_start_index-1)),
                array_values($request->item_name)); 

            $unit_name = array_combine(range($New_start_index,  count($request->unit_name) + ($New_start_index-1)),
                array_values($request->unit_name)); 

            $qty = array_combine(range($New_start_index,  count($request->qty) + ($New_start_index-1)),
                array_values($request->qty)); 

            $unit_price = array_combine(range($New_start_index,  count($request->unit_price) + ($New_start_index-1)),
                array_values($request->unit_price)); 

            $amount = array_combine(range($New_start_index,  count($request->amount) + ($New_start_index-1)),
                array_values($request->amount)); 
          
            for($i=0; $i < $length; $i++)
            {
                $purchase_order = new PurchaseOrder;
                $purchase_order->po_id = "PO-".strtotime(date('Y-m-d H:m:s')); 
                $purchase_order->party_id = Str::lower($request->party_id);
                $purchase_order->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');            
                $purchase_order->item_name = Str::lower($item_name[$i]);
                $purchase_order->unit_name = Str::lower($unit_name[$i]);
                $purchase_order->qty = $qty[$i];                
                $purchase_order->unit_price = $unit_price[$i];
                $purchase_order->amount = $amount[$i];
                $purchase_order->payment_type = Str::lower($request->payment_type);
                $purchase_order->round_off = $request->round_off;
                $purchase_order->gst_amount = $request->gst_amount;
                $purchase_order->total = $request->total;
                $purchase_order->advance = $request->advance;
                $purchase_order->balance = $request->balance;
                $purchase_order->remarks = $request->remarks;
                $purchase_order->save();
            }
                $purchaseOrder = PurchaseOrder::leftJoin('products','purchase_orders.item_name','=','products.product_id')
                                ->select(array('purchase_orders.*','products.*'))
                                ->orderBy('purchase_orders_id','asc')
                                ->get(); 
                $success = array('success' => "Item added successfully.", 'purchaseOrder' => $purchaseOrder);
                return response()->json($success);
            
        }
         
    }   
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($po_id)
    {
        $editData = PurchaseOrder::where('po_id','=',$po_id)
                                ->leftJoin('products','purchase_orders.item_name','=','products.product_id')
                                ->select(array('purchase_orders.*','products.*'))
                                ->orderBy('purchase_orders_id','desc')
                                ->get();
        return $editData;
        // return view('portal.purchase_order.edit',['editData' => $editData]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
