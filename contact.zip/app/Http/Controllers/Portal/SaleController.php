<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Sale;
use App\Models\Portal\Product;
use App\Models\Portal\Unit;
use App\Models\Portal\Brand;
use App\Models\Portal\Customer;
use App\Models\Portal\Stock;
use App\Models\Portal\PaymentIn;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;

class SaleController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                            ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                            ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*'))
                            ->orderBy('product_id','DESC')
                            ->get();
        $units = Unit::orderBy('unit_id','DESC')->get();
        $customers = Customer::orderBy('customer_id','DESC')->get();
        $saleTable = Sale::leftJoin('products','sales.item_name','=','products.product_id')
                                ->leftJoin('customers','sales.customer_id','=','customers.customer_id')
                                ->leftJoin('units','sales.unit_id','=','units.unit_id')
                                ->select(array('sales.*','products.*','customers.*','units.*'))
                                ->orderBy('date','desc')
                                ->get()->unique('invoice_id'); 
        if(request()->ajax())
        {
          return datatables()->of($saleTable)
                ->editColumn('date', function ($data) {
                    return date('d-m-Y', strtotime($data->date));
                })   
                ->addColumn('name', function($data){                  
                    $name = '<a href="page.invoice.detail.html" class="item-company ajax h-1x" data-pjax-state="">'.$data->f_name.' '.$data->s_name.'</a>
                            <div class="item-mail text-muted h-1x d-none d-sm-block">'.$data->shop_name.'</div>'; 
                  return $name;
                })         
                ->addColumn('action', function($data){                  
                    $action = '<div class="item-action dropdown">
                                    <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right bg-black" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                        <a class="dropdown-item view" href="#" id="'.$data->invoice_id.'">See detail </a>
                                        <a class="dropdown-item edit">Edit</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item trash">Delete item</a>
                                    </div>
                                </div>'; 
                  return $action;
                })
                ->addIndexColumn()    
                ->rawColumns(['action','name'])                   
                ->make(true); 
        } 
        else{
            $sales = Sale::leftJoin('products','sales.item_name','=','products.product_id')
                                ->leftJoin('customers','sales.customer_id','=','customers.customer_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units','sales.unit_id','=','units.unit_id')
                                ->select(array('sales.*','products.*','customers.*','units.*'))
                                ->orderBy('sale_id','desc')
                                ->get();             
            return view('portal.sale.index',['products'=>$products, 'units' => $units , 'customers' => $customers ,'sales' =>$sales]);
        }    
    }

    public function create(Request $request)
    {
        if(request()->ajax())
        {
            if($request->date)
            {
                $date = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
                $validator_date = \Validator::make($date, [
                    'date' => 'required|date|before:tomorrow',         
                ],[
                    'date.before' => 'The date mustbe today or before.',
                    'date.unique' => 'Can not add two item on same date',
                ]);
                if ($validator_date->fails())         
                {
                    return response()->json(['errors' => $validator_date->errors()]);
                }
            }
            $validator = \Validator::make($request->all(), [
                'customer_id' => 'required|not_in:0',
                'date' => 'required|date|before:tomorrow',     
                'item_name.*' => 'required|max:255',
                'unit_id.*' => 'required|max:255',
                'qty.*' => 'required|integer|not_in:0',
                'product_mrp.*' => 'required',
                'amount.*' => 'required',
                'payment_type' => 'required|not_in:0',
                ],[
                  'date.before' => 'The date mustbe today or before.',
                  'customer_id.required' => 'Customer name required.',
                  'item_name.*.required' => 'Item name required.',
                  'unit_id.*.required' => 'Unit Name required.',
                  'qty.*.required' => 'Quantity required.',
                  'product_mrp.*.required' => 'MRP price required.',
                  'amount.*.required' => 'Price required.',
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }
            
            if($validator->passes())
            {
                $data = $request->all();
                $New_start_index = 0;          
                $length = count($data['product_mrp']);
              
                $item_name = array_combine(range($New_start_index,  count($request->item_name) + ($New_start_index-1)),
                    array_values($request->item_name)); 

                $unit_id = array_combine(range($New_start_index,  count($request->unit_id) + ($New_start_index-1)),
                    array_values($request->unit_id)); 

                $qty = array_combine(range($New_start_index,  count($request->qty) + ($New_start_index-1)),
                    array_values($request->qty)); 

                $product_mrp = array_combine(range($New_start_index,  count($request->product_mrp) + ($New_start_index-1)),
                    array_values($request->product_mrp)); 
                $discount = array_combine(range($New_start_index,  count($request->discount) + ($New_start_index-1)),
                    array_values($request->discount)); 

                $amount = array_combine(range($New_start_index,  count($request->amount) + ($New_start_index-1)),
                    array_values($request->amount)); 
              
                for($i=0; $i < $length; $i++)
                {
                    $newSale = new Sale;
                    $newSale->invoice_id = "INV-".(1000000000+strtotime(date('Y-m-d H:m:s'))); 
                    $newSale->customer_id = $request->customer_id;
                    $newSale->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');            
                    $newSale->item_name = Str::lower($item_name[$i]);
                    $newSale->unit_id = Str::lower($unit_id[$i]);
                    $newSale->qty = $qty[$i];                
                    $newSale->product_mrp = $product_mrp[$i];
                    $newSale->discount = $discount[$i];
                    $newSale->amount = $amount[$i];
                    $newSale->payment_type = Str::lower($request->payment_type);
                    $newSale->round_off = $request->round_off;
                    $newSale->gst_amount = $request->gst_amount;
                    $newSale->total = $request->total;
                    $newSale->received = $request->received;
                    $newSale->balance = $request->balance;
                    $newSale->prev_balance = $request->prev_balance;
                    $newSale->remarks = $request->remarks;
                    if($request->received <= 0)
                    {
                        $newSale->status  = 0;
                    }
                    elseif($request->balance <= 0)
                    {
                        $newSale->status  = 2;                    
                    }
                    else
                    {
                        $newSale->status  = 1;  
                    }
                    $newSale->save();

                    $findCustomer = Customer::find($request->customer_id);
                    $findCustomer->balance = $request->balance;
                    $findCustomer->update();
                }
                    $sales = Sale::leftJoin('products','sales.item_name','=','products.product_id')
                                ->leftJoin('customers','sales.customer_id','=','customers.customer_id')
                                ->leftJoin('units','sales.unit_id','=','units.unit_id')
                                ->select(array('sales.*','products.*','customers.*','units.*'))
                                ->orderBy('sale_id','desc')
                                ->get();  
                    $customers = Customer::orderBy('customer_id','DESC')->get();
                    $success = array('success' => "New invoice created successfully.", 'sales' => $sales, 'customers' => $customers);
                    return response()->json($success);
                
            }
             
        }  
    }

    public function paymentIndex()
    {
        $payments = PaymentIn::leftJoin('customers','payment_ins.customer_id','customers.customer_id')
                            ->select(array('payment_ins.*','customers.*','payment_ins.balance'))
                            ->orderBy('payment_ins.date','desc')
                            ->get();
        if(request()->ajax())
        {
          return datatables()->of($payments)
                ->editColumn('date', function ($data) {
                    return date('d-m-Y', strtotime($data->date));
                })  
                ->addColumn('name', function($data){                  
                    $name = '<a href="#" class="item-company ajax h-1x" data-pjax-state="">'.$data->f_name.' '.$data->s_name.'</a>
                            <div class="item-mail text-muted h-1x d-none d-sm-block">'.$data->shop_name.'</div>'; 
                  return $name;
                })         
                ->addColumn('action', function($data){                  
                    $action = '<div class="item-action dropdown">
                                    <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right bg-black" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                        <a class="dropdown-item view" href="#" id="'.$data->invoice_id.'">See detail </a>
                                        <a class="dropdown-item edit">Edit</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item trash">Delete item</a>
                                    </div>
                                </div>'; 
                  return $action;
                })
                ->addIndexColumn()    
                ->rawColumns(['action','name'])                   
                ->make(true); 
        } 
        else{   
            $customers = Customer::where('customers.balance','>',0)->get();               
            return view('portal.sale_payment_in.index',['customers' => $customers]);
        }
    }

    public function payment_in(Request $request)
    {
        if(request()->ajax())
        {
            if($request->date)
            {
                $date = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
                $validator_date = \Validator::make($date, [
                    'date' => 'required|date|before:tomorrow',         
                ],[
                    'date.before' => 'The date mustbe today or before.',
                    'date.unique' => 'Can not add two item on same date',
                ]);
                if ($validator_date->fails())         
                {
                    return response()->json(['errors' => $validator_date->errors()]);
                }
            }
            $validator = \Validator::make($request->all(), [
                'customer_id' => 'required|not_in:0',
                'date' => 'required|date|before:tomorrow',   
                'payment_type' => 'required|not_in:0',
                'received' => 'required|not_in:0',
                ],[
                  'date.before' => 'The date mustbe today or before.',                  
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }
            
            if($validator->passes())
            {
                
                    $newSale = new PaymentIn;
                    $newSale->invoice_id = "PAY-".(2000000000+strtotime(date('Y-m-d H:m:s'))); 
                    $newSale->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');            
                    $newSale->customer_id = $request->customer_id;
                    $newSale->received = $request->received;
                    $newSale->balance = $request->balance;
                    $newSale->prev_balance = $request->prev_balance;
                    $newSale->payment_type = $request->payment_type;
                    $newSale->remarks = $request->remarks;                    
                    $newSale->save();

                    $findCustomer = Customer::find($request->customer_id);
                    $findCustomer->balance = $request->balance;
                    $findCustomer->update();
                }
                    
                    $success = array('success' => "Payment saved successfully.");
                    return response()->json($success);                
            }
             
         
    }
}
