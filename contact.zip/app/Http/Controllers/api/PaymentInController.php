<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Customer;
use App\Models\Portal\PaymentIn;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;

class PaymentInController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        if($request->date)
        {
            $date = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
            $validator_date = \Validator::make($date, [
                'date' => 'required|date|before:tomorrow',         
            ],[
                'date.before' => 'The date mustbe today or before.',
                'date.unique' => 'Can not add two item on same date',
            ]);
            if ($validator_date->fails())         
            {
                return response()->json(['errors' => $validator_date->errors()]);
            }
        }

        $validator = \Validator::make($request->all(), [
            'customer_id' => 'required|not_in:0',
            'date' => 'required|date|before:tomorrow',   
            'payment_type' => 'required|not_in:0',
            'received' => 'required|not_in:0',
            ],[
              'date.before' => 'The date mustbe today or before.',                  
        ]);

        if ($validator->fails())         
        {
            return response()->json(['errors' => $validator->errors()]);
        }
        
        if($validator->passes())
        {
            $lastPaymentIn = PaymentIn::orderBy('created_at','DESC')->first();
            $newSale = new PaymentIn;
            $newSale->payment_in_trnx_id = 1000000000+strtotime(date('Y-m-d H:m:s'))+$lastPaymentIn->id; 
            $newSale->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');            
            $newSale->customer_id = $request->customer_id;
            $newSale->received = $request->received;
            $newSale->balance = $request->balance;
            $newSale->prev_balance = $request->prev_balance;
            $newSale->payment_type = $request->payment_type;
            $newSale->remarks = $request->remarks;                    
            $newSale->save();

            $findCustomer = Customer::find($request->customer_id);
            $findCustomer->balance = $request->balance;
            $findCustomer->update();
        }
            
        $customer = Customer::find($request->customer_id); 
        $success = array('message' => "Payment save successfully.", 'customer' => $customer);
        return response()->json($success);

    }
}
