<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Portal\Product;
use App\Models\Portal\Brand;
use App\Models\Portal\Unit;
use App\Models\Portal\Sale;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Validator;
use Image;  


class ProductController extends Controller
{   
    public function __construct()
    {
        $this->middleware('auth:api');
    }
    
    public function index()
    {
        $product =  Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                            ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                            ->select(array('products.*','p.unit_id as primary_unit_id','p.unit_name as primary_unit_name','s.unit_id as secondary_unit_id','s.unit_name as secondary_unit_name','brands.*'))
                            ->where('pro_type','Purchasing')->where('product_stat',1)
                            ->orderBy('product_name','ASC')
                            ->get();
        $brands = Brand::orderBy('brand_id','ASC')->get();
        $units = Unit::orderBy('unit_id','ASC')->get();

        $data = array('product' => $product, 'brands' => $brands, 'units' => $units);
        return response()->json($data);
    }

    
}
