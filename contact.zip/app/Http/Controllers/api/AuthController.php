<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Session;
use Validator;

class AuthController extends Controller
{
	/*
		Admin/User Register Function 
	*/
	public function register(Request $request)
    {
    	$validator = \Validator::make($request->all(), [
            'f_name' => 'required|max:255',
            's_name' => 'required|max:255',   
            'email' => 'required|max:255|email|unique:users,email',
            'password' => 'required|min:8|confirmed',
        ],[
            'f_name.required' => 'Please enter First name',
            's_name.required' => 'Please enter Surname',
            'email.required' => 'Please enter email id',
        ]);
      
        if ($validator->fails())
        {
            return response()->json(['errors' => $validator->errors()]);
        }

        $user = User::create([
            'f_name' => $request['f_name'],
            's_name' => $request['s_name'],
            'phone' => $request['phone'],
            'email' => $request['email'],
            'password' => Hash::make($request['password']),
        ]);

        if($user)
        {
            return response()->json(['success' => "OK"]);
        }
        else
        {
            return response()->json(['error' => "error"]);
        }
    }

    /*
		Admin/User Login Function 
	*/
    public function login(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'email' => 'required|max:255|email',
            'password' => 'required|min:8',
        ]);
      
        if ($validator->fails())
        {
            return response()->json(['errors' => $validator->errors()]);
        }   

        if(Auth::attempt(['email' => $request->email , 'password' => $request->password])) {

            $accessToken = Auth::User()->createToken('authToken')->accessToken;
            return response(['user' => Auth::User(), 'access_token' => $accessToken]);
            
        }      

        return response()->json(['errors' => 'Invalid credentials']);

    }
  
    /**
     * Logout user (Revoke the token)
     *
     * @return [string] message
     */
    public function logout(Request $request)
    {
        $request->user()->token()->revoke();        
        return response()->json(['message' => 'Successfully logged out']);
    }

    /**
     * Get the authenticated User
     *
     * @return [json] user object
     */

    public function details(Request $request)
    {
        return response()->json($request->user());
    }
}
