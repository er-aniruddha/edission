<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Portal\Customer;
use App\Models\Portal\CustomerRoute;
use App\Models\Portal\Sale;
use App\Models\Portal\CustomerDiscount;
use App\Models\Portal\CreditNote;
use App\Models\Portal\PaymentIn;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Illuminate\Support\Str;
use Validator;
use Image;  

class CustomerController extends Controller
{
    
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    public function index()
    {
        $customer = Customer::orderBy('f_name','asc')->join('customer_routes','customers.customer_routes_id',"=",'customer_routes.customer_routes_id')->get();
        return response()->json($customer);
    }

    public function profile($customer_id)
    {
        $customer = Customer::find($customer_id);
        $sales = Sale::where('sales.customer_id',$customer_id)                            
                            ->leftJoin('customers','sales.customer_id','=','customers.customer_id')
                            ->leftJoin('products','sales.item_name','=','products.product_id')
                            ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('units','sales.unit_id','=','units.unit_id')
                            ->select(array('sales.*','products.*','customers.*','units.*','brands.*'))
                            ->orderBy('sale_id','asc')
                            ->get();   
        $creditNotes = CreditNote::where('credit_notes.customer_id',$customer_id)
                                ->leftJoin('products','credit_notes.item_name','=','products.product_id')
                                ->leftJoin('customers','credit_notes.customer_id','=','customers.customer_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units','credit_notes.unit_id','=','units.unit_id')
                                ->select(array('credit_notes.*','products.*','customers.*','units.*','brands.*'))
                                ->orderBy('cr_note_id','asc')
                                ->get(); 
        $paymentIn = PaymentIn::where('payment_ins.customer_id',$customer_id)
                                ->leftJoin('customers','payment_ins.customer_id','=','customers.customer_id')
                                ->select(array('payment_ins.*','customers.*','payment_ins.date as order_date','payment_ins.date as delivery_date','payment_type as payment_type','prev_balance as total','prev_balance as prev_balance','received as received','payment_ins.balance as balance'))
                                ->orderBy('payment_ins.date','desc')
                                ->get();   
        $customerDiscount = CustomerDiscount::where('customer_discounts.customer_id',$customer_id)
                                ->leftJoin('customers','customer_discounts.customer_id','=','customers.customer_id')
                                ->select(array('customer_discounts.*','customers.*','customer_discounts.date as order_date','customer_discounts.date as delivery_date','payment_type as payment_type'))
                                ->orderBy('customer_discounts.date','desc')
                                ->get(); 

        $allTableData = $sales->concat($creditNotes)->concat($paymentIn)->concat($customerDiscount);
        return response()->json(['customer'=>$customer,'allTableData' => $allTableData]);   
    }

    public function data_table_transaction($customer_id)
    {
        $startDate = $_GET['startDate']; 
        $endDate = $_GET['endDate'];

        $sales = Sale::where('sale_order_date', '>=', $startDate)->where('sale_order_date', '<=', $endDate)
                        ->where('sales.customer_id',$customer_id)
                        ->select(array('sales.*','sale_order_date as order_date','sale_delivery_date as delivery_date','sale_payment_type as payment_type','sale_total as total','sale_prev_balance as prev_balance','sale_received as received','sale_balance as balance','sale_payment_status as payment_status'))
                        ->orderBy('sale_order_date','desc')
                        ->get()->unique('sale_trnx_id'); 
        $creditNotes = CreditNote::where('cr_order_date', '>=', $startDate)->where('cr_order_date', '<=', $endDate)
                                ->where('credit_notes.customer_id',$customer_id)
                                ->select(array('credit_notes.*','cr_order_date as order_date','cr_delivery_date as delivery_date','cr_payment_type as payment_type','cr_total as total','cr_prev_balance as prev_balance','cr_paid as received','cr_balance as balance','cr_payment_status as payment_status'))
                                ->orderBy('cr_order_date','desc')
                                ->get()->unique('cr_trnx_id'); 
        $paymentIn = PaymentIn::where('date', '>=', $startDate)->where('date', '<=', $endDate)
                                ->where('payment_ins.customer_id',$customer_id)
                                ->select(array('payment_ins.*','payment_ins.date as order_date','payment_ins.date as delivery_date','payment_type as payment_type','prev_balance as total','prev_balance as prev_balance','received as received','balance as balance'))
                                ->orderBy('payment_ins.date','desc')
                                ->get(); 

        $customerDiscount = CustomerDiscount::where('customer_discounts.customer_id',$customer_id)
                                ->leftJoin('customers','customer_discounts.customer_id','=','customers.customer_id')
                                ->select(array('customer_discounts.*','date as order_date','date as delivery_date','payment_type as payment_type','discount_amount as total','paid as received'))
                                ->orderBy('customer_discounts.date','desc')
                                ->get();

        $tableData = $sales->concat($creditNotes)->concat($paymentIn)->concat($customerDiscount)->sortByDesc('order_date');

       
        return datatables()->of($tableData)     
        ->addColumn('trnxid', function($data){
            if( $data->sale_status == 1)
            {
                $trnxid = '<span class="text-sm text-success text-capitalize">INV-'.$data->sale_trnx_id.'</span>';  
            }
            elseif( $data->sale_status == 0 && !$data->cr_trnx_id && !$data->payment_in_trnx_id && !$data->discount_id)
            {
                $trnxid = '<span class="text-sm text-success text-capitalize">OD-'.$data->sale_trnx_id.'</span>';  
            }
            elseif( $data->cr_status == 1 )
            {
                $trnxid = '<span class="text-sm text-warning text-capitalize">CRN-'.$data->cr_trnx_id.'</span>';   
            }   
            elseif($data->cr_status == 0 && !$data->sale_trnx_id && !$data->payment_in_trnx_id && !$data->discount_id)
            {
                $trnxid = '<span class="text-sm text-warning text-capitalize">CRN-OD-'.$data->cr_trnx_id.'</span>';   
            }
            elseif($data->discount_id)
            {
               $trnxid = '<span class="item-badge badge text-uppercase bg-danger">DISC-'.$data->discount_id.'</span>';  
            }
            else
            {
                $trnxid = '<span class="text-sm text-muted text-capitalize">PAY-IN-'.$data->payment_in_trnx_id.'</span>';   
            }

            return $trnxid;
        })
        ->addColumn('status', function($data){
            if( $data->sale_status == 1)
            {
                $status = '<span class="text-sm item-badge badge text-uppercase bg-success">Order Complete</span>';  
            }
            elseif( $data->sale_status == 0 && !$data->cr_trnx_id && !$data->payment_in_trnx_id && !$data->discount_id)
            {
                $status = '<a class="text-sm item-badge badge text-uppercase bg-secondary convert-to-sale"data-trnxid="'.$data->sale_trnx_id.'" data-date="'.$data->order_date.'">Convert to Sale</a>';
            }
            elseif( $data->cr_status == 1 )
            {
                $status = '<span class="text-sm item-badge badge text-uppercase bg-success">Order Complete</span>';  
            }  
            elseif($data->cr_status == 0 && !$data->sale_trnx_id && !$data->payment_in_trnx_id && !$data->discount_id)
            {
                $status = '<a class="text-sm item-badge badge text-uppercase bg-secondary convert-to-purchase" data-trnxid="'.$data->cr_trnx_id.'" data-date="'.$data->order_date.'">Convert to Purchase</a>';                        
            }
            elseif($data->discount_id)
            {
                $status = '<span class="text-sm item-badge badge text-uppercase bg-danger">Payment Complete</span>';
            }
            else
            {
                $status = '<span class="text-sm item-badge badge text-uppercase bg-success">Payment Complete</span>';
            }
            return $status;
        })
        ->rawColumns(['trnxid','status'])                
        ->make(true); 
        
    }
    public function create(Request $request)
    {        
        $validator = \Validator::make($request->all(), [
            'f_name' => 'required|max:255',
            's_name' => 'required|max:255',
            'shop_name' => 'required|max:255',
            'phone_1' => 'required|min:10|numeric|regex:/[6-9][0-9]{9}/|unique:customers,phone_1',
            'email' => 'nullable|email|unique:customers,email',
            'customer_type' => 'required|not_in:0',
            'customer_routes_id' => 'required|not_in:0',
            'locality' => 'required|max:255',
            'district' => 'required|max:255',
            'pin' => 'required|min:6',
            ],[
                'f_name.required' => 'Please enter first name.',
                's_name.required' => 'Please enter surname.',

                'phone_1.required' => 'Please enter valid phone number.',
                'phone_1.min' => 'Please enter valid phone number.',
                'phone_1.numeric' => 'Please enter valid phone number.',
                'phone_1.regex' => 'Please enter valid phone number.',
                'phone_1.unique' => 'Phone nuber already been taken.',
                'customer_routes_id.required' => 'Please select route.',
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }

            $customer = new Customer;
            $customer->f_name = Str::lower($request->f_name);
            $customer->s_name = Str::lower($request->s_name);
            $customer->shop_name = Str::lower($request->shop_name);
            $customer->phone_1 = $request->phone_1;
            $customer->phone_2 = $request->phone_2;
            $customer->whatsapp_no = $request->whatsapp_no;
            $customer->email = Str::lower($request->email);
            $customer->customer_type = $request->customer_type;
            $customer->customer_routes_id = $request->customer_routes_id;
            $customer->locality = Str::lower($request->locality);
            $customer->district = $request->district;
            $customer->state = $request->state;
            $customer->pin = $request->pin;
            $customer->addline_1 = Str::lower($request->addline_1);
            $customer->addline_2 = Str::lower($request->addline_2);                 
            $is_saved = $customer->save();

            if($is_saved)
            {            
                $success = array('success' => 'OK', 'message' => 'Created Successfully');
                return response()->json($success);
            } 
    }

    public function update(Request $request)
    {
        $customer = Customer::find($request->customer_id);    
        $validator = \Validator::make($request->all(), [
            'f_name' => 'required|max:255',
            's_name' => 'required|max:255',
            'shop_name' => 'required|max:255',
            'phone_1' => ['required','min:10','numeric','regex:/[6-9][0-9]{9}/',
                Rule::unique('customers')->ignore($customer->phone_1,'phone_1'),
            ],
            'email' => ['email','nullable',
                Rule::unique('customers')->ignore($customer->email,'email'),
            ],
            'customer_routes_id' => 'required|not_in:0',
            'customer_type' => 'required|not_in:0',
            'locality' => 'required|max:255',
            'district' => 'required|max:255',
            'pin' => 'required|min:6',
        ],[
            'f_name.required' => 'Please enter first name.',
            's_name.required' => 'Please enter surname.',
            'phone_1.required' => 'Please enter valid phone number.',
            'phone_1.min' => 'Please enter valid phone number.',
            'phone_1.numeric' => 'Please enter valid phone number.',
            'phone_1.regex' => 'Please enter valid phone number.',
            'customer_routes_id.required' => 'Please select route.',
        ]);
        if ($validator->fails())         
        {
            return response()->json(['errors' => $validator->errors()]);
        }

        $customer->f_name = Str::lower($request->f_name);
        $customer->s_name = Str::lower($request->s_name);
        $customer->shop_name = Str::lower($request->shop_name);
        $customer->phone_1 = $request->phone_1;
        $customer->phone_2 = $request->phone_2;
        $customer->whatsapp_no = $request->whatsapp_no;
        $customer->email = Str::lower($request->email);
        $customer->customer_routes_id = $request->customer_routes_id;
        $customer->customer_type = $request->customer_type;
        $customer->locality = Str::lower($request->locality);
        $customer->district = $request->district;
        $customer->state = $request->state;
        $customer->pin = $request->pin;
        $customer->addline_1 = Str::lower($request->addline_1);
        $customer->addline_2 = Str::lower($request->addline_2);               
        $is_saved = $customer->update();

        if($is_saved)
        {            
            $success = array('success' => 'OK', 'message' => 'Update Successfully');
            return response()->json($success);
        }        
        
    }

    public function destroy($customer_id)
    {
        $customer = Customer::find($customer_id);               
        $sale = Sale::where('customer_id',$customer_id)->first();
        if($sale)
        {
            $error = array('error' => "This customer can't be deleted.");
            return response()->json($error);
        }
        else
        {           
            $customer->delete();
            $success = array('success' => 'Customer deleted successfully');
            return response()->json($success);            
        }

    }
}




    //->addColumn('action', function($data){                  
    //     if($data->sale_trnx_id)
    //     {   
    //         $action = '<div class="dropdown">
    //                    <a href="#" data-bs-toggle="dropdown" aria-expanded="false" class="text-muted dropdown-toggle" aria-expanded="true">
    //                         <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
    //                         </svg>
    //                     </a>
    //                     <div class="dropdown-menu" style="">
    //                         <a class="dropdown-item view" href="#" data-saletrnxid="'.$data->sale_trnx_id.'" data-status="'.$data->sale_status.'">
    //                             <i class="bi bi-eye"></i>
    //                             See detail
    //                         </a>                        
    //                     </div>
    //                 </div>'; 
    //     }
    //     elseif($data->cr_trnx_id)
    //     {
    //         $action = '<div class="dropdown">
    //                        <a href="#" data-bs-toggle="dropdown" aria-expanded="false" class="text-muted dropdown-toggle" aria-expanded="true">
    //                             <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
    //                             </svg>
    //                         </a>
    //                         <div class="dropdown-menu" style="">
    //                             <a class="dropdown-item view" href="#" data-crtrnxid="'.$data->cr_trnx_id.'" data-status="'.$data->cr_status.'">
    //                                 <i class="bi bi-eye"></i>
    //                                 See detail
    //                             </a>                        
    //                         </div>
    //                     </div>';
    //     }
    //     if($data->payment_in_trnx_id)
    //     {
    //         $action = '<div class="dropdown">
    //                         <a href="#" data-bs-toggle="dropdown" aria-expanded="false" class="text-muted dropdown-toggle" aria-expanded="true">
    //                             <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
    //                             </svg>
    //                         </a>
    //                         <div class="dropdown-menu" style="">
    //                             <a class="dropdown-item view" href="#" data-payintrnxid="'.$data->payment_in_trnx_id.'" data-status="1">
    //                                 <i class="bi bi-eye"></i>
    //                                 See detail
    //                             </a>                        
    //                         </div>
    //                     </div>'; 
    //     }
    //     return $action;
    // })
