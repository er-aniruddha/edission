<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Sale;
use App\Models\Portal\CreditNote;
use App\Models\Portal\Product;
use App\Models\Portal\Unit;
use App\Models\Portal\Brand;
use App\Models\Portal\Customer;
use App\Models\Portal\Stock;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;

class SaleOrderController extends Controller
{
    public function __construct()
    {
        $this->middleware("auth:api");
    }

    public function index()
    {
        $saleOrderList = Sale::leftJoin('customers','sales.customer_id','=','customers.customer_id')
                                ->select(array('sales.*','customers.*'))
                                ->where('sale_status',0)
                                ->orderBy('sale_order_date','desc')
                                ->get()->unique('sale_trnx_id'); 

        $creditNoteList = CreditNote::leftJoin('customers','credit_notes.customer_id','=','customers.customer_id')
                                ->select(array('credit_notes.*','customers.*'))
                                ->where('cr_status',0)
                                ->orderBy('cr_order_date','desc')
                                ->get()->unique('cr_trnx_id'); 

        $data = array('saleOrderList'=> $saleOrderList, 'creditNoteList'=>$creditNoteList);

        return response()->json($data); 
    }

    public function create(Request $request)
    {    
        $data = $request->allProductsInfo;
        $confirmModaldata =  $request->confirmModaldata;
        $invoceTotal = $request->inoviceBottomForm;

        $openOrderchk = Sale::where('customer_id',$data[0]['customerId'])->where('sale_status',0)->count();           
        
        // return response()->json($request->all());
        if($openOrderchk < 1)
        {
            $validator = \Validator::make(['order_date' => $confirmModaldata['order_date'],'payment_type' => $confirmModaldata['payment_type']], [
                'order_date' => 'required|date|before:tomorrow', 
                'payment_type' => 'required|not_in:0',
            ],[
                'order_date.before' => 'The date mustbe today or before.',                    
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }
            if($validator->passes())
            {
                $invId = 1000000000+strtotime("now"); 
                $New_start_index = 0;          
                $length = count($data);
                for($i=0; $i < $length; $i++)
                {  
                    $findProduct = Product::find($data[$i]['selectProductId']);           

                    $newSale = new Sale;
                    $newSale->sale_order_date = Carbon::createFromFormat('d-m-Y', $confirmModaldata['order_date'])->format('Y-m-d'); ;            
                    $newSale->sale_trnx_id = $invId; 
                    $newSale->customer_id = $data[$i]['customerId'];     
                    $newSale->item_name = Str::lower($data[$i]['selectProductId']);
                    $newSale->unit_id = Str::lower($data[$i]['unitId']);  
                    $newSale->sale_qty = $data[$i]['qty'];                        
                    if($findProduct->primary_unit == $data[$i]['unitId'])
                    {
                        $newSale->sale_primary_qty = $data[$i]['qty'];
                        $newSale->sale_secondary_qty = $data[$i]['qty'] * $findProduct->no_of_pcs;
                    }
                    if($findProduct->secondary_unit == $data[$i]['unitId'])
                    {
                        $newSale->sale_primary_qty = (int)($data[$i]['qty'] / $findProduct->no_of_pcs);
                        $newSale->sale_secondary_qty = $data[$i]['qty'];
                    } 

                    $newSale->sale_unit_price = $data[$i]['mrp'];
                    $newSale->sale_primary_pp = $findProduct->primary_pp_for_stock;
                    $newSale->sale_secondary_pp = $findProduct->secondary_pp_for_stock;
                    $newSale->sale_discount_percentage = $data[$i]['discount_percentage'];
                    $newSale->sale_discount = $data[$i]['discount'];
                    $newSale->sale_amount = $data[$i]['amount'];
                    $newSale->sale_payment_type = $confirmModaldata['payment_type'];
                    $newSale->sale_delivery_charges = $invoceTotal['delivery_charges'];
                    $newSale->sale_round_off = $invoceTotal['round_off'];
                    $newSale->sale_gst_amount = $invoceTotal['gst_amount'];
                    $newSale->sale_total = $invoceTotal['total'];
                    $newSale->sale_received = $invoceTotal['received'];
                    $newSale->sale_balance = $invoceTotal['balance'];
                    $newSale->sale_prev_balance = $invoceTotal['prev_balance'];
                    $newSale->sale_remarks = $confirmModaldata['remarks'];
                    if($invoceTotal['received'] <= 0)
                    {
                        $newSale->sale_payment_status  = 0;
                    }
                    elseif($request->balance <= 0)
                    {
                        $newSale->sale_payment_status  = 2;           
                    }
                    else
                    {
                        $newSale->sale_payment_status  = 1;  
                    }
                    $newSale->sale_status = 0;
                    $newSale->save();
                } // for loop end                
                $success = array('success' => "New order created successfully.");
                return response()->json($success);
                
            }
        }

        else
        {
            $errors = array('errors'=> array('message' => array('0'=>"Order can't be completed. This customer has an open order.")));
            return response()->json($errors);
        } 
    }

    public function show($sale_trnx_id)
    {
        $saleOrderEdit = Sale::leftJoin('products','sales.item_name','=','products.product_id')
                                ->leftJoin('customers','sales.customer_id','=','customers.customer_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units','sales.unit_id','=','units.unit_id')
                                ->select(array('sales.*','products.*','customers.*','units.*','brands.*'))
                                ->where('sale_trnx_id',$sale_trnx_id)
                                ->orderBy('sale_order_date','desc')
                                ->get();  
        return response()->json($saleOrderEdit);
    }

    public function update(Request $request)
    {
        $data = $request->allProductsInfo;
        $confirmModaldata =  $request->confirmModaldata;
        $invoceTotal = $request->inoviceBottomForm;
        $invId = $request->trnxId;
        $customerId = $request->customerId;
        $validator = \Validator::make(['order_date' => $confirmModaldata['order_date'],
                                    'payment_type' => $confirmModaldata['payment_type']], [
                                    'order_date' => 'required|date|before:tomorrow', 
                                    'payment_type' => 'required|not_in:0',
                                ],[
                                    'order_date.before' => 'The date mustbe today or before.',                    
                                ]);
        if ($validator->fails())         
        {
            return response()->json(['errors' => $validator->errors()]);
        }
        if($validator->passes())
        {    
            Sale::where('sale_trnx_id',$invId)->delete();       

            $New_start_index = 0;          
            $length = count($data);

            for($i=0; $i < $length; $i++)
            {  
                $findProduct = Product::find($data[$i]['selectProductId']);           

                $newSale = new Sale;
                $newSale->sale_order_date = Carbon::createFromFormat('d-m-Y', $confirmModaldata['order_date'])->format('Y-m-d'); ;            
                $newSale->sale_trnx_id = $invId; 
                $newSale->customer_id = $customerId;     
                $newSale->item_name = Str::lower($data[$i]['selectProductId']);
                $newSale->unit_id = Str::lower($data[$i]['unitId']);  
                $newSale->sale_qty = $data[$i]['qty'];                        
                if($findProduct->primary_unit == $data[$i]['unitId'])
                {
                    $newSale->sale_primary_qty = $data[$i]['qty'];
                    $newSale->sale_secondary_qty = $data[$i]['qty'] * $findProduct->no_of_pcs;
                }
                if($findProduct->secondary_unit == $data[$i]['unitId'])
                {
                    $newSale->sale_primary_qty = (int)($data[$i]['qty'] / $findProduct->no_of_pcs);
                    $newSale->sale_secondary_qty = $data[$i]['qty'];
                } 

                $newSale->sale_unit_price = $data[$i]['mrp'];
                $newSale->sale_primary_pp = $findProduct->primary_pp_for_stock;
                $newSale->sale_secondary_pp = $findProduct->secondary_pp_for_stock;
                $newSale->sale_discount_percentage = $data[$i]['discount_percentage'];
                $newSale->sale_discount = $data[$i]['discount'];
                $newSale->sale_amount = $data[$i]['amount'];
                $newSale->sale_payment_type = $confirmModaldata['payment_type'];
                $newSale->sale_delivery_charges = $invoceTotal['delivery_charges'];
                $newSale->sale_round_off = $invoceTotal['round_off'];
                $newSale->sale_gst_amount = $invoceTotal['gst_amount'];
                $newSale->sale_total = $invoceTotal['total'];
                $newSale->sale_received = $invoceTotal['received'];
                $newSale->sale_balance = $invoceTotal['balance'];
                $newSale->sale_prev_balance = $invoceTotal['prev_balance'];
                $newSale->sale_remarks = $confirmModaldata['remarks'];
                if($invoceTotal['received'] <= 0)
                {
                    $newSale->sale_payment_status  = 0;
                }
                elseif($request->balance <= 0)
                {
                    $newSale->sale_payment_status  = 2;           
                }
                else
                {
                    $newSale->sale_payment_status  = 1;  
                }
                $newSale->sale_status = 0;
                $newSale->save();
            } // for loop end

            $success = array('success' => "Order updated successfully.");
            return response()->json($success);
            
        }
    }
    public function convert(Request $request)
    {
        $saletrnxId = $request->saleTrnxId;
        $deliveryDate = $request->deliveryDate;

        $validator = \Validator::make(['delivery_date' => $deliveryDate], [
            'delivery_date' => 'required|date|before:tomorrow|after_or_equal:order_date',     
            ],[
            'delivery_date.before' => 'The date mustbe today or before.',
        ]);
        if ($validator->fails())         
        {
            return response()->json(['errors' => $validator->errors()]);
        }
        if($validator->passes())
        {

            $data = Sale::where('sale_trnx_id',$saletrnxId)->where('sale_status',0)->get();
            $customerId = $data[0]['customer_id'];
            foreach($data as $d)
            {  
                $findProduct = Product::find($d->item_name);     
                if($findProduct->secondary_unit == $d->unit_id)
                { 
                    $prevStockValue = $findProduct->stock_value;
                    $nowSecondaryQty = $findProduct->in_hand_stock_second - $d->sale_qty; 
                    $findProduct->stock_value = $nowSecondaryQty * $findProduct->secondary_pp_for_stock;
                    $findProduct->in_hand_stock_primary = (int)($nowSecondaryQty/$findProduct->no_of_pcs);
                    $findProduct->in_hand_stock_second = $nowSecondaryQty;
                }
                if($findProduct->primary_unit == $d->unit_id)
                {
                    $prevStockValue = $findProduct->stock_value;
                    $nowSecondaryQty = $findProduct->in_hand_stock_second - ($findProduct->no_of_pcs * $d->sale_qty);
                    $findProduct->stock_value = $nowSecondaryQty * $findProduct->secondary_pp_for_stock;
                    $findProduct->in_hand_stock_primary = (int)($nowSecondaryQty/$findProduct->no_of_pcs);
                    $findProduct->in_hand_stock_second = $nowSecondaryQty;
                }
                $findProduct->update();

                $newStock = New Stock;
                $newStock->stock_type = 2;
                $newStock->trnx_id  = $d->sale_trnx_id; 
                $newStock->item_name  = Str::lower($d->item_name);
                $newStock->customer_id  = $customerId;
                $newStock->order_date  = $d->sale_order_date;
                $newStock->delivery_date  = $deliveryDate;     
                $newStock->qty = $d->sale_qty;     
                if($findProduct->primary_unit == $d->unit_id)
                {
                    $newStock->primary_qty =  $d->sale_qty;
                    $newStock->secondary_qty =  $d->sale_qty * $findProduct->no_of_pcs;
                }
                if($findProduct->secondary_unit == $d->unit_id)
                {
                    $newStock->primary_qty = (int)( $d->sale_qty / $findProduct->no_of_pcs);
                    $newStock->secondary_qty =  $d->sale_qty;
                } 
                $newStock->unit_id  = Str::lower( $d->unit_id);
                $newStock->unit_price  = $d->sale_unit_price - $d->sale_discount;
                $newStock->amount  = -$d->sale_amount;
                $newStock->delivered_qty  = $newStock->delivered_qty + $d->sale_qty;
                $newStock->stock_stat  = $d->sale_payment_status;                   
                $newStock->save();

            } // foreach loop end
            
            $findCustomer = Customer::find($customerId);
            $findCustomer->balance = $data[0]['sale_balance'];;
            $findCustomer->update();

            Sale::where('sale_trnx_id',$saletrnxId)->update(['sale_delivery_date' => $deliveryDate, 'sale_status' => 1]);
            
            $success = array('success' => "New invoice saved successfully.");
            return response()->json($success);        
        }   
    }

    public function destroy($sale_trnx_id)
    {
        $invId = $sale_trnx_id;
        $is_delete = Sale::where('sale_trnx_id',$invId)->delete();

       if($is_delete)
       {            
            $success = array('success' => "Order deleted successfully #OD-".$invId.".");
            return response()->json($success);
       }
    }
}
