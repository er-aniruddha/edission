<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Expense;
use Illuminate\Support\Str;
use Validator;
use Carbon\Carbon;

class ExpenseController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {      
      $expenses = Expense::orderBy('date','DESC')->get();
  

    	if(request()->ajax())
      {
        return datatables()->of($expenses)
          ->addColumn('action', function($data){
            $today = Carbon::now();
            $endDate = $data->date;
            $diff_in_days = $today->diffInDays($endDate);

            if($diff_in_days < 600)
            {
              $button = '<button type="button" id="'.$data->expense_id .'" data-date="'.date('d-m-Y', strtotime($data->date)).'" data-fuel="'.$data->fuel .'" data-travelling="'.$data->travelling .'" data-transport="'.$data->transport .'" data-tiffin="'.$data->tiffin .'" data-roomrent="'.$data->room_rent .'" data-salary="'.$data->salary .'" data-others="'.$data->extra_exp .'" data-total="'.$data->total .'" data-remarks="'.$data->remarks .'" class="view btn btn-outline-info  btn-sm">View</button>';
              $button .= '&nbsp;';
              $button .= '<button type="button" id="'.$data->expense_id .'" data-date="'.date('d-m-Y', strtotime($data->date)).'" data-fuel="'.$data->fuel .'" data-travelling="'.$data->travelling .'" data-transport="'.$data->transport .'" data-tiffin="'.$data->tiffin .'" data-roomrent="'.$data->room_rent .'" data-salary="'.$data->salary .'" data-others="'.$data->extra_exp .'" data-total="'.$data->total .'" data-remarks="'.$data->remarks .'" class="edit btn btn-outline-primary btn-sm">Edit</button>';
              $button .= '&nbsp;';
              $button .= '<button type="button" data-id="'.$data->expense_id .'" data-date="'.date('d-m-Y', strtotime($data->date)).'" class="delete btn btn-outline-danger btn-sm">Del</button>';
            }
            else
            {
              $button = '<button type="button" id="'.$data->expense_id.'" data-date="'.date('d-m-Y', strtotime($data->date)).'" class="view btn btn-outline-info  btn-sm">View</button>';
            }
            
            return $button;
          })
          ->editColumn('date', function ($data) {
              return date('d-m-Y', strtotime($data->date));
          })
          ->addIndexColumn()
          ->rawColumns(['action','date'])
          ->make(true);       
                  
      }  
      else
      {
        return view('portal.expense.index');
      }      
    }

    public function create(Request $request)
    {
      if(request()->ajax())
      {
        if($request->date)
        {
          $date = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
          $validator_date = \Validator::make($date, [
            'date' => 'required|date|before:tomorrow|unique:expenses,date',         
          ],[
              'date.before' => 'The date mustbe today or before.',
              'date.unique' => 'Can not add two item on same date',
          ]);
          if ($validator_date->fails())         
          {
            return response()->json(['errors' => $validator_date->errors()]);
          }
        }

        $validator = \Validator::make($request->all(), [
          'date' => 'required|date|before:tomorrow',         
          'fuel' => 'required',
          'travelling' => 'required',
          'transport' => 'required',
          'tiffin' => 'required',
          'room_rent' => 'required',
          'salary' => 'required',
          'extra_exp' => 'required',
          'total' => 'required|not_in:0',
          'remarks' => 'required', 
        ],[
            'date.before' => 'The date mustbe today or before.',
        ]);
        if ($validator->fails())         
        {
          return response()->json(['errors' => $validator->errors()]);
        }
        
        if($validator->passes())
        {
          //$stock = $request->all();
          $expense = new Expense;
          $expense->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
          $expense->fuel = $request->fuel;
          $expense->travelling = $request->travelling;                
          $expense->transport = $request->transport;
          $expense->tiffin = $request->tiffin;
          $expense->room_rent = $request->room_rent;
          $expense->salary = $request->salary;
          $expense->extra_exp = $request->extra_exp;
          $expense->total = $request->total;
          $expense->remarks = $request->remarks;
          $is_save = $expense->save();

          if($is_save)
          {
            $success = array('success' => 'Expense saved successfully');
            return response()->json($success);
          } 
        } 
      }
    }

    public function update(Request $request)
    {      
      if(request()->ajax())
      {
        $expense = Expense::find($request->expense_id);
        if($request->date)
        {
          $reqDate = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
          if($expense->date != Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d'))
          {
            $validator_date = \Validator::make($reqDate, [
              'date' => 'required|date|before:tomorrow|unique:expenses,date',         
            ],[
                'date.before' => 'The date mustbe today or before.',
                'date.unique' => 'Can not add two item on same date',
            ]);
            if ($validator_date->fails())         
            {
              return response()->json(['errors' => $validator_date->errors()]);
            }
          }
        } 
        $validator = \Validator::make($request->all(), [
          'fuel' => 'required',
          'travelling' => 'required',
          'transport' => 'required',
          'tiffin' => 'required',
          'room_rent' => 'required',
          'salary' => 'required',
          'extra_exp' => 'required',
          'total' => 'required|not_in:0',
          'remarks' => 'required', 
        ]);

        if ($validator->fails())         
        {
          return response()->json(['errors' => $validator->errors()]);
        }
        if($validator->passes())
        {
          $expense = Expense::find($request->expense_id);
          $expense->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
          $expense->fuel = $request->fuel;
          $expense->travelling = $request->travelling;                
          $expense->transport = $request->transport;
          $expense->tiffin = $request->tiffin;
          $expense->room_rent = $request->room_rent;
          $expense->salary = $request->salary;
          $expense->extra_exp = $request->extra_exp;
          $expense->total = $request->total;
          $expense->remarks = $request->remarks;
          $is_save = $expense->update();

          if($is_save)
          {
            $success = array('success' => 'Expense update successfully');
            return response()->json($success);
          }
        } 
      }
    }

    public function destroy(Request $request)
    {
      $data = Expense::find($request->id);
      $is_delete = $data->delete();
      if($is_delete)
      {
        $success = array('success' => 'Expense deleted successfullly');
        return response()->json($success);
      }
    }

    public function details()
    {
      $oneYear = Carbon::now()->subDays(365);
      $oneMonth = Carbon::now()->subDays(30);
      $sevenDays = Carbon::now()->subDays(7);

      $oneYearExpense = Expense::where('date','>=',$oneYear)->sum('total');
      $oneMonthExpense = Expense::where('date','>=',$oneMonth)->sum('total');
      $sevenDaysExpense = Expense::where('date','>=',$sevenDays)->sum('total');

      $data = array('oneYearExpense' => $oneYearExpense, 'oneMonthExpense' => $oneMonthExpense, 'sevenDaysExpense' => $sevenDaysExpense);

      return response()->json($data);
    }

    public function dateRange()
    {
      $startDate = $_GET['startDate']; 
      $endDate = $_GET['endDate'];
      // $x = Carbon::now()->subDays(30);
      $totalExpense = Expense::where('date', '>=', $startDate)->where('date', '<=', $endDate)->sum('total');
      return response()->json($totalExpense);
    }
}
