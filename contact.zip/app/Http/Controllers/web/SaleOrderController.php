<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Sale;
use App\Models\Portal\Product;
use App\Models\Portal\Unit;
use App\Models\Portal\Brand;
use App\Models\Portal\Customer;
use App\Models\Portal\Stock;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;

class SaleOrderController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                            ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                            ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*'))
                            ->where('pro_type','Purchasing')->where('product_stat',1)
                            ->orderBy('product_name','DESC')
                            ->get();
        $customers = Customer::orderBy('customer_id','DESC')->get();
        $saleTable = Sale::leftJoin('customers','sales.customer_id','=','customers.customer_id')
                                ->select(array('sales.*','customers.*'))
                                ->where('sale_status',0)
                                ->orderBy('sale_order_date','desc')
                                ->get()->unique('sale_trnx_id'); 
        if(request()->ajax())
        {
          return datatables()->of($saleTable)  
                ->addColumn('name', function($data){                  
                    $name = '<a href="page.invoice.detail.html" class="item-company ajax h-1x text-capitalize" data-pjax-state="">'.$data->f_name.' '.$data->s_name.'</a>
                            <div class="item-mail text-muted h-1x d-none d-sm-block text-capitalize">'.$data->shop_name.'</div>'; 
                  return $name;
                })         
                ->addColumn('action', function($data){                  
                    $action = '<div class="item-action dropdown">
                                    <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right bg-light" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                        <a class="dropdown-item view" href="#" data-trnxid="'.$data->sale_trnx_id.'">See detail </a>
                                        <a class="dropdown-item edit" data-trnxid="'.$data->sale_trnx_id.'" data-cid="'.$data->customer_id.'" data-ctype="'.$data->customer_type.'">Edit</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item delete" data-trnxid="'.$data->sale_trnx_id.'" data-cid="'.$data->customer_id.'">Delete item</a>
                                    </div>
                                </div>'; 
                  return $action;
                })
                ->addColumn('trnxid', function($data){
                    if( $data->sale_status == 1)
                    {
                        $status = '<span class="item-amount d-none d-sm-block text-sm text-success text-capitalize">INV-'.$data->sale_trnx_id.'</span>';  
                    }
                    else
                    {
                        $status = '<span class="item-amount d-none d-sm-block text-sm text-success text-capitalize">OD-'.$data->sale_trnx_id.'</span>';   
                    }
                    return $status;
                })
                ->addColumn('status', function($data){
                  if( $data->sale_status == 1)
                  {
                    $status = '<span class="item-badge badge text-uppercase bg-success">Order Complete</span>';  
                  }
                  else
                  {
                    $status = '<a class="item-badge badge text-uppercase bg-secondary convert-to-sale" data-trnxid="'.$data->sale_trnx_id.'" data-date="'.$data->order_date.'">Convert to Sale</a>';   
                  }
                  return $status;
                })                
                ->addIndexColumn()    
                ->rawColumns(['action','name','trnxid','status'])                   
                ->make(true); 
        } 
        else{
            $sales = Sale::leftJoin('products','sales.item_name','=','products.product_id')
                                ->leftJoin('customers','sales.customer_id','=','customers.customer_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units','sales.unit_id','=','units.unit_id')
                                ->select(array('sales.*','products.*','customers.*','units.*','brands.*'))
                                ->orderBy('sale_id','asc')
                                ->get();             
            return view('portal.sale_order.index',['products'=>$products , 'customers' => $customers ,'sales' =>$sales]);
        }    
    }

    public function create(Request $request)
    {
        if(request()->ajax())
        {
            $openOrderchk = Sale::where('customer_id',$request->customer_id)->where('sale_status',0)->count();

            if($openOrderchk < 1)
            {
                $validator = \Validator::make($request->all(), [
                    'customer_id' => 'required|not_in:0',
                    'order_date' => 'required|date|before:tomorrow',       
                    'item_name.*' => 'required|max:255',
                    'unit_id.*' => 'required|max:255',
                    'qty.*' => 'required|integer|not_in:0',
                    'product_mrp.*' => 'required',
                    'amount.*' => 'required',
                    'payment_type' => 'required|not_in:0',
                ],[
                    'order_date.before' => 'The date mustbe today or before.',
                    'delivery_date.before' => 'The date mustbe today or before.',
                    'customer_id.required' => 'Select customer.',
                    'item_name.*.required' => 'Item name required.',
                    'unit_id.*.required' => 'Unit Name required.',
                    'qty.*.required' => 'Quantity required.',
                    'product_mrp.*.required' => 'MRP price required.',
                    'amount.*.required' => 'Price required.',
                ]);
                if ($validator->fails())         
                {
                    return response()->json(['errors' => $validator->errors()]);
                }
                if($validator->passes())
                {
                    $invId = 1000000000+strtotime("now");                    
                    $data = $request->all();
                    $New_start_index = 0;          
                    $length = count($data['product_mrp']);
                  
                    $item_name = array_combine(range($New_start_index,  count($request->item_name) + ($New_start_index-1)),
                        array_values($request->item_name)); 
                    $unit_id = array_combine(range($New_start_index,  count($request->unit_id) + ($New_start_index-1)),
                        array_values($request->unit_id)); 
                    $qty = array_combine(range($New_start_index,  count($request->qty) + ($New_start_index-1)),
                        array_values($request->qty));                 
                    $product_mrp = array_combine(range($New_start_index,  count($request->product_mrp) + ($New_start_index-1)),
                        array_values($request->product_mrp)); 
                    $discount_percentage = array_combine(range($New_start_index,  count($request->discount_percentage) + ($New_start_index-1)), array_values($request->discount_percentage));
                    $discount = array_combine(range($New_start_index,  count($request->discount) + ($New_start_index-1)),
                        array_values($request->discount));  
                    $amount = array_combine(range($New_start_index,  count($request->amount) + ($New_start_index-1)),
                        array_values($request->amount)); 
                  
                    for($i=0; $i < $length; $i++)
                    {  
                        $findProduct = Product::find($item_name[$i]);           

                        $newSale = new Sale;
                        $newSale->sale_order_date = Carbon::createFromFormat('d-m-Y', $request->order_date)->format('Y-m-d');            
                        $newSale->sale_trnx_id = $invId; 
                        $newSale->customer_id = $request->customer_id;     
                        $newSale->item_name = Str::lower($item_name[$i]);
                        $newSale->unit_id = Str::lower($unit_id[$i]);  
                        $newSale->sale_qty = $qty[$i];                        
                        if($findProduct->primary_unit == $unit_id[$i])
                        {
                            $newSale->sale_primary_qty = $qty[$i];
                            $newSale->sale_secondary_qty = $qty[$i] * $findProduct->no_of_pcs;
                        }
                        if($findProduct->secondary_unit == $unit_id[$i])
                        {
                            $newSale->sale_primary_qty = (int)($qty[$i] / $findProduct->no_of_pcs);
                            $newSale->sale_secondary_qty = $qty[$i];
                        } 

                        $newSale->sale_unit_price = $product_mrp[$i];
                        $newSale->sale_primary_pp = $findProduct->primary_pp_for_stock;
                        $newSale->sale_secondary_pp = $findProduct->secondary_pp_for_stock;
                        $newSale->sale_discount_percentage = $discount_percentage[$i];
                        $newSale->sale_discount = $discount[$i];
                        $newSale->sale_amount = $amount[$i];
                        $newSale->sale_payment_type = Str::lower($request->payment_type);
                        $newSale->sale_delivery_charges = $request->delivery_charges;
                        $newSale->sale_round_off = $request->round_off;
                        $newSale->sale_gst_amount = $request->gst_amount;
                        $newSale->sale_total = $request->total;
                        $newSale->sale_received = $request->received;
                        $newSale->sale_balance = $request->balance;
                        $newSale->sale_prev_balance = $request->prev_balance;
                        $newSale->sale_remarks = $request->remarks;
                        if($request->received <= 0)
                        {
                            $newSale->sale_payment_status  = 0;
                        }
                        elseif($request->balance <= 0)
                        {
                            $newSale->sale_payment_status  = 2;           
                        }
                        else
                        {
                            $newSale->sale_payment_status  = 1;  
                        }
                        $newSale->sale_status = 0;
                        $newSale->save();
                    } // for loop end
                    

                    $sales = Sale::leftJoin('products','sales.item_name','=','products.product_id')
                                ->leftJoin('customers','sales.customer_id','=','customers.customer_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units','sales.unit_id','=','units.unit_id')
                                ->select(array('sales.*','products.*','customers.*','units.*','brands.*'))
                                ->orderBy('sale_id','asc')
                                ->get();   
                    $customers = Customer::orderBy('customer_id','DESC')->get();
                    $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                                ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                                ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*'))
                                ->where('pro_type','Purchasing')->where('product_stat',1)
                                ->orderBy('product_id','DESC')
                                ->get();
                    $success = array('success' => "New order created successfully.", 'sales' => $sales, 'customers' => $customers, 'products' => $products);
                    return response()->json($success);
                    
                }
            }

            else
            {
                $errors = array('errors'=> array('customer_id' => array('0'=>"Order can't be completed. This customer has an open order.")));
                return response()->json($errors);
            }
             
        }  
    }

    public function update(Request $request)
    {
        if(request()->ajax())
        {
            $validator = \Validator::make($request->all(), [
                'order_date' => 'required|date|before:tomorrow',      
                'item_name.*' => 'required|max:255',
                'unit_id.*' => 'required|max:255',
                'qty.*' => 'required|integer|not_in:0',
                'product_mrp.*' => 'required',
                'amount.*' => 'required',
                'payment_type' => 'required|not_in:0',
                ],[
                  'order_date.before' => 'The date mustbe today or before.',
                  'delivery_date.before' => 'The date mustbe today or before.',
                  'customer_id.required' => 'Select customer.',
                  'item_name.*.required' => 'Item name required.',
                  'unit_id.*.required' => 'Unit Name required.',
                  'qty.*.required' => 'Quantity required.',
                  'product_mrp.*.required' => 'MRP price required.',
                  'amount.*.required' => 'Price required.',
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }

            if($validator->passes())
            {
                $data = $request->all();
                $invId = $request->sale_trnx_id;
                $saleDetails = Sale::where('sale_trnx_id',$invId)->where('sale_status',0)->first();
                $customerId = $saleDetails->customer_id;
                $New_start_index = 0;          
                $length = count($data['item_name']);              
                $item_name = array_combine(range($New_start_index,  count($request->item_name) + ($New_start_index-1)),
                    array_values($request->item_name)); 
                $unit_id = array_combine(range($New_start_index,  count($request->unit_id) + ($New_start_index-1)),
                    array_values($request->unit_id)); 
                $qty = array_combine(range($New_start_index,  count($request->qty) + ($New_start_index-1)),
                    array_values($request->qty));                 
                $product_mrp = array_combine(range($New_start_index,  count($request->product_mrp) + ($New_start_index-1)),
                    array_values($request->product_mrp)); 
                $discount_percentage = array_combine(range($New_start_index,  count($request->discount_percentage) + ($New_start_index-1)), array_values($request->discount_percentage));
                $discount = array_combine(range($New_start_index,  count($request->discount) + ($New_start_index-1)),
                    array_values($request->discount)); 
                $amount = array_combine(range($New_start_index,  count($request->amount) + ($New_start_index-1)),
                    array_values($request->amount)); 
                
                Sale::where('sale_trnx_id',$invId)->delete();

                for($i=0; $i < $length; $i++)
                {  
                    $findProduct = Product::find($item_name[$i]);           

                    $newSale = new Sale;
                    $newSale->sale_order_date = Carbon::createFromFormat('d-m-Y', $request->order_date)->format('Y-m-d');            
                    $newSale->sale_trnx_id = $invId; 
                    $newSale->customer_id = $customerId;     
                    $newSale->item_name = Str::lower($item_name[$i]);
                    $newSale->unit_id = Str::lower($unit_id[$i]);  
                    $newSale->sale_qty = $qty[$i];                        
                    if($findProduct->primary_unit == $unit_id[$i])
                    {
                        $newSale->sale_primary_qty = $qty[$i];
                        $newSale->sale_secondary_qty = $qty[$i] * $findProduct->no_of_pcs;
                    }
                    if($findProduct->secondary_unit == $unit_id[$i])
                    {
                        $newSale->sale_primary_qty = (int)($qty[$i] / $findProduct->no_of_pcs);
                        $newSale->sale_secondary_qty = $qty[$i];
                    } 

                    $newSale->sale_unit_price = $product_mrp[$i];
                    $newSale->sale_primary_pp = $findProduct->primary_pp_for_stock;
                    $newSale->sale_secondary_pp = $findProduct->secondary_pp_for_stock;
                    $newSale->sale_discount_percentage = $discount_percentage[$i];
                    $newSale->sale_discount = $discount[$i];
                    $newSale->sale_amount = $amount[$i];
                    $newSale->sale_payment_type = Str::lower($request->payment_type);
                    $newSale->sale_delivery_charges = $request->delivery_charges;
                    $newSale->sale_round_off = $request->round_off;
                    $newSale->sale_gst_amount = $request->gst_amount;
                    $newSale->sale_total = $request->total;
                    $newSale->sale_received = $request->received;
                    $newSale->sale_balance = $request->balance;
                    $newSale->sale_prev_balance = $request->prev_balance;
                    $newSale->sale_remarks = $request->remarks;
                    if($request->received <= 0)
                    {
                        $newSale->sale_payment_status  = 0;
                    }
                    elseif($request->balance <= 0)
                    {
                        $newSale->sale_payment_status  = 2;           
                    }
                    else
                    {
                        $newSale->sale_payment_status  = 1;  
                    }
                    $newSale->sale_status = 0;
                    $newSale->save();
                } // for loop end

                $sales = Sale::leftJoin('products','sales.item_name','=','products.product_id')
                                ->leftJoin('customers','sales.customer_id','=','customers.customer_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units','sales.unit_id','=','units.unit_id')
                                ->select(array('sales.*','products.*','customers.*','units.*','brands.*'))
                                ->orderBy('sale_id','asc')
                                ->get();   
                $customers = Customer::orderBy('customer_id','DESC')->get();
                $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                            ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                            ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*'))
                            ->where('pro_type','Purchasing')->where('product_stat',1)
                            ->orderBy('product_id','DESC')
                            ->get();
                $success = array('success' => "Order updated successfully.", 'sales' => $sales, 'customers' => $customers, 'products' => $products);
                return response()->json($success);
                
            }
             
        }  
    }

    public function convert(Request $request)
    {
        if(request()->ajax())
        {
            $validator = \Validator::make($request->all(), [
                'order_date' => 'date',
                'delivery_date' => 'required|date|before:tomorrow|after_or_equal:order_date',     
                ],[
                'delivery_date.before' => 'The date mustbe today or before.',
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }
            if($validator->passes())
            {
                $data = Sale::where('sale_trnx_id',$request->sale_trnx_id)->where('sale_status',0)->get();
                $customerId = $data[0]['customer_id'];
                $deliveryDate = Carbon::createFromFormat('d-m-Y', $request->delivery_date)->format('Y-m-d');

                foreach($data as $d)
                {  
                    $findProduct = Product::find($d->item_name);     
                    if($findProduct->secondary_unit == $d->unit_id)
                    { 
                        $prevStockValue = $findProduct->stock_value;
                        $nowSecondaryQty = $findProduct->in_hand_stock_second - $d->sale_qty; 
                        $findProduct->stock_value = $nowSecondaryQty * $findProduct->secondary_pp_for_stock;
                        $findProduct->in_hand_stock_primary = (int)($nowSecondaryQty/$findProduct->no_of_pcs);
                        $findProduct->in_hand_stock_second = $nowSecondaryQty;
                    }
                    if($findProduct->primary_unit == $d->unit_id)
                    {
                        $prevStockValue = $findProduct->stock_value;
                        $nowSecondaryQty = $findProduct->in_hand_stock_second - ($findProduct->no_of_pcs * $d->sale_qty);
                        $findProduct->stock_value = $nowSecondaryQty * $findProduct->secondary_pp_for_stock;
                        $findProduct->in_hand_stock_primary = (int)($nowSecondaryQty/$findProduct->no_of_pcs);
                        $findProduct->in_hand_stock_second = $nowSecondaryQty;
                    }
                    $findProduct->update();

                    $newStock = New Stock;
                    $newStock->stock_type = 2;
                    $newStock->trnx_id  = $d->sale_trnx_id; 
                    $newStock->item_name  = Str::lower($d->item_name);
                    $newStock->customer_id  = $customerId;
                    $newStock->order_date  = $d->sale_order_date;
                    $newStock->delivery_date  = $deliveryDate;     
                    $newStock->qty = $d->sale_qty;     
                    if($findProduct->primary_unit == $d->unit_id)
                    {
                        $newStock->primary_qty =  $d->sale_qty;
                        $newStock->secondary_qty =  $d->sale_qty * $findProduct->no_of_pcs;
                    }
                    if($findProduct->secondary_unit == $d->unit_id)
                    {
                        $newStock->primary_qty = (int)( $d->sale_qty / $findProduct->no_of_pcs);
                        $newStock->secondary_qty =  $d->sale_qty;
                    } 
                    $newStock->unit_id  = Str::lower( $d->unit_id);
                    $newStock->unit_price  = $d->sale_unit_price - $d->sale_discount;
                    $newStock->amount  = -$d->sale_amount;
                    $newStock->delivered_qty  = $newStock->delivered_qty + $d->sale_qty;
                    $newStock->stock_stat  = $d->sale_payment_status;                   
                    $newStock->save();

                } // foreach loop end
                
                $findCustomer = Customer::find($customerId);
                $findCustomer->balance = $request->balance;
                $findCustomer->update();

                Sale::where('sale_trnx_id',$request->sale_trnx_id)->update(['sale_delivery_date' => $deliveryDate, 'sale_status' => 1]);

                $sales = Sale::leftJoin('products','sales.item_name','=','products.product_id')
                                ->leftJoin('customers','sales.customer_id','=','customers.customer_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units','sales.unit_id','=','units.unit_id')
                                ->select(array('sales.*','products.*','customers.*','units.*','brands.*'))
                                ->orderBy('sale_id','asc')
                                ->get();   
                $customers = Customer::orderBy('customer_id','DESC')->get();
                $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                            ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                            ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*'))
                            ->orderBy('product_id','DESC')
                            ->where('pro_type','Purchasing')->where('product_stat',1)
                            ->get();
                $success = array('success' => "New invoice saved successfully.", 'sales' => $sales, 'customers' => $customers, 'products' => $products);
                return response()->json($success);        
            }             
        }  
    }

    public function destroy(Request $request)
    {
        $invId = $request->id;


        $is_delete = Sale::where('sale_trnx_id',$invId)->delete();

       if($is_delete)
       {
            $sales = Sale::leftJoin('products','sales.item_name','=','products.product_id')
                                    ->leftJoin('customers','sales.customer_id','=','customers.customer_id')
                                    ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                    ->leftJoin('units','sales.unit_id','=','units.unit_id')
                                    ->select(array('sales.*','products.*','customers.*','units.*','brands.*'))
                                    ->orderBy('sale_id','asc')
                                    ->get();   
            $customers = Customer::orderBy('customer_id','DESC')->get();
            $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                        ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                        ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                        ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*'))
                        ->where('pro_type','Purchasing')->where('product_stat',1)
                        ->orderBy('product_id','DESC')
                        ->get();
            $success = array('success' => "Order deleted successfully.", 'sales' => $sales, 'customers' => $customers, 'products' => $products);
            return response()->json($success);
       }
    }

    public function dateRange()
    {
        $startDate = $_GET['startDate']; 
        $endDate = $_GET['endDate'];

        $sales = Sale::where('sale_order_date', '>=', $startDate)->where('sale_order_date', '<=', $endDate)->where('sale_status',0)->get()->unique('sale_trnx_id');
        $total = 0;
        foreach ($sales as $sale) {
            $total = $total+ $sale->sale_total;
        }
        return response()->json($total);
    }
     
}
