<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\BankAccount;
use App\Models\Portal\BankTransaction;
use Illuminate\Support\Str;
use Validator;
use Carbon\Carbon;

class BankTransactionController extends Controller
{
  public function __construct()
    {
        $this->middleware('auth');
    }
  public function b2cTransaction(Request $request)
  {
    if(request()->ajax())
    {
      $validator = \Validator::make($request->all(), [
        'date' => 'required|date|before:tomorrow',         
        'baccount_id' => 'required',
        'amount' => 'required|integer|not_in:0',
      ],[
        'date.before' => 'The date mustbe today or before.',
        'baccount_id.required' => 'Select an ccount.',
        'amount.not_in' => 'Enter amount.'
      ]);
      if ($validator->fails())         
      {
        return response()->json(['errors' => $validator->errors()]);
      }

      if($validator->passes())
      {
        $bankTrns = new BankTransaction;
        $bankTrns->bank_trnx_id = "BT-".(8000000000+strtotime("now"));
        $bankTrns->baccount_id = $request->baccount_id;
        $bankTrns->trnx_type = 1;
        $bankTrns->amount = -$request->amount;
        $bankTrns->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
        $bankTrns->remarks = $request->remarks;
        $is_save = $bankTrns->save();

        $bank = BankAccount::where('baccount_id',$request->baccount_id)->first();
        $bank->account_balance = $bank->account_balance - $request->amount;
        $bank->update();

        $bankaccounts = BankAccount::orderBy('baccount_id','desc')->get();
        $success = array('success' => 'Transaction save successfully.', 'bankaccounts' => $bankaccounts);
        return response()->json($success);
      }        
    }
  }

  public function c2bTransaction(Request $request)
  {
    if(request()->ajax())
    {
      $validator = \Validator::make($request->all(), [
        'date' => 'required|date|before:tomorrow',         
        'baccount_id' => 'required',
        'amount' => 'required|integer|not_in:0',
      ],[
          'date.before' => 'The date mustbe today or before.',
          'baccount_id.required' => 'Select an ccount.',
          'amount.not_in' => 'Enter amount.'
      ]);
      if ($validator->fails())         
      {
        return response()->json(['errors' => $validator->errors()]);
      }

      if($validator->passes())
      {
        $bankTrns = new BankTransaction;
        $bankTrns->bank_trnx_id = "BT-".(8000000000+strtotime("now"));
        $bankTrns->baccount_id = $request->baccount_id;
        $bankTrns->trnx_type = 2;
        $bankTrns->amount = $request->amount;
        $bankTrns->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
        $bankTrns->remarks = $request->remarks;
        $is_save = $bankTrns->save();


        $bank = BankAccount::where('baccount_id',$request->baccount_id)->first();
        $bank->account_balance = $bank->account_balance + $request->amount;
        $bank->update();

        $bankaccounts = BankAccount::orderBy('baccount_id','desc')->get();
        $success = array('success' => 'Transaction save successfully.', 'bankaccounts' => $bankaccounts);
        return response()->json($success);
      } 
    }
  }

  public function update(Request $request)
  {
    $validator = \Validator::make($request->all(), [
      'date' => 'required|date|before:tomorrow',     
      'amount' => 'required|integer|not_in:0',
    ],[
      'date.before' => 'The date mustbe today or before.',
      'amount.not_in' => 'Enter amount.'
    ]);
    if ($validator->fails())         
    {
      return response()->json(['errors' => $validator->errors()]);
    }

    if($validator->passes())
    {
      $bankTrns = BankTransaction::find($request->id);

      // b2c transaction
      if($bankTrns->trnx_type == 1)
      {
        $bankTrnsAmount = abs($bankTrns->amount);
        if($bankTrnsAmount < $request->amount)
        {
          $changingAmount = $request->amount - $bankTrnsAmount;
          $bank = BankAccount::where('baccount_id',$bankTrns->baccount_id)->first();
          $bank->account_balance = $bank->account_balance - $changingAmount;
          $bank->update();
        }
        if($bankTrnsAmount > $request->amount)
        {
          $changingAmount = $bankTrnsAmount - $request->amount;
          $bank = BankAccount::where('baccount_id',$bankTrns->baccount_id)->first();
          $bank->account_balance = $bank->account_balance + $changingAmount;
          $bank->update();
        }    

        $bankTrns->amount = -$request->amount;
        $bankTrns->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
        $bankTrns->remarks = $request->remarks;
        $bankTrns->update();    
      }

      // c2b transaction
      if($bankTrns->trnx_type == 2)
      {
        if($bankTrns->amount < $request->amount)
        {
          $changingAmount = $request->amount - $bankTrns->amount;
          $bank = BankAccount::where('baccount_id',$bankTrns->baccount_id)->first();
          $bank->account_balance = $bank->account_balance + $changingAmount;
          $bank->update();
        }
        if($bankTrns->amount > $request->amount)
        {
          $changingAmount = $bankTrns->amount - $request->amount;
          $bank = BankAccount::where('baccount_id',$bankTrns->baccount_id)->first();
          $bank->account_balance = $bank->account_balance - $changingAmount;
          $bank->update();
        }    
        $bankTrns->amount = $request->amount;
        $bankTrns->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
        $bankTrns->remarks = $request->remarks;
        $bankTrns->update();    
      }
      

      $bankaccounts = BankAccount::orderBy('baccount_id','desc')->get();
      $success = array('success' => 'Transaction updated successfully.', 'bankaccounts' => $bankaccounts);
      return response()->json($success);
    }
  }

  public function destroy(Request $request)
  {
    $bankTrns = BankTransaction::find($request->id);

    // b2c transaction
    if($bankTrns->trnx_type == 1)
    {
      $bank = BankAccount::where('baccount_id',$bankTrns->baccount_id)->first();
      $bank->account_balance = $bank->account_balance + abs($bankTrns->amount);
      $bank->update();     
    }
    // c2b transaction
    if($bankTrns->trnx_type == 2)
    { 
      $bank = BankAccount::where('baccount_id',$bankTrns->baccount_id)->first();
      $bank->account_balance = $bank->account_balance - $bankTrns->amount;
      $bank->update();
    }

    $is_delete = $bankTrns->delete();

    if($is_delete)
    {
      $bankaccounts = BankAccount::orderBy('baccount_id','desc')->get();
      $success = array('success' => 'Transaction updated successfully.', 'bankaccounts' => $bankaccounts);
      return response()->json($success);
    }
  }
}
