<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Category;
use Validator;

class CategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function create(Request $request)
    {
        if(request()->ajax())
        {
            $validator = \Validator::make($request->all(), [
               'category_name' => 'required|max:255|unique:categories,category_name'
            ]);
            if ($validator->fails())         
            {
               return response()->json(['errors' => $validator->errors()]);
            }

            $category = new Category;
            $category->category_name = $request->category_name;
            $category->category_stat = 1;
            $is_saved = $category->save();

            if($is_saved)
            {
                $success = array('success' => 'Category added successfully');
                return response()->json($success);
            }

        }
    }

    public function remove($category_id)
    {
        $category = Category::find($category_id);       
        $category->delete();
        $success = array('success' => 'Category deleted successfully');
        return response()->json($success);       
    }
}
