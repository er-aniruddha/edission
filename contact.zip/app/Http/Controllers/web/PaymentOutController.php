<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Stock;
use App\Models\Portal\PaymentOut;
use App\Models\Portal\Supplier;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;

class PaymentOutController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $payments = PaymentOut::leftJoin('suppliers','payment_outs.supplier_id','suppliers.supplier_id')
                            ->select(array('payment_outs.*','suppliers.*','payment_outs.balance'))
                            ->orderBy('payment_outs.date','desc')
                            ->get();
        $suppliers = Supplier::all();  

        if(request()->ajax())
        {
          return datatables()->of($payments)
                ->editColumn('date', function ($data) {
                    return date('d-m-Y', strtotime($data->date));
                })                       
                ->addColumn('action', function($data){                  
                    $action = '<div class="item-action dropdown">
                                    <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right bg-black" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                        <a class="dropdown-item view" id="'.$data->id.'" data-date="'.$data->date.'"
                                        data-paytrnxid="'.$data->payment_trnx_id.'" data-supplierid="'.$data->supplier_id.'" data-prevbal="'.$data->prev_balance.'" data-paid="'.$data->paid.'" data-balance="'.$data->balance.'" data-paymenttype="'.$data->payment_type.'" data-remarks="'.$data->remarks.'">See detail </a>
                                        <a class="dropdown-item edit" id="'.$data->id.'" data-date="'.$data->date.'"
                                        data-paytrnxid="'.$data->payment_trnx_id.'" data-supplierid="'.$data->supplier_id.'" data-prevbal="'.$data->prev_balance.'" data-paid="'.$data->paid.'" data-balance="'.$data->balance.'" data-paymenttype="'.$data->payment_type.'" data-remarks="'.$data->remarks.'">Edit</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item delete" id="'.$data->id.'" data-paytrnxid="'.$data->payment_trnx_id.'">Delete</a>
                                    </div>
                                </div>'; 
                  return $action;
                })
                ->addColumn('paymentType',function($data){
                    if( $data->payment_type == 1)
                    {
                        $paymentType = '<span class="text-sm text-capitalize">Cash</span>';  
                    }
                    elseif( $data->payment_type == 2)
                    {
                        $paymentType = '<span class="text-sm text-capitalize">Online</span>';  
                    }
                    else
                    {
                        $paymentType = '<span class="text-sm text-capitalize">Cheque</span>';  
                    }
                    return $paymentType;
                })
                ->addIndexColumn()    
                ->rawColumns(['action','paymentType'])                   
                ->make(true); 
        } 
        else{   
                         
            return view('portal.purchase_payment_out.index',['suppliers' => $suppliers]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        if($request->date)
        {
            $date = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
            $validator_date = \Validator::make($date, [
                'date' => 'required|date|before:tomorrow',         
            ],[
                'date.before' => 'The date mustbe today or before.',
                'date.unique' => 'Can not add two item on same date',
            ]);
            if ($validator_date->fails())         
            {
                return response()->json(['errors' => $validator_date->errors()]);
            }
        }

        $validator = \Validator::make($request->all(), [
            'supplier_id' => 'required|not_in:0',
            'date' => 'required|date|before:tomorrow',   
            'payment_type' => 'required|not_in:0',
            'paid' => 'required|not_in:0',
            ],[
              'date.before' => 'The date mustbe today or before.',                  
        ]);

        if ($validator->fails())         
        {
            return response()->json(['errors' => $validator->errors()]);
        }
        
        if($validator->passes())
        {
            $lastPaymentOut = PaymentOut::orderBy('created_at','DESC')->first();
            $newSale = new PaymentOut;
            $newSale->payment_trnx_id = strtotime("now"); 
            $newSale->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');            
            $newSale->supplier_id = $request->supplier_id;
            $newSale->paid = $request->paid;
            $newSale->balance = $request->balance;
            $newSale->prev_balance = $request->prev_balance;
            $newSale->payment_type = $request->payment_type;
            $newSale->remarks = Str::lower($request->remarks);                
            $newSale->save();

            $findCustomer = Supplier::find($request->supplier_id);
            $findCustomer->balance = $request->balance;
            $findCustomer->update();
        }
            
        $suppliers = Supplier::all(); 
        $success = array('success' => "Payment save successfully.", 'suppliers' => $suppliers);
        return response()->json($success);       
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $thisPayment = PaymentOut::find($request->id); // this is require bcs #s_id disabled  
        $thisValue = PaymentOut::where('supplier_id',"=",$thisPayment->supplier_id)->whereDate('date','>', $thisPayment->date)->count();

        if($thisValue > 0)
        {
            $errors = array('errors'=> array('trnx_error' => array('0'=>"This supplier has payment transaction, after this date.")));
            return response()->json($errors);
        }
        else
        {     

            $validator = \Validator::make($request->all(), [ 
                'payment_type' => 'required|not_in:0',
                'paid' => 'required|not_in:0',
            ]);

            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }
            
            if($validator->passes())
            {              
                
                $thisPayment->paid = $request->paid;
                $thisPayment->balance = $request->balance;
                $thisPayment->payment_type = $request->payment_type;
                $thisPayment->remarks = Str::lower($request->remarks);                    
                $thisPayment->update();

                $findCustomer = Supplier::find($thisPayment->supplier_id);
                $findCustomer->balance = $request->balance;
                $findCustomer->update();
            }
                
            $suppliers = Supplier::all(); 

            $success = array('success' => "Payment save successfully.", 'suppliers' => $suppliers);
            return response()->json($success);       
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $thisPayment = PaymentOut::find($request->id); // this is require bcs #s_id disabled  
        $thisValue = PaymentOut::where('supplier_id',"=",$thisPayment->supplier_id)->whereDate('date','>', $thisPayment->date)->count();

        if($thisValue > 0)
        {
            $error = array('error' => "Supplier has more transaction, after this date.");
            return response()->json($error);
        }
        else
        {
            $findCustomer = Supplier::find($thisPayment->supplier_id);
            $findCustomer->balance = $findCustomer->balance + $thisPayment->paid;
            $findCustomer->update();

            $thisPayment->delete();

            $suppliers = Supplier::all(); 
            $success = array('success' => 'Payment deleted successfully', 'suppliers' => $suppliers);
            return response()->json($success); 
        }
    }
}
