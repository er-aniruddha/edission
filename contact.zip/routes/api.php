<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\api\AuthController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

/*
|--------------------------------------------------------------------------
| Product and website content routes are here
|--------------------------------------------------------------------------|
*/

//Auth related routes are here
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

Route::group(['middleware' => 'auth:api'], function() {
	    Route::get('/logout', [AuthController::class, 'logout']);
		Route::get('/profile', [AuthController::class, 'details']);
	});

// Route::post('/password_reset', [LoginController::class, 'password_reset']);
// Route::post('/mlogin', 'api\LoginController@mlogin');
// Route::post('/plogin', 'api\LoginController@plogin');	

// Route::group(['middleware' => 'auth:delivery-api'], function() {
//     Route::get('/logout', 'api\LoginController@logout');
//     Route::get('/details', 'api\LoginController@details');
//     Route::post('/reset', 'api\LoginController@reset');
//     Route::post('/user/profile/img/upload', 'api\LoginController@profileImg');
// });
//Auth related routes end here

