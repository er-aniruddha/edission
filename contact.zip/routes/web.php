<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\Portal\BrandController;
use App\Http\Controllers\Portal\ProductController;
use App\Http\Controllers\Portal\ProductionCostController;
use App\Http\Controllers\Portal\SaleController;
use App\Http\Controllers\Portal\PaymentController;
use App\Http\Controllers\Portal\StockController;
use App\Http\Controllers\Portal\UserAccessController;
use App\Http\Controllers\Portal\CategoryController;
use App\Http\Controllers\Portal\CustomerController;
use App\Http\Controllers\Portal\RoutesController;
use App\Http\Controllers\Portal\PurchaseController;
use App\Http\Controllers\Portal\CalenderController;
use App\Http\Controllers\Portal\ExpenseController;
use App\Http\Controllers\Portal\UnitController;
use App\Http\Controllers\Portal\PurchaseOrderController;
use App\Http\Controllers\Portal\PurchaseBillController;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group whic
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect()->route('dashboard');
});
Route::group(['middleware' => 'prevent-back-history'],function(){
    Auth::routes(['verify' => true]);
    Route::get('/dashboard', [HomeController::class, 'index'])->middleware('verified')->name('dashboard');
});
//Error page or Page not found
Route::get('/error',[HomeController::class, 'error'])->name('error');

//Brands Routes are here
Route::get('/brands', [BrandController::class, 'index'])->name('brand.index');
Route::post('/brand/create', [BrandController::class, 'create'])->name('brand.create');
Route::post('/brand/update', [BrandController::class, 'update'])->name('brand.update');
Route::post('/brand/delete', [BrandController::class, 'destroy'])->name('brand.delete');
Route::get('/brand/status/{brand_id}', [BrandController::class, 'status'])->name('brand.status');

//Products Routes are here
Route::get('/products', [ProductController::class, 'index'])->name('product.index');
Route::get('/products/list', [ProductController::class, 'list'])->name('product.list');
Route::post('/product/create', [ProductController::class, 'create'])->name('product.create');
Route::post('/product/update', [ProductController::class, 'update'])->name('product.update');
Route::post('/product/delete', [ProductController::class, 'destroy'])->name('product.delete');
Route::get('/product/status/{product_id}', [ProductController::class, 'status'])->name('product.status');

//Sales Routes are here
Route::get('/sale/all', [SaleController::class, 'index'])->name('sale.index');
Route::post('/sale/new/create', [SaleController::class, 'create'])->name('sale.new.create');
Route::get('/sale/payments', [SaleController::class, 'paymentIndex'])->name('sale.payment.index');
Route::post('/sale/payment-in', [SaleController::class, 'payment_in'])->name('sale.payment.in');


//Purchase Order Routes are here
Route::get('/purchase/order', [PurchaseOrderController::class, 'index'])->name('purchase.order.index');
Route::post('/purchase/create', [PurchaseOrderController::class, 'create'])->name('purchase.order.create');
Route::post('/purchase/update', [PurchaseOrderController::class, 'update'])->name('purchase.order.update');
Route::post('/purchase/delete', [PurchaseOrderController::class, 'destroy'])->name('purchase.order.delete');
Route::post('/purchase/status', [PurchaseOrderController::class, 'status'])->name('purchase.order.status');

//Purchase Bill Routes are here
Route::get('/purchase/bill', [PurchaseBillController::class, 'index'])->name('purchase.bill.index');

//Brands Routes are here
Route::get('/cost', [ProductionCostController::class, 'index'])->name('productionCost.index');
Route::post('/cost/create', [ProductionCostController::class, 'create'])->name('cost.create');
Route::post('/cost/update', [ProductionCostController::class, 'update'])->name('cost.update');
Route::post('/cost/delete', [ProductionCostController::class, 'destroy'])->name('productionCost.delete');
Route::get('/cost/status/{cost_id}', [ProductionCostController::class, 'status'])->name('productionCost.status');

//SKU Code Routes are here
Route::get('/stock',[StockController::class, 'index'])->name('stock.index');
// Route::post('/stock/add/new',[StockController::class, 'createNew'])->name('stock.create.new');
// Route::post('/stock/update/existing',[StockController::class, 'updateExs'])->name('stock.update.exs');
// Route::match(['get','post'], '/stock/edit',[StockController::class, 'edit'])->name('stock.update');
// Route::post('/stock/view',[StockController::class, 'view'])->name('stock.view');
// Route::get('/stock/status/{stock_id}', [StockController::class, 'status'])->name('stock.status');
// Route::post('/stock/delete',[StockController::class, 'destroy'])->name('stock.delete');

//Purcahse Route are here
Route::get('/purchase',[PurchaseController::class, 'index'])->name('purchase.index');
Route::post('/purcahse/create',[PurchaseController::class, 'create'])->name('purchase.create');
Route::post('/purcahse/update',[PurchaseController::class, 'update'])->name('purchase.update');
Route::post('/purcahse/delete',[PurchaseController::class, 'destroy'])->name('purchase.delete');

//Expenses Route are here
Route::get('/expense',[ExpenseController::class, 'index'])->name('expense.index');
Route::post('/expense/create',[ExpenseController::class, 'create'])->name('expense.create');
Route::post('/expense/update',[ExpenseController::class, 'update'])->name('expense.update');
Route::post('/expense/delete',[ExpenseController::class, 'destroy'])->name('expense.delete');

//Add New Category Route
Route::post('/add/category', [CategoryController::class, 'create'])->name('category.create');
Route::get('/remove/category/{category_id}', [CategoryController::class, 'remove'])->name('category.remove');

//User Access Routes are here
Route::get('/users' , [UserAccessController::class, 'index'])->name('user.index');
Route::get('/user/profile' , [UserAccessController::class, 'profile'])->name('user.profile');
Route::post('/user/profile/update' , [UserAccessController::class, 'profileUpdate'])->name('user.profile.update');
Route::post('/user/chnage/permission' , [UserAccessController::class, 'chnagePermission'])->name('user.permission.chnage');
Route::post('/user/chnage/password' , [UserAccessController::class, 'chnagePassword'])->name('user.password.chnage');
Route::post('/user/remove', [UserAccessController::class, 'remove'])->name('user.remove');

//Add Customer Routes are here
Route::get('/customer/all',[CustomerController::class, 'all'])->name('customer.all');
Route::match(['get','post'], '/add/customer',[CustomerController::class, 'create'])->name('customer.create');
Route::post('/add/update/',[CustomerController::class, 'update'])->name('customer.update');
Route::get('/details/customer/{customer_id}',[CustomerController::class, 'details'])->name('customer.details');
Route::post('/details/customer/delete',[CustomerController::class, 'destroy'])->name('customer.delete');
		//Customer Routes 
Route::post('/routes/add',[CustomerController::class, 'createRoutes'])->name('routes.create');
Route::post('/routes/edit',[CustomerController::class, 'editRoutes'])->name('routes.update');
Route::post('/routes/planing',[CustomerController::class, 'editRoutes'])->name('routes.planing');
Route::get('/customer/payments/{customer_id}', [CustomerController::class, 'payments'])->name('customer.payments');
Route::get('/calender',[CalenderController::class, 'index'])->name('calender.index');


//Settings Routes are here
Route::get('/settings', function(){
    return view('portal.settings.index');
})->middleware('auth')->name('settings.index');

//Unit Routes are here
Route::get('/unit' , [UnitController::class, 'index'])->name('unit.index');
Route::post('/create' , [UnitController::class, 'create'])->name('unit.create');
Route::post('/update' , [UnitController::class, 'update'])->name('unit.update');
Route::post('/delete' , [UnitController::class, 'destroy'])->name('unit.delete');

Route::get('/clear-cache', function() {
    $exitCode = Artisan::call('config:cache');
    // return what you want
    
    dd($exitCode);
});