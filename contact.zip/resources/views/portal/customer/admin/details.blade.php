<div id="content" class="flex">
    <!-- ############ Main START-->
    <div class="d-flex flex fixed-content">
        @include('portal.customer.route_sidebar')
        <div class="d-flex flex" id="content-body">
            <div class="d-flex flex-column flex">
                <div class="p-3">
                    <div class="toolbar">
                        <a href="{{ route('customer.all')}}" class="btn btn-sm btn-white" data-pjax-state="">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left">
                                <line x1="19" y1="12" x2="5" y2="12"></line>
                                <polyline points="12 19 5 12 12 5"></polyline>
                            </svg>
                        </a>
                        <button class="btn btn-sm no-bg ml-auto" data-toggle="tooltip" data-original-title="Edit Customer">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
                                <path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"></path>
                                <polygon points="18 2 22 6 12 16 8 16 8 12 18 2"></polygon>
                            </svg>
                        </button>
                        <!-- <button data-toggle="modal" data-target="#content-aside" data-modal="" class="btn btn-sm btn-white d-md-none">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-menu">
                                <line x1="3" y1="12" x2="21" y2="12"></line>
                                <line x1="3" y1="6" x2="21" y2="6"></line>
                                <line x1="3" y1="18" x2="21" y2="18"></line>
                            </svg>
                        </button> -->
                    </div>
                </div>
                <div class="mx-3 mb-3 card customer-profile">
                    <div class="p-4 d-sm-flex no-shrink b-b profile-top">
                        <div>
                            <a href="#" class="w-96" data-pjax-state="">
                                <span class="w-96 avatar gd-info" style="height: 96px; font-size: 45px;">
                                    <img src="{{ asset(Auth::User()->user_img) }}" alt="{{ $customer->f_name[0] }}{{ $customer->s_name[0] }}" style="margin-bottom: 9px">
                                </span>
                            </a>
                        </div>
                        <div class="px-sm-4 flex" style="padding-right: 0px !important;">
                            <div>
                                <button class="btn btn-raised btn-wave mb-2 blue text-white" style="float: right;" id="paymentin" data-name="{{$customer->f_name}} {{$customer->s_name}}" data-balance="{{$customer->balance}}" data-cid="{{$customer->customer_id}}">Add Payment-In</button>
                                <h2 class="text-md">{{$customer->f_name}} {{$customer->s_name}}</h2>
                            </div>
                            <small class="d-block text-fade">{{$customer->shop_name}}</small>
                            <div class="my-3">
                                <a href="#" data-pjax-state="">
                                    <strong>561</strong>
                                    <span class="text-muted">Orders</span>
                                </a>
                                <a href="#" class="mx-2" data-pjax-state="">
                                    <strong>4,000</strong>
                                    <span class="text-muted">Delivered</span>
                                </a>
                                <a href="#" data-pjax-state="">
                                    <strong>500</strong>
                                    <span class="text-muted">Amount</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- table start -->
                    <div class="customer-profile-table">
                        <div class="card">
                            <div class="b-b">
                                <div class="nav-active-border b-primary bottom" style="float: left; padding-left: 1%; padding-top: 9px;">
                                    <span style="font-weight: 600; color: #535c78;">Transaction Table</span>
                                </div>
                                <div class="nav-active-border b-primary bottom" style="float: right;">
                                    <ul class="nav" id="myTab" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active cart" id="bill-tab" data-toggle="tab" href="#bill" role="tab" aria-controls="bill" aria-selected="true">Bills</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="payment-tab" data-toggle="tab" href="#payment" role="tab" aria-controls="payment" aria-selected="false">Payment</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="tab-content p-3">
                                <!-- Invoice Start -->
                                <div class="tab-pane fade active show" id="bill" role="tabpanel" aria-labelledby="bill-tab">
                                    <div class="table-responsive">
                                        <table class="table table-theme table-row v-middle" id="trnx_table" style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th style="width: 26px;"><span class="text-muted">#</span></th>
                                                    <th><span class="text-muted">Date</span></th>
                                                    <th><span class="text-muted">Invoice No</span></th>
                                                    <th><span class="text-muted">Payment Type</span></th>
                                                    <th><span class="text-muted">Amount</span></th>
                                                    <th><span class="text-muted">Prev. Due</span></th>
                                                    <th><span class="text-muted">Paid/Received</span></th>
                                                    <th><span class="text-muted">Balance Due</span></th>
                                                    <th style="width:50px"></th>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                    <!-- <div class="nocartproduct show">
                                        <div class="no-product-cart-banner">
                                            <div style="padding:20px;"><span class="text-dark">
                                                    <h5>No transaction</h5>
                                                </span></div>
                                        </div>
                                    </div> -->
                                </div>
                                <!-- Invoice End -->
                                <!-- Show Product Start -->
                                <div class="tab-pane fade" id="payment" role="tabpanel" aria-labelledby="payment-tab">
                                    <div class="table-responsive">
                                        <table class="table table-theme table-row v-middle" id="payments_table" style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th style="width: 26px;"><span class="text-muted">#</span></th>                                
                                                    <th><span class="text-muted">Date</span></th>
                                                    <th><span class="text-muted">Invoice No</span></th>
                                                    <th><span class="text-muted">Payment Type</span></th>
                                                    <th><span class="text-muted">Prev. Due</span></th>
                                                    <th><span class="text-muted">Received/Paid</span></th>
                                                    <th><span class="text-muted">Balance</span></th>
                                                    <th style="width:50px"></th>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </div>
                                <!-- Show Product end -->
                            </div>
                        </div>
                    </div>
                </div> <!-- customer profile end -->
            </div>
        </div>
    </div>
</div>
</div>
@include('portal.customer.editModal')
@include('portal.sale_payment_in.paymentModal')
</div>
<script>
// global app configuration object
var routes = {
    update: "{{ route('customer.update') }}",
    details: "{{ route('customer.details',$customer->customer_id) }}",
    payments: "{{ route('customer.payments',$customer->customer_id) }}",
    payment_in: "{{ route('sale.payment.in') }}",
};
</script>
<script type="text/javascript" src="{{asset('resources/js/customer/customer.all.js')}}"></script>
<script type="text/javascript" src="{{asset('resources/js/customer/details.js')}}"></script>
<script type="text/javascript">
// $(document).ready(function() {
    // $("#payments_table").DataTable({
    //     "scrollY":        "200px",
    //     "scrollCollapse": true,
    //     "paging":         true
    // })
    /* This script use for in details balde */
    // $("#payments_table").DataTable()

//     $("#orderTable").click(function() {
//         $(".feather-shopping-cart.orderTable, .feather-list").toggle()
//         $(".table-responsive, .invoice").toggle()
//         if ($('.feather-shopping-cart.orderTable').is(":visible")) {
//             $(this).attr('data-original-title', 'Orders');
//         } else {
//             $(this).attr('data-original-title', 'Table');
//         }
//     });
//     /* Above script use for in details balde */
//     $(document).on('click', "a.cart", function() {
//         if (window.allCartProducts.length == 0) {
//             $(".hascartproduct").hide()
//             $(".nocartproduct").show()
//         } else {
//             $(".nocartproduct").hide()
//             $(".hascartproduct").show()
//         }
// //     })
// });
</script>