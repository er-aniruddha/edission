<div id="content" class="flex">
    <!-- ############ Main START-->
    <div class="d-flex flex fixed-content">
        @include('portal.customer.route_sidebar')
        <div class="d-flex flex" id="content-body">
            <div class="d-flex flex-column flex" id="user-list">
                <div class="p-3">
                    <div class="toolbar">
                        <div class="btn-group">
                            <a  href="{{ route('customer.create')}}" class="btn btn-raised btn-wave blue text-white" data-toggle="tooltip"
                                data-original-title="Add Customer">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user-plus mx-2"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line>
                                </svg>
                            </a>
                        </div>
                        <form class="flex">
                            <div class="input-group">
                                <input type="text" class="form-control form-control-theme form-control-sm search" placeholder="Search" id="searchUser">
                                <span class="input-group-append">
                                    <button class="btn btn-white no-border btn-sm" type="button">
                                    <span class="d-flex text-muted">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round"
                                            class="feather feather-search">
                                            <circle cx="11" cy="11" r="8"></circle>
                                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                        </svg>
                                    </span>
                                    </button>
                                </span>
                            </div>
                        </form>
                        <button data-toggle="modal" data-target="#content-aside" data-modal="" class="btn btn-sm btn-icon btn-white d-md-none">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round" class="feather feather-menu"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line>
                            </svg>
                        </button>
                    </div>
                </div>
                <!-- User List Start -->
                <div class="scroll-y mx-3 mb-0 card">
                    <div class="list list-row" id="userList">
                        @foreach($customers as $customer)
                        <div class="list-item" style="visibility: visible; transform: none; opacity: 1; transition: transform 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0s, opacity 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0s;">
                            <div>
                                <label class="ui-check m-0">
                                    <input type="checkbox" name="id" value="3">
                                    <i></i>
                                </label>
                            </div>
                          <!--   <div>
                                <a href="#" data-toggle-class="">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                        fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round"
                                        class="feather feather-bookmark active-primary text-muted">
                                    <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
                                </svg>
                                </a>
                            </div> -->
                            <div class="flex">
                                <a href="{{route('customer.details',$customer->customer_id)}}" class="item-author">{{$customer->shop_name}}
                                    <span class="text-dark mr-2">({{$customer->f_name}} {{$customer->s_name}})</span>
                                </a>
                                <div class="item-mail text-muted h-1x d-none d-sm-block">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-phone"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                                    : {{$customer->phone_1}}
                                </div>
                                <!-- <div style="display: none;">{{$customer->route_name}}</div>  -->                               
                            </div>
                            <a class="btn btn-raised btn-wave btn-icon btn-rounded" href="tel:+91 {{$customer->phone_1}})">
                                <span class="nav-icon text-primary">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-phone"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                                </span>
                            </a>
                            <div> <!-- Vied,Edit -->
                                <div class="item-action dropdown">
                                    <a href="#" data-toggle="dropdown" class="text-muted">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"
                                            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                            class="feather feather-more-vertical">
                                            <circle cx="12" cy="12" r="1"></circle>
                                            <circle cx="12" cy="5" r="1"></circle>
                                            <circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" role="menu">
                                        <a class="dropdown-item view" href="{{route('customer.details',$customer->customer_id)}}">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>View
                                        </a>
                                        <a class="dropdown-item edit" data-id="{{$customer->customer_id}}" data-fname="{{$customer->f_name}}" 
                                            data-sname="{{$customer->s_name}}" data-shop="{{$customer->shop_name}}" data-phone1="{{$customer->phone_1}}" data-phone2="{{$customer->phone_2}}" data-whatsapp="{{$customer->whatsapp_no }}" data-email="{{$customer->email}}" data-route="{{$customer->route_id }}" data-locality="{{$customer->locality}}" data-district="{{$customer->district}}" data-pin="{{$customer->pin}}" data-addline1="{{$customer->addline_1}}" data-addline2="{{$customer->addline_2}}" data-toggle="modal" data-target="#editModal">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"></path><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"></polygon></svg>Edit
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <delete class="dropdown-item trash" data-id="{{$customer->customer_id}}" data-shop="{{$customer->shop_name}}">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>
                                            </svg>Delete
                                        </delete>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="dropdown-divider"></div>
                        @endforeach
                    </div>
                </div>
                
                <div class="px-3 py-3">
                    <div class="d-flex align-items-center">
                        <div class="flex d-flex flex-row">                            
                           
                        </div>
                        <div>
                            <span class="text-muted">Total:</span> 
                            <span id="count"></span>
                        </div>
                    </div>
                </div>


                <div class="no-result" style="display: none;">
                    <div class="p-4 text-center">No Results</div>
                </div>

            </div>

        </div>

    </div>

</div><!-- ############ Main END-->

@include('portal.layouts.deleteModal')
@include('portal.customer.editModal')
</div>
<script>
// global app configuration object
var routes = {
update: "{{ route('customer.update') }}",
delete: "{{ route('customer.delete') }}",
};

</script>
<script type="text/javascript" src="{{asset('resources/js/customer/customer.all.js')}}"></script>
