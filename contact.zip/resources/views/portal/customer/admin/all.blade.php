@section('page_title','All Customer List')
<div id="content" class="flex">
    <!-- ############ Main START-->
    <div class="d-flex flex fixed-content">
        @include('portal.customer.route_sidebar')
        <div class="d-flex flex">
            <div class="d-flex flex-column flex" id="user-list">
                <div class="p-3">
                    <div class="toolbar">
                        <div class="btn-group">
                            <a href="{{ route('customer.create')}}" class="btn btn-raised btn-wave blue text-white" data-toggle="tooltip" data-original-title="Add Customer">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user-plus mx-2">
                                    <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                    <circle cx="8.5" cy="7" r="4"></circle>
                                    <line x1="20" y1="8" x2="20" y2="14"></line>
                                    <line x1="23" y1="11" x2="17" y2="11"></line>
                                </svg>
                            </a>
                        </div>
                        <form class="flex">
                            <div class="input-group">
                                <input type="text" class="form-control form-control-theme form-control-sm search" placeholder="Search" id="searchUser">
                                <span class="input-group-append">
                                    <button class="btn btn-white no-border btn-sm" type="button">
                                        <span class="d-flex text-muted">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search">
                                                <circle cx="11" cy="11" r="8"></circle>
                                                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                            </svg>
                                        </span>
                                    </button>
                                </span>
                            </div>
                        </form>
                        <button data-toggle="modal" data-target="#content-aside" data-modal="" class="btn btn-sm btn-icon btn-white d-md-none">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-menu">
                                <line x1="3" y1="12" x2="21" y2="12"></line>
                                <line x1="3" y1="6" x2="21" y2="6"></line>
                                <line x1="3" y1="18" x2="21" y2="18"></line>
                            </svg>
                        </button>
                        <div class="">
                            <div class="dataTables_length" id="customer_table_length">
                                <select name="customer_table_length" aria-controls="customer_table" class="form-control form-control-theme form-control-sm paging">
                                    <option value="10">10</option>
                                    <option value="25">25</option>
                                    <option value="50">50</option>
                                    <option value="100">100</option>
                                    <option value="all">All</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- User List Start -->
                <div class="d-flex flex pr-md-3">
                    <div class="d-flex flex-column flex m-0 mb-md-3" id="chat-list">
                        <div class="table-responsive">
                            <table class="table table-theme table-row v-middle" id="customer_table">
                                <thead>
                                    <tr>
                                        <th style="width: 26px; text-align: center;"><span class="text-muted">#</span></th>
                                        <th><span class="text-muted">Customer Name</span></th>
                                        <th><span class="text-muted">Shop Name</span></th>
                                        <th><span class="text-muted">Location</span></th>
                                        <th><span class="text-muted">Phone</span></th>
                                        <th><span class="text-muted">What's App</span></th>
                                        <th><span class="text-muted">Balance</span></th>
                                        <th style="width:50px"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div><!-- ############ Main END-->
@include('portal.layouts.deleteModal')
@include('portal.customer.editModal')
</div>
<script>
// global app configuration object
var routes = {
    update: "{{ route('customer.update') }}",
    delete: "{{ route('customer.delete') }}",
    all: "{{ route('customer.all') }}",
};
var customer_routes = @json($routes);
var customers = @json($customers);
</script>
<script type="text/javascript" src="{{asset('resources/js/customer/customer.all.js')}}"></script>