<div class="fade aside aside-sm" id="content-aside">
	<div class="modal-dialog d-flex flex-column w-md bg-body" id="user-nav">
		<div class="navbar">
			<span class="text-md mx-2">Routes</span>
			<div class="dropdown dropright">
				<button data-toggle="dropdown" class="btn btn-sm btn-raised btn-wave purple" id="editRoute">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit route"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"></path><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"></polygon></svg>

					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="hide feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>
					</svg>
				</button>
				<button data-toggle="dropdown" class="btn btn-sm btn-raised btn-wave blue" id="showRouteInput">
					<svg xmlns="http://www.w3.org/2000/svg"
						width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
						stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
						class="feather feather-plus">
						<line x1="12" y1="5" x2="12" y2="19"></line>
						<line x1="5" y1="12" x2="19" y2="12"></line>
					</svg>
				</button>	

			</div>
		</div>
		<div class="scrollable hover">
			<div class="sidenav p-2">
				<nav class="nav-active-text-primary" id="routeList">
					<ul class="nav">
						@foreach($routes as $route)
						<li>
							<a href="javascript:void(0)" id="_routeSelect" data-name="{{$route->route_name}}">
								<span class="nav-text" style="width: 70%">{{$route->route_name}}</span>
								<span class="nav-badge">
								@php
									$i=0;
								@endphp
								@foreach($customers as $customer)
									@if($customer->route_id == $route->route_id)
										@php
											$i = $i+1;
										@endphp
									@endif
								@endforeach
								<b class="badge badge-sm badge-pill gd-info counter">{{$i}}</b></span>
								<button class="btn btn-sm hide thisRoute" data-id="{{$route->route_id}}" 
									data-name="{{$route->route_name}}">
									<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit-2"><polygon points="16 3 21 8 8 21 3 21 3 16 16 3"></polygon>
									</svg>
								</button>
							</a>
						</li>
						@endforeach
					</ul>
				</nav>
			</div>
			<div class="route-input">
				<div class="dropdown-menu w-lg show" style="width: 241px;">
					<div class="p-3">
						<div class="input-group">
							<form id="routeForm" method="POST">
								@csrf
								<span class="input-group-append">
									<input type="text" class="form-control routes" required="" id="route_name" name="route_name" placeholder="Route Name">											

									<input type="hidden" name="route_id" id="route_id">
									<button class="btn btn-white no-shadow btn-sm hide" id="addBtn">
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
									</button>
									<button class="btn btn-white no-shadow btn-sm hide" id="editBtn">
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-save mx-2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg>
									</button>
								</span>
							</form>
							<span class="text-danger mr-2" id="route_name_error"></span>	
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	var croutes = {
		create: "{{ route('routes.create') }}",
		update: "{{ route('routes.update') }}",
	}; 
</script>
<script type="text/javascript" src="{{asset('resources/js/customer/customer.sidebar.route.js')}}"></script>