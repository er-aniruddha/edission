<!-- Order COnfirm Modal Start -->
<div id="orderModal" class="modal fade show" data-backdrop="true" aria-modal="true">
    <div class="modal-dialog modal-bottom text-dark" style="height:70%;">
        <div class="modal-content" style="height:100%;">
            <div class="modal-header bg-primary">
                <div class="modal-title text-white"></div>                
            </div>
            <div class="modal-body">
                <form id="selectSkuForm">                        
                    <div class="form-group" style="margin-bottom:10px;">
                        <label class="text-muted">Date</label>
                        <input data-provide="datepicker" id="date" name="date" type="text" class="form-control date" placeholder="Date">
                        <span class="text-danger" id="date_error"></span>
                    </div>                           
                    <table class="table-bordered table table-theme table-row v-middle" id="cartInputTable">
                        <thead>
                            <tr>
                                <th>SL No</th>
                                <th style="width:52%;">SKU</th>
                                <th style="width:30%">Quantity</th>                               
                                <th >
                                    <a href="javascript:void(0)" class="addRow">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
                                    </a>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="row_0">
                                <td >                                
                                   1
                                </td>
                                <td>
                                    <select class="form-control custom-select stockId" name="stock_id[0]" id="stock_id_0">
                                       <option>Select an option</option>   
                                    </select>
                                </td>
                                <td>                                
                                   <input type="number" class="form-control qty" name="qty[0]" id="qty" 
                                   autocorrect="off" autofocus="autofocus" autocomplete="off" animate="true" autocomplete="off" 
                                   autocapitalize="off" spellcheck="false" placeholder="Quantity" min="1"
                                   oninput="this.value = Math.round(this.value);">
                                </td>                            
                                 <td >
                                                                    
                                </td>
                            </tr>
                        </tbody> 
                    </table>  
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-dark btn-block" id="cancelSkuBtn" >Cancel</button> 
                <button type="button" class="btn red btn-block" style="margin-bottom:8px;" id="addSkuBtn">Add to cart</button>
            </div>
            </form>
        </div>
        <!-- /.modal-content -->
    </div>
</div>
<!-- Order COnfirm Modal End -->