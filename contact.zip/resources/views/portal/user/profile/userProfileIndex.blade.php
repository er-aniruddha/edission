@extends('portal.layouts.main')

@section('content')

    @switch (Auth::User()->user_permission) 

        @case ('1' || '2')
            @include('portal.user.profile.userProfile')
        @break

        @default
            @include('portal.layouts.blocked')
        @break

    @endswitch

@endsection