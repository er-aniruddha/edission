<div id="modal" class="modal fade show" aria-modal="true">
    <div class="modal-dialog text-dark modal-lg" style="max-width: 95%;">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white"></h5>                
            </div>
            <div class="modal-body p-4">
                <form id="purchaseOrderForm" method="POST">
                    @csrf
                    <div class="form-group row mb-3" style="float: left;">
                        <label class="col-sm-2 col-form-label">Party</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="party_id" id="party_id">
                                <option value="" selected="">Select Party</option>
                                <option value="1">Croma</option>
                                <option value="2">marc</option>

                            </select>
                            <span class="text-danger" id="party_id_error"></span>
                        </div>
                            
                    </div>
                    <div class="form-group row mb-3" style="float: right;">
                        <label class="col-sm-3 col-form-label text-dark">Date</label>
                        <div class="col-sm-9">
                            <input data-provide="datepicker" id="date" name="date" type="text" class="form-control date" placeholder="Date">
                            <span class="text-danger" id="date_error"></span>
                        </div>
                    </div>
                    <table class="table-bordered table table-theme table-row v-middle" id="tdFormRow">
                        <thead>
                            <tr>
                                <th style="width: 40%;">Item Name</th>
                                <th style="width: 10%;">Unit Name/Primary Unit</th>
                                <th style="width: 10%;">Quantity</th>
                                <th style="width: 20%;">Unit Price</th>
                                <th style="width: 20%;">Amount</th>
                                <th>
                                    <a href="javascript:void(0)" class="addRow">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
                                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                            <line x1="12" y1="8" x2="12" y2="16"></line>
                                            <line x1="8" y1="12" x2="16" y2="12"></line>
                                        </svg>
                                    </a>
                                </th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group mb-3">
                                <label class="text-muted">Payment Type</label>
                                <select class="form-control col-sm-8" name="payment_type" id="payment_type" tabindex="-1" aria-hidden="true">
                                    <option value="" selected="">Select an option</option>
                                    <option value="cash">Cash</option>
                                    <option value="online">Online</option>
                                </select>
                                <span class="text-danger" id="payment_type_error"></span>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Remarks</label>
                                <div class="col-sm-9">
                                    <textarea id="remarks" name="remarks" class="form-control" rows="3"></textarea>
                                    <span class="text-danger" id="remarks_error"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4" style="left: 50%;">
                            <div class="input-group mb-3" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">Round Off</span>
                                </div>
                                <input type="number" class="form-control" placeholder="0.00" name="round_off" id="round_off" value="0.00" >
                            </div>
                            <div class="input-group mb-3" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">GST Amount</span>
                                </div>
                                <input type="number" class="form-control" min="0" placeholder="0.00" name="gst_amount" id="gst_amount" value="0.00" >
                            </div>
                            <div class="input-group mb-3" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">Total</span>
                                </div>
                                <input type="number" class="form-control total" min="0" placeholder="0.00" name="total" id="total"  value="0.00" readonly="">
                            </div>
                            <div class="input-group mb-3" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">Advance</span>
                                </div>
                                <input type="number" class="form-control advance" min="0" placeholder="0.00" name="advance" id="advance" value="0.00" >
                            </div>
                            <div class="input-group mb-3" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">Balance</span>
                                </div>
                                <input type="number" class="form-control" min="0" placeholder="0.00" name="balance" id="balance"  value="0.00" readonly="">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="po_id" id="po_id">                        
                        <button class="btn btn-outline-dark" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" id="addBtn">Save Changes</button>
                        <button type="submit" class="btn btn-warning text-uppercase hide" id="convertPOBtn">convert to puchase</button>
                        <button type="submit" class="btn btn-primary hide" id="editBtn">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.modal-content -->
</div>