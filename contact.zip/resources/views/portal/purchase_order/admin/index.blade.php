<div id="content" class="flex">
    <div class="page-hero" id="page-hero">
        <div class="padding d-flex">
            <div class="page-title">
                <h2 class="text-md text-highlight">All Expenses</h2>
                <!-- <small class="text-muted">Products</small> -->
            </div>
            <div class="flex"></div>
            <div>
                <button class="btn btn-raised btn-wave blue text-white add" data-toggle="modal" data-target="#modal">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus">
                        <line x1="12" y1="5" x2="12" y2="19"></line>
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                    </svg>
                    Add
                </button>
                <button class="btn btn-raised btn-wave btn-outline-primary" data-toggle="dropdown">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-download-cloud">
                        <polyline points="8 17 12 21 16 17"></polyline>
                        <line x1="12" y1="12" x2="12" y2="21"></line>
                        <path d="M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29"></path>
                    </svg>
                    Export
                </button>
                <div class="dropdown-menu" role="menu" x-placement="bottom-start">
                    <a class="dropdown-item export" id=".buttons-csv">
                        <i class="badge badge-circle text-primary"></i> CSV
                    </a>
                    <a class="dropdown-item export" id=".buttons-excel">
                        <i class="badge badge-circle text-primary"></i> EXCEL
                    </a>
                    <a class="dropdown-item export" id=".buttons-pdf">
                        <i class="badge badge-circle text-primary"></i> PDF
                    </a>
                    <a class="dropdown-item export" id=".buttons-print">
                        <i class="badge badge-circle text-primary"></i> Print
                    </a>
                </div>
                <!-- <div class="input-group input-daterange">
                        <input type="text" class="form-control" value="2012-04-05">
                        <div class="input-group-addon">to</div>
                        <input type="text" class="form-control" value="2012-04-19">
                    </div>  -->
            </div>
        </div>
    </div>
    <div class="page-content" id="page-content">
        <div class="padding">
            <!-- <div class="col-md-4">
                <div class="input-group input-daterange mb-3">
                    <input type="text" class="form-control date-range-filter" data-date-format="dd-mm-yyyy" id="min-date">
                    <div class="input-group-prepend">
                        <span class="input-group-text">to</span>
                    </div>
                    <input type="text" class="form-control date-range-filter" data-date-format="dd-mm-yyyy" id="max-date">
                </div>
            </div> -->
            <div class="table-responsive">
                <table id="purchase_order_table" class="table table-theme table-row v-middle">
                    <thead>
                        <tr>
                            <th style="width: 26px;"><span class="text-muted">SL No</span></th>
                            <th><span class="text-muted">PO Id</span></th>
                            <th style="width: 50px;"><span class="text-muted">Date</span></th>
                            <th><span class="text-muted">Party</span></th>
                            <th><span class="text-muted">Total Amount</span></th>
                            <th><span class="text-muted">Advance Payment</span></th>
                            <th><span class="text-muted">Balance</span></th>
                            <th><span class="text-muted">Status</span></th>
                            <th style="width: 16%;"><span class="text-muted">Action</span></th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>
@include('portal.purchase_order.modal')
@include('portal.layouts.deleteModal')
</div>
<script>
// global app configuration object
var routes = {
    index: "{{ route('purchase.order.index') }}",
    create: "{{ route('purchase.order.create') }}",
    // update: "{{ route('expense.update') }}",
    // delete: "{{ route('expense.delete') }}",
};
// All the vaiables are required for exsModal Start
var purchaseOrder = @json($purchaseOrder);
var productsObj = @json($products);
var products = Object.keys(productsObj).map((key) => [Number(key), productsObj[key]]);
var unitsObj = @json($units);
var units = Object.keys(unitsObj).map((key) => [Number(key), unitsObj[key]]);
// All the vaiables are required for end
</script>
<script type="text/javascript" src="{{asset('resources/js/purchaseOrder.js')}}"></script>