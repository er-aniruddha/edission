@extends('portal.layouts.main')
@section('content')

<div id="modal-backdrop-dark" class="modal bg-dark fade show" data-backdrop="false" style="display: block;" aria-modal="true">
    <div class="modal-dialog modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <div class="p-4 text-center">
                    <p>Woohoo, you're not authorized to access this page !!!</p>
                    <a href="#" class="b-b b-white">Contact to Admin</a>
                </div>
            </div>                
            <a class="btn btn-primary btn-block" href="http://localhost/anwesh/portal/logout" onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">Sign Out</a>

            <form id="logout-form" action="http://localhost/anwesh/portal/logout" method="POST" class="d-none">
                <input type="hidden" name="_token" value="t0vgPHfqfEso75JjkPw87xjT35fMUIf8FU5DY4jt">            </form>
        </div><!-- /.modal-content -->
    </div>
</div>

@endsection
 
