<!-- Sidebar START-->
<div id="aside" class="page-sidenav no-shrink bg-light nav-dropdown fade sticky" aria-hidden="true" data-class="bg-light">
	<div class="sidenav h-100 modal-dialog bg-light">
		<!-- sidenav top -->
		<div class="navbar">
			<!-- brand -->
			<a href="{{route('dashboard')}}" class="navbar-brand" data-pjax-state="">
				<img src="{{asset('public/portal/images/logo-01.png')}}" alt="...">
				<span class="hidden-folded d-inline l-s-n-1x">United Enterprise</span> 
			</a>
		<!-- / brand -->
	</div>
	<!-- Flex nav content -->
	<div class="flex scrollable hover">
		<div class="nav-stacked nav-active-primary auto-nav nav-active-text-primary nav-border b-primary" data-nav="">
			<ul class="nav">
				<li class="{{Route::is('dashboard') ? 'active' : null}}">
					<a href="{{route('dashboard')}}" data-pjax-state="load">
						<span class="nav-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather eather-home">
								<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
								<polyline points="9 22 9 12 15 12 15 22"></polyline>
							</svg>
						</span> 
						<span class="nav-text">Dashboard</span>
					</a>
				</li>				
				<li class="{{Route::is('customer.index') || Route::is('customer.all') || Route::is('customer.create') || Route::is('customer.details')? 'active' : null}}">
					<a href="javascript:void(0);" data-pjax-state="load">
						<span class="nav-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
						</span> 
						<span class="nav-text">Customers</span>
					</a>

					<ul class="nav-sub nav-mega">
					    <li class="{{Route::is('customer.create')? 'active' : null}}">
					    	<a href="{{ route('customer.create')}}" class="" data-pjax-state="load">
					    		<span class="nav-text">Add Customer</span>
					    	</a>
					    </li>
					    <li class="{{Route::is('customer.all') || Route::is('customer.details')? 'active' : null}}">
					    	<a href="{{route('customer.all')}}" class="" data-pjax-state="load">
					    		<span class="nav-text">All Customer</span>
					    	</a>
					    </li>					   
					</ul>
				</li>
				<li class="{{Route::is('brand.index') || Route::is('product.index') || Route::is('productionCost.index')? 'active' : null}}">
					<a href="javascript:void(0)" data-pjax-state="load">
						<span class="nav-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-package"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line><line x1="7" y1="3.5" x2="17" y2="8.5"></line></svg>
						</span> 
						<span class="nav-text">Products</span>
					</a>

					<ul class="nav-sub nav-mega">
					    <li class="{{Route::is('brand.index')? 'active' : null}}">
					    	<a href="{{ route('brand.index')}}" class="" data-pjax-state="load">
					    		<span class="nav-text">Brand</span>
					    	</a>
					    </li>
					    <li class="{{Route::is('product.index') ? 'active' : null}}">
					    	<a href="{{ route('product.index')}}" class="" data-pjax-state="load">
					    		<span class="nav-text">Products</span>
					    	</a>
					    </li>					   			    					   
					</ul>
				</li>
				<li class="{{Route::is('sale.index') || Route::is('sale.order.index') || Route::is('payment.in.index') || Route::is('credit.note.index') ? 'active' : null}}">
					<a href="javascript:void(0)" data-pjax-state="load">
						<span class="nav-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file mx-2"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
						</span> 
						<span class="nav-text">Sale</span>
					</a>
					<ul class="nav-sub nav-mega">
					    <li class="{{Route::is('sale.index')? 'active' : null}}">
					    	<a href="{{route('sale.index')}}" class="" data-pjax-state="load">
					    		<span class="nav-text">All Sale</span>
					    	</a>
					    </li>	
					    <li class="{{Route::is('sale.order.index')? 'active' : null}}">
					    	<a href="{{route('sale.order.index')}}" class="" data-pjax-state="load">
					    		<span class="nav-text">Sale Order</span>
					    	</a>
					    </li>
					    <li class="{{Route::is('payment.in.index')? 'active' : null}}">
					    	<a href="{{route('payment.in.index')}}" class="" data-pjax-state="load">
					    		<span class="nav-text">Payment-In</span>
					    	</a>
					    </li>
					    <li class="{{Route::is('credit.note.index')? 'active' : null}}">
					    	<a href="{{route('credit.note.index')}}" class="" data-pjax-state="load">
					    		<span class="nav-text">Sale Return/ Cr. Note</span>
					    	</a>
					    </li>
					</ul>
				</li>	
				<li class="{{Route::is('purchase.index') || Route::is('purchase.order.index') || Route::is('purchase.bill.index') || Route::is('supplier.index') || Route::is('payment.out.index') ? 'active' : null}}">
					<a href="javascript:void(0)" data-pjax-state="load">
						<span class="nav-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-cart mx-2"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
						</span> 
						<span class="nav-text">Purchase</span>
					</a>
					<ul class="nav-sub nav-mega">
					    <li class="{{Route::is('purchase.index')? 'active' : null}}">
					    	<a href="{{route('purchase.index')}}" class="" data-pjax-state="load">
					    		<span class="nav-text">All Purchase</span>
					    	</a>
					    </li>	
					    <li class="{{Route::is('purchase.order.index')? 'active' : null}}">
					    	<a href="{{route('purchase.order.index')}}" class="" data-pjax-state="load">
					    		<span class="nav-text">Purchase Order</span>
					    	</a>
					    </li>
					    <li class="">
					    	<a href="{{route('payment.out.index')}}" class="" data-pjax-state="load">
					    		<span class="nav-text">Payment-Out</span>
					    	</a>
					    </li>					    			   
					    <li class="">
					    	<a href="{{route('coming.soon')}}" class="" data-pjax-state="load">
					    		<span class="nav-text">Purchase Return\ Dr. Note</span>
					    	</a>
					    </li>
					    <li class="">
					    	<a href="{{route('supplier.index')}}" class="" data-pjax-state="load">
					    		<span class="nav-text">Supplier</span>
					    	</a>
					    </li>
					</ul>
				</li>				
				<li class="{{ Route::is('stock.index') ? 'active' : null }}">
					<a href="{{ route('stock.index') }}" data-pjax-state="load">
						<span class="nav-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-layers"><polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline></svg>
						</span> 
						<span class="nav-text">Inventory</span>
					</a>					
				</li>
				<li class="{{Route::is('expense.index') ? 'active' : null}}">
					<a href="{{ route('expense.index') }}" data-pjax-state="load">
						<span class="nav-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-dollar-sign"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
						</span> 
						<span class="nav-text">Expenses</span>
					</a>
				</li>
				<li class="{{Route::is('bank.index') || Route::is('loan.account.index')? 'active' : null}}">
					<a href="javascript:void(0)" data-pjax-state="load">
						<span class="nav-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home mx-2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
						</span> 
						<span class="nav-text">Cash & Bank</span>
					</a>
					<ul class="nav-sub nav-mega">
					    <li class="#">
					    	<a href="{{route('bank.index')}}" class="" data-pjax-state="load">
					    		<span class="nav-text">Bank Account</span>
					    	</a>
					    </li>	
					    <li class="#">
					    	<a href="{{route('loan.account.index')}}" class="" data-pjax-state="load">
					    		<span class="nav-text">Loan Accounts</span>
					    	</a>
					    </li>	
					</ul>
				</li>
				<li class="{{Route::is('user.index') ? 'active' : null}}">
					<a href="{{ route('user.index') }}" data-pjax-state="load">
						<span class="nav-icon text-success">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
							</svg>
							
						</span> 
						<span class="nav-text">Users</span>
					</a>
				</li>
				<li class="{{ Route::is('settings.index') || Route::is('unit.index') ? 'active' : null}}">
					<a href="{{ route('settings.index') }}" data-pjax-state="load">
						<span class="nav-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-settings mx-2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
						</span> 
						<span class="nav-text">Settings</span>
					</a>
				</li>
			</ul>

		</div>
	</div>
	<!-- sidenav bottom -->
</div>
</div>
    <!-- Sidebar END-->