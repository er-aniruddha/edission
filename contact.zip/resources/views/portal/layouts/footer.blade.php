 	<!-- ############ Footer START-->
        <!-- <div class="page-footer">
            <div class="d-flex p-3"><span class="text-sm text-muted flex">© Copyright. Omnipresence Overseas</span>
                <div class="text-sm text-muted">Version 1.0</div>
            </div>
        </div> -->
        <!-- ############ Footer END-->
        <snackbar></snackbar>
    <script src="{{asset('public/portal/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('public/portal/js/parsley.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('public/portal/js/list.js')}}"></script>      
    <script type="text/javascript" src="{{asset('public/portal/js/user.js')}}"></script>  
    <!-- DataTables JavaScript -->
    <script type="text/javascript" src="{{asset('public/portal/dataTables/jquery.dataTables.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('public/portal/dataTables/dataTables.bootstrap4.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('public/portal/dataTables/dataTables.buttons.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('public/portal/dataTables/jszip.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('public/portal/dataTables/pdfmake.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('public/portal/dataTables/vfs_fonts.js')}}"></script>
    <script type="text/javascript" src="{{asset('public/portal/dataTables/buttons.html5.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('public/portal/dataTables/buttons.print.min.js')}}"></script>
    <!-- <script type="text/javascript" src="https://cdn.datatables.net/plug-ins/1.10.24/filtering/row-based/range_dates.js"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/list.js/1.5.0/list.min.js"></script> -->
    <!-- Select2 JavaScript -->
    <script type="text/javascript" src="{{asset('public/portal/js/select2.min.js')}}"></script>
    <!-- Datepicker JavaScript -->
    <script type="text/javascript" src="{{asset('public/portal/js/bootstrap-datepicker.min.js')}}"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.js"></script> -->
    <script type="text/javascript" src="{{asset('public/portal/js/moment-with-locales.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('public/portal/js/fullcalendar.min.js')}}"></script>
    <script>
    // In your Javascript (external .js resource or <script> tag)
    $("#image").change(function(){
        readURL(this);
    });  
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#show-img').attr('src', e.target.result);
            };
            reader.readAsDataURL(input.files[0]);
        }
    } 
    //showing successfull message
    function snacbar(data){
        let message = data;
        let snackbar  = new SnackBar;
        snackbar.make("message",
        [
            data,
            null,
            "bottom",
            "center"
        ], 4000);
    }
    $('form').on('focus', 'input[type=number]', function (e) {
        $(this).on('wheel.disableScroll', function (e) {
            e.preventDefault()
        })
    })
    </script>
  
</body>

</html>