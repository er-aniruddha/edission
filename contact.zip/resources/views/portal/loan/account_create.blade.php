<div id="loanAccountModal" class="modal fade show"  aria-modal="true">
    <div class="modal-dialog text-dark">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white text-capitalize"></h5><button class="close" data-dismiss="modal">×</button>
            </div>
            <div class="modal-body">
                <form id="loanForm" method="POST">  
                    @csrf  
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Account Name</label>
                        <div class="col-sm-9">
                            <input id="account_name" name="account_name" type="text" class="form-control text-capitalize" placeholder="Diplay A/C name">
                            <span class="text-danger" id="account_name_error"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Loan Amount</label>
                        <div class="col-sm-9">
                            <input id="loan_amount" name="loan_amount" type="number" class="form-control" placeholder="Loan Amount">
                            <span class="text-danger" id="loan_amount_error"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Interest Rate %</label>
                        <div class="col-sm-9">
                            <input id="interest_rate" name="interest_rate" type="number" class="form-control" placeholder="Interest Rate" >
                            <span class="text-danger" id="interest_rate_error"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Tenure</label>
                        <div class="col-sm-9">
                            <div class="row">
                            	<div class="col-sm-6">
                            		<input id="year" name="year" type="number" class="form-control" placeholder="Year" oninput="this.value = Math.round(this.value);" minlength="1" min="1">
                            	</div>
                            	<div class="col-sm-6">
                            		<input id="month" name="month" type="number" class="form-control" placeholder="Month" oninput="this.value = Math.round(this.value);">
                            	</div>
                            </div>
                            <span class="text-danger" id="tenure_error"></span>
                        </div>                       
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Date</label>
                        <div class="col-sm-9">
                            <input data-provide="datepicker" id="date" name="date" type="text" class="form-control date" placeholder="Date">
                            <span class="text-danger" id="date_error"></span>
                        </div>                        
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Remarks</label>
                        <div class="col-sm-9">
                            <input id="remarks" name="remarks" type="text" class="form-control" placeholder="Remarks">
                        </div>                        
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="loanAc_id" id="loanAc_id"/>
                        <button class="btn gd-primary text-white btn-rounded" id="addBtn">Save</button>
                        <button class="btn gd-warning text-white btn-rounded hide" id="editBtn">Update</button>
                    </div>   
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
</div>