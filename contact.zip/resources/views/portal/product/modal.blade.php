<div id="modal" class="modal fade" data-backdrop="true" style="display: none; padding-right: 17px;" aria-modal="true">
    <div class="modal-dialog">
        <div class="modal-content box-shadow mb-4">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white"></h5>
            </div>
            <div class="modal-body p-4">
                <form id="productForm" method="POST">
                    @csrf
                    <div class="form-group mb-3">
                        <label class="text-muted">Product Name</label>
                        <input type="text" class="form-control" name="product_name" id="product_name" placeholder="Product Name">
                        <span class="text-danger" id="product_name_error"></span>
                    </div>
                    <div class="form-group mb-3">
                        <label class="text-muted">Product Description</label>
                        <input type="text" class="form-control" id="product_desc" name="product_desc" placeholder="Product description">
                        <span class="text-danger" id="product_desc_error"></span>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="text-muted">Brand</label>
                                <select class="form-control select2" name="brand_id" id="brand_id" tabindex="-1" aria-hidden="true">
                                    <option value="0" selected>Select Brand</option>
                                    @foreach($brands as $brand)
                                    @if($brand->brand_stat == 1)
                                    <option value="{{$brand->brand_id}}">{{ ucwords(trans($brand->brand_name))}}</option>
                                    @else
                                    <option value="{{$brand->brand_id}}" disabled="disabled">{{ ucwords(trans($brand->brand_name))}}</option>
                                    @endif
                                    @endforeach
                                </select>
                                <span class="text-danger" id="brand_id_error"></span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="text-muted">Product Type</label>
                                <select class="form-control select2" name="pro_type" id="production" tabindex="-1" aria-hidden="true">
                                    <option value="0" selected>Select Product Type</option>
                                    <option value="Manufacturing">Manufacturing</option>
                                    <option value="Purchasing">Purchasing</option>
                                </select>
                            </div>
                            <span class="text-danger" id="pro_type_error"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="text-muted">Primry Unit</label>
                                <select class="form-control select2 priUnit" name="primary_unit" id="primary_unit" tabindex="-1" aria-hidden="true">
                                    <option value="" selected>Select Unit</option>
                                    @foreach($units as $unit)
                                    <option value="{{$unit->unit_id}}">{{ ucwords(trans($unit->unit_name))}}</option>
                                    @endforeach
                                </select>
                                <span class="text-danger" id="primary_unit_error"></span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="text-muted">Secondary Unit</label>
                                <select class="form-control select2 secUnit" name="secondary_unit" id="secondary_unit" tabindex="-1" aria-hidden="true">
                                    <option value="" selected>Select Unit</option>
                                    @foreach($units as $unit)
                                    <option value="{{$unit->unit_id}}">{{ ucwords(trans($unit->unit_name))}}</option>
                                    @endforeach
                                </select>
                                <span class="text-danger" id="secondary_unit_error"></span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <button type="button" class="btn btn-sm btn-primary disabled mb-3" id="convBtn">
                                <span class="mx-1">Add Conversion Rate</span>
                            </button>
                        </div>
                        <div class="col-sm-12 conversion" style="display: none;">
                            <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="selectedPriUnit"></span>
                                </div>
                                <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" type="number" name="no_of_pcs" id="no_of_pcs" autocorrect="off" autofocus="autofocus" autocomplete="off" animate="true" autocomplete="off" autocapitalize="off" spellcheck="false" oninput="this.value = Math.round(this.value);" placeholder="Enter value">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="selectedSecUnit"></span>
                                </div>
                            </div>
                            <span class="text-danger" id="no_of_pcs_error"></span>
                        </div>                        
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="text-muted">Product Image</label>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="image" name="image">
                                    <span class="text-danger" id="image_error"></span>
                                    <label class="custom-file-label" for="image">Choose file</label>
                                </div>
                                <img id="show-img" style="padding: 10px; width: 100px;" />
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="text-muted">Product MRP</label>
                                <input class="form-control" type="number" value="" name="product_mrp" id="product_mrp" required="" placeholder="MRP" disabled="disabled">
                                <span class="text-danger" id="product_mrp_error"></span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="text-muted">Publication Status</label></br>
                                <label class="ui-switch ui-switch-md info m-t-xs" style="top:5px;">
                                    <input type="checkbox" id="checkbox"> <i></i>
                                </label>
                                <input type="hidden" name="product_stat" id="product_stat" value="0">
                            </div>
                        </div>
                    </div>
                    <div class="row unitprice" style="display: none;">
                        <div class="col-sm-6">
                            <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="selectedPriUnit2"></span>
                                </div>
                                <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" id="priUnit_price" disabled="">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="selectedSecUnit2"></span>
                                </div>
                                <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" id="secUnit_price" disabled="">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="product_id" id="product_id" />
                        <input type="hidden" name="image_update" id="image-update">
                        <button class="btn btn-outline-dark" data-dismiss="modal" onclick=" 
                        document.getElementById('show-img').removeAttribute('src');">Close</button>
                        <button type="submit" class="btn btn-primary" id="addBtn">Save Changes</button>
                        <button type="submit" class="btn btn-primary hide" id="editBtn">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.modal-content -->
</div>