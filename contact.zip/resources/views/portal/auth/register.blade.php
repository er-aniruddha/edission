@include('portal.layouts.header')
@section('pageTitle','Register')
<div class="flex">
    <div class="w-xl w-auto-sm mx-auto py-5">
        <div class="p-4 d-flex flex-column h-100">
            <!-- brand --> 
            <a href="{{url('/')}}" class="navbar-brand align-self-center">
                <img src="{{asset('public/portal/images/logo-01.png')}}" alt="..."> 
                <!-- span class="hidden-folded d-inline l-s-n-1x align-self-center">Omnipresenceway</span> --> 
            </a>
            <!-- / brand -->
        </div>
        <div class="card">
            <div id="content-body">
                <div class="p-3 p-md-5">
                    <h5>Register</h5>
                    <p><small class="text-muted">Register to access your account</small></p>

                    <form role="form" method="POST" action="{{ route('register') }}">
                        @csrf
                        <div class="md-form-group float-label">    
                            <input type="text" class="md-input @error('f_name') is-invalid @enderror" 
                            onkeyup="this.setAttribute('value', this.value);" name="f_name" id="f_name" value="{{ old('f_name') }}" required>
                            <label>First name</label>
                            @error('f_name')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                        <div class="md-form-group float-label">
                            <input type="text" class="md-input @error('s_name') is-invalid @enderror" 
                            onkeyup="this.setAttribute('value', this.value);" name="s_name" id="s_name" value="{{ old('s_name') }}" required>
                            <label>Surname</label>

                            @error('s_name')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                        <div class="md-form-group float-label">
                            <input type="email" class="md-input @error('email') is-invalid @enderror"
                             onkeyup="this.setAttribute('value', this.value);" name="email" id="email" value="{{ old('email') }}" required>
                             <label>Email</label>

                            @error('email')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                        
                        <div class="md-form-group float-label">
                            <input type="password" class="md-input @error('password') is-invalid @enderror"
                            name="password" id="password" value="{{ old('password') }}" required>
                             <label>Password</label>
                            
                            @error('password')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>

                        <div class="md-form-group float-label">
                            <input type="password" class="md-input @error('password') is-invalid @enderror" 
                             name="password_confirmation" id="password-confirm" autocomplete="new-password" required>
                            <label>Confirm Password</label>
                        </div>
                        <div style="border-top: 1px solid #ccc;
                        padding-bottom: 20px;
                        margin-top: 30px;
                        width: 100%;"></div>
                        <button type="submit" class="btn btn-raised btn-wave mb-4 green text-white">Sign Up</button>
                        <a href="{{ route('login')}}" class="btn btn-raised btn-wave mb-4 blue text-white" style="float: right;">Sign In</a>
                    </form>
                    
                </div>
            </div>
        </div>
        <div class="text-center text-muted">© Copyright. Edission</div>
    </div>
</div>
@include('portal.layouts.footer')