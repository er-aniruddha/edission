@include('portal.layouts.header')
@section('pageTitle','Verify')

<div id="ajax-content" class="dark h-v d-flex flex align-items-center">
    <div class="mx-auto w-xl w-auto-xs animate fadeIn text-center">
        <div class="p-4 d-flex flex-column h-100">
            <!-- brand --> 
            <a href="{{url('/')}}" class="navbar-brand align-self-center">
                <img src="{{asset('public/portal/images/logo.png')}}" alt="..."> 
                <!-- span class="hidden-folded d-inline l-s-n-1x align-self-center">Omnipresenceway</span> --> 
            </a>
            <!-- / brand -->
        </div>
        <form method="POST" action="{{ route('password.email') }}">
            @csrf
            <div class="md-form-group">
                <input type="email" class="md-input text-center @error('email') is-invalid @enderror" id="email"
                    name="email" value="{{ $email ?? old('email') }}" autocomplete="email" autofocus>
                <label class="d-block w-100">Enter email</label>
    
                @error('email')
                <p class="text-danger">{{ $message }}</p>
                @enderror
            </div>
            <div class="mt-3">
                <button type="submit" class="btn btn-rounded btn-primary">Send Password Reset Link</button>                
            </div>
            <div class="mt-3">
                <a href="{{ route('login') }}" class="btn btn-rounded btn-dark">Login</a>                
            </div>
        </form>
        @if (session('status'))
            <p class="text-primary" style="margin-top:20px;">
                {{ session('status') }}
            </p>
        @endif
    </div>
</div>


@include('portal.layouts.footer')