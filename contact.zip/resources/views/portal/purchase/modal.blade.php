<form id="purchaseForm" method="POST">
@csrf
    <div id="modal" class="modal fade show" aria-modal="true">
        <div class="modal-dialog text-dark modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                    <h5 class="modal-title text-white"></h5>                
                    <button class="close" data-dismiss="modal">×</button>
                </div>
                <div class="modal-body p-4">
                    <div class="form-group row" style="float: right;">
                        <label class="col-sm-3 col-form-label text-dark">Date</label>
                        <div class="col-sm-9">
                            <input data-provide="datepicker" id="date" name="date" type="text" class="form-control date" placeholder="Date">
                            <span class="text-danger" id="date_error"></span>
                        </div>                        
                    </div>
                    <table class="table-bordered table table-theme table-row v-middle">
                        <thead>
                            <tr>
                                <th>Item Name</th>
                                <th>Unit Name</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Total</th>
                                <th>
                                    <a href="javascript:void(0)" class="addRow">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
                                    </a>

                                </th>
                            </tr>
                        </thead>
                        <tr class="row_0">
                            <td>                                
                               <input class="form-control" value="" id="item_name" name="item_name[0]" placeholder="Item Name">
                               <span class="text-danger item_name_error_0"></span>
                            </td>
                            <td>
                               <input class="form-control" value="" id="unit_name" name="unit_name[0]" placeholder="Unit Name">
                               <span class="text-danger unit_name_error_0"></span>
                            </td>
                            <td style="width: 109px;">
                               <input type="number" class="form-control qty" value="" id="qty" name="qty[0]" autocorrect="off" autofocus="autofocus" autocomplete="off" animate="true" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Quantity" oninput="this.value = Math.round(this.value);">
                               <span class="text-danger qty_error_0"></span>
                            </td>
                            <td style="width: 109px;">
                                <input type="number" class="form-control unitPrice" value="" id="unit_price" name="unit_price[0]" placeholder="Unit Price">
                                <span class="text-danger unit_price_error_0"></span>
                            </td>
                            <td style="width: 109px;">
                                <input type="number" class="form-control subTotal" value="" id="total_price" name="total_price[0]"  placeholder="Total" readonly>
                                <span class="text-danger total_price_error_0"></span>
                            </td>
                             <td>
                                <a href="javascript:void(0)" class="btn btn-icon" style="border: 1px solid #f54394" onclick="alert('You can not remove first row');">
                                    <svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="color: red;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>
                                    </svg>
                                </a>                                
                            </td>
                        </tr> 
                    </table>          
                    
                       <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-sm-3 col-form-label">Remarks</label>
                                    <div class="col-sm-9">
                                        <textarea id="remarks" name="remarks" class="form-control" rows="3"></textarea>
                                        <span class="text-danger" id="remarks_error"></span>
                                    </div>                        
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="modal-footer">
                                    <input type="hidden" name="purchase_id" id="purchase_id"/>
                                    <button class="btn gd-primary text-white btn-rounded" id="addBtn">Save</button>
                                    <button class="btn gd-warning text-white btn-rounded hide" id="editBtn">Update</button>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
</form>