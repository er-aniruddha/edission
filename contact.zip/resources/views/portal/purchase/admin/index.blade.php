<div id="content" class="flex">
    <div class="page-hero" id="page-hero">
        <div class="padding d-flex">
            <div class="page-title">
                <h2 class="text-md text-highlight">All Purchase Items</h2>
                <!-- <small class="text-muted">Products</small> -->
            </div>
            <div class="flex"></div>
            <div>
                <button class="btn btn-raised btn-wave blue text-white add" data-toggle="modal" data-target="#modal">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                    Add
                </button>
                <button class="btn btn-raised btn-wave btn-outline-primary" data-toggle="dropdown">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-download-cloud"><polyline points="8 17 12 21 16 17"></polyline><line x1="12" y1="12" x2="12" y2="21"></line><path d="M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29"></path></svg>
                    Export
                </button>
                <div class="dropdown-menu" role="menu" x-placement="bottom-start">
                    <a class="dropdown-item export" id=".buttons-csv">
                        <i class="badge badge-circle text-primary"></i> CSV 
                    </a>
                    <a class="dropdown-item export" id=".buttons-excel">
                        <i class="badge badge-circle text-primary"></i> EXCEL 
                    </a>
                    <a class="dropdown-item export" id=".buttons-pdf">
                        <i class="badge badge-circle text-primary"></i> PDF 
                    </a>
                    <a class="dropdown-item export" id=".buttons-print">
                        <i class="badge badge-circle text-primary"></i> Print 
                    </a>
                </div>
            </div>                
        </div>
    </div>
    <form method="POST" action="{{ route('purchase.create')}}">
        @csrf
        <label>Choose a browser from this list:
        <input list="browsers" name="myBrowser" /></label>
        <datalist id="browsers">
          <option value="Chrome">
          <option value="Firefox">
          <option value="Internet Explorer">
          <option value="Opera">
          <option value="Safari">
          <option value="Microsoft Edge">
        </datalist>
        <select class="form-control select2 priUnit" name="primary_unit" id="primary_unit" tabindex="-1" aria-hidden="true">
          <option selected="selected">orange</option>
          <option>white</option>
          <option>purple</option>
        </select>

        
        <button type="submit">Submit</button>
    </form>
        
    <div class="page-content" id="page-content">        
        <div class="padding">
            <div class="table-responsive">
                <table id="purchase_table" class="table table-theme table-row v-middle" >
                    <thead>
                        <tr>
                            <th style="width: 26px;"><span class="text-muted">SL No</span></th>
                            <th><span class="text-muted">Date</span></th>
                            <th><span class="text-muted">Item</span></th>
                            <th><span class="text-muted">Unit</span></th>
                            <th><span class="text-muted">Quantity</span></th>
                            <th><span class="text-muted">Unit Price</span></th>
                            <th><span class="text-muted">Total</span></th>
                        </tr>
                    </thead>
                    
                </table>
            </div>
        </div>
    </div>
</div>
@include('portal.purchase.modal')
@include('portal.layouts.deleteModal')
</div>
<script>
    // global app configuration object
    var routes = {
            index: "{{ route('purchase.index') }}",
            create: "{{ route('purchase.create') }}",
            update: "{{ route('purchase.update') }}",
            delete: "{{ route('purchase.delete') }}",
        };
    var purchase = @json($purchase);
</script>
<script type="text/javascript">

$(document).ready(function() {
    var base_url = "https://varneyatechnologies.com";
    $('.select2').select2({
        width:"100%",
         tags: true
    });//to initiatate select2  
})
</script>

<script type="text/javascript" src="{{asset('resources/js/purchase.js')}}"></script>
