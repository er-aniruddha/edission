<!-- CONTENT START -->
<div id="content" class="flex">
    <div class="d-flex flex fixed-content">
        <div class="aside aside-sm" id="content-aside">
            <div class="d-flex flex-column w-xl modal-dialog bg-body" id="chat-nav">
                <div class="navbar">
                    <div class="input-group flex bg-light rounded">                        
                        <input type="text" class="form-control no-bg no-border no-shadow search" placeholder="Search" required="" id="searchProduct">
                        <span class="input-group-append">
                            <button class="btn no-bg no-shadow" type="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search text-fade">
                                    <circle cx="11" cy="11" r="8"></circle>
                                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                </svg>
                            </button>
                        </span>
                    </div>
                </div>
                <div class="scrollable hover">
                    <div class="sidenav p-2">
                        <nav class="nav-active-text-primary" data-nav="">
                            <ul class="nav" id="customerList">
                                @foreach($customers as $customer)
                                <li class="active list-item"> 
                                    <a href="javascript:void(0);" data-pjax-state="anchor" class="b-b customer item-company text-primary" data-name="{{$customer->f_name}} {{$customer->s_name}}">
                                        <span class="nav-text text-capitalize">{{$customer->f_name}} {{$customer->s_name}}
                                        <p class="item-except text-muted text-sm h-1x">{{$customer->shop_name}}</p></span>
                                        <span class="nav-badge">
                                            <span class="badge bg-primary-lt">{{$customer->balance}}</span>
                                        </span>
                                    </a>
                                </li>
                                @endforeach
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex flex pr-md-3" id="content-body">
            <div class="d-flex flex-column flex m-0 mb-md-3" id="chat-list">
                <div class="row" style="padding-top: 50px;">
                    <div class="mb-md-3" style="padding-left: 83.5%;">
                        <button class="btn btn-raised btn-wave mb-2 blue text-white"  id="paymentin">Add Payment-In</button>
                    </div>                    
                </div>
                <div class="table-responsive">
                    <table class="table table-theme table-row v-middle" id="payments_table">
                        <thead>
                            <tr>
                                <th style="width: 26px;"><span class="text-muted">#</span></th>
                                <th><span class="text-muted">Date</span></th>
                                <th><span class="text-muted">Invoice No</span></th>
                                <th><span class="text-muted">Customer Name</span></th>
                                <th><span class="text-muted">Payment Type</span></th>
                                <th><span class="text-muted">Prev. Due</span></th>
                                <th><span class="text-muted">Received/Paid</span></th>
                                <th><span class="text-muted">Balance</span></th>
                                <th style="width:50px"></th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- CONTENT END -->
@include('portal.sale_payment_in.paymentModal')
</div>
<script>
// global app configuration object
var routes = {
    index: "{{ route('sale.payment.index') }}",
    payment_in: "{{ route('sale.payment.in') }}",
};

// All the vaiables are required for end
</script>
<script type="text/javascript" src="{{asset('resources/js/sale/payment-in.js')}}"></script>