<form id="exsSkuAddForm" method="POST">
    @csrf
    <div id="exsModal" class="modal fade modal-open-aside show" data-backdrop="true" style="display: none; padding-right: 17px;" aria-hidden="true" data-class="modal-open-aside">
    <div class="modal-dialog modal-right w-xl">
        <div class="modal-content h-100 no-radius">
            <div class="modal-header">
                <div class="modal-title text-md">Existing SKU Update</div>
                <button class="close" data-dismiss="modal">×</button></div>
                <div class="modal-body">
                    <div class="row row-sm">
                        <div class="col-md-12">    
                            <div class="form-group">
                                <label class="text-muted">SKU</label>
                                <select class="form-control select2" name="sku_code" id="exs_sku_code" tabindex="-1" aria-hidden="true" required="">
                                   <option selected="" value="">Select an option</option>   
                                </select>
                                <span class="text-danger mr-2" id="exs_sku_code_error"></span>
                            </div>
                            <div class="form-group">
                                <label class="text-muted">Date</label>
                                <input type="text" class="form-control date" data-provide="datepicker" id="exsdate" name="date" value="" required="">
                                <span class="text-danger mr-2" id="exs_date_error"></span>
                            </div>
                            <div class="form-group">
                                <label class="text-muted">Cost</label>
                                <select class="form-control select2" name="cost_id" id="exs_cost_id" tabindex="-1" aria-hidden="true" required="">
                                   <option selected="" value="">Select an option</option>   
                                </select>
                                <span class="text-danger mr-2" id="exs_cost_id_error"></span>
                            </div>
                            <div class="form-group">
                                <label class="text-muted">Quantity</label>
                                <input type="number" class="form-control" value="" id="sku_qty" name="sku_qty" placeholder="Enter stock quantity"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                <span class="text-danger mr-2" id="exs_stock_qty_error"></span>
                            </div>
                            <div class="form-group">
                                <label class="text-muted">Publication Status</label>
                                <label class="ui-switch ui-switch-md info m-t-xs" style="top:5px;">
                                    <input type="checkbox" id="exsCheckbox"> <i></i>
                                    <input type="hidden" name="stock_stat" id="exs_stock_stat" value="0">
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-dark" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" id="exsBtn">Update</button>
                </div>
        </div>
        <!-- /.modal-content -->
    </div>
    </div>
</form>
<script>
    $(document).ready(function(){        
        /* This part for HTML */
        $('input[type="checkbox"]').click(function(event) {
            /* Act on the event */
            if($('#exsCheckbox').is(':checked')){
                $("#exs_stock_stat").val(1)
            }
            else{
                $("#exs_stock_stat").val(0)
            }
        })//set publication status 
    })
</script>


