@section('page_title','Inventory')
<!-- CONTENT START -->
<div id="content" class="flex">
    <div class="d-flex flex fixed-content">
        <div class="aside aside-sm" id="content-aside">
            <div class="d-flex flex-column w-xl modal-dialog bg-body" id="chat-nav">
                <div class="navbar">
                    <div class="input-group flex bg-light rounded">
                        <input type="text" class="form-control no-bg no-border no-shadow search" placeholder="Search" required="" id="searchProduct">
                        <span class="input-group-append">
                            <button class="btn no-bg no-shadow" type="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search text-fade">
                                    <circle cx="11" cy="11" r="8"></circle>
                                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                </svg>
                            </button>
                        </span>
                    </div>
                </div>
                <div class="scrollable hover">
                    <div class="sidenav p-2">
                        <nav class="nav-active-text-primary" data-nav="">
                            <ul class="nav" id="productList">
                                @foreach($products as $pro)
                                <li class="item">
                                    <a href="javascript:void(0);" data-pjax-state="anchor" class="mb-2 item-company text-primary product" id="{{$pro->product_id}}" data-name="{{$pro->product_name}}">
                                        <!-- <img src="{{asset($pro->product_img)}}" alt="..." class="w-40 r"> -->
                                        <span class="nav-text text-capitalize">{{$pro->product_name}} ({{$pro->brand_name}})</span>

                                        <span class="nav-badge">
                                            <span class="badge bg-primary text-uppercase">{{$pro->in_hand_stock_primary}}/{{$pro->in_hand_stock_second}}</span>
                                        </span>
                                    </a>
                                    <div class="b-b mb-3"></div>
                                </li>
                                @endforeach
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex flex pr-md-3" id="content-body">
            <div class="d-flex flex-column flex card m-0 mb-md-3" id="chat-list">
                <div class="row">
                    <div class="card-body m-4">
                        <div class="row row-sm">
                            <div class="col-sm-12">
                                <div class="mb-2"><div class="mt-2 font-weight-500"><h3 class="text-info product-name text-capitalize">Product Name</h3></div></div>
                                <div class="row row-sm">
                                    <div class="col-3">
                                        <div class="text-highlight text-md sale-price">00</div><small>SALE PRICE</small>
                                    </div>
                                    <div class="col-3">
                                        <div class="text-danger text-md purchase-price">00</div><small>PURCHASE PRICE</small>
                                    </div>
                                    <div class="col-3">
                                        <div class="text-md stock-qty">00</div><small>STOCK QUANTITY</small>
                                    </div>
                                    <div class="col-3">
                                        <div class="text-md stock-val">00</div><small>STOCK VALUE</small>
                                    </div>
                                </div>
                            </div>                            
                        </div>
                    </div>
                </div>
                <div class="table-responsive" style="background-color:#f9f9fa;">
                    <table class="table table-striped table-bordered" id="transaction_table">
                        <thead>
                            <tr>
                                <th class="text-muted sortable" data-toggle-class="asc">Type</th>
                                <th class="text-muted sortable" data-toggle-class="asc">Party</th>
                                <th class="text-muted sortable" data-toggle-class="asc">Order Date</th>
                                <th class="text-muted sortable" data-toggle-class="asc">Delivery Date</th>
                                <th class="text-muted sortable" data-toggle-class="asc">Trnx Id</th>
                                <th class="text-muted sortable" data-toggle-class="asc">Quantity</th>
                                <th class="text-muted sortable" data-toggle-class="asc">Unit Name</th>
                                <th class="text-muted sortable" data-toggle-class="asc">Unit Price</th>
                                <th class="text-muted sortable" data-toggle-class="asc">Amount</th>
                                <th class="text-muted sortable" data-toggle-class="asc">Satus</th>
                                <th style="width:50px"></th>
                            </tr>
                        </thead>
                        <tbody>
                                                     
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- CONTENT END -->
</div>
<script>
// global app configuration object
var routes = {
    index: "{{ route('stock.index') }}",
};
var stocks = @json($stocks);
var products = @json($products);
// All the vaiables are required for end
</script>
<script type="text/javascript" src="{{asset('resources/js/stock.js')}}"></script>