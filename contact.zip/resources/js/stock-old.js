$(document).ready(function() {    
    exsStockCost(stocks)
    /*Months Array*/
    months = [ "JAN", "FEB", "MAR", "APR", "MAY", "JUN","JUL", "AUG", "SEP", "OCT", "NOV", "DEC" ]; 
   
    var getAllData = []; //sku code variable
    var date = new Date(); //page initilaization choose date
    var month = months[date.getMonth()]; //page initilaization choose month
    getAllData[2] = month; //assing month to SKU variable
    
    $('.select2').select2({
            width:"100%", 
    });
    $("#product_id").change(function(){        
        getAllData[0] = $("#product_id option:selected").text();
        codeCreate()
    })
    $("#maker_name").change(function(){
        $(this).val($(this).val().toUpperCase());
        getAllData[1] = $("#maker_name").val();
        codeCreate()
    })
    
    $('.date').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
        width: "100%",
        startDate: "01-04-2021",
        endDate: "0d",
        todayHighlight: true,
    }).on('change',function(){
        var month = months[$(this).datepicker('getDate').getMonth()]   
        getAllData[2] = month;
        codeCreate()
    });
    function codeCreate(){  
        let productName;
        let makerName = getAllData[1];
        let month = getAllData[2];
        if(getAllData[0]){
            productName = getAllData[0].split(/\s/).reduce((response, word) => response += word.slice(0, 2), '');
        }
        // if(getAllData[1]){
        //     makerName = getAllData[1].split(/\s/).reduce((response, word) => response += word.slice(0, 2), '');
        // }
        let code = productName+'-'+makerName+'-'+month;
        $("#sku_code").val(code.toUpperCase())
    }  
    /* This part for HTML */
    /* Show Brand Table Start */ 
    var dataTable = $('#stock_table').DataTable({
        processing: true,
        serverSide: true,
        ajax:{
            url: routes.index,
        },
        columns:[
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},  
            {data: 'date', name: 'date' },    
            {data: 'product_name', name: 'product_name' },                 
            {data: 'maker_name', name: 'maker_name' },
            {data: 'sku', name: 'sku' },
            {data: 'in_hand_stock', name: 'in_hand_stock' },
            {data: 'status', name: 'status', },
            {data: 'action', name: 'action', }, 
    ]});
    /* Show Brand Table End */
    
    /* Add Stock Cost Start */ 
    $('#newSkuAddForm').on('click', '#addBtn', function(event) {
        event.preventDefault();
        $("#product_id_error").html(" ")
        $("#maker_name_error").html(" ")
        $("#date_error").html(" ")
        $("#sku_code_error").html(" ")
        $("#cost_id_error").html(" ")
        $("#stock_qty_error").html(" ")       
        var formData = new FormData($('#newSkuAddForm')[0]);
        $.ajax({
            method: 'POST',
            url: routes.createNew,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if(response.errors.product_id){
                        $("#product_id_error").text(response.errors.product_id[0])
                    }
                    if(response.errors.maker_name){
                        $("#maker_name_error").text(response.errors.maker_name[0])
                    }
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.sku_code){
                        $("#sku_code_error").text(response.errors.sku_code[0])
                    }
                    if(response.errors.cost_id){
                        $("#cost_id_error").text(response.errors.cost_id[0])
                    }
                    if(response.errors.sku_qty){
                        $("#stock_qty_error").text(response.errors.sku_qty[0])
                    }                    
                }
                else{
                    stocks = response.stocks;
                    exsStockCost(stocks)
                    $(".exsBody").load(window.location + " .exsBody");
                    $("#newSkuAddForm")[0].reset(); 
                    $('.select2').select2({ 
                            width:"100%",                       
                            initSelection: function(element, callback) {                   
                        }
                    }); 
                    getAllData = [];
                    getAllData[2] = month;
                    $('#newModal').modal('hide');  
                    $('#stock_table').DataTable().ajax.reload(); 
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })
    })
    /* Add Stock Cost End */ 
    /* Stock Cost Status Start */ 
    $(document).on("click", ".status", function(event) {
        event.preventDefault()
        $.ajax({
            type: "GET",
            url: $(this).data("url"),
            success: function(response) {
                if (response.success) {
                    $("#stock_table").DataTable().ajax.reload();
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end here
    })//function end here
    
    /* Stock Cost Status End */ 

    /* Stock Cost Delete Start */ 
    $(document).on("click", "button.delete", function() {
        $("#id").val($(this).data("id"))
        $(".modal-title").text("SKU: " + $(this).data("code")) 
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {

                if (response.success) {
                    stocks = response.stocks;
                    exsStockCost(stocks)
                    $("#stock_table").DataTable().ajax.reload()
                    $("#confirmModal").modal("hide");
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end here
    })//form end here
    /* Stock Cost Delete End */ 

/*+++++++++++++++++++++++++++++++++++++++++++ exsStock START ++++++++++++++++++++++++++++++++++++++*/       
    $("#exs_sku_code").change(function(){   
        var skuCode = $("#exs_sku_code").val();
        let date;
        for(var i = 0; i < stocks.length; i++){
            if(stocks[i][1].sku_code == skuCode){
                date = stocks[i][1].date                
            }
        }
        var dateSplit = date.split('-')
        var srtDate = dateSplit[2]+'-'+dateSplit[1]+'-'+dateSplit[0]
        $('#exsdate').datepicker('setStartDate', srtDate);
    })
    /* Add Stock Cost Start */ 
    $('#exsSkuAddForm').on('click', '#exsBtn', function(event) {
        event.preventDefault();
        $("#exs_sku_code_error").html(" ")
        $("#exs_date_error").html(" ")
        $("#exs_cost_id_error").html(" ")
        $("#exs_stock_qty_error").html(" ")       
        var formData = new FormData($('#exsSkuAddForm')[0]);
        $.ajax({
            method: 'POST',
            url: routes.updateExs,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if(response.errors.sku_code){
                        $("#exs_sku_code_error").text(response.errors.sku_code[0])
                    }
                    if(response.errors.date){
                        $("#exs_date_error").text(response.errors.date[0])
                    }
                    if(response.errors.cost_id){
                        $("#exs_cost_id_error").text(response.errors.cost_id[0])
                    }
                    if(response.errors.sku_qty){
                        $("#exs_stock_qty_error").text(response.errors.sku_qty[0])
                    }                    
                }
                else{                    
                    $("#exsSkuAddForm")[0].reset(); 
                    $('.select2').select2({ 
                            width:"100%",                       
                            initSelection: function(element, callback) {                   
                        }
                    }); 
                    $('#exsModal').modal('hide');  
                    $('#stock_table').DataTable().ajax.reload(); 
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })
    })
    /* Add Stock Cost End */ 
/*+++++++++++++++++++++++++++++++++++++++++++ exsStock END ++++++++++++++++++++++++++++++++++++++*/

function exsStockCost(stocks){
        $('#exs_sku_code').empty().append('<option selected="" value="">Select an option</option>');
        $('#exs_cost_id').empty().append('<option selected="" value="">Select an option</option>');        
        for(i=0; i<stocks.length; i++){
            $("#exs_sku_code").append('<option value="'+stocks[i][1].sku_code+'">'+stocks[i][1].sku_code+'</option>')
        }  
        for(i=0; i<costs.length; i++){
            if(costs[i][1].cost_stat == 1){
                $("#exs_cost_id").append('<option value="'+costs[i][1].cost_id+'">'+costs[i][1].cost_name+' / INR '+costs[i][1].cost_total+'</option>')
            }
            else{

                $("#exs_cost_id").append('<option value="'+costs[i][1].cost_id+'" disabled>'+costs[i][1].cost_name+' / INR '+costs[i][1].cost_total+'</option>')
            }
        }             
    } 
});