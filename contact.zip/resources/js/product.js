$(document).ready(function() {
    var base_url = "https://varneyatechnologies.com";
	$('.select2').select2({
		width:"100%"
	});//to initiatate select2	
	/* To prevent multi decimal input start */
    $('#product_mrp').on('keyup',function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
        }
        if($(this).val() != ''){
            $(".unitprice").show()
            $("#priUnit_price").val($("#product_mrp").val())
            $("#secUnit_price").val($("#product_mrp").val()/$("#no_of_pcs").val())            
        }
        else{
            $(".unitprice").hide()
        }
    });
    /* On Change of Unit Start*/
    $('#no_of_pcs').on('keyup',function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
        }
        if($("#product_mrp").val() != ''){
            $(".unitprice").show()
            $("#priUnit_price").val($("#product_mrp").val())
            $("#secUnit_price").val($("#product_mrp").val()/$("#no_of_pcs").val())            
        }
        else{
            $(".unitprice").hide()
        }
    });
    $(".priUnit").on('change',function() {
        var data = $(".priUnit option:selected").val();
        if(data == ''){
            onChangeSelectOption()
        } 
        else{
            $("#selectedPriUnit").text('1 '+data) 
            $("#selectedPriUnit2").text('Price/'+data) 
            conversionUnitChngCount()
        }
    })
    $(".secUnit").on('change',function() {
        var data = $(".secUnit option:selected").val();
        if(data == ''){
            onChangeSelectOption()
        }
        else{
            $("#selectedSecUnit").text(data)
            $("#selectedSecUnit2").text('Price/'+data)
            conversionUnitChngCount()
        }
    })
    function conversionUnitChngCount(){
        if($(".priUnit option:selected").val() != '' && $(".secUnit option:selected").val() != ''){
            $("#convBtn").addClass('enable')
            $("#convBtn").removeClass('disabled')
            $("#product_mrp").prop('disabled', false)
        }
    }
    $('#convBtn').click(function(event){
        event.preventDefault()
        if($("#convBtn").hasClass('enable')){
            $("#convBtn").hide()
            $(".conversion").show()
        }
        
    })
    function onChangeSelectOption(){
        $("#convBtn").addClass('disabled')
        $("#convBtn").removeClass('enable')
        $("#product_mrp").prop('disabled', true)
        $("#convBtn").show()
        $(".conversion").hide()            
        $(".unitprice").hide()
    }
    /* On Change of Unit End*/
    /* To prevent multi decimal input edn */
	$('input[type="checkbox"]').click(function(event) {
		/* Act on the event */
		if($('#checkbox').is(':checked')){
			$("#product_stat").val(1)
		}
		else{
			$("#product_stat").val(0)
		}
	})//set publication status
	/* Show Brand Table Start */ 
	$('#product_table').DataTable({
      	processing: true,
      	serverSide: true,
      	ajax:{
       		url: routes.list,
      	},
      	columns:[
       		{data: 'DT_RowIndex', name: 'DT_RowIndex'},
       		{data: 'product_img', name: 'product_img', render: function(data, type, full, meta){
         		return "<img src="+base_url+'/'+data+ " width='70' class='img-thumbnail' />";
         	},orderable: false},
       		{data: 'product_name', name: 'product_name', className:"text-capitalize"},
       		{data: 'brand_name', name: 'brand_name', className:"text-capitalize"},
            {data: 'product_mrp', name: 'product_mrp'},
       		{data: 'status', name: 'status', },
       		{data: 'action', name: 'action', }, 
    ]});
	/* Show Brand Table End */
	/* Add Modal Start */
	$(document).on('click','button.add',function(){ 
	    $('.modal-title').text("Add Product");
	    $('#brand_id').val("");
	    $('#addBtn').show();
	    $('#editBtn').hide();
        $('#show-img').removeAttr('src'); 
        $("input[type='text']").removeClass("text-capitalize")
        $('#productForm')[0].reset();        
        $('.select2').select2({                       
                initSelection: function(element, callback) {                   
            },
            width:"100%"
        }); 
        $("#convBtn").addClass('disabled')
        $("#convBtn").show()
        $("#product_mrp").prop('disabled', true)
        $(".unitprice").hide()
        $(".conversion").hide()
        $(".text-danger").html("")

	 });
	/* Add Modal end */

	/* Add Product Start */
	$('#productForm').on('click', '#addBtn', function (event) {
        event.preventDefault();
        $(".text-danger").html("") 
        var formData = new FormData($('#productForm')[0]);
        $.ajax({
            method: 'POST',
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function (response) {
                if(response.errors){
                    if(response.errors.product_name){
                        $("#product_name_error").text(response.errors.product_name[0])
                    }
                    if(response.errors.product_desc){
                        $("#product_desc_error").text(response.errors.product_desc[0])
                    }
                    if(response.errors.brand_id){
                        $("#brand_id_error").text(response.errors.brand_id[0])
                    }
                    if(response.errors.primary_unit){
                        $("#primary_unit_error").text(response.errors.primary_unit[0])
                    }
                    if(response.errors.secondary_unit){
                        $("#secondary_unit_error").text(response.errors.secondary_unit[0])
                    }
                    if(response.errors.no_of_pcs){
                        $("#no_of_pcs_error").text(response.errors.no_of_pcs[0])
                    }
                    if(response.errors.product_mrp){
                        $("#product_mrp_error").text(response.errors.product_mrp[0])
                    }
                    if(response.errors.image){
                        $("#image_error").text(response.errors.image[0])
                    }
                    if(response.errors.pro_type){
                        $("#pro_type_error").text(response.errors.pro_type[0])
                    }                        
                }
                //on success
                else{
                    $('#product_table').DataTable().ajax.reload(); 
                    $("#modal").modal('hide')
                    $("#productForm")[0].reset()
                    $('input.md-input').attr('value' , '')
                    $('.select2').select2({                       
                            initSelection: function(element, callback) {                   
                        }
                    }); 
                    $("#convBtn").addClass('disabled')                    
                    let message = response.success;
                    snacbar(message)
                }
            },
            error:function(error){
                snacbar(error.statusText)
            }
        })//ajax end here
    })//Add product function end here
    /*Add Product End*/
    /* Product Show Start*/
    $(document).on("click", "button.view", function() {
        $(".modal-title").text("Product Details") 
        $("#editBtn").hide()
        showProduct($(this).data())        

    })//Product Edit show 
    /* Product Show End*/
    /*Product Edit Start*/
    $(document).on("click", "button.edit", function() {        
        $(".modal-title").text("Edit Product") 
        $("#editBtn").show()
        $("#product_id").val($(this).attr("id"))
        showProduct($(this).data())
    })//Product Edit show 
    $("#productForm").on("click", "#editBtn", function(event) {
        event.preventDefault()
        $( '#product_name_error' ).html( "" );
        $( '#product_desc_error' ).html( "" );
        $( '#brand_id_error' ).html( "" );
        $( '#product_mrp_error' ).html( "" );
        $( '#image_error' ).html( "" );
        $( '#pro_type_error' ).html( "" ); 
        var formData = new FormData($("#productForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                // console.log(response)
                if(response.errors){
                    if(response.errors.product_name){
                        $("#product_name_error").text(response.errors.product_name[0])
                    }
                    if(response.errors.product_desc){
                        $("#product_desc_error").text(response.errors.product_desc[0])
                    }
                    if(response.errors.brand_id){
                        $("#brand_id_error").text(response.errors.brand_id[0])
                    }
                    if(response.errors.product_mrp){
                        $("#product_mrp_error").text(response.errors.product_mrp[0])
                    }
                    if(response.errors.image){
                        $("#image_error").text(response.errors.image[0])
                    }
                    if(response.errors.pro_type){
                        $("#pro_type_error").text(response.errors.pro_type[0])
                    }                        
                }
                //on success
                else{
                    $('#product_table').DataTable().ajax.reload(); 
                    $("#modal").modal('hide')
                    $("#productForm")[0].reset()
                    $('input.md-input').attr('value' , '')
                    $('.select2').select2({                       
                            initSelection: function(element, callback) {                   
                        }
                    }); 
                    let message = response.success;
                    snacbar(message)
                }
            },
            error:function(error){
                snacbar(error.statusText)
            }
        })//ajax end here
    })//Product edit form function end here
    /*Product Edit End*/

    /* Product Status Start */ 
    $(document).on("click", ".status", function(event) {
        event.preventDefault()
        $.ajax({
            type: "GET",
            url: $(this).data("url"),
            success: function(response) {
                if (response.success) {
                    $("#product_table").DataTable().ajax.reload();
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end here
    })//function end here    
    /* Product Status End */ 

    /* Product Delete Start */ 
    $(document).on("click", "button.delete", function() {
        $("#id").val($(this).data("id"))
        $(".modal-title").text("Product: " + $(this).data("name")) 
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $("#product_table").DataTable().ajax.reload();
                    $("#confirmModal").modal("hide");
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end here
    })//form end here
    /* Product Delete End */ 
    /* Add && Show functions start*/
    function showProduct(data){
        console.log(data)
        if(data.status == 1){
            $('input[type="checkbox"]').prop("checked", true)
            $("#product_stat").val(1)
        }
        else{
            $('input[type="checkbox"]').prop("checked", false)
            $("#product_stat").val(0)
        }
        $("input[type='text']").addClass("text-capitalize")
        $("#product_name").val(data.name)
        $("#product_desc").val(data.desc)
        $("#product_mrp").val(data.mrp)
        $("#brand_id").select2({width:"100%" }).val(data.brand).trigger("change");
        $("#production").select2({width:"100%" }).val(data.production).trigger("change");
        $("#primary_unit").select2({width:"100%" }).val(data.punitid).trigger("change");
        $("#secondary_unit").select2({width:"100%" }).val(data.sunitid).trigger("change");
        $("#image-update").val(data.image)
        $("#show-img").attr("src", data.image)
        $("#addBtn").hide() 
        $("#convBtn").hide()
        $("#selectedPriUnit").text('1 '+data.punitname)
        $("#selectedPriUnit2").text('Price/'+data.punitname)
        $("#priUnit_price").val(data.primaryunitrate)
        $("#selectedSecUnit").text(data.sunitname)
        $("#selectedSecUnit2").text('Price/'+data.sunitname)
        $("#secUnit_price").val(data.secondaryunitrate)  
        $("#no_of_pcs").val(data.noofpcs) 
        $(".unitprice").show()
        $(".conversion").show()        
        $("#modal").modal("show")
    }
    /* Add && Show functions end*/
});