$(document).ready(function() {
	/*-------- Show bank modal start -------*/
    $(document).on('click', '#addLoanAc', function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        $('.modal-title').text('Add Loan Account')
        $("#computeForm")[0].reset()
        $("#addBtn").show()
        $("#editBtn").hide()
    })
    /*-------- Show bank modal start -------*/
    $("#computeForm").on('keyup', '#year', function(event) {
        event.preventDefault()
        let year = $("#year").val() 
        let month = year*12;
        $("#month").val(month);
    })

    $("#computeForm").on('keyup', '#month', function(event) {
        event.preventDefault()
        let month = $("#month").val() 
        let year = month/12;
        if(year >= 1){
        	$("#year").val(parseInt(year));
        }
        else{
        	$("#year").val(0);
        }        
    })
    /*-------- Save bank accounts start -------*/
    $("#computeForm").on('click', '#computeBtn', function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        var formData = new FormData($("#computeForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.compute,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(res) {
                console.log(res)
                if (res.errors) {
                    if (res.errors.account_name) {
                        $("#account_name_error").text(res.errors.account_name[0])
                    }
                    if (res.errors.loan_amount) {
                        $("#loan_amount_error").text(res.errors.loan_amount[0])
                    }
                    if (res.errors.interest_rate) {
                        $("#interest_rate_error").text(res.errors.interest_rate[0])
                    }
                    if (res.errors.month) {
                        $("#tenure_error").text(res.errors.month[0])
                    }
                    if (res.errors.date) {
                        $("#date_error").text(res.errors.date[0])
                    }
                } 
                else {
                    // $("#loanForm")[0].reset()
                    // // $("#bank_trnx_table").DataTable().ajax.reload()
                    // $("#loanAccountModal").modal("hide")
                    // let message = response.success;
                    // loanaccounts = response.loanaccounts;
                    // loanAcList()
                    // snacbar(message)
                    $("#monthWiseTable tbody").append().empty()
                    for($i=0; $i<res.length; $i++){
                        tr = '<tr>'
                            +'<td>'+res[$i].month+'</td>'
                            +'<td>'+moment(res[$i].paymentDate).format("DD-MM-YYYY")+'</td>'
                            +'<td>'+res[$i].principalPaid+'</td>'
                            +'<td>'+res[$i].interest+'</td>'
                            +'<td>'+res[$i].totalPayment+'</td>'
                            +'<td>'+res[$i].endingBalance+'</td>'                          
                        +'</tr>'
                        $("#monthWiseTable tbody").append(tr)
                    }
                    
                }

            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })

    })
    /*-------- Compute Loan end -------*/
    /*-------- Save loan accounts start -------*/
    $("#loanForm").on('click', '#addBtn', function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        var formData = new FormData($("#loanForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if (response.errors.account_name) {
                        $("#account_name_error").text(response.errors.account_name[0])
                    }
                    if (response.errors.loan_amount) {
                        $("#loan_amount_error").text(response.errors.loan_amount[0])
                    }
                    if (response.errors.interest_rate) {
                        $("#interest_rate_error").text(response.errors.interest_rate[0])
                    }
                    if (response.errors.month) {
                        $("#tenure_error").text(response.errors.month[0])
                    }
                    if (response.errors.date) {
                        $("#date_error").text(response.errors.date[0])
                    }
                } else {
                    $("#loanForm")[0].reset()
                    // $("#bank_trnx_table").DataTable().ajax.reload()
                    $("#loanAccountModal").modal("hide")
                    let message = response.success;
                    loanaccounts = response.loanaccounts;
                    loanAcList()
                    snacbar(message)
                }

            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })

    })
    /*-------- Save loan accounts end -------*/

    /*-------- Show  loan accounts start ------*/  
    window.loanAcList = function() {
        $("#loanAcList").empty().append('')
        for (let i = 0; i < loanaccounts.length; i++) {
            let amount
            if(loanaccounts[i].loan_balance >= 0){
                amount = '<span class="badge bg-primary-lt inr-sign" style="float: right; margin-top: 12px;"> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(loanaccounts[i].loan_balance)  + '</span></br>' 
            }
            if(loanaccounts[i].loan_balance < 0){
                amount = '<span class="badge bg-danger-lt inr-sign" style="float: right; margin-top: 12px;"> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(loanaccounts[i].loan_balance)  + '</span></br>' 
            }

            $("#loanAcList").append('<li>' +
                '<a href="javascript:void(0);" data-pjax-state="anchor" class="b-b item-company text-primary b-account" data-name="' + loanaccounts[i].account_name + '">' +
                '<span class="nav-text text-capitalize">' + loanaccounts[i].account_name + '' +
                '<p class="item-except text-muted text-sm h-1x">' + moment(loanaccounts[i].date, 'YYYY-MM-DD').format("DD-MM-YYYY") + '</p></span>' +
                '<span class="nav-badge">' + amount +       
                '<span class="badge bg-secondary-lt b-account-view" style="float: right;" id="' + loanaccounts[i].loan_ac_id + '" data-name="' + loanaccounts[i].account_name + '" data-loanamount="' + loanaccounts[i].loan_amount + '" data-interest="' + loanaccounts[i].interest_rate + '" data-years="' + loanaccounts[i].years + '" data-years="' + loanaccounts[i].years + '" data-month="' + loanaccounts[i].month + '" data-remarks="' + loanaccounts[i].remarks + '">' +
                '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye mx-2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg></span>' +
                '</span>' +
                '</a>' +
                '</li>')
            let loanAcList = '<option class="text-capitalize" value="'+loanaccounts[i].loan_ac_id+'">'+loanaccounts[i].account_name+'</option>'
            $("#b2c_baccount_id").append(loanAcList)
            $("#c2b_baccount_id").append(loanAcList)
            $("#edit_baccount_id").append(loanAcList)
        }

    }
    loanAcList()
     /*-------- Show  loan accounts end ------*/  
})