$(document).ready(function () { 
    /*-------- Sales DataTable Start Here --------*/    
    var customrDataTable = $("#customer_table").DataTable({
        processing: true,
        responsive: true,
        serverSide: true,  
        "lengthChange": false,
        dom:'ltip',
        buttons: [
            { extend: 'csv', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'excel', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7]}},
            { extend: 'pdf', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'print', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}}
        ],
        ajax: {
            url: routes.all
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex",
            render: function(data){
                return '<small class="text-muted">'+data+'</small>'
            }
        }, {
            data: "name",
            name: "name",      
        }, {
            data: "phone_1",
            name: "phone_1",
            render: function(data){
                return '<a class="btn btn-raised btn-wave btn-icon btn-rounded" href="tel:+91 '+data+'">'
                                +'<span class="nav-icon text-primary">'
                                    +'<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-phone"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>'
                                +'</span>'
                            +'</a>'
            }
        },{
            data: "action",
            name: "action"
        }],

    });
    /*------ Sale dataTable end ------*/

    /*------- Search function start ----------*/
    $("#searchUser").on("keyup", function () {
        $(this).attr("placeholder", "Search");        
        var value = $(this).val().toLowerCase();
        customrDataTable.search(value).draw();
        // $("#userList .list-item").filter(function () {
        //     $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1) //this to show if there is value
        //     //$(".no-result").toggle($(this).text().toLowerCase().indexOf(value) === -1) //if no values then show this div
        // });
    });
    /*------- Search function end ----------*/
console.log(customrDataTable.rows().count())
    /*------- Select table lenght start -------*/
    $("select.paging").on('change',function(event){
        event.preventDefault()
        if($(this).val() == 'all'){
            customrDataTable.page.len( -1 ).draw();
        }
        else{
            customrDataTable.page.len( $(this).val() ).draw();
        }
    })
    /*------- Select table lenght end -------*/

    /*------- on select route draw table start ------*/
    $(document).on('click','#_routeSelect',function(event){
        event.preventDefault()
        var value = $(this).data('name').toLowerCase();
        customrDataTable.search(value).draw();
    })
    /*------- on select route draw table end ------*/

    /* Edit Customer Modal Start*/
    $(document).on('click', '.edit', function (event) {
        event.preventDefault()
        $("#customer_id").val($(this).data('id'))
        $("#f_name").val($(this).data('fname'))
        $("#s_name").val($(this).data('sname'))
        $("#shop_name").val($(this).data('shop'))
        $("#phone_1").val($(this).data('phone1'))
        $("#phone_2").val($(this).data('phone2'))
        $("#whatsapp_no").val($(this).data('whatsapp'))
        $("#email").val($(this).data('email'))
        $("#route").select2({width:"100%" }).select2('val', $(this).data('route').toString());
        $("#locality").val($(this).data('locality'))
        $("#district").select2({width:"100%"}).val($(this).data('district')).trigger("change");
        $("#pin").val($(this).data('pin'))
        $("#addline_1").val($(this).data('addline1'))
        $("#addline_2").val($(this).data('addline2'))
        $("#editModal").modal('show')
    })
    /*Edit Customer Modal End here*/
    /* Edit Customer Form Start*/
    $("#editCustomerForm").on('click', '#editBtn', function (event) {
        event.preventDefault()
        $( '.text-danger' ).html( "" );

        let postData = new FormData($('#editCustomerForm')[0])
        $.ajax({
            type: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: postData,
            success: function (response) {
                if(response.errors){
                    if(response.errors.f_name){
                        $("#f_name_error").text(response.errors.f_name[0])
                    }
                    if(response.errors.s_name){
                        $("#s_name_error").text(response.errors.s_name[0])
                    }
                    if(response.errors.shop_name){
                        $("#shop_name_error").text(response.errors.shop_name[0])
                    }
                    if(response.errors.phone_1){
                        $("#phone_1_error").text(response.errors.phone_1[0])
                    }
                    if(response.errors.phone_2){
                        $("#phone_2_error").text(response.errors.phone_2[0])
                    }
                    if(response.errors.whatsapp_no){
                        $("#whatsapp_no_error").text(response.errors.whatsapp_no[0])
                    }
                    if(response.errors.locality){
                        $("#route_error").text(response.errors.route_id[0])
                    }
                    if(response.errors.locality){
                        $("#locality_error").text(response.errors.locality[0])
                    }
                    if(response.errors.district){
                        $("#district_error").text(response.errors.district[0])
                    }
                    if(response.errors.pin){
                        $("#pin_error").text(response.errors.pin[0])
                    }
                    if(response.errors.email){
                        $("#email_error").text(response.errors.email[0])
                    }
                }
                //on success
                else{
                    $("#userList").load(window.location + " #userList")
                	$("#content-body").load(window.location + " #content-body")
                	$("#editModal").modal('hide')
                    let message = response.success;
                    snacbar(message)
                }
                
            },//ajax success end
            error: function (error) {
                snacbar(error.statusText)
            }//ajax error end
        })//ajax end 
    })
    /*Edit Customer Form Function End*/

    /*Customer Remove Start*/
    $(document).on('click', '.trash', function (event) {
        event.preventDefault()
        $("#id").val($(this).data("id"))
        $(".modal-title").text("Shop : " + $(this).data("shop")) 
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })//Customer Remove ID valuye set to modal

    //ajax call function
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $("#userList").load(window.location + " #userList")
                    $("#confirmModal").modal("hide");
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end here
    })//form end here
    /*Customer Remove End*/
    
})
