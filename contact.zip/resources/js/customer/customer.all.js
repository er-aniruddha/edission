$(document).ready(function () {        
    $("#searchUser").on("keyup", function () {
        $(this).attr("placeholder", "Search");
        var value = $(this).val().toLowerCase();
        $("#userList .list-item").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1) //this to show if there is value
            //$(".no-result").toggle($(this).text().toLowerCase().indexOf(value) === -1) //if no values then show this div
        });
    });//search function end here

    /* Edit Customer Modal Start*/
    $(document).on('click', '.edit', function (event) {
        event.preventDefault()
        $("#customer_id").val($(this).data('id'))
        $("#f_name").val($(this).data('fname'))
        $("#s_name").val($(this).data('sname'))
        $("#shop_name").val($(this).data('shop'))
        $("#phone_1").val($(this).data('phone1'))
        $("#phone_2").val($(this).data('phone2'))
        $("#whatsapp_no").val($(this).data('whatsapp'))
        $("#email").val($(this).data('email'))
        $("#route").select2({width:"100%" }).select2('val', $(this).data('route').toString());
        $("#locality").val($(this).data('locality'))
        $("#district").select2({width:"100%"}).val($(this).data('district')).trigger("change");
        $("#pin").val($(this).data('pin'))
        $("#addline_1").val($(this).data('addline1'))
        $("#addline_2").val($(this).data('addline2'))
    })
    /*Edit Customer Modal End here*/
    /* Edit Customer Form Start*/
    $("#editCustomerForm").on('click', '#editBtn', function (event) {
        event.preventDefault()
        $( '#f_name_error' ).html( "" );
        $( '#s_name_error' ).html( "" );
        $( '#shop_name_error' ).html( "" );
        $( '#phone_1_error' ).html( "" );
        $( '#phone_2_error' ).html( "" );
        $( '#whatsapp_no_error' ).html( "" );
        $( '#route_error' ).html( "" );
        $( '#locality_error' ).html( "" );
        $( '#district_error' ).html( "" );
        $( '#pin_error' ).html( "" );
        $( '#email_error' ).html( "" );

        let postData = new FormData($('#editCustomerForm')[0])
        $.ajax({
            type: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: postData,
            success: function (response) {
                if(response.errors){
                    if(response.errors.f_name){
                        $("#f_name_error").text(response.errors.f_name[0])
                    }
                    if(response.errors.s_name){
                        $("#s_name_error").text(response.errors.s_name[0])
                    }
                    if(response.errors.shop_name){
                        $("#shop_name_error").text(response.errors.shop_name[0])
                    }
                    if(response.errors.phone_1){
                        $("#phone_1_error").text(response.errors.phone_1[0])
                    }
                    if(response.errors.phone_2){
                        $("#phone_2_error").text(response.errors.phone_2[0])
                    }
                    if(response.errors.whatsapp_no){
                        $("#whatsapp_no_error").text(response.errors.whatsapp_no[0])
                    }
                    if(response.errors.locality){
                        $("#route_error").text(response.errors.route_id[0])
                    }
                    if(response.errors.locality){
                        $("#locality_error").text(response.errors.locality[0])
                    }
                    if(response.errors.district){
                        $("#district_error").text(response.errors.district[0])
                    }
                    if(response.errors.pin){
                        $("#pin_error").text(response.errors.pin[0])
                    }
                    if(response.errors.email){
                        $("#email_error").text(response.errors.email[0])
                    }
                }
                //on success
                else{
                	$("#userList").load(window.location + " #userList")
                	$("#editModal").modal('hide')
                    let message = response.success;
                    snacbar(message)
                }
                
            },//ajax success end
            error: function (error) {
                snacbar(error.statusText)
            }//ajax error end
        })//ajax end 
    })
    /*Edit Customer Form Function End*/

    /*Customer Remove Start*/
    $(document).on('click', '.trash', function (event) {
        event.preventDefault()
        $("#id").val($(this).data("id"))
        $(".modal-title").text("Shop : " + $(this).data("shop")) 
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })//Customer Remove ID valuye set to modal

    //ajax call function
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $("#userList").load(window.location + " #userList")
                    $("#confirmModal").modal("hide");
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end here
    })//form end here
    /*Customer Remove End*/
})
