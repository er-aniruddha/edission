$(document).ready(function(){    
    var proId; 
    var maxRowCount, minRowCount,slRowCount_cartInputTable;
    var qtyinput_val, qtyinput_maxVal;
    var stocks = window.stocks;
    var toShowListOfStock = window.stocks;
    window.allCartProducts = []
   
    // Buy button click start
    $(document).on('click','button.buyBtn', function(event){
        event.preventDefault()
        slRowCount_cartInputTable=1
        maxRowCount=0
        minRowCount=0
        var chkThisProduct = 0 // this is to check, to add row
        proId = $(this).attr('id') //product_id
        var name = $(this).data('name') //product_name        
        for(let i=0; i< stocks.length; i++){
            if( stocks[i].item_name == proId){
                maxRowCount++ // for max number of row to show
            }
        } 
        if(window.allCartProducts.length != 0){
            for(var i=0; i < window.allCartProducts.length; i++){
                if(window.allCartProducts[i].product_id == proId){
                    var stockId = window.allCartProducts[i].stock_id
                    var qty = window.allCartProducts[i].qty
                    var discount = window.allCartProducts[i].discount
                    chkThisProduct++;
                    addRow(stockId, qty, discount)
                }
            }
            if(chkThisProduct == 0){
                addRow()
            }
        }
        else{            
            addRow()
        }     
        $(".modal-title").text("Place Order : " +name)
        $("#addToCart").modal('show')
    })
    // Buy button click end    
    // Add row to form START
    $('#_addRow').on('click',function() {
        qtyinput_val = $("#cartInputTable tbody tr:last").children('td:nth-last-child(2)').children('.qty').val();
        qtyinput_maxVal = $("#cartInputTable tbody tr:last").children('td:nth-last-child(2)').children('.qty').attr('max');       
        if(qtyinput_val > 0){
            if(qtyinput_val == qtyinput_maxVal){
                if(minRowCount < maxRowCount){
                    addRow();
                }
                else{
                    snacbar("Max row added !!!")
                }                                
            }  
            else{                
                snacbar("Last SKU has quantity.")                
            }             
        }
        else{
            snacbar("Enter quantity first.")
        }
    })
    // Add row to form END
    function addRow(stockId, qty, discount) {
        if(stockId){            
            for(var count=0; count < stocks.length; count++){
                if(stockId == stocks[count].stock_id){
                   var sku_code = stocks[count].sku_code+'-'+stocks[count].sku_count
                   var max = stocks[count].in_hand_stock
                }
            }
            $("#discount").val(discount)
            var tr = '<tr class="addedRow">'+
                '<td>'+slRowCount_cartInputTable+'</td>'+
                '<td>'+
                '<select class="form-control custom-select stockId" name="stock_id" id="stock_id">'+
                   '<option value="'+stockId+'">'+sku_code+'</option>'+
                '</select>'+
                '</td>'+ 
                '<td>'+
                '<input type="number" class="form-control qty" name="qty" id="qty" autocorrect="off" '+
                'autofocus="autofocus" autocomplete="off" animate="true" autocomplete="off" autocapitalize="off"'+ 
                'spellcheck="false" placeholder="Quantity" oninput="this.value = Math.round(this.value);" value="'+qty+'" '+
                'placeholder="Quantity" max="'+max+'">'+
                '</td>'+ 
                '<td><a href="javascript:void(0)" class="btn btn-icon remove" id="'+minRowCount+'"  data-count="'+minRowCount+'" style="border: 1px solid #f54394">' +
                    '<svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="color: red;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
                    '</a>'+            
                '</td>' +
                '</tr>';                   
                slRowCount_cartInputTable++;
                minRowCount++;
                // window.rowCount = minRowCount;
                $('#cartInputTable tbody').append(tr); 
                destroySelectedOption() 
        }       
        
        else{
            var tr = '<tr class="addedRow">'+
                    '<td>'+slRowCount_cartInputTable+'</td>'+
                    '<td>'+
                    '<select class="form-control custom-select stockId" name="stock_id" id="stock_id">'+
                       '<option selected="" value="">Select an option</option>'+  
                    '</select>'+
                    '</td>'+ 
                    '<td>'+
                    '<input type="number" class="form-control qty" name="qty" id="qty" autocorrect="off" '+
                    'autofocus="autofocus" autocomplete="off" animate="true" autocomplete="off" autocapitalize="off"'+ 
                    'spellcheck="false" placeholder="Quantity" oninput="this.value = Math.round(this.value);" value="" '+
                    'placeholder="Quantity" max="">'+
                    '</td>'+ 
                    '<td><a href="javascript:void(0)" class="btn btn-icon remove" id="'+minRowCount+'"  data-count="'+minRowCount+'" style="border: 1px solid #f54394">' +
                        '<svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="color: red;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
                        '</a>'+            
                    '</td>' +
                    '</tr>';                   
                    slRowCount_cartInputTable++;
                    minRowCount++;
                    window.rowCount = minRowCount;
                    $('#cartInputTable tbody').append(tr); 
                     //need to destroy prev selected option value                 
                    destroySelectedOption()
                     
            }
        $( "#cartInputTable tbody").children('tr').prev().children('td').children('.remove').hide();                
        $( "#cartInputTable tbody").children('tr').prev().children('td').children('.qty').attr('readonly',true);
        $("#cartInputTable tbody tr:nth-last-child(2)").children('td:nth-last-child(3)').children('.stockId').attr('disabled',true)
    }
    // Selected Product all SKU show Start
    function showStocks(msg){
        let proId = msg  
        for(let count=0; count< toShowListOfStock.length; count++){
            if( toShowListOfStock[count].product_id == proId){
                $("#cartInputTable tbody tr:last").children('td:nth-last-child(3)').children('.stockId').append('<option value="'+toShowListOfStock[count].stock_id+'">'+toShowListOfStock[count].sku_code+'-'+toShowListOfStock[count].sku_count+'</option>')
            }
        }                      
    }
    // Get Selected Product all SKU show end
    // need to destroy selected option start
    function destroySelectedOption(){
        var data = $("#cartInputTable tbody tr:nth-last-child(2)").children('td:nth-last-child(3)').children('.stockId').val()
        for (var i=0; i < toShowListOfStock.length; i++) {
            if( data ==  toShowListOfStock[i].stock_id){
                toShowListOfStock = toShowListOfStock.filter(function(elem){
                   return elem != toShowListOfStock[i];
                });
            }
        }
        showStocks(proId)
    }
    // need to destroy selected option end
    // Remove row start of FORM
    $(document).on('click', '.remove', function() {  
        if(slRowCount_cartInputTable < 3){
            alert("You can not remove last row.")
        }
        else{
            var reEnterStockID = $("#cartInputTable tbody tr:last").children('td').children('.stockId').val();
            enterRmeoveRowStock(reEnterStockID)
            minRowCount--;
            slRowCount_cartInputTable--;    
            $(this).parent().parent().remove(); 
            qtyinput_val = $("#cartInputTable tbody tr:last").children('td:nth-last-child(2)').children('.qty').val();
            qtyinput_maxVal = $("#cartInputTable tbody tr:last").children('td:nth-last-child(2)').children('.qty').attr('max');
            $("#cartInputTable tbody tr:last").children('td:nth-last-child(2)').children('.qty').attr('readonly',false)
            $("#cartInputTable tbody tr:last").children('td').children('.stockId').attr('disabled',false) 
            $("#cartInputTable tbody tr:last").children('td').children('.remove').show();
        }
        
    });
    // Remove row end of FORM
    // re-enter stock to liast variable after remove row function start
    function enterRmeoveRowStock(id){
        // first remove data if already exists
        for (var i=0; i < toShowListOfStock.length; i++) {
            if( id ==  toShowListOfStock[i].stock_id){
                toShowListOfStock = toShowListOfStock.filter(function(elem){
                   return elem != toShowListOfStock[i];
                });
            }
        }
        for(var i=0; i < stocks.length; i++){
            if(id == stocks[i].stock_id){
                toShowListOfStock = toShowListOfStock.filter(function(elem){
                   return elem != toShowListOfStock[i];
                });
                toShowListOfStock.push(stocks[i])
            }
        }  
    }
    // re-enter stock to liast variable after remove row function end
    // On Select SKU change fiels and show error Start
    $(document).on('change' , '.stockId' , function(event) {
        event.preventDefault()           
        var thisId = $(this).val(); // stock_id
        if(thisId){
            for(let i=0; i< toShowListOfStock.length; i++){
                if( toShowListOfStock[i].stock_id == thisId){
                    var  maxValue =  toShowListOfStock[i].in_hand_stock
                }
            }     
            $(this).parent().parent().children('td').children('.qty').attr({
                "placeholder":"Max : "+maxValue+"",
                "max" : maxValue,
            })   
            $(this).removeClass('is-invalid')
            $(this).addClass('is-valid')
        } 
        
    })
    // On Select SKU change fiels and show error End
    // Input type discount change function Start
    $('#discount').keyup(function() {   
        let val = $(this).val();
        if(!val ){            
            $(this).addClass('is-invalid')
        }
        else{
            $(this).removeClass('is-invalid')
            $(this).addClass('is-valid')                
        }         
    })
    // Input type discount change function End
    // Input type Quantity change function Start
    $('#cartInputTable tbody').delegate('.qty','keyup', function() {       
        let max = $(this).attr("max");
        let val = parseInt($(this).val(), 10);        
        if(max){            
            if(val > max || val < 1){
                $(this).addClass('is-invalid')
                $("#cartInputTable thead th:last").children('.addRow').prop('disabled', true); //disable add button
            }
            else{
                $(this).removeClass('is-invalid')
                $(this).addClass('is-valid')
                $("#cartInputTable thead th:last").children('.addRow').prop('disabled', false); //enable add button
            }            
        }
        else{
            snacbar("Select respective SKU first")
            $(this).addClass('is-invalid')
        }
    })
    // Input type Quantity change function End
    // Form submit btn press start
    $(document).on('click','#addToCartBtn',function( event ) {      
        event.preventDefault();
        $("#addToCartForm :input").map(function(){
            if( !$(this).val() ) {
                $(this).addClass('is-invalid');
            }              
        });   
        var error = $('.is-invalid').length;
        if(error == 0){ 
            // if products already in cart then destroy first then re-enter
            for(var x =0; x < window.allCartProducts.length; x++){
                if(proId == window.allCartProducts[x].product_id){
                    window.allCartProducts = window.allCartProducts.filter(function(elem){
                       return elem.product_id != window.allCartProducts[x].product_id; 
                    });
                }
            } 
            //to get data of select value before submit need below function
            $("#cartInputTable tbody tr").children('td:nth-last-child(3)').children('.stockId').attr('disabled',false)
            $("#cartInputTable tbody tr:last").children('td:nth-last-child(2)').children('.qty').attr('readonly',false) 
            var formSerialData = $("#addToCartForm").serializeArray();
            for(var count=1; count < formSerialData.length; count++){                             
                data = 
                {
                    discount : formSerialData[0].value,
                    stock_id: formSerialData[count].value,
                    qty: formSerialData[++count].value,
                    product_id : proId
                }
                window.allCartProducts.push(data)  //All form data save in this variable  
            } 
            toShowListOfStock = []
            addToCart()
        }
        else{
            snacbar("Check all error fields.")
        }
    });
    // Form submit btn press End    
    // To show all cart product to invoice list Start
    var cartSlNo = 1; 
    function addToCart(){  
        var totalQty=0;   
        var productName,productMrp;
        var stock_id,discount;
        for(var count=0; count < window.allCartProducts.length; count++){
            if(proId == window.allCartProducts[count].product_id){
                totalQty = totalQty + (+window.allCartProducts[count].qty);
                stock_id = window.allCartProducts[count].stock_id
                discount = window.allCartProducts[count].discount
            }
            
        }// total quantity loop end
        for(var i=0; i < stocks.length; i++){
            if(stock_id == stocks[i].stock_id){
                productName = stocks[i].product_name;
                productMrp = stocks[i].product_mrp;
            }
        }
        // first remove all product from cart tabel then re-add
        $("#cartTable tbody").children('.'+proId+'').remove()
        if(discount != 0){
            $("#cartTable tbody").append('<tr class="'+proId+'" style="border-bottom: 1px solid rgba(32, 133, 200, 0.07);">'+
            '<td>'+cartSlNo+'</td>'+
            '<td>'+productName+
                '<div class="text-muted" style="font-size:11px;">Price : &#8377;'+productMrp+'</div>'+
                '<div style="font-size:11px; color: #ff5722;">Discount : &#8377;'+discount+'</div>'+
                '<div style="font-size:.75rem; color: #535c78;">Discounted Price : &#8377;'+(productMrp - discount)+'</div>'+
            '</td>'+
            '<td class="text-right">'+totalQty+'</td>'+
            '<td class="text-right ctotalColumn">'+
                '<div class="text-dark" > &#8377;<span class="csubTotal">'+(totalQty*productMrp)+'</span></div>'+
                '<div style="font-size:.875rem; color: #ff5722;">&#8377;<span class="cdiscount">'+(totalQty*discount)+'</span></div>'+
                '<div style="border-bottom: 1px solid rgba(32, 133, 200, 0.11); margin-left:50%;"></div>'+
                '<div style="font-size:.75rem; color: #535c78;">'+
                'Discounted Price = &#8377;<span class="cdiscounted">'+((totalQty*productMrp)-(totalQty*discount))+'</span></div>'+
            '</td>'+
            '<td class="text-right">'+
                '<a href="javascript:void(0)" class="proRemove" id="'+proId+'">'+
                    '<span class="badge badge-danger text-uppercase">x</span>'+
                '</a>'+  
            '</td>'+
            '</tr>');
        }
        else{
            $("#cartTable tbody").append('<tr class="'+proId+'" style="border-bottom: 1px solid rgba(32, 133, 200, 0.07);">'+
            '<td>'+cartSlNo+'</td>'+
            '<td>'+productName+
                '<div class="text-muted" style="font-size:11px;">Price : &#8377;'+productMrp+'</div>'+
            '</td>'+
            '<td class="text-right">'+totalQty+'</td>'+
            '<td class="text-right ctotalColumn">'+
                '<div class="text-dark" > &#8377;<span class="csubTotal">'+(totalQty*productMrp)+'</span></div>'+                
            '</td>'+
            '<td class="text-right">'+
                '<a href="javascript:void(0)" class="proRemove" id="'+proId+'">'+
                    '<span class="badge badge-danger text-uppercase">x</span>'+
                '</a>'+  
            '</td>'+
            '</tr>');   
        }
        cartSlNo++;         
        tableTotal()
        resetForm()
    }
    // To show all cart product to invoice list End
    // Cancel modal click function start
    $(document).on('click','#cancelCartBtn',function(event){
        event.preventDefault()
        toShowListOfStock = []
        resetForm()        
    })
    // Cancel modal click function end
    // Reset form after cancel/submit start
    function resetForm(){ 
        // this is required to re-store all the listed stock to variable
        toShowListOfStock = window.stocks;
        $('.addedRow').remove()
        $("#addToCartForm :input").map(function(){
            $(this).removeClass('is-invalid');
            $(this).removeClass('is-valid');
        });
        $(".stockId").empty().append('<option selected="" value="">Select an option</option>')
        $('#qty').attr({
            "placeholder": "Quantity",
            "max":"",            
        })
        $('#qty').val("")
        $('#discount').val("")
        $("#cartInputTable tbody tr:last").children('td').children().attr('disabled',false)
        $("#addToCart").modal('hide')
    }
    // Reset form after cancel/submit end
    
    // sum of cartTotal table function start
    function tableTotal(){
        var subtotal = 0, discount=0, discounted=0, shipping=0, total=0;
        $("#cartTable tbody tr").children('td:nth-last-child(2)').children().children('.csubTotal').each(function(){
        subtotal += parseFloat($(this).text());        
        })
        $("#cartTotaltable tbody tr td").children().children('.tsubTotal').text(subtotal)
        // subtotal end
        $("#cartTable tbody tr").children('td:nth-last-child(2)').children().children('.cdiscount').each(function(){
            discount += parseFloat($(this).text());
        })
        $("#cartTotaltable tbody tr td").children().children('.tdiscount').text(discount)
        // discount end          
        discounted = subtotal - discount;
        $("#cartTotaltable tbody tr td").children().children('.tdiscounted').text(discounted)
        // discounted end
        shipping = 0
        $("#cartTotaltable tbody tr td").children().children('.tshipping').text(shipping)
        // shipping end
        total = (subtotal + shipping) - discount
        $("#cartTotaltable tbody tr td").children().children('.tTotal').text(total)
        // discount end  

    }
    // sum of cartTotal table function end
     
});

