$(document).ready(function() {
		$("#showRouteInput").click(function(){
			$('.route-input').show();
			$('#addBtn').show()
			$('#editBtn').hide()
			$('#route_name').val(null).removeClass('text-info').css('border-color', "#ccc")
		})

		$('#routeForm').on('click', '#addBtn', function (e) {
            e.preventDefault();
            $('#route_name_error').html("")

            if(!$("#route_name").val()){
            	$('input.form-control.routes').addClass('is-invalid');
            }
            else{
            	$('input.form-control.routes').removeClass('is-valid');  
	            $('input.form-control.routes').removeClass('is-invalid');     

	            var formData = new FormData($('#routeForm')[0]);

	            $.ajax({
	                method: 'POST',
	                url: croutes.create,
	                contentType: false,
	                cache: false,
	                processData: false,
	                dataType: "json",
	                data: formData,
	                success: function (response) {
	                	if(response.errors){
	                		if(response.errors.route_name){
	                			$('#route_name_error').text(response.errors.route_name[0])
	                			$('input.form-control.routes').addClass('is-invalid');
	                		}
	                	}
	                	if (response.success)
	                	{
	                		$('input.form-control.routes').addClass('is-valid'); 
	                		$("#routeList").load(window.location + " #routeList");
	                	}
	          	    },//success end here
	          	    error:function(error){
	          	    	$('#route_name_error').text(error.statusText)
	          	    }
	            })//ajax end here
            }            
        })//add route form end here

        $(document).on('click', "#_routeSelect", function(){
        	var value = $(this).data('name').toLowerCase();      	

        	$("#userList .list-item").filter(function () {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1) //this to show if there is value

                //$(".no-result").toggle($(this).text().toLowerCase().indexOf(value) === -1) //if no values then show this div
            });
        })

        $("#editRoute").click(function(event) {
        	event.preventDefault()
        	$(".counter, .thisRoute").toggle()  
        	$(".feather-edit.route, .feather-x, .route").toggle()     	
        });

        $(document).on('click','.thisRoute',function(event) {
        	event.preventDefault()
        	/* Act on the event */        	
        	$('#addBtn').hide()
			$('#editBtn').show()
			$('#route_id').val($(this).data('id'))
        	let id = $(this).data('id')
        	let name = $(this).data('name')
        	$('#route_name').addClass('text-info')
        	$('#route_name').val(name)
        	$('.route-input').show()
        });

        $('#routeForm').on('click', '#editBtn', function (e) {
            e.preventDefault();
            $('#route_name_error').html("")
            if(!$("#route_name").val()){
            	$('input.form-control.routes').addClass('is-invalid');
            }
            else{
            	$('input.form-control.routes').removeClass('is-valid');  
	            $('input.form-control.routes').removeClass('is-invalid');     

	            var formData = new FormData($('#routeForm')[0]);

	            $.ajax({
	                method: 'POST',
	                url: croutes.update,
	                contentType: false,
	                cache: false,
	                processData: false,
	                dataType: "json",
	                data: formData,
	                success: function (response) {
	                	if(response.errors){
	                		if(response.errors.route_name){
	                			$('#route_name_error').text(response.errors.route_name[0])
	                			$('input.form-control.routes').addClass('is-invalid');
	                		}
	                	}
	                	if (response.success)
	                	{
	                		$('input.form-control.routes').addClass('is-valid'); 	                		
	                		$("#routeList").load(window.location + " #routeList");
        					$(".feather-edit.route, .feather-x, .route").toggle()
        					$('#route_name').val("")
        					$('.route-input').hide()
	                	}
	          	    },//success end here
	          	    error:function(error){
	          	    	$('#route_name_error').text(error.statusText)
	          	    }
	            })//ajax end here
            }            
        })//add route form end here
	});