$(document).ready(function(){
	// Initialize Date Start
    $('.date').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
        width: "100%",
        startDate: "01-04-2021",
        endDate: "0d",
        todayHighlight: true,
    }).on("change", function() {
        $(this).removeClass('is-invalid');
        $(this).addClass('is-valid');
    });
    // Initialize Date End
    $(document).on('click',"#orderBtn", function(event){
    	event.preventDefault()
    	$("input.date").map(function(){
            if( !$(this).val() ) {
                $(this).addClass('is-invalid');
            }              
        });
    })
    // remove products from cart table function start
    $(document).on('click','a.proRemove',function(event){
        event.preventDefault()
        var result = confirm('Are you sure you want to delete this item?');
        if(result){
            let id = $(this).attr('id');
            for(var i=0; i< window.allCartProducts.length; i++){
                if(id == window.allCartProducts[i].product_id){
                    window.allCartProducts = window.allCartProducts.filter(function(elem){
                        return elem != window.allCartProducts[i];
                    })
                }
            }
            $(this).parent().parent().remove();
        } 
       
    })
    // renove products from cart table function end
})