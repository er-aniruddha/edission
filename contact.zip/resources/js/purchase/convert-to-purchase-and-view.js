$(document).ready(function(){
    /*------ PurchaseOrder View Start ------*/
    $(document).on("click", "button.view", function(event) {
        let po_id = $(this).attr('id');
        $("a.addRow").show()
        $(".addedRow").remove()
        $("#convertPOBtn").hide()
        $(".delivery-date").hide()
        $("#conver2PurchaseModal .modal-title").text("Purchase Order Details #PO-" + po_id)
        $('#c2pRoWFrom tbody').empty().append();
        c2pModalDetails(po_id)
    })
    /*------ PurchaseOrder View End ------*/

	/*------ Order Completion Function Start -----*/
    $(document).on('click', ".over-due", function() {
        let po_id = $(this).attr('id');
        $("#c2p_po_id").val(po_id)
        $("a.addRow").show()
        $(".addedRow").remove()
        $("#convertPOBtn").show()
        $(".delivery-date").show()
        $("#conver2PurchaseModal .modal-title").text("Purchase Order Details #PO-" + po_id)
        $('#c2pRoWFrom tbody').empty().append();
        c2pModalDetails(po_id)
    })
    $("#convertToPurchaseForm").on("click", "#convertPOBtn", function(event) {
        event.preventDefault()
        $("#loader").show()
        $("#convertToPurchaseForm .text-danger").html("")
        var formData = new FormData($("#convertToPurchaseForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.status,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                 $("#loader").hide()
            	if (response.errors) {
                    if (response.errors.delivery_date) {
                        $("#c2p_delivery_date_error").text(response.errors.delivery_date[0])
                    }
                }
                //on success
                else{
                	$('#purchase_order_table').DataTable().ajax.reload();
	                $("#conver2PurchaseModal").modal('hide')
	                $("#convertToPurchaseForm")[0].reset()
	                allPoItem = response.allPoItem
	                let message = response.success;
	                snacbar(message)
                }
            },
            error: function(error) {
                 $("#loader").hide()
                snacbar(error.statusText)
            }
        })
    })
    /*------ Order Completion Function Start -----*/
    function c2pModalDetails(po_id) {
    	for (var count = 0; count < allPoItem.length; count++){
    		if(po_id == allPoItem[count].po_id){
    			var tr = '<tr class="">' +
			            '<td>' +
			            	'<input class="form-control text-capitalize" value="' + allPoItem[count].product_name + ' - '+allPoItem[count].brand_name+'" readonly>' +
			            '</td>' +
			            '<td>' +
			            	'<input class="form-control text-capitalize" value="'+allPoItem[count].unit_name+'" readonly">' +
			            '</td>' +
			            '<td class="td-qty">' +
			            	'<input type="number" value="' + allPoItem[count].qty + '"  class="form-control" readonly>' +
			            '</td>' +
			            '<td>' +
			            	'<input type="number" value="' + allPoItem[count].unit_price + '"  class="form-control" readonly>' +	            
			            '</td>' +
			            '<td>' +
			            	'<input type="number" value="' + allPoItem[count].amount + '"  class="form-control" readonly>' +
			            '</td>' +
			            '</tr>';
			        $('#c2pRoWFrom tbody').append(tr);

			$("#c2p_order_date").val(moment(allPoItem[count].order_date, 'YYYY-MM-DD').format("DD-MM-YYYY"))
            $('#supplier_name').val(allPoItem[count].supplier_name);
            $('#c2p_payment_type').val(allPoItem[count].payment_type);
            $("#c2p_round_off").val(allPoItem[count].round_off)
            $("#c2p_delivery_charges").val(allPoItem[count].delivery_charges)
            $("#c2p_gst_amount").val(allPoItem[count].gst_amount)
            $("#c2p_total").val(allPoItem[count].total)
            $("#c2p_advance").val(allPoItem[count].advance)
            prevBalance = allPoItem[count].prev_balance
            $(".prev_bal").text('Previous Balance: '+prevBalance)
            $("#c2p_prev_balance").val(parseFloat(prevBalance))//this is to store
            $("#c2p_balance").val(parseFloat(allPoItem[count].PO_balance))//this is to store
            $("#c2p_remarks").val(allPoItem[count].remarks)

    		}
    	}
    	$("#conver2PurchaseModal").modal('show')
    }
	
})