$(document).ready(function(){   
    $('.date').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
        width: "100%",
        startDate: "01-04-2021",
        endDate: "0d",
        todayHighlight: true,
    })
    $('#fuel, #travelling ,#transport, #tiffin, #extra_exp').keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /* Expense Item DataTable Start Here*/
    var dataTable = $("#expense_table").DataTable({
        processing: true,
        serverSide: true,
        buttons: [
            { 
                extend: 'csv',
                exportOptions: {
                    columns: [ 0, 1, 2, 3,4,5,6,7 ]
                }            
            },
            { 
                extend: 'excel',
                exportOptions: {
                    columns: [ 0, 1, 2, 3,4,5,6,7 ]
                }              
            },
            { 
                extend: 'pdf',
                exportOptions: {
                    columns: [ 0, 1, 2, 3,4,5,6,7 ]
                }              
            },
            { 
                extend: 'print',
                exportOptions: {
                    columns: [ 0, 1, 2, 3,4,5,6,7 ]
                }           
            }
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex"
        }, {
            data: "date",
            name: "date"
        }, {
            data: "fuel",
            name: "fuel"
        },{
            data: "travelling",
            name: "travelling"
        }, {
            data: "transport",
            name: "transport"
        }, {
            data: "tiffin",
            name: "tiffin"
        }, {
            data: "extra_exp",
            name: "extra_exp"
        },{
            data: "total",
            name: "total"
        }, {
            data: "action",
            name: "action"
        }]
    });
    /* Expense Item DataTable End Here*/
    /* Export Start*/
    $(document).on('click',".export",function(){
        var btn = $(this).attr('id').toString()
        dataTable.button(btn).trigger();
    })
    /* Export End*/
    /* Toatal calculation*/
    $('.modal-body').delegate('#fuel, #travelling ,#transport, #tiffin, #extra_exp', 'keyup', function() {
        let fuel = $("#fuel").val()
        let travelling = $("#travelling").val()
        let transport = $("#transport").val()
        let tiffin = $("#tiffin").val()
        let extra_exp = $("#extra_exp").val()
        let total = (+fuel)+(+travelling)+(+transport)+(+tiffin)+(+extra_exp)
        $("#total").val(total.toFixed(2))
    });
    /* Toatal calculation*/
    /* Expense Item Add Start*/
    $(document).on("click", "button.add", function() {
        $(".modal-title").text("Add Expense")
        $('#expenseForm')[0].reset()
        $("#expense_id").val("")
        $(".text-danger").html("")
        // $('input.md-input').attr('value' , '')
        $("#addBtn").show()
        $("#editBtn").hide()

    })//to show modal for add
    $("#expenseForm").on("click", "#addBtn", function(event) {
        event.preventDefault()
        $("#date_error").html("")
        $("#fuel_error").html("")
        $("#travelling_error").html("")
        $("#transport_error").html("")
        $("#tiffin_error").html("")
        $("#extra_exp_error").html("")
        $("#total_error").html("")
        $("#remarks_error").html("")
        var formData = new FormData($("#expenseForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.fuel){
                        $("#fuel_error").text(response.errors.fuel[0])
                    }
                    if(response.errors.travelling){
                        $("#travelling_error").text(response.errors.travelling[0])
                    }
                    if(response.errors.transport){
                        $("#transport_error").text(response.errors.transport[0])
                    }
                    if(response.errors.tiffin){
                        $("#tiffin_error").text(response.errors.tiffin[0])
                    }
                    if(response.errors.extra_exp){
                        $("#extra_exp_error").text(response.errors.extra_exp[0])
                    }
                    if(response.errors.total){
                        $("#total_error").text(response.errors.total[0])
                    }
                    if(response.errors.remarks){
                        $("#remarks_error").text(response.errors.remarks[0])
                    }
                }                    
                else {
                    $("#expenseForm")[0].reset() 
                    // $('input.md-input').attr('value' , '')
                    $("#expense_table").DataTable().ajax.reload()
                    $("#modal").modal("hide")
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })
    })
    /* Expense Item Add End*/

     /* Expense Item View Start*/
    $(document).on("click", "button.view", function() {        
        $(".modal-title").text("Expense Details")
        $("#modal").modal("show") 
        $(".text-danger").html("")
        $("#date").val($(this).data("date"))
        $("#fuel").val($(this).data("fuel"))
        $("#travelling").val($(this).data("travelling"))
        $("#transport").val($(this).data("transport"))
        $("#tiffin").val($(this).data("tiffin"))
        $("#extra_exp").val($(this).data("others"))
        $("#total").val($(this).data("total"))
        // $("#total_price").attr('value',$(this).data("total")).val($(this).data("total"))
        $("#remarks").val($(this).data("remarks"))
        $("#addBtn").hide()
        $("#editBtn").hide()
    })
    /* Purchase Item View End*/
    /* Purchase Item Edit Start*/
    $(document).on("click", "button.edit", function() {    
       $(".modal-title").text("Expense Edit")
        $("#modal").modal("show") 
        $(".text-danger").html("")
        $("#expense_id").val($(this).attr("id"))
        $("#date").val($(this).data("date"))
        $("#fuel").val($(this).data("fuel"))
        $("#travelling").val($(this).data("travelling"))
        $("#transport").val($(this).data("transport"))
        $("#tiffin").val($(this).data("tiffin"))
        $("#extra_exp").val($(this).data("others"))
        $("#total").val($(this).data("total"))
        // $("#total_price").attr('value',$(this).data("total")).val($(this).data("total"))
        $("#remarks").val($(this).data("remarks"))
        $("#addBtn").hide()
        $("#editBtn").show()
    })//Purchase Item Edit show 
    $("#expenseForm").on("click", "#editBtn", function(event) {
        event.preventDefault()
        $("#date_error").html("")
        $("#fuel_error").html("")
        $("#travelling_error").html("")
        $("#transport_error").html("")
        $("#tiffin_error").html("")
        $("#extra_exp_error").html("")
        $("#total_error").html("")
        $("#remarks_error").html("")
        var formData = new FormData($("#expenseForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.fuel){
                        $("#fuel_error").text(response.errors.fuel[0])
                    }
                    if(response.errors.travelling){
                        $("#travelling_error").text(response.errors.travelling[0])
                    }
                    if(response.errors.transport){
                        $("#transport_error").text(response.errors.transport[0])
                    }
                    if(response.errors.tiffin){
                        $("#tiffin_error").text(response.errors.tiffin[0])
                    }
                    if(response.errors.extra_exp){
                        $("#extra_exp_error").text(response.errors.extra_exp[0])
                    }
                    if(response.errors.total){
                        $("#total_error").text(response.errors.total[0])
                    }
                    if(response.errors.remarks){
                        $("#remarks_error").text(response.errors.remarks[0])
                    }
                }                    
                else {
                    $("#expenseForm")[0].reset() 
                    // $('input.md-input').attr('value' , '')
                    $("#expense_table").DataTable().ajax.reload()
                    $("#modal").modal("hide")
                    let message = response.success;
                    snacbar(message)
                }
            },//success end
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end here
    })//Purchase Item edit form function end here
    /* Purchase Item Edit End*/
    
    /* Purchase Item Delete Start*/
    $(document).on("click", "button.delete", function() {
        $("#id").val($(this).data("id")) 
        $(".modal-title").text("Expense Date : " + $(this).data("date"))
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $("#expense_table").DataTable().ajax.reload()
                    $("#confirmModal").modal("hide");
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end
    })//Purchase Item Delete function end
    /* Purchase Item Delete End*/
});