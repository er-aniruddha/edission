$(document).ready(function(){   
    $('#fuel, #travelling ,#transport, #tiffin, #extra_exp').keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /* Expense Item DataTable Start Here*/
    var dataTable = $("#expense_table").DataTable({
        processing: true,
        serverSide: true,
        responsive: true,
        lengthMenu: [
            [10, 25, 50,100, -1],
            [10, 25, 50,100, 'All'],
        ],
        buttons: [
            { 
                extend: 'csv',
                exportOptions: {
                    columns: [ 0, 1, 2, 3,4,5,6,7,8,9 ]
                }            
            },
            { 
                extend: 'excel',
                exportOptions: {
                    columns: [ 0, 1, 2, 3,4,5,6,7,8,9 ]
                }              
            },
            { 
                extend: 'pdf',
                exportOptions: {
                    columns: [ 0, 1, 2, 3,4,5,6,7,8,9 ]
                }              
            },
            { 
                extend: 'print',
                exportOptions: {
                    columns: [ 0, 1, 2, 3,4,5,6,7,8,9 ]
                }           
            }
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex"
        }, {
            data: "date",
            name: "date"
        }, {
            data: "fuel",
            name: "fuel",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
            }
        },{
            data: "travelling",
            name: "travelling",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
            }
        }, {
            data: "transport",
            name: "transport",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
            }
        }, {
            data: "tiffin",
            name: "tiffin",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
            }
        },
        {
            data: "room_rent",
            name: "room_rent",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
            }
        },
        {
            data: "salary",
            name: "salary",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">&#8377; '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
            }
        }, {
            data: "extra_exp",
            name: "extra_exp",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
            }
        },{
            data: "total",
            name: "total",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
            }
        }, {
            data: "action",
            name: "action"
        }]
    });
    /* Expense Item DataTable End Here*/
    /**/
    details()
    function details(argument) {        
        $.ajax({
            method: "GET",
            url: routes.details,
            dataType: "json",
            success: function(res) {
                $('.y-expence').html('&#8377; '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.oneYearExpense)+'')
                $('.m-expence').html('&#8377; '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.oneMonthExpense)+'')
                $('.d-expence').html('&#8377; '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.sevenDaysExpense)+'')
            }
        })
    }
    /* Export Start*/
    $(document).on('click',".export",function(){
        var btn = $(this).attr('id').toString()
        dataTable.button(btn).trigger();
    })
    /* Export End*/
    /* Toatal calculation*/
    $('.modal-body').delegate('#fuel, #travelling ,#transport, #tiffin, #room_rent, #salary, #extra_exp', 'keyup', function() {
        let fuel = $("#fuel").val()
        let travelling = $("#travelling").val()
        let transport = $("#transport").val()
        let tiffin = $("#tiffin").val()
        let room_rent = $("#room_rent").val()
        let salary = $("#salary").val()
        let extra_exp = $("#extra_exp").val()
        let total = (+fuel)+(+travelling)+(+transport)+(+tiffin)+(+room_rent)+(+salary)+(+extra_exp)
        $("#total").val(total.toFixed(2))
    });
    /* Toatal calculation*/
    /* Expense Item Add Start*/
    $(document).on("click", "button.add", function() {
        $(".modal-title").text("Add Expense")
        $('#expenseForm')[0].reset()
        $("#expense_id").val("")
        $(".text-danger").html("")
        // $('input.md-input').attr('value' , '')
        $("#addBtn").show()
        $("#editBtn").hide()

    })//to show modal for add
    $("#expenseForm").on("click", "#addBtn", function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        var formData = new FormData($("#expenseForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.fuel){
                        $("#fuel_error").text(response.errors.fuel[0])
                    }
                    if(response.errors.travelling){
                        $("#travelling_error").text(response.errors.travelling[0])
                    }
                    if(response.errors.transport){
                        $("#transport_error").text(response.errors.transport[0])
                    }
                    if(response.errors.tiffin){
                        $("#tiffin_error").text(response.errors.tiffin[0])
                    }
                    if(response.errors.room_rent){
                        $("#room_rent_error").text(response.errors.room_rent[0])
                    }
                    if(response.errors.salary){
                        $("#salary_error").text(response.errors.salary[0])
                    }
                    if(response.errors.extra_exp){
                        $("#extra_exp_error").text(response.errors.extra_exp[0])
                    }
                    if(response.errors.total){
                        $("#total_error").text(response.errors.total[0])
                    }
                    if(response.errors.remarks){
                        $("#remarks_error").text(response.errors.remarks[0])
                    }
                }                    
                else {
                    $("#expenseForm")[0].reset() 
                    details()
                    // $('input.md-input').attr('value' , '')
                    $("#expense_table").DataTable().ajax.reload()
                    $("#modal").modal("hide")
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })
    })
    /* Expense Item Add End*/

     /* Expense Item View Start*/
    $(document).on("click", "button.view", function() {        
        $(".modal-title").text("Expense Details")
        $("#modal").modal("show") 
        $(".text-danger").html("")
        $("#date").val($(this).data("date"))
        $("#fuel").val($(this).data("fuel"))
        $("#travelling").val($(this).data("travelling"))
        $("#transport").val($(this).data("transport"))
        $("#tiffin").val($(this).data("tiffin"))
        $("#extra_exp").val($(this).data("others"))
        $("#total").val($(this).data("total"))
        // $("#total_price").attr('value',$(this).data("total")).val($(this).data("total"))
        $("#remarks").val($(this).data("remarks"))
        $("#addBtn").hide()
        $("#editBtn").hide()
    })
    /* Purchase Item View End*/
    /* Purchase Item Edit Start*/
    $(document).on("click", "button.edit", function() {    
       $(".modal-title").text("Expense Edit")
        $("#modal").modal("show") 
        $(".text-danger").html("")
        $("#expense_id").val($(this).attr("id"))
        $("#date").val($(this).data("date"))
        $("#fuel").val($(this).data("fuel"))
        $("#travelling").val($(this).data("travelling"))
        $("#transport").val($(this).data("transport"))
        $("#tiffin").val($(this).data("tiffin"))
        $("#room_rent").val($(this).data("roomrent"))
        $("#salary").val($(this).data("salary"))
        $("#extra_exp").val($(this).data("others"))
        $("#total").val($(this).data("total"))
        // $("#total_price").attr('value',$(this).data("total")).val($(this).data("total"))
        $("#remarks").val($(this).data("remarks"))
        $("#addBtn").hide()
        $("#editBtn").show()
    })//Purchase Item Edit show 
    $("#expenseForm").on("click", "#editBtn", function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        var formData = new FormData($("#expenseForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.fuel){
                        $("#fuel_error").text(response.errors.fuel[0])
                    }
                    if(response.errors.travelling){
                        $("#travelling_error").text(response.errors.travelling[0])
                    }
                    if(response.errors.transport){
                        $("#transport_error").text(response.errors.transport[0])
                    }
                    if(response.errors.tiffin){
                        $("#tiffin_error").text(response.errors.tiffin[0])
                    }
                    if(response.errors.room_rent){
                        $("#room_rent_error").text(response.errors.room_rent[0])
                    }
                    if(response.errors.salary){
                        $("#salary_error").text(response.errors.salary[0])
                    }
                    if(response.errors.extra_exp){
                        $("#extra_exp_error").text(response.errors.extra_exp[0])
                    }
                    if(response.errors.total){
                        $("#total_error").text(response.errors.total[0])
                    }
                    if(response.errors.remarks){
                        $("#remarks_error").text(response.errors.remarks[0])
                    }
                }                    
                else {
                    $("#expenseForm")[0].reset() 
                    details()
                    // $('input.md-input').attr('value' , '')
                    $("#expense_table").DataTable().ajax.reload()
                    $("#modal").modal("hide")
                    let message = response.success;
                    snacbar(message)
                }
            },//success end
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end here
    })//Purchase Item edit form function end here
    /* Purchase Item Edit End*/
    
    /* Purchase Item Delete Start*/
    $(document).on("click", "button.delete", function() {
        $("#id").val($(this).data("id")) 
        $(".modal-title").text("Expense Date : " + $(this).data("date"))
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $("#expense_table").DataTable().ajax.reload()
                    $("#confirmModal").modal("hide");
                    details()
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end
    })//Purchase Item Delete function end
    /* Purchase Item Delete End*/
});