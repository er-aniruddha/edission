$(document).ready(function() {
    /*-------- Bank Transaction table start -------*/
    var bank_trnx_table = $("#bank_trnx_table").DataTable({
        processing: true,
        serverSide: true,
        lengthMenu: [
            [10, 25, 50,100, -1],
            [10, 25, 50,100, 'All'],
        ],
        buttons: [{ extend: 'csv', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
            { extend: 'excel', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
            { extend: 'pdf', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
            { extend: 'print', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } }
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex",
            render: function(data) {
                return '<small class="text-muted">' + data + '</small>'
            }
        }, {
            data: "date",
            name: "date",
            render: function(data, type, full, meta) {
                return '<span class="text-sm text-capitalize">' + data + '</span>'
            },
        }, {
            data: "bank_trnx_id",
            name: "bank_trnx_id",
            render: function(data, type, full, meta) {
                return '<span class="text-sm text-capitalize text-primary">' + data + '</span>'
            },
        }, {
            data: "trnx_type",
            name: "trnx_type",
            render: function(data) {
                if (data == 0) {
                    return '<span class="text-sm text-capitalize text-info">opening banlance</span>'
                } else if (data == 1) {
                    return '<span class="text-sm text-capitalize text-danger">cash withdraw</span>'
                } else {
                    return '<span class="text-sm text-capitalize text-success">cash deposite</span>'
                }

            }
        }, {
            data: "account_name",
            name: "account_name",
            render: function(data) {
                return '<span class="text-sm text-capitalize">' + data + '</span>'
            }
        }, {
            data: "amount",
            name: "amount",
            render: function(data) {
                var data = data.split('/')
                var amount = data[0]
                var trnx_type = data[1]
                if( trnx_type == 0)
                {
                    return '<span class="text-sm text-capitalize text-info inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount.toString().replace('-',' ')) +'</span>';  
                }
                if( trnx_type == 1)
                {
                    return '<span class="text-sm text-capitalize text-danger inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount.toString().replace('-',' ')) +'</span>';  
                }
                else
                {
                    return '<span class="text-sm text-capitalize text-success inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount.toString().replace('-',' ')) +'</span>';   
                }
            }
        }, {
            data: "remarks",
            name: "remarks",
        },{
            data: "action",
            name: "action"
        }],

    });
    /*-------- Bank Transaction table end -------*/
    /*-------- Show bank modal start -------*/
    $(document).on('click', '#addBankAc', function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        $('.modal-title').text('Add Bank Account')
        $("#bankForm")[0].reset()
        $("#addBtn").show()
        $("#editBtn").hide()
    })
    /*-------- Show bank modal start -------*/
    /*-------- Save bank accounts start -------*/
    $("#bankForm").on('click', '#addBtn', function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        var formData = new FormData($("#bankForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if (response.errors.account_name) {
                        $("#account_name_error").text(response.errors.account_name[0])
                    }
                    if (response.errors.opening_balance) {
                        $("#opening_balance_error").text(response.errors.opening_balance[0])
                    }
                    if (response.errors.date) {
                        $("#date_error").text(response.errors.date[0])
                    }
                } else {
                    $("#bankForm")[0].reset()
                    $("#bank_trnx_table").DataTable().ajax.reload()
                    $("#bankAccountModal").modal("hide")
                    let message = response.success;
                    bankaccounts = response.bankaccounts;
                    bankAcList()
                    snacbar(message)
                }

            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })

    })
    /*-------- Save bank accounts end -------*/
    /*-------- Show  bank accounts start ------*/
    

    window.bankAcList = function() {
        $("#bankAcList").empty().append('')
        $("#b2c_baccount_id").empty().append('<option selected="" value="">Select account</option>')
        $("#c2b_baccount_id").empty().append('<option selected="" value="">Select account</option>')
        $("#edit_baccount_id").empty().append('<option selected="" value="">Select account</option>')
        for (let i = 0; i < bankaccounts.length; i++) {
            let amount
            if(bankaccounts[i].account_balance >= 0){
                amount = '<span class="badge bg-primary-lt inr-sign" style="float: right; margin-top: 12px;"> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(bankaccounts[i].account_balance)  + '</span></br>' 
            }
            if(bankaccounts[i].account_balance < 0){
                amount = '<span class="badge bg-danger-lt inr-sign" style="float: right; margin-top: 12px;"> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(bankaccounts[i].account_balance)  + '</span></br>' 
            }

            $("#bankAcList").append('<li>' +
                '<a href="javascript:void(0);" data-pjax-state="anchor" class="b-b item-company text-primary b-account" data-name="' + bankaccounts[i].account_name + '">' +
                '<span class="nav-text text-capitalize">' + bankaccounts[i].account_name + '' +
                '<p class="item-except text-muted text-sm h-1x">' + moment(bankaccounts[i].date, 'YYYY-MM-DD').format("DD-MM-YYYY") + '</p></span>' +
                '<span class="nav-badge">' + amount +       
                '<span class="badge bg-secondary-lt b-account-view" style="float: right;" id="' + bankaccounts[i].baccount_id + '" data-name="' + bankaccounts[i].account_name + '" data-obal="' + bankaccounts[i].opening_balance + '" data-date="' + bankaccounts[i].date + '" data-remarks="' + bankaccounts[i].remarks + '">' +
                '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye mx-2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg></span>' +
                '</span>' +
                '</a>' +
                '</li>')
            let bankAcList = '<option class="text-capitalize" value="'+bankaccounts[i].baccount_id+'">'+bankaccounts[i].account_name+'</option>'
            $("#b2c_baccount_id").append(bankAcList)
            $("#c2b_baccount_id").append(bankAcList)
            $("#edit_baccount_id").append(bankAcList)
        }

    }
    bankAcList()
    /*-------- Show  bank accounts end ------*/
    /*-------- Searching table on account base start -------*/
    $(document).on('click', '.b-account', function(event) {
        event.preventDefault()
        let name = $(this).data('name')
        bank_trnx_table.search(name).draw();
    })
    /*-------- Searching table on account base end ---------*/

    /*-------- Bank account update start ------*/
    $(document).on('click', '.b-account-view', function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        $('input.form-controll').attr('value', '')
        $('.modal-title').text('Edit Bank Account #' + $(this).data('name'))
        $("#baccount_id").val($(this).attr('id'))
        $("#account_name").val($(this).data('name'))
        $("#opening_balance").val($(this).data('obal'))
        $("#remarks").val($(this).data('remarks'))
        $("#date").val(moment($(this).data('date'), 'YYYY-MM-DD').format("DD-MM-YYYY"))
        $("#bankAccountModal").modal("show")
        $("#addBtn").hide()
        $("#editBtn").show()
    })

    $("#bankForm").on('click', '#editBtn', function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        var formData = new FormData($("#bankForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if (response.errors.account_name) {
                        $("#account_name_error").text(response.errors.account_name[0])
                    }
                    if (response.errors.opening_balance) {
                        $("#opening_balance_error").text(response.errors.opening_balance[0])
                    }
                    if (response.errors.date) {
                        $("#date_error").text(response.errors.date[0])
                    }
                } else {
                    $("#bankForm")[0].reset()
                    $("#bank_trnx_table").DataTable().ajax.reload()
                    $("#bankAccountModal").modal("hide")
                    let message = response.success;
                    bankaccounts = response.bankaccounts;
                    bankAcList()
                    snacbar(message)
                }

            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })
    })
    /*-------- Bank account update end ------*/
    
})