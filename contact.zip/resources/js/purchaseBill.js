$(document).ready(function() {
    var base_url = "https://varneyatechnologies.com";   
    /* Brand DataTable Start Here*/
    var dataTable = $("#purchase_bill_table").DataTable({
        processing: true,
        serverSide: true,
        buttons: [{ extend: 'csv', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'excel', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'pdf', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'print', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}}
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex",
            render: function(data){
                return '<small class="text-muted">'+data+'</small>'
            }
        }, {
            data: "po_id",
            name: "po_id",
            render: function(data, type, full, meta) {
                return '<a href="#" class="item-company ajax h-1x" data-pjax-state="">'+data+'</a>'
            },      
        }, {
            data: "date",
            name: "date",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        },{
            data: "party_id",
            name: "party_id"
        },{
            data: "total",
            name: "total",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        },{
            data: "advance",
            name: "advance",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        }, {
            data: "balance",
            name: "balance",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        },{
            data: "status",
            name: "status"
        }, {
            data: "action",
            name: "action"
        }]
    });
    /*------ Purchase Bill dataTable end here ------*/
    /*------ Export Start ------*/
    $(document).on('click',".export",function(){
        var btn = $(this).attr('id').toString()
        dataTable.button(btn).trigger();
    })
    /*------ Export End -------*/ 

     /* PO Bill View Start*/
    $(document).on("click", "button.view", function(event) { 
        event.preventDefault(); 
        $('#po_bill_details_table tbody').empty(tr);    
          // $('#po_bill_details_table tbody').empty(tr2);    
        let po_id = $(this).attr('id');
        let date = moment($(this).data('date'), 'YYYY-MM-DD').format("DD-MM-YYYY");
        for(var count=0; count< allPurchaseBill.length; count++){ //allPurchaseBill variable declare in index.php
            if( allPurchaseBill[count].po_id == po_id){   
                
                if(allPurchaseBill[count].product_name != '' ){
                    var tr ='<tr>'
                        +'<td class="text-capitalize">'+allPurchaseBill[count].product_name+'</td>'
                        +'<td class="text-capitalize text-right">'+allPurchaseBill[count].unit_name+'</td>'
                        +'<td class="text-right">'+allPurchaseBill[count].qty+'</td>'
                        +'<td class="text-right">'+allPurchaseBill[count].unit_price+'</td>'
                        +'<td class="text-right">'+allPurchaseBill[count].amount+'</td>'
                    +'</tr>'
                }
                if(allPurchaseBill[count].product_name == null ){
                     var tr ='<tr>'
                        +'<td class="text-capitalize">'+allPurchaseBill[count].item_name+'</td>'
                        +'<td class="text-capitalize text-right">'+allPurchaseBill[count].unit_name+'</td>'
                        +'<td class="text-right">'+allPurchaseBill[count].qty+'</td>'
                        +'<td class="text-right">'+allPurchaseBill[count].unit_price+'</td>'
                        +'<td class="text-right">'+allPurchaseBill[count].amount+'</td>'
                    +'</tr>'
                }
                $('#po_bill_details_table tbody').append(tr);               
                $(".party_name").text(allPurchaseBill[count].party_id) 
                $(".po_id").text('#'+allPurchaseBill[count].po_id) 
                $(".date").text(date) 
                $('.payment_type').text(allPurchaseBill[count].payment_type);
                $(".round_off").text('-'+allPurchaseBill[count].round_off) 
                $(".gst_amount").text(allPurchaseBill[count].gst_amount) 
                $(".total").text(allPurchaseBill[count].total) 
                $(".advance").text(allPurchaseBill[count].advance) 
                $(".balance").text(allPurchaseBill[count].balance) 
                $(".remarks").text(allPurchaseBill[count].remarks) 
                if(allPurchaseBill[count].status == 1){
                    $(".status").text("Order Complete") 
                }                
                
            }        
        }
        $(".modal").modal("show") 
        $(".modal-title").text("PO Details #"+po_id)
    })
    /* PO Bill View End*/ 
    /*----- On print Button click start -----*/
    $(document).on('click','#printBtn',function(){
        document.title = $(".po_id").text();
        window.print();
    })
    /*----- On print Button click start -----*/

})