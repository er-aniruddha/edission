$(document).ready(function(){  
    //Add row into purchase modal form start
    var i=1;
    var singleItemDel = [];
    $('.addRow').on('click', function() {  
        var item ={};        
        item.item_name = '';
        item.unit_name = '';
        item.qty = '';
        item.unit_price = '';
        item.total_price = '';
        item.purchase_id = '';
        addRow(item)
    })
    function addRow(item){
        var tr = '<tr class="addedRow">' +
            '<td>'+
            '<input type="text" name="item_name['+i+']" id="item_name" value="'+item.item_name+'" class="form-control" placeholder="Item Name">'+
            '<span class="text-danger item_name_error_'+i+'"></span> '+
            '</td>' + 

            '<td>'+
            '<input type="text" name="unit_name['+i+']" id="unit_name" value="'+item.unit_name+'" class="form-control" placeholder="Unit Name">'+
            '<div class="text-danger unit_name_error_'+i+'"></div> '+
            '</td>' + 

            '<td>'+
            '<input type="number" name="qty['+i+']" id="qty" value="'+item.qty+'"  class="form-control qty" placeholder="Quantity" oninput="this.value = Math.round(this.value);">'+
            '<span class="text-danger qty_error_'+i+'"></span> '+
            '</td>' + 

            '<td>'+
            '<input type="number" name="unit_price['+i+']" id="unit_price" value="'+item.unit_price+'"  class="form-control unitPrice" placeholder="Price">'+
            '<span class="text-danger unit_price_error_'+i+'"></span> '+
            '</td>' + 
            '<td>'+
            '<input type="number" name="total_price['+i+']" id="total_price" value="'+item.total_price+'"  class="form-control subTotal" placeholder="Total" readonly>'+
            '<span class="text-danger total_price_error_'+i+'"></span> '+
            '</td>' +
            '<td><a href="javascript:void(0)" class="btn btn-icon remove" id="'+item.purchase_id+'" data-date="'+item.date+'" data-count="'+i+'" style="border: 1px solid #f54394">' +
            '<svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="color: red;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
            '</a>' +            
            '</td>' +
            '</tr>';
            i++;
        $('tbody').append(tr);
        window.rowCount = i;
    }
    //Add row into purchase modal form end
    //Remove row start of FORM
    $(document).on('click', '.remove', function() {        
        $(this).parent().parent().remove();
        let id = $(this).attr('id')
        let date = $(this).data('date')
        let data = {};
        data =
        {  
            date : date,
            id : id,
        }  
        if(singleItemDel.length != 0 ){            
            if(singleItemDel[0].date == date){               
                singleItemDel.push(data)
            }
            else{
                singleItemDel = [];
                singleItemDel.push(data)
            }
        }
        else{
            singleItemDel.push(data)
        }      
        // $("#singleItemDel").val(singleItemDel)
    });
    //Remove row end of FORM
    //Add row into purchase modal form end
    /* Date Picker Start*/
    $('.date').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
        width: "100%",
        startDate: "01-04-2021",
        endDate: "0d",
        todayHighlight: true,
    })
    /* Date Picker End*/
    /* To prevent multi decimal input start */
    $('#unit_price').keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /* To prevent multi decimal input edn */
    /* Toatal calculation*/
    $('tbody').delegate('.qty, .unitPrice', 'keyup', function() {
        var tr = $(this).parent().parent();
        var qty = tr.find('.qty').val();
        var unitPrice = tr.find('.unitPrice').val();
        var amount = (qty * unitPrice);
        tr.find('.subTotal').val(amount);
        // total();
        // $("#total_price").attr('value',total).val(total)
    });

    // function total() {
    //     var total = 0;
    //     $('.total').each(function(i, e) {
    //         var amount = $(this).val() - 0;
    //         total += amount;  
    //     });
    //     $("#total_price").val(total)
    //     //$('.total').html(total)
    // }
    /* Toatal calculation*/

    //Form modal Html Part end

    /********* Purchase Item DataTable Start Here *********/
    var today = new Date();     
    var groupColumn = 1 //to group from row
    var dataTable = $("#purchase_table").DataTable({
        
        processing: true,
        serverSide: true,
        buttons: [{ extend: 'csv', exportOptions: { columns: [ 0, 1, 2, 3,4,5, ]}},
            { extend: 'excel', exportOptions: { columns: [ 0, 1, 2, 3,4,5 ]}},
            { extend: 'pdf', exportOptions: { columns: [ 0, 1, 2, 3,4,5, ]}},
            { extend: 'print', exportOptions: { columns: [ 0, 1, 2, 3,4,5 ]}}
        ],
        ajax: {
            url: routes.index,
        },
        columns: [
            { data: "DT_RowIndex", name: "DT_RowIndex"}, 
            { data:"date", name:"date"}, 
            { data:"item_name", name:"item_name" },
            { data:"unit_name", name:"unit_name" }, 
            { data:"qty", name: "qty" }, 
            { data:"unit_price", name:"unit_price"},
            { data: "total_price", name:"total_price"}, 
        ]
    });
    $.fn.dataTable.ext.errMode = 'throw';
    /********* Purchase Item DataTable End Here *********/
    /* Export Start*/
    $(document).on('click',".export",function(){
        var btn = $(this).attr('id').toString()
        dataTable.button(btn).trigger();
    })
    /* Export End*/    
    /* Modal close button start*/
    $(document).on('click','button.close',function(event){
        $(".addedRow").remove()
    })
    /* Modal close button start*/

    /* Purchase Item Add Start*/
    $(document).on("click", "button.add", function(event) {
        event.preventDefault();
        $(".modal-title").text("Add Item")
        $(".addedRow").remove()
        $('#purchaseForm')[0].reset()
        $("#purchase_id").val("")
        $(".text-danger").html("")
        $(".row_0").show() 
        // $("#total_price").val("")
        // $('input.md-input').attr('value' , '')
        $("#addBtn").show()
        $("#editBtn").hide()
        $("a.addRow").show()   
        $('a.btn-icon').show() 

    })//to show modal for add
    /* Purchase Form modal satrt */
    $("#purchaseForm").on("click", "#addBtn", function(event) {
        event.preventDefault()
        $("#date_error").html("")
        $("#remarks_error").html("")
        $("tr .text-danger").html("")
        var formData = new FormData($("#purchaseForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                console.log(response)
                if (response.errors) {
                    if(response.errors.date){
                        $("#date_error").html(response.errors.date[0])
                    }
                    if(response.errors.remarks){
                        $("#remarks_error").text(response.errors.remarks[0])
                    }
                    for (var i = 0; i < window.rowCount || i < 1  ; i++) {
                        
                        if(response.errors["item_name."+i]){
                            $(".item_name_error_"+i).text(response.errors["item_name."+i][0])
                        }
                        if(response.errors["unit_name."+i]){
                            $(".unit_name_error_"+i).text(response.errors["unit_name."+i][0])
                        }
                        if(response.errors["qty."+i]){
                            $(".qty_error_"+i).text(response.errors["qty."+i][0])
                        }
                        if(response.errors["unit_price."+i]){
                            $(".unit_price_error_"+i).text(response.errors["unit_price."+i][0])
                        }
                        if(response.errors["total_price."+i]){
                            $(".total_price_error_"+i).text(response.errors["total_price."+i][0])
                        }
                    }
                }                    
                else {
                    purchase = response.purchase;
                    $("#purchaseForm")[0].reset()
                    $(".addedRow").remove() 
                    singleItemDel=[]
                    // $('input.md-input').attr('value' , '')
                    $("#purchase_table").DataTable().ajax.reload()
                    $("#modal").modal("hide")
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })
    })
    /* Purchase Item Add End*/
    /* Purchase Item View Start*/
    $(document).on("click", "button.view", function(event) { 
        event.preventDefault();
        $("a.addRow").hide()        
        $(".addedRow").remove() 
        $(".row_0").hide()
        i = 0;
        let date = $(this).data('date');
        let dateSplit = date.split('-')
        let date_for_show = dateSplit[2]+'-'+dateSplit[1]+'-'+dateSplit[0]    
        for(var count=0; count< purchase.length; count++){ //purchase variable declare in index.php
            if(purchase[count].date == date){                
                $("#date").val(date_for_show)
                $("#remarks").val(purchase[count].remarks) 
                addRow(purchase[count])
                $('a.btn-icon').hide()                
            }
        }        
        $(".modal-title").text("Purchase Item Details")
        $("#modal").modal("show") 
        $(".text-danger").html("")
        $("#addBtn").hide()
        $("#editBtn").hide()        
    })
    /* Purchase Item View End*/    
    /* Purchase Item Edit Start*/
    $(document).on("click", "button.edit", function(event) {
        event.preventDefault();
        $(".modal-title").text("Purchase Item Edit")
        $("#modal").modal("show") 
        $(".text-danger").html("")
        $("#addBtn").hide()
        $("#editBtn").show()
        $("a.addRow").hide()    
        $(".addedRow").remove() 
        $(".row_0").hide()
        i = 1;       
        let date = $(this).data('date');
        window.editeDate = $(this).data('date');
        let dateSplit = date.split('-')
        let date_for_show = dateSplit[2]+'-'+dateSplit[1]+'-'+dateSplit[0]    
        for(var count=0; count< purchase.length; count++){ //purchase variable declare in index.php
            if(purchase[count].date == date){                
                $("#date").val(date_for_show)
                $("#remarks").val(purchase[count].remarks) 
                $("#purchase_id").val(purchase[count].purchase_id)
                addRow(purchase[count])
                $('a.btn-icon').show()                
            }
        } 
        // $("#total_price").attr('value',$(this).data("total"))
    })//Purchase Item Edit show 
    $("#purchaseForm").on("click", "#editBtn", function(event) {
        event.preventDefault()
        $("#date_error").html("")
        $("#remarks_error").html("")
        $("tr .text-danger").html("")
        var formData = new FormData($("#purchaseForm")[0]);
        formData.append('delete',JSON.stringify(singleItemDel))
        $.ajax({
            method: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if(response.errors.date){
                        $("#date_error").html(response.errors.date[0])
                    }
                    if(response.errors.remarks){
                        $("#remarks_error").text(response.errors.remarks[0])
                    }
                    for (var i = 1; i < window.rowCount || i < 2  ; i++) {
                        
                        if(response.errors["item_name."+i]){
                            $(".item_name_error_"+i).text(response.errors["item_name."+i][0])
                        }
                        if(response.errors["unit_name."+i]){
                            $(".unit_name_error_"+i).text(response.errors["unit_name."+i][0])
                        }
                        if(response.errors["qty."+i]){
                            $(".qty_error_"+i).text(response.errors["qty."+i][0])
                        }
                        if(response.errors["unit_price."+i]){
                            $(".unit_price_error_"+i).text(response.errors["unit_price."+i][0])
                        }
                        if(response.errors["total_price."+i]){
                            $(".total_price_error_"+i).text(response.errors["total_price."+i][0])
                        }
                    }
                }
                else {
                    purchase = response.purchase;
                    $("#purchaseForm")[0].reset()
                    $(".addedRow").remove() 
                    singleItemDel=[];
                    // $('input.md-input').attr('value' , '')
                    $("#purchase_table").DataTable().ajax.reload()
                    $("#modal").modal("hide")
                    let message = response.success;
                    snacbar(message)
                }       
            },//success end
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end here
    })//Purchase Item edit form function end here
    /* Purchase Item Edit End*/
    
    /* Purchase Item Delete Start*/
    $(document).on("click", "button.delete", function() {
        $("#id").val($(this).data("date")) //have to use date regrad id 
        $(".modal-title").text("Item Name : " + $(this).data("date"))
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $("#purchase_table").DataTable().ajax.reload()
                    $("#confirmModal").modal("hide");
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end
    })//Purchase Item Delete function end
    /* Purchase Item Delete End*/
});
 /* Purchase Item View End*/
    // let count = 0;
    // function drawTable(item){
    //     console.log(item)
    //     var tr = '<tr class="row_edit_view">' +
    //         '<td>'+
    //         '<input type="text" name="item_name[]" id="item_name" class="form-control" placeholder="Item Name" value="'+item.item_name+'" >'+
    //         '<span class="text-danger item_name_error_'+count+'"></span> '+
    //         '</td>' + 

    //         '<td>'+
    //         '<input type="text" name="unit_name[]" id="unit_name" class="form-control" placeholder="Unit Name" value="'+item.unit_name+'">'+
    //         '<div class="text-danger unit_name_error_'+count+'"></div> '+
    //         '</td>' + 

    //         '<td>'+
    //         '<input name="qty[]" id="qty" oninput="this.value = Math.round(this.value);" class="form-control" value="'+item.qty+'" placeholder="Quantity">'+
    //         '<span class="text-danger qty_error_'+count+'"></span> '+
    //         '</td>' + 

    //         '<td>'+
    //         '<input type="text" name="unit_price[]" id="unit_price" class="form-control unitPrice" value="'+item.unit_price+'" placeholder="Unit Price">'+
    //         '<span class="text-danger unit_price_error_'+count+'"></span> '+
    //         '</td>' + 
    //         '<td>'+
    //         '<input type="number" name="total_price[]" id="total_price" class="form-control total" value="'+item.total_price+'" placeholder="Total">'+
    //         '<span class="text-danger total_price_error_'+count+'"></span> '+
    //         '</td>' +
    //         '<td><a href="javascript:void(0)" class="btn btn-icon remove" style="border: 1px solid #f54394">' +
    //         '<svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="color: red;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
    //         '</a>' +
    //         '</td>' +
    //         '</tr>';
    //         count++;
    //     $('tbody').append(tr);
    // }