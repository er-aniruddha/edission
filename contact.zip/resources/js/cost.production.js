$(document).ready(function() {
    /* HTML part Start */
    $('input[type="checkbox"]').click(function(event) {
        /* Act on the event */
        if($('#checkbox').is(':checked')){
            $("#cost_stat").val(1)
        }
        else{
            $("#cost_stat").val(0)
        }
    })//set publication status
    /* Row addition to modal form start*/
    var i = 1;
    $('.addRow').on('click', function() {
        var tr = '<tr>' +
            '<td>'+
            '<input type="text" name="cost_item_name[]" id="cost_item_name" class="form-control" placeholder="Enter Name">'+
            '<span class="text-danger cost_item_name_error_'+i+'"></span> '+
            '</td>' +            
            '<td>'+
            '<input type="text" name="cost_qty[]" id="cost_qty" '+            
            'class="form-control qty" placeholder="Enter Quantity" '+
            'oninput="this.value = Math.round(this.value);">'+
            '<span class="text-danger cost_qty_error_'+i+'"></span> '+
            '</td>' +
            '<td>'+
            '<input type="number" name="cost_price[]" id="cost_price" class="form-control price" placeholder="Enter Price">'+
            '<span class="text-danger cost_price_error_'+i+'"></span> '+
            '</td>' +
            '<td><input type="text" name="cost_sub_total[]" id="cost_sub_total" class="form-control subTotal" placeholder="Total" readonly></td>' +
            '<td><a href="javascript:void(0)" class="btn btn-icon remove" style="border: 1px solid #f54394">' +
            '<svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="color: red;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
            '</a>' +
            '</td>' +
            '</tr>';
            i++;
        $('tbody').append(tr);
        window.rowCount = i;
    });
    /* Row addition to modal form end*/
    /* Row remove from modal form start*/
    $(document).on('click', '.remove', function() {
        var last = $('tbody tr').length;
        if (last == 1) {
            alert("you can not remove last row");
        } else {
            $(this).parent().parent().remove();
        }
    });
    /* Row remove from modal form end*/
    /* Addition of total and sub total start*/
    $('tbody').delegate('.qty, .price', 'keyup', function() {
        var tr = $(this).parent().parent();
        var quantity = tr.find('.qty').val();
        var budget = tr.find(' .price').val();
        var amount = (quantity * budget);
        tr.find('.subTotal').val(amount);
        total();
    });
    function total() {
        var total = 0;
        $('.subTotal').each(function(i, e) {
            var amount = $(this).val() - 0;
            total += amount;  

        });
        $("#cost_total").val(total)
        //$('.total').html(total)
    }
    /* Addition of total and sub total end*/
    /* HTML part end */
    /* Show Brand Table Start */ 
    $('#cost_table').DataTable({
        processing: true,
        serverSide: true,
        ajax:{
            url: routes.index,
        },
        columns:[
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},                        
            {data: 'cost_name', name: 'cost_name' },
            {data: 'amount', name: 'amount' },
            {data: 'status', name: 'status', },
            {data: 'action', name: 'action', }, 
      ]});
    /* Show Brand Table End */
    /* DataTable Search and Pagination Start*/
    /* DataTable Search and Pagination End*/
    /* Add Production Cost Start */ 
	$('#costForm').on('click', '#addBtn', function(event) {
        event.preventDefault();
        $("#cost_name_error").html(" ")
	            	
		for (var i = 0; i < window.rowCount || i < 1 ; i++) {
			$(".cost_item_name_error_"+i).html(" ")
			$(".cost_qty_error_"+i).html(" ")
			$(".cost_price_error_"+i).html(" ")
		}
        var formData = new FormData($('#costForm')[0]);
        $.ajax({
            method: 'POST',
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
            	if (response.errors) {
	            	if(response.errors.cost_name){
	            		$("#cost_name_error").text(response.errors.cost_name[0])
	            	}
        			for (var i = 0; i < window.rowCount || i < 1 ; i++) {
        				if(response.errors["cost_item_name."+i]){
        					$(".cost_item_name_error_"+i).text(response.errors["cost_item_name."+i][0])
        				}
        				if(response.errors["cost_qty."+i]){
        					$(".cost_qty_error_"+i).text(response.errors["cost_qty."+i][0])
        				}
        				if(response.errors["cost_price."+i]){
            				$(".cost_price_error_"+i).text(response.errors["cost_price."+i][0])
        				}
        			}
            	}
            	else{
                    $("#cost_table").DataTable().ajax.reload()
                    $("#costForm")[0].reset();  
                    $('#modal').modal('hide');              		
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })
    })
    /* Add Production Cost End */ 
    /* Production Cost Status Start */ 
    $(document).on("click", ".status", function(event) {
        event.preventDefault()
        $.ajax({
            type: "GET",
            url: $(this).data("url"),
            success: function(response) {
                if (response.success) {
                    $("#cost_table").DataTable().ajax.reload();
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end here
    })//function end here
    
    /* Production Cost Status End */ 

    /* Production Cost Delete Start */ 
    $(document).on("click", "button.delete", function() {
        $("#id").val($(this).data("id"))
         $(".modal-title").text("Cost Name : " + $(this).data("name")) 
         $("#ok_button").text("YES")
         $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $("#cost_table").DataTable().ajax.reload()
                    $("#confirmModal").modal("hide");
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end here
    })//form end here
    /* Production Cost Delete End */ 
})
