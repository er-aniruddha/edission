$(document).ready(function() {
	var base_url = "https://varneyatechnologies.com";    
    var prevBalance ;
    $.fn.modal.Constructor.prototype._enforceFocus = function() {};

    /*------- input[type='number'] can't be null -------*/
    const numInputs = document.querySelectorAll('input[type=number]')
    numInputs.forEach(function(input) {
      input.addEventListener('change', function(e) {
        if (e.target.value == '') {
          e.target.value = 0
          totalCalculation()
        }
      })
    })
    /*------- input[type='number'] can't be null -------*/
    /*--------- Add customer list start -------*/
    function customerList(){
        $('#customer_id').empty().append('<option selected="" value="">Select customer</option>');               
        for(let i=0; i < customers.length; i++){
            $("#customer_id").append('<option value="'+customers[i].customer_id+'" data-balance="'+customers[i].balance+'" data-type="'+customers[i].customer_type+'" style="width: 100%;">'+customers[i].f_name+' '+customers[i].s_name+' ('+customers[i].phone_1+')'+' ('+customers[i].shop_name+')' +' (' +customers[i].locality +')'+'</option>')
        }
        $('#customer_id').select2({ width: "100%"}); //to initiatate select2             
    }     
    /*--------- Add customer list end -------*/

    /*Form modal Html Part Start*/
    $('.addRow').on('click', function() {
        var item = {
            item_name: '',
            unit_id: '',
            sale_qty: '',
            sale_unit_price: '',
            sale_discount_percentage: 0.00,
            sale_discount: 0.00,
            sale_amount: 0.00,
        }
        addRow(item)
        $("#tdFormRow tbody tr").children('td:nth-child(2)').addClass("unit-td")
    })
    /* Add input row into Purchase Order Form Start */
    var tdFormRowIndex = 0;
    function addRow(item) {
        var tr = '<tr class="addedRow row_'+tdFormRowIndex+'">' +
            '<td>' +
            '<select class="form-control text-capitalize select2 proChng productList'+tdFormRowIndex+'" name="item_name['+tdFormRowIndex+']" id="item_name'+tdFormRowIndex+'" value="' + item.item_name + '" tabindex="-1" aria-hidden="true">' +
            '</select>' +
            '<span class="text-danger text-sm item_name_error_'+tdFormRowIndex+'"></span> ' +
            '</td>' +
            '<td class="">' +
            '<select class="form-control text-capitalize unitList" name="unit_id['+tdFormRowIndex+']" id="unit_id' +tdFormRowIndex+ '" value="'+item.unit_id+'" tabindex="-1" aria-hidden="true">' +
            '</select>' +
            '<div class="text-danger text-sm unit_id_error_' +tdFormRowIndex+ '"></div> ' +
            '</td>' +
            '<td class="qty-td">' +
            '<input type="number" name="qty['+tdFormRowIndex+']" id="qty" value="'+item.sale_qty+'"  class="form-control qty" placeholder="Quantity" oninput="this.value = Math.round(this.value);">' +
            '<span class="text-danger text-sm qty_error_'+tdFormRowIndex+'"></span> ' +
            '</td>' +
            '<td class="mrp-td">' +
            '<input type="number" name="product_mrp['+tdFormRowIndex+']" id="product_mrp" value="'+item.sale_unit_price+'"  class="form-control mrp" placeholder="Price">' +
            '<span class="text-danger text-sm product_mrp_error_'+tdFormRowIndex+'" ></span> ' +
            '</td>' +
            '<td class="discount-percentage-td">' +
            '<input type="number" name="discount_percentage['+tdFormRowIndex+']" id="discount_percentage" value="'+item.sale_discount_percentage+'" class="form-control discount-percentage percent text-info">' +
            '</td>' +
            '<td class="discount-td">' +
            '<input type="number" name="discount['+tdFormRowIndex+']" id="discount" value="'+item.sale_discount+'" class="form-control discount text-info">' +
            '</td>' +
            '<td class="amount-td">' +
            '<input type="number" name="amount['+tdFormRowIndex+']" id="amount" value="'+item.sale_amount+'"  class="form-control amount" placeholder="Amount" onchange="(function(el){el.value=parseFloat(el.value).toFixed(2);})(this)" readonly>' +
            '<span class="text-danger text-sm amount_error_' +tdFormRowIndex+ '"></span> ' +
            '</td>' +
            '<td><a href="javascript:void(0)" class="btn btn-icon remove" id="remove'+tdFormRowIndex+'" style="border: 1px solid #f54394">' +
            '<svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="color: red;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
            '</a>' +
            '</td>' +
            '</tr>';
        window.rowCount = tdFormRowIndex;
        tdFormRowIndex++;
        $('#tdFormRow tbody').append(tr);
        productsList(products)
        tdRowCount()
    }//Add row into purchase modal form end
    
    $(document).on('change','select.customer',function(event){ 
        event.preventDefault()
        $(".addedRow").remove() 
        $(".addRow").show()
        tdFormRowIndex=0;
        var item = {
            item_name: '',
            unit_id: '',
            sale_qty: '',
            sale_unit_price: '',
            sale_discount_percentage: 0.00,
            sale_discount: 0.00,
            sale_amount: 0.00,
        }
        addRow(item)       
        $("#tdFormRow tbody tr").children('td:nth-child(2)').addClass("unit-td") 
        // $("#balance").val($(this).find(':selected').data('balance'))
        prevBalance = $(this).find(':selected').data('balance')
        $("#prev_balance").val(parseFloat(prevBalance))//this is to store
        $('.prev_bal').text("Previous balance: "+prevBalance) 
        window.customerType = $(this).find(':selected').data('type')    
        totalCalculation()      
    })

    // Add list of product into form select
    function productsList(products) {
        $(".productList"+window.rowCount).empty().append('<option selected="" value="">Select an option</option>');
        for (count = 0; count < products.length; count++) {
            $(".productList"+window.rowCount).append('<option value="'+products[count].product_id+'"'
                +'data-punitid="'+products[count].p_unit_id+'" data-sunitid="'+products[count].s_unit_id+'" '
                +'data-punitname="'+products[count].p_unit_name+'" data-sunitname="'+products[count].s_unit_name+'" '
                +'data-priunitrater="'+products[count].r_pri_unit_rate+'" data-secunitrater="'+products[count].r_sec_unit_rate+'"'
                +'data-priunitrated="'+products[count].d_pri_unit_rate+'" data-secunitrated="'+products[count].d_sec_unit_rate+'"'
                +'data-maxpri="'+products[count].in_hand_stock_primary+'" data-maxsec="'+products[count].in_hand_stock_second+'"'
                +'data-noofpcs="'+products[count].no_of_pcs+'"'
                +'>'+products[count].product_name+' - '+products[count].brand_name+'</option>')
        }
        $('#item_name' + window.rowCount).select2({ width: "100%"}); //to initiatate select2  
    }//Product list end here 

    
    $("#tdFormRow").on('change','select.proChng',function(){ 
        $(this).parents('.addedRow').children('.unit-td').children('.unitList').empty().append('<option selected="" value="">Select an option</option>');
        if(window.customerType == 1 || window.customerType == 3){ 

            $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option value="'+$(this).find(':selected').data('punitid')+'"'
                +'data-max="'+$(this).find(':selected').data('maxpri')+'" data-unitrate="'+$(this).find(':selected').data('priunitrater')+'"'
                +'>'+$(this).find(':selected').data('punitname')+'</option>')

            $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option value="'+$(this).find(':selected').data('sunitid')+'"'
                +'data-max="'+$(this).find(':selected').data('maxsec')+'" data-unitrate="'+$(this).find(':selected').data('secunitrater')+'"'
                +'>'+$(this).find(':selected').data('sunitname')+'</option>')

           
        }
        if(window.customerType == 2){

            $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option value="'+$(this).find(':selected').data('punitid')+'"'
                +'data-max="'+$(this).find(':selected').data('maxpri')+'" data-unitrate="'+$(this).find(':selected').data('priunitrated')+'"'
                +'>'+$(this).find(':selected').data('punitname')+'</option>')

            $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option value="'+$(this).find(':selected').data('sunitid')+'"'
                +'data-max="'+$(this).find(':selected').data('maxsec')+'" data-unitrate="'+$(this).find(':selected').data('secunitrated')+'"'
                +'>'+$(this).find(':selected').data('sunitname')+'</option>')

        }
       
    })
    
    $("#tdFormRow").on('change','select.unitList',function(){   
        $(this).parents('.addedRow').children('.mrp-td').children('#product_mrp').val($(this).find(':selected').data('unitrate'))
        $(this).parents('.addedRow').children('.qty-td').children('#qty').attr({"max": $(this).find(':selected').data('max'), "placeholder":"Max Qty: "+$(this).find(':selected').data('max')+"",})        
        $(this).parents('.addedRow').children('.qty-td').children('#qty').val('')        
        $(this).parents('.addedRow').children('.discount-td').children('#discount').val(0)        
        $(this).parents('.addedRow').children('.amount-td').children('#amount').val('')
    })//Onchange unit show primary qty & mrp

    /*------ Remove row start of FORM ------*/
    $(document).on('click', '.remove', function() {        
        $(this).parent().parent().remove()
        tdRowCount()
        // $(this).closest('table').children('tr').addClass('xxx');
        // $(this).closest('td').parent('tr').parent()[0].sectionRowIndex
        totalCalculation()   
    });
    /*------ Remove row end of FORM ------*/

    /*------ To prevent multi decimal input start ------*/
    $('#product_mrp, #discount, #discount_percentage').keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /*------ To prevent multi decimal input edn ------*/
    
    // Input type Quantity change function Start
    $('#tdFormRow tbody').delegate('.qty','keyup', function() { 
        var tr = $(this).parent().parent();      
        let max = $(this).attr("max");
        let val = parseInt($(this).val(), 10);   
        if(max){            
            if(val > max || val < 1){
                $(this).addClass('is-invalid')
                // $("#cartInputTable thead th:last").children('.addRow1').prop('disabled', true); //disable add button
            }
            else{
                $(this).removeClass('is-invalid')
                $(this).addClass('is-valid')
                // $("#cartInputTable thead th:last").children('.addRow1').prop('disabled', false); //enable add button
            }            
        }
        // else{
        //     snacbar("Select respective SKU first")
        //     $(this).addClass('is-invalid')
        // }
    })
    // Input type Quantity change function End

    /* Toatal calculation*/   
    $('#tdFormRow tbody').on('keyup','.qty',function(){
        var tr = $(this).parent().parent();
        amountCalculation(tr)
    })
    $('#tdFormRow tbody').on('keyup','.mrp',function(){
        var tr = $(this).parent().parent();
        amountCalculation(tr)
    })

    $('#tdFormRow tbody').on('keyup','.percent',function(){
        var tr = $(this).parent().parent();
        var percent = tr.find('.percent').val();
        var mrp = tr.find('.mrp').val();
        var discount = (mrp*percent)/100;
        tr.children('.discount-td').children('.discount').val(parseFloat(discount).toFixed(2))
        amountCalculation(tr)
        
    })

    $('#tdFormRow tbody').on('keyup','.discount',function(){
        var tr = $(this).parent().parent();
        var discount = tr.find('.discount').val();
        var mrp = tr.find('.mrp').val();
        var percent = 100 - (((mrp - discount)/mrp)*100);
        tr.children('.discount-percentage-td').children('.percent').val(parseFloat(percent).toFixed(2))
         amountCalculation(tr)
    })

    function amountCalculation(tr){
        var qty = tr.find('.qty').val();
        var mrp = tr.find('.mrp').val();
        var discount = tr.find('.discount').val();
        var amount = qty * (mrp - discount);
        tr.find('.amount').val(parseFloat(amount).toFixed(2));
        totalCalculation()       
    }

    $("#received").on('keyup',function(){
        if($("#received").val() != ''){
            totalCalculation()
        }    
    })

    $("#delivery_charges").on('keyup',function(){
        if($("#delivery_charges").val() != ''){
            totalCalculation()
        }    
    })

    $("#round_off").on('keyup',function(){
        if($("#round_off").val() != ''){
            totalCalculation()
        }  
    })

    $("#gst_amount").on('keyup',function(){
        if($("#gst_amount").val() != ''){
            totalCalculation()
        }
    })

    function totalCalculation() {
        var subTotal = 0;
        var total = 0;
        var received = $("#received").val()
        var roundOff = $("#round_off").val()
        var deliveryCharges = $("#delivery_charges").val()
        var gstAmount = $("#gst_amount").val()
        $('.amount').each(function(i, e) {
            var amount = $(this).val() - 0;
            subTotal += amount;  
        });
        total = parseFloat(subTotal) + parseFloat(gstAmount);   
        total = parseFloat(total) + parseFloat(deliveryCharges);  
        total = parseFloat(total) - parseFloat(roundOff);    
        var balance = parseFloat(total) - parseFloat(received);
        balance = parseFloat(balance) + parseFloat(prevBalance)
        $("#total").val(total)
        $("#balance").val(balance)
    }//Toatal calculation  
    /*------ Form modal Html Part end -------*/

    /*------ Add Modal Start -------*/
    $(document).on('click','button.add',function(){ 
        $(".addedRow").remove() 
        $('#createAndEditModal .modal-title').text("New Sale");
        $('#saveBtn').show();
        $('#editBtn').hide();
        $("input[type='text']").removeClass("text-capitalize")
        $("#createAndEditForm")[0].reset()   
        $('.prev_bal').text("Previous balance: 00")   
        $("#createAndEditForm .text-danger").html("")
        $('a.btn-icon').show()  
        customerList()
        $("#customer_id").prop('disabled',false) 
     });
    /*------ Add Modal end -------*/

    /*------ Create New Sale function start -------*/
    $('#createAndEditForm').on('click', '#saveBtn', function (event) {
        event.preventDefault();
        $("#loader").show()
        $("#createAndEditForm .text-danger").html("")
        // var error = $('.is-invalid').length; uncommit after old enter
        // if( error == 0){
            var formData = new FormData($('#createAndEditForm')[0]);
            $.ajax({
                method: 'POST',
                url: routes.create,
                contentType: false,
                cache: false,
                processData: false,
                dataType: "json",
                data: formData,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content'),
                },
                success: function (response) {
                    $("#loader").hide()
                    if(response.errors){
                        if(response.errors.customer_id){
                            $("#customer_id_error").text(response.errors.customer_id[0])
                        }
                        if(response.errors.order_date){
                            $("#order_date_error").text(response.errors.order_date[0])
                        }
                        if(response.errors.delivery_date){
                            $("#delivery_date_error").text(response.errors.delivery_date[0])
                        }
                        if(response.errors.payment_type){
                            $("#payment_type_error").text(response.errors.payment_type[0])
                        }
                        for (var i = 0; i < window.rowCount+1 || i < 1  ; i++) {
                            
                            if(response.errors["item_name."+i]){
                                $(".item_name_error_"+i).text(response.errors["item_name."+i][0])
                            }
                            if(response.errors["unit_id."+i]){
                                $(".unit_id_error_"+i).text(response.errors["unit_id."+i][0])
                            }
                            if(response.errors["qty."+i]){
                                $(".qty_error_"+i).text(response.errors["qty."+i][0])
                            }
                            if(response.errors["product_mrp."+i]){
                                $(".product_mrp_error_"+i).text(response.errors["product_mrp."+i][0])
                            }
                            if(response.errors["amount."+i]){
                                $(".amount_error_"+i).text(response.errors["amount."+i][0])
                            }
                        }      
                    }
                    // //on success
                    else{
                        $('#sale_table').DataTable().ajax.reload(); 
                        $("#createAndEditModal").modal('hide')
                        $("#createAndEditForm")[0].reset()
                        $('.select2').select2({                       
                                initSelection: function(element, callback) {                   
                            }
                        });  
                        customers = response.customers  
                        products = response.products  
                        sales = response.sales      
                        let message = response.success;
                        snacbar(message)
                    }
                },
                error:function(error){
                    $("#loader").hide()
                    snacbar(error.statusText)
                }
            })//ajax end here
        // }
    })
    /*------ Create New Sale function end -------*/

    /* PurchaseOrder Edit Start*/
    $(document).on("click", "a.edit", function(event) {
        event.preventDefault();
        let trnxId = $(this).data('trnxid');
        let customerId = $(this).data('cid');
        window.customerType = $(this).data('ctype');
        $("#sale_trnx_id").val(trnxId)
        $("a.addRow").show()
        $(".addedRow").remove()
        $("#createAndEditModal .modal-title").text("Sale Order Edit #OD-" + trnxId)
        $("#saveBtn").hide()
        $("#editBtn").show()
        $("#tdFormRow tbody tr").children('td:nth-child(2)').addClass("unit-td")        
        productsList(products)
        showData(trnxId)
    })

    $("#createAndEditForm").on("click", "#editBtn", function(event) {
        event.preventDefault()
        $("#createAndEditForm .text-danger").html("")
        $("#loader").show()
        var formData = new FormData($("#createAndEditForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {                
                $("#loader").hide()
                if(response.errors){
                    if(response.errors.customer_id){
                        $("#customer_id_error").text(response.errors.customer_id[0])
                    }
                    if(response.errors.order_date){
                        $("#order_date_error").text(response.errors.order_date[0])
                    }
                    if(response.errors.delivery_date){
                        $("#delivery_date_error").text(response.errors.delivery_date[0])
                    }
                    if(response.errors.payment_type){
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }
                    for (var i = 0; i < window.rowCount+1 || i < 1  ; i++) {
                        
                        if(response.errors["item_name."+i]){
                            $(".item_name_error_"+i).text(response.errors["item_name."+i][0])
                        }
                        if(response.errors["unit_id."+i]){
                            $(".unit_id_error_"+i).text(response.errors["unit_id."+i][0])
                        }
                        if(response.errors["qty."+i]){
                            $(".qty_error_"+i).text(response.errors["qty."+i][0])
                        }
                        if(response.errors["product_mrp."+i]){
                            $(".product_mrp_error_"+i).text(response.errors["product_mrp."+i][0])
                        }
                        if(response.errors["amount."+i]){
                            $(".amount_error_"+i).text(response.errors["amount."+i][0])
                        }
                    }      
                }
                //on success
                else {
                    $('#sale_table').DataTable().ajax.reload();
                    $("#createAndEditModal").modal('hide')
                    $("#createAndEditForm")[0].reset()
                    $('.select2').select2({
                        initSelection: function(element, callback) {},
                        width: "100%"
                    });
                    sales = response.sales
                    customers = response.customers
                    products = response.products
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                $("#loader").hide()
                snacbar(error.statusText)
            }
        })
    })
    /*------ PurchaseOrder Edit End ----------------*/
    

    function showData(trnxId) {
        tdFormRowIndex = 0;
        j = 0;
        for (var count = 0; count < sales.length; count++){
            if(trnxId == sales[count].sale_trnx_id){
                addRow(sales[count])
                $('#item_name'+j).select2({ width: "100%" }).val(sales[count].item_name).trigger("change");
                // $('#unit_id'+j).select2({ width: "100%" }).val(sales[count].unit_id).trigger("change");
                $('#unit_id'+j).append('<option value="' + sales[count].unit_id + '">' + sales[count].unit_name + '</option>')
                $("#customer_id").append('<option value="'+sales[count].customer_id+'">'+sales[count].f_name+' '+sales[count].s_name+' ('+sales[count].phone_1+') ('+sales[count].shop_name+') ('+sales[count].locality+')'+'</option>')
                $('#customer_id').select2({ width: "100%" })
                $("#order_date").val(moment(sales[count].sale_order_date, 'YYYY-MM-DD').format("DD-MM-YYYY"))            
                $('#payment_type').val(sales[count].sale_payment_type);
                $("#round_off").val(sales[count].sale_round_off)
                $("#delivery_charges").val(sales[count].sale_delivery_charges )
                $("#gst_amount").val(sales[count].sale_gst_amount)
                $("#total").val(sales[count].sale_total)
                $("#advance").val(sales[count].sale_advance)
                $("#received").val(sales[count].sale_received)
                prevBalance = sales[count].sale_prev_balance
                $(".prev_bal").text('Previous Balance: '+prevBalance)
                $("#prev_balance").val(parseFloat(prevBalance))//this is to store
                $("#balance").val(parseFloat(sales[count].sale_balance))//this is to store
                $("#remarks").val(sales[count].sale_remarks)
                j++
            }

        }

        $("#createAndEditModal").modal('show')
    }

    /*------ tdRowCount check -----*/
    function tdRowCount() {
        let tdRowCount = $('#tdFormRow tr').length;
        if(tdRowCount == 1){
            $("#saveBtn").prop('disabled',true)
            $("#editBtn").prop('disabled',true)
        } 
        else{
            $("#saveBtn").prop('disabled',false)
            $("#editBtn").prop('disabled',false)
        }
    }
    /*------ tdRowCount check -----*/
   
   /* Sale Order Delete Start */
    $(document).on("click", "a.delete", function() {
        $("#id").val($(this).data("trnxid"))
        $(".modal-title").text("Sale Order No: #OD" + $(this).data("trnxid"))
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $('#sale_table').DataTable().ajax.reload();
                    $("#confirmModal").modal("hide");
                    $('.select2').select2({
                        initSelection: function(element, callback) {},
                        width: "100%"
                    });
                    sales = response.sales
                    customers = response.customers
                    products = response.products
                    let message = response.success;
                    snacbar(message)
                }
                if (response.error) {
                    $("#ok_button").text("Yes")
                    let message = response.error;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        }) //ajax end here
    }) //form end here
    /* Sale Order Delete End */

    /*---------- This function is from customer balde --------*/
    $(document).on("click", "#addSalesFromCustomerBtn", function(event) {
        event.preventDefault();
        let customer_id = $(this).data('cid');
        $('#createAndEditModal .modal-title').text("New Sale");
        $('#saveBtn').show();
        $('#editBtn').hide();
        $("input[type='text']").removeClass("text-capitalize")
        $("#createAndEditForm")[0].reset()   
        $('.prev_bal').text("Previous balance: 00")   
        $("#createAndEditForm .text-danger").html("")
        $('a.btn-icon').show()  
        
        customers = customers.filter(elem => {
            return elem.customer_id == customer_id;
        })
        customerList()
        $("#customer_id").select2({ width: "100%" }).val(customer_id).trigger("change");
        
    })
    /*---------- This function is from customer balde --------*/

    $(document).on('keydown', '.select2', function(e) {
        if (e.originalEvent && e.which == 40) {
            e.preventDefault();
            $(this).siblings('select').select2('open');
        }
    });

    $('.select2').select2({
        selectOnClose: true
    });
})