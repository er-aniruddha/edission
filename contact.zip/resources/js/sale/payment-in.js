$(document).ready(function() {
	var base_url = "https://varneyatechnologies.com";    
    var prevBalance ;
	/* Sales DataTable Start Here*/
    var payments_table = $("#payments_table").DataTable({
        processing: true,
        serverSide: true,
        buttons: [{ extend: 'csv', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'excel', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7]}},
            { extend: 'pdf', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'print', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}}
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex",
            render: function(data){
                return '<small class="text-muted">'+data+'</small>'
            }
        }, {
            data: "date",
            name: "date",
            render: function(data, type, full, meta) {
                return '<a href="#" class="item-company ajax h-1x" data-pjax-state="">'+data+'</a>'
            },      
        }, {
            data: "invoice_id",
            name: "invoice_id",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm text-success text-capitalize">'+data+'</span>'
            }
        },{
            data: "name",
            name: "name",
        },{
            data: "payment_type",
            name: "payment_type",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'
            }
        },{
            data: "prev_balance",
            name: "prev_balance",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'
            }
        },{
            data: "received",
            name: "received",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'
            }
        }, {
            data: "balance",
            name: "balance",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'
            }
        },{
            data: "action",
            name: "action"
        }],

    });
    /*------ Sale dataTable end here ------*/
    /*------ Export Start ------*/
    $(document).on('click',".export",function(){
        var btn = $(this).attr('id').toString()
        dataTable.button(btn).trigger();
    })
    /*------ Export End -------*/ 
    /*------ On click customer show in table start -------*/ 
    $(document).on('click','.customer',function(event){
        event.preventDefault()
        let name = $(this).data('name')
        payments_table.search(name).draw();
    })
    /*------ On click customer show in table end -------*/ 

    /*------ Payment-IN start here --------*/
    $(document).on('click',"#paymentin",function(event){
        event.preventDefault()        
        $('.select2').select2({ 
            width:"100%", tags:true, dropdownParent: $('#payMentModal')
        }); 
        $("#payMentModal").modal("show")
    })

    $("#payment-form").on('change','select.customer',function(){ 
        $("#prev_balance").val($(this).find(':selected').data('prevbal'))
    })

    /* Add Product Start */
    $('#payment-form').on('click', '#savePayBtn', function (event) {
        event.preventDefault();
        $(".text-danger").html("") 
        var formData = new FormData($('#payment-form')[0]);
        $.ajax({
            method: 'POST',
            url: routes.payment_in,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function (response) {
                console.log(response)
                if(response.errors){
                    if(response.errors.received){
                        $("#received_error").text(response.errors.received[0])
                    }
                    if(response.errors.balance){
                        $("#balance_error").text(response.errors.balance[0])
                    } 
                    if(response.errors.payment_type){
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }                                    
                }
                //on success
                else{
                    $('#trnx_table').DataTable().ajax.reload(); 
                    $("#payMentModal").modal('hide')
                    $("#payment-form")[0].reset()
                    $('input.md-input').attr('value' , '')               
                    let message = response.success;
                    snacbar(message)
                }
            },
            error:function(error){
                snacbar(error.statusText)
            }
        })//ajax end here
    })//Add product function end here
    /*Add Product End*/

    /*------ Payment-IN end here --------*/

    /*------ Date Picker start ----------*/
    $('.date').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
        width: "100%",
        startDate: "01-04-2021",
        endDate: "0d",
        todayHighlight: true,
    })
    /*------ Date Picker end ----------*/

    /*------ check mul;tiple decimnl value start ------*/
    $('#received').keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /*------ check mul;tiple decimnl value end ------*/

    /*------ Toatal calculation -------*/
    $('.modal-body').delegate('#received', 'keyup', function() {
        let prev_balance = $("#prev_balance").val()
        let received = $("#received").val()
        let balance = parseFloat(prev_balance) - parseFloat(received)
        $("#balance").val(balance.toFixed(2))
    });
    /*----- Toatal calculation -------*/
})