$(document).ready(function() {
	var base_url = "https://varneyatechnologies.com";    
    var prevBalance ;
	/* Sales DataTable Start Here*/
    var dataTable = $("#sale_table").DataTable({
        processing: true,
        serverSide: true,
        buttons: [{ extend: 'csv', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'excel', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7]}},
            { extend: 'pdf', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'print', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}}
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex",
            render: function(data){
                return '<small class="text-muted">'+data+'</small>'
            }
        }, {
            data: "date",
            name: "date",
            render: function(data, type, full, meta) {
                return '<a href="#" class="item-company ajax h-1x" data-pjax-state="">'+data+'</a>'
            },      
        }, {
            data: "invoice_id",
            name: "invoice_id",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm text-success text-capitalize">'+data+'</span>'
            }
        },{
            data: "name",
            name: "name",
        },{
            data: "payment_type",
            name: "payment_type",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'
            }
        },{
            data: "amount",
            name: "amount",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'
            }
        },{
            data: "prev_balance",
            name: "prev_balance",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'
            }
        },{
            data: "received",
            name: "received",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'
            }
        }, {
            data: "balance",
            name: "balance",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'
            }
        },{
            data: "action",
            name: "action"
        }],

    });
    /*------ Sale dataTable end here ------*/
    /*------ Export Start ------*/
    $(document).on('click',".export",function(){
        var btn = $(this).attr('id').toString()
        dataTable.button(btn).trigger();
    })
    /*------ Export End -------*/ 
    /* Add Modal Start */
    $(document).on('click','button.add',function(){ 
        $(".addedRow").remove() 
        tdFormRowIndex=0;
        var item = {}
        addRow(item)    
        $('.modal-title').text("New Sale");
        $('#addBtn').show();
        $('#editBtn').hide();
        $("input[type='text']").removeClass("text-capitalize")
        $("#newSaleForm")[0].reset()
        $('.select2').select2({ 
            width:"100%", tags:true, dropdownParent: $('#modal')
        });          
        $(".text-danger").html("")
        $("a.addRow").show()    
        $('a.btn-icon').show()  
        $("#tdFormRow tbody tr").children('td:nth-child(2)').addClass("unit-td")
        customerList()
     });
    /* Add Modal end */

    /*--------- Add customer list start -------*/
    function customerList(stocks){
        $('#customer_id').empty().append('<option selected="" value="">Select customer</option>');               
        for(let i=0; i < customers.length; i++){
            $("#customer_id").append('<option value="'+customers[i].customer_id+'" data-balance="'+customers[i].balance+'">'+customers[i].f_name+' '+customers[i].s_name+' ('+customers[i].phone_1+')'+' ('+customers[i].shop_name+')'+'</option>')
        }            
    } 
    /*--------- Add customer list end -------*/

    /*Form modal Html Part Start*/
    $('.addRow').on('click', function() {
        var item = {};
        item.item_name = '';
        item.unit_id = '';
        item.qty = '';
        item.product_mrp = '';
        item.total_price = '';
        item.discount = '';
        item.purchase_id = '';
        addRow(item)
    })
    /* Add input row into Purchase Order Form Start */
    var tdFormRowIndex = 0;
    function addRow(item) {
        var tr = '<tr class="addedRow row_'+tdFormRowIndex+'">' +
            '<td>' +
            '<select class="form-control text-capitalize select2 proChng productList'+tdFormRowIndex+'" name="item_name['+tdFormRowIndex+']" id="item_name'+tdFormRowIndex+'" value="' + item.item_name + '" tabindex="-1" aria-hidden="true">' +
            '</select>' +
            '<span class="text-danger text-sm item_name_error_'+tdFormRowIndex+'"></span> ' +
            '</td>' +
            '<td class="">' +
            '<select class="form-control text-capitalize unitList" name="unit_id['+tdFormRowIndex+']" id="unit_id' +tdFormRowIndex+ '" value="'+item.unit_id+'" tabindex="-1" aria-hidden="true">' +
            '</select>' +
            '<div class="text-danger text-sm unit_name_error_' +tdFormRowIndex+ '"></div> ' +
            '</td>' +

            '<td class="qty-td">' +
            '<input type="number" name="qty['+tdFormRowIndex+']" id="qty" value="'+item.qty+'"  class="form-control qty" placeholder="Quantity" oninput="this.value = Math.round(this.value);">' +
            '<span class="text-danger text-sm qty_error_'+tdFormRowIndex+'"></span> ' +
            '</td>' +
            '<td class="mrp-td">' +
            '<input type="number" name="product_mrp['+tdFormRowIndex+']" id="product_mrp" value="'+item.product_mrp+'"  class="form-control mrp" placeholder="Price" readonly>' +
            '<span class="text-danger text-sm product_mrp_error_'+tdFormRowIndex+'" ></span> ' +
            '</td>' +
            '<td class="discount-td">' +
            '<input type="number" name="discount['+tdFormRowIndex+']" id="discount" value="0" class="form-control discount">' +
            '</td>' +
            '<td class="amount-td">' +
            '<input type="number" name="amount['+tdFormRowIndex+']" id="amount" value="'+item.amount+'"  class="form-control amount" placeholder="Total" onchange="(function(el){el.value=parseFloat(el.value).toFixed(2);})(this)" readonly>' +
            '<span class="text-danger text-sm amount_error_' +tdFormRowIndex+ '"></span> ' +
            '</td>' +
            '<td><a href="javascript:void(0)" class="btn btn-icon remove" id="'+item.purchase_order_id+'" id="remove'+tdFormRowIndex+'" style="border: 1px solid #f54394">' +
            '<svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="color: red;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
            '</a>' +
            '</td>' +
            '</tr>';
        window.rowCount = tdFormRowIndex;
        tdFormRowIndex++;
        $('#tdFormRow tbody').append(tr);
        productsList(products)
    }//Add row into purchase modal form end
    
    // Add list of product into form select
    function productsList(products) {
        $(".productList"+window.rowCount).empty().append('<option selected="" value="">Select an option</option>');
        for (count = 0; count < products.length; count++) {
            $(".productList"+window.rowCount).append('<option value="'+products[count][1].product_id+'"'
                +'data-punitid="'+products[count][1].p_unit_id+'" data-sunitid="'+products[count][1].s_unit_id+'" '
                +'data-punitname="'+products[count][1].p_unit_name+'" data-sunitname="'+products[count][1].s_unit_name+'" '
                +'data-priunitrate="'+products[count][1].pri_unit_rate+'" data-secunitrate="'+products[count][1].sec_unit_rate+'"'
                +'data-maxpri="'+products[count][1].in_hand_stock_primary+'" data-maxsec="'+products[count][1].in_hand_stock_second+'"'
                +'data-noofpcs="'+products[count][1].no_of_pcs+'"'
                +'>'+products[count][1].product_name+'</option>')
        }
        $('#item_name' + window.rowCount).select2({ width: "100%", tags: true }); //to initiatate select2  
    }//Product list end here  

    $("#tdFormRow").on('change','select.proChng',function(){ 
        $(this).parents('.addedRow').children('.unit-td').children('.unitList').empty();

        $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option value="'+$(this).find(':selected').data('punitid')+'"'
            +'data-max="'+$(this).find(':selected').data('maxpri')+'" data-unitrate="'+$(this).find(':selected').data('priunitrate')+'"'
            +'>'+$(this).find(':selected').data('punitname')+'</option>')

        $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option value="'+$(this).find(':selected').data('sunitid')+'"'
            +'data-max="'+$(this).find(':selected').data('maxsec')+'" data-unitrate="'+$(this).find(':selected').data('secunitrate')+'"'
            +'>'+$(this).find(':selected').data('sunitname')+'</option>')

        $(this).parents('.addedRow').children('.mrp-td').children('#product_mrp').val($(this).find(':selected').data('priunitrate')) 
        $(this).parents('.addedRow').children('.qty-td').children('#qty').attr({"max" : $(this).find(':selected').data('maxpri'), "placeholder":"Max Qty: "+$(this).find(':selected').data('maxpri')+""}) 
    })//Onchange product show primary unit & mrp

    $("#tdFormRow").on('change','select.unitList',function(){                       
        $(this).parents('.addedRow').children('.mrp-td').children('#product_mrp').val($(this).find(':selected').data('unitrate'))        
        $(this).parents('.addedRow').children('.qty-td').children('#qty').attr({"max": $(this).find(':selected').data('max'), "placeholder":"Max Qty: "+$(this).find(':selected').data('max')+"",})        
        $(this).parents('.addedRow').children('.qty-td').children('#qty').val('')        
        $(this).parents('.addedRow').children('.discount-td').children('#discount').val(0)        
        $(this).parents('.addedRow').children('.amount-td').children('#amount').val('')        
    })//Onchange unit show primary qty & mrp

    $(document).on('change','select.customer',function(event){ 
        event.preventDefault()        
        // $("#balance").val($(this).find(':selected').data('balance'))
        prevBalance = $(this).find(':selected').data('balance')
        $("#prev_balance").val(parseFloat(prevBalance))//this is to store
        $('#prev_bal').text("Previous balance: "+prevBalance) 
        totalCalculation()           
    })

    /*Remove row start of FORM*/
    $(document).on('click', '.remove', function() {        
        $(this).parent().parent().remove()
        // $(this).closest('table').children('tr').addClass('xxx');
        // $(this).closest('td').parent('tr').parent()[0].sectionRowIndex
        totalCalculation()
        // let id = $(this).attr('id')
        // let data = {};
        // data =
        // {  
        //     id : id,
        // }          
        // singleItemDel.push(data)        
    });
    /*Remove row end of FORM*/

    /* Date Picker Start*/
    $('.date').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
        width: "100%",
        startDate: "01-04-2021",
        endDate: "0d",
        todayHighlight: true,
    })
    /* Date Picker End*/

    /* To prevent multi decimal input start */
    $('#product_mrp, #discount').keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /* To prevent multi decimal input edn */
    
    // Input type Quantity change function Start
    $('#tdFormRow tbody').delegate('.qty','keyup', function() {       
        let max = $(this).attr("max");
        let val = parseInt($(this).val(), 10);        
        if(max){            
            if(val > max || val < 1){
                $(this).addClass('is-invalid')
                // $("#cartInputTable thead th:last").children('.addRow').prop('disabled', true); //disable add button
            }
            else{
                $(this).removeClass('is-invalid')
                $(this).addClass('is-valid')
                // $("#cartInputTable thead th:last").children('.addRow').prop('disabled', false); //enable add button
            }            
        }
        // else{
        //     snacbar("Select respective SKU first")
        //     $(this).addClass('is-invalid')
        // }
    })
    // Input type Quantity change function End

    /* Toatal calculation*/
    var total = 0;
    $('#tdFormRow tbody').delegate('.qty, .mrp, .discount', 'keyup', function() {
        var tr = $(this).parent().parent();
        var qty = tr.find('.qty').val();
        var mrp = tr.find('.mrp').val();
        var discount = tr.find('.discount').val();
        var amount = qty * (mrp - discount);
        tr.find('.amount').val(parseFloat(amount).toFixed(2));
        totalCalculation()
    });

    $("#received").on('keyup',function(){
        if($("#received").val() != ''){
            totalCalculation()
        }    
    })
    $("#round_off").on('keyup',function(){
        if($("#round_off").val() != ''){
            totalCalculation()
        }  
    })
    $("#gst_amount").on('keyup',function(){
        if($("#gst_amount").val() != ''){
            totalCalculation()
        }
    })
    
    function totalCalculation() {
        var subTotal = 0;
        var received = $("#received").val()
        var roundOff = $("#round_off").val()
        var gstAmount = $("#gst_amount").val()
        $('.amount').each(function(i, e) {
            var amount = $(this).val() - 0;
            subTotal += amount;  
        });
        total = parseFloat(subTotal) + parseFloat(gstAmount);    
        total = parseFloat(total) - parseFloat(roundOff);    
        var balance = parseFloat(total) - parseFloat(received);
        balance = parseFloat(balance) + parseFloat(prevBalance)
        $("#total").val(total)
        $("#balance").val(balance)     
    }//Toatal calculation  
    /*Form modal Html Part end*/

    /*------ Create New Sale function start -------*/
    $('#newSaleForm').on('click', '#addBtn', function (event) {
        event.preventDefault();
        $(".text-danger").html("") 
        var error = $('.is-invalid').length;
        if( error == 0){
        var formData = new FormData($('#newSaleForm')[0]);
        $.ajax({
            method: 'POST',
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function (response) {
                if(response.errors){
                    if(response.errors.customer_id){
                        $("#customer_id_error").text(response.errors.customer_id[0])
                    }
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.payment_type){
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }
                    for (var i = 0; i < window.rowCount+1 || i < 1  ; i++) {
                        
                        if(response.errors["item_name."+i]){
                            $(".item_name_error_"+i).text(response.errors["item_name."+i][0])
                        }
                        if(response.errors["unit_name."+i]){
                            $(".unit_name_error_"+i).text(response.errors["unit_name."+i][0])
                        }
                        if(response.errors["qty."+i]){
                            $(".qty_error_"+i).text(response.errors["qty."+i][0])
                        }
                        if(response.errors["product_mrp."+i]){
                            $(".product_mrp_error_"+i).text(response.errors["product_mrp."+i][0])
                        }
                        if(response.errors["amount."+i]){
                            $(".amount_error_"+i).text(response.errors["amount."+i][0])
                        }
                    }      
                }
                // //on success
                else{
                    $('#sale_table').DataTable().ajax.reload(); 
                    $("#modal").modal('hide')
                    $("#newSaleForm")[0].reset()
                    $('.select2').select2({                       
                            initSelection: function(element, callback) {                   
                        }
                    });  
                    customers = response.customers  
                    sales = response.sales        
                    let message = response.success;
                    snacbar(message)
                }
            },
            error:function(error){
                snacbar(error.statusText)
            }
        })//ajax end here
        }
    })//Add product function end here
    /*------ Create New Sale function end -------*/

    /*------- Vie Start Here -------------*/
    $(document).on('click','a.view', function(event){
        event.preventDefault()
        customerList()
        let id = $(this).attr('id')
        tdFormRowIndex = 0
        let j = 0;  
        $(".unitList").empty()
        $('.addedRow').remove()
        for(let count=0; count < sales.length; count++){
            if(sales[count].invoice_id == id){
                addRow(sales[count])               
                if(sales[count].item_name == sales[count].product_id){
                    $('.productList'+j).select2({width:"100%" }).val(sales[count].item_name).trigger("change");
                }
                else{
                    var newOption = new Option(sales[count].item_name, sales[count].item_name, true, true);
                    $(".productList"+j).append(newOption).trigger('change');
                }                
                $('#unit_id'+j).append('<option value="'+sales[count].unit_id+'">'+sales[count].unit_name+'</option>') 
                console.log(sales[count].customer_id) 
                $('#customer_id').val(sales[count].customer_id);                
                $('#date').val(moment(sales[count].date, 'YYYY-MM-DD').format("DD-MM-YYYY"));
                $('#payment_type').val(sales[count].payment_type);
                $("#round_off").val(sales[count].round_off) 
                $("#gst_amount").val(sales[count].gst_amount) 
                $("#total").val(sales[count].total) 
                $("#advance").val(sales[count].advance) 
                $("#balance").val(sales[count].balance) 
                $("#remarks").val(sales[count].remarks) 
                j++
            }
        } 
        $('.select2').select2({width:"100%", tags:true, dropdownParent: $('#modal')}); 
        $('.modal-title').text("Details Sale #"+id);
        $('#addBtn').hide();
        $('#editBtn').hide();
        $("input[type='text']").removeClass("text-capitalize")
        $(".text-danger").html("")
        $("a.addRow").hide()    
        $('a.btn-icon').remove()  
        $('#modal').modal('show')
        $("#tdFormRow tbody tr").children('td:nth-child(2)').removeClass("unit-td")

    })
    /*------- Vie End Here -------------*/

   
})