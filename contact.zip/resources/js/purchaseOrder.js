$(document).ready(function() {
    var base_url = "https://varneyatechnologies.com";
    window.rowCount = 0;     
    var singleItemDel = []; // required at the time of edit
    /*Form modal Html Part Start*/
    $('.addRow').on('click', function() {
        var item = {};
        item.item_name = '';
        item.unit_id = '';
        item.qty = '';
        item.unit_price = '';
        item.total_price = '';
        item.purchase_id = '';
        addRow(item)
        $("#tdFormRow tbody tr").children('td:nth-child(2)').addClass("unit-td")        
    })
    /* Add input row into Purchase Order Form Start */
    var tdFormRowIndex = 0;
    function addRow(item) {
        var tr = '<tr class="addedRow row_'+tdFormRowIndex+'">' +
            '<td>' +
            '<select class="form-control text-capitalize select2 proChng productList'+tdFormRowIndex+'" name="item_name[' +tdFormRowIndex+ ']" id="item_name' +tdFormRowIndex+ '" value="' + item.item_name + '" tabindex="-1" aria-hidden="true">' +
            '</select>' +
            '<span class="text-danger item_name_error_' +tdFormRowIndex+ '"></span> ' +
            '</td>' +
            '<td>' +
            '<select class="form-control text-capitalize unitList" name="unit_id['+tdFormRowIndex+']" id="unit_id'+tdFormRowIndex+'" value="" tabindex="-1" aria-hidden="true">' +
            '</select>' +
            '<div class="text-danger unit_id_error_' +tdFormRowIndex+ '"></div> ' +
            '</td>' +

            '<td class="td-qty">' +
            '<input type="number" name="qty[' +tdFormRowIndex+ ']" id="qty" value="' + item.qty + '"  class="form-control qty" placeholder="Quantity" oninput="this.value = Math.round(this.value);">' +
            '<span class="text-danger qty_error_' +tdFormRowIndex+ '"></span> ' +
            '</td>' +

            '<td>' +
            '<input type="number" name="unit_price[' +tdFormRowIndex+ ']" id="unit_price" value="' + item.unit_price + '"  class="form-control unitPrice" placeholder="Price">' +
            '<span class="text-danger unit_price_error_' +tdFormRowIndex+ '"></span> ' +
            '</td>' +
            '<td>' +
            '<input type="number" name="amount[' +tdFormRowIndex+ ']" id="amount" value="' + item.amount + '"  class="form-control amount" placeholder="Total" onchange="(function(el){el.value=parseFloat(el.value).toFixed(2);})(this)"readonly>' +
            '<span class="text-danger amount_error_' +tdFormRowIndex+ '"></span> ' +
            '</td>' +
            '<td>'
            +'<input type="hidden" class="primary-qty" name="primary_qty['+tdFormRowIndex+']" id="primary_qty" value="">'
            +'<input type="hidden" class="second-qty" name="secondary_qty['+tdFormRowIndex+']" id="secondary_qty" value="">'
            +'<a href="javascript:void(0)" class="btn btn-icon remove" id="'+item.purchase_order_id+'" id="remove'+tdFormRowIndex+'" style="border: 1px solid #f54394">' +
            '<svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="color: red;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
            '</a>' +
            '</td>' +
            '</tr>';
        window.rowCount = tdFormRowIndex;
        tdFormRowIndex++;
        $('#tdFormRow tbody').append(tr);
        productsList(products)
    }//Add row into purchase modal form end
    
    function productsList(products) {
        $(".productList"+window.rowCount).empty().append('<option selected="" value="">Select an option</option>');
        for (count = 0; count < products.length; count++) {
            $(".productList"+window.rowCount).append('<option value="'+products[count][1].product_id+'"'
                +'data-punitid="'+products[count][1].p_unit_id+'" data-punitname="'+products[count][1].p_unit_name+'" data-sunitid="'+products[count][1].s_unit_id+'"'
                +'data-sunitname="'+products[count][1].s_unit_name+'" data-noofpcs="'+products[count][1].no_of_pcs+'"'
                +'>'+products[count][1].product_name+'</option>')
        }
        // $('#item_name' + window.rowCount).off('productList:select');
        $('#item_name' + window.rowCount).select2({ width: "100%", tags: true }); //to initiatate select2  
    }//Product lsit end here  
    var p1,s2;
    $("#tdFormRow").on('change','select.proChng',function(){ 
    if($(this).find(':selected').data('noofpcs')){
        $(this).parents('.addedRow').children('.unit-td').children('.unitList').empty().append('<option selected="" value="">Select an option</option>');           
        $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option class="text-capitalize p-pcs" value="'+$(this).find(':selected').data('punitid')+'" data-p1="'+$(this).find(':selected').data('noofpcs')+'">'+$(this).find(':selected').data('punitname')+'</option>')    
        $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option class="text-capitalize s-pcs" value="'+$(this).find(':selected').data('sunitid')+'" data-s2="'+$(this).find(':selected').data('noofpcs')+'">'+$(this).find(':selected').data('sunitname')+'</option>')
        p1 = 1
        s2 = $(this).find(':selected').data('noofpcs');
    } 
    else{   
        $(this).parents('.addedRow').children('.unit-td').children('.unitList').empty().append('<option selected="" value="">Select an option</option>');
        for(let count=0; count < units.length; count++){
            $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option class="text-capitalize" value="'+units[count][1].unit_id+'">'+units[count][1].unit_name+'</option>')
        }
    }         
    })//Onchange product show primary unit & mrp
    
    $("#tdFormRow").on('change','select.unitList',function(){ 
        $(this).parents('.addedRow').children('.td-qty').children('#qty').val('')            
            if($(this).find(':selected').data('p1')){
                p1 = 1
                s2 = $(this).find(':selected').data('p1');
            }
            if($(this).find(':selected').data('s2')){
                p1 = $(this).find(':selected').data('s2');
                s2 = 1
            }
    })//Onchange unit set value no_of_pcs 

    /*Remove row start of FORM*/
    $(document).on('click', '.remove', function() {        
        $(this).parent().parent().remove()
        // $(this).closest('table').children('tr').addClass('xxx');
        // $(this).closest('td').parent('tr').parent()[0].sectionRowIndex
        totalCalculation()
        let id = $(this).attr('id')
        let data = {};
        data =
        {  
            id : id,
        } 
        singleItemDel.push(data)
    });
    /*Remove row end of FORM*/

    /* Date Picker Start*/
    $('.date').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
        width: "100%",
        startDate: "01-04-2021",
        endDate: "0d",
        todayHighlight: true,
    })
    /* Date Picker End*/

    /* To prevent multi decimal input start */
    $('#unit_price').keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /* To prevent multi decimal input edn */

    /* Toatal calculation*/
    var total = 0;
    $('tbody').delegate('.qty, .unitPrice', 'keyup', function() {
        var tr = $(this).parent().parent();
        var qty = tr.find('.qty').val();
        var unitPrice = tr.find('.unitPrice').val();
        var amount = qty * unitPrice;
        tr.find('.amount').val(parseFloat(amount).toFixed(2));
        tr.find('.primary-qty').val(parseInt(qty/p1, 10));
        tr.find('.second-qty').val(parseInt(qty*s2, 10));          
        totalCalculation()        
    });

    $("#advance").on('keyup',function(){
        if($("#advance").val() != ''){
            totalCalculation()
        }   
        else{
            $("#advance").val(0)
        }     
    })
    $("#round_off").on('keyup',function(){
        if($("#round_off").val() != ''){
            totalCalculation()
        }  
    })
    $("#gst_amount").on('keyup',function(){
        if($("#gst_amount").val() != ''){
            totalCalculation()
        }
    })
    
    function totalCalculation() {
        var subTotal = 0;
        var advance = $("#advance").val()
        var roundOff = $("#round_off").val()
        var gstAmount = $("#gst_amount").val()
        $('.amount').each(function(i, e) {
            var amount = $(this).val() - 0;
            subTotal += amount;  
        });
        total = parseFloat(subTotal) + parseFloat(gstAmount);    
        total = parseFloat(total) - parseFloat(roundOff);    
        var balance = parseFloat(total) - parseFloat(advance);
        $("#total").val(total)
        $("#balance").val(balance)     
    }//Toatal calculation  
    /*Form modal Html Part end*/
    /* PurchaseOrder Item DataTable Start Here*/
    var dataTable = $("#purchase_order_table").DataTable({
        processing: true,
        serverSide: true,
        buttons: [{ extend: 'csv', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'excel', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'pdf', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'print', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}}
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex",
            render: function(data){
                return '<small class="text-muted">'+data+'</small>'
            }
        }, {
            data: "po_id",
            name: "po_id",
            render: function(data, type, full, meta) {
                return '<a href="#" class="item-company ajax h-1x" data-pjax-state="">'+data+'</a>'
            },      
        }, {
            data: "date",
            name: "date",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        },{
            data: "party_id",
            name: "party_id"
        },{
            data: "total",
            name: "total",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        },{
            data: "advance",
            name: "advance",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        }, {
            data: "balance",
            name: "balance",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        },{
            data: "status",
            name: "status"
        }, {
            data: "action",
            name: "action"
        }]
    });
    /*------ Purchase Order dataTable end here ------*/
    /*------ Export Start ------*/
    $(document).on('click',".export",function(){
        var btn = $(this).attr('id').toString()
        dataTable.button(btn).trigger();
    })
    /*------ Export End -------*/ 
    /* PurchaseOrder Item DataTable End Here*/
    /* Add Modal Start */
    $(document).on('click','button.add',function(){ 
        $(".addedRow").remove() 
        tdFormRowIndex=0;
        var item = {}
        addRow(item)    
        $('.modal-title').text("Purchase Order");
        $('#addBtn').show();
        $('#editBtn').hide();
        $('#convertPOBtn').hide();
        $("input[type='text']").removeClass("text-capitalize")
        $('.select2').select2({ 
            initSelection: function(element, callback) {                   
            },
            width:"100%", tags:true, dropdownParent: $('#modal')
        });  
        $("#purchaseOrderForm")[0].reset()
        $(".text-danger").html("")
        $("a.addRow").show()    
        $('a.btn-icon').show()  
        $("#tdFormRow tbody tr").children('td:nth-child(2)').addClass("unit-td")
     });
    /* Add Modal end */
    /* Add PurchaseOrder Start */
    $('#purchaseOrderForm').on('click', '#addBtn', function (event) {
        event.preventDefault();
        $(".text-danger").html("") 
        var formData = new FormData($('#purchaseOrderForm')[0]);
        $.ajax({
            method: 'POST',
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function (response) {
                if(response.errors){
                    if(response.errors.party_id){
                        $("#party_id_error").text(response.errors.party_id[0])
                    }
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.payment_type){
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }
                    for (var i = 0; i < window.rowCount+1 || i < 1  ; i++) {
                        
                        if(response.errors["item_name."+i]){
                            $(".item_name_error_"+i).text(response.errors["item_name."+i][0])
                        }
                        if(response.errors["unit_id."+i]){
                            $(".unit_id_error_"+i).text(response.errors["unit_id."+i][0])
                        }
                        if(response.errors["qty."+i]){
                            $(".qty_error_"+i).text(response.errors["qty."+i][0])
                        }
                        if(response.errors["unit_price."+i]){
                            $(".unit_price_error_"+i).text(response.errors["unit_price."+i][0])
                        }
                        if(response.errors["amount."+i]){
                            $(".amount_error_"+i).text(response.errors["amount."+i][0])
                        }
                    }      
                }
                //on success
                else{
                    $('#purchase_order_table').DataTable().ajax.reload(); 
                    $("#modal").modal('hide')
                    $("#purchaseOrderForm")[0].reset()
                    $('.select2').select2({                       
                            initSelection: function(element, callback) {                   
                        }
                    });      
                    allPoItem = response.allPoItem             
                    let message = response.success;
                    snacbar(message)
                }
            },
            error:function(error){
                snacbar(error.statusText)
            }
        })//ajax end here
    })//Add product function end here
    /*Add PurchaseOrder End*/

    /* PurchaseOrder View Start*/
    $(document).on("click", "button.view", function(event) { 
        event.preventDefault();    
        let po_id = $(this).attr('id');
        let date = moment($(this).data('date'), 'YYYY-MM-DD').format("DD-MM-YYYY");   
        $("a.addRow").hide()        
        $(".addedRow").remove()          
        $(".modal-title").text("Purchase Order Details #"+po_id)
        $('#addBtn').hide();
        $('#editBtn').hide();
        $('#convertPOBtn').hide();
        $('a.btn-icon').remove() 
        $("#tdFormRow tbody tr").children('td:nth-child(2)').removeClass("unit-td")
        let remove=true ;
        showData(date,po_id,remove)      
    })
    /* PurchaseOrder View End*/ 

    /* PurchaseOrder Edit Start*/
    $(document).on("click", "button.edit", function(event) { 
        event.preventDefault();
        let po_id = $(this).attr('id');
        let date = moment($(this).data('date'), 'YYYY-MM-DD').format("DD-MM-YYYY");
        $("#po_id").val(po_id)
        $("a.addRow").show()  
        $(".addedRow").remove()      
        $(".modal-title").text("Purchase Order Edit #"+po_id)
        $("#addBtn").hide()
        $("#editBtn").show()  
        $("#convertPOBtn").hide()  
        $("#tdFormRow tbody tr").children('td:nth-child(2)').addClass("unit-td")
        let remove=false ;  
        showData(date,po_id,remove)    
    })
    
    $("#purchaseOrderForm").on("click", "#editBtn", function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        let tdRowCount = $('#purchase_order_table tr').length;
        var formData = new FormData($("#purchaseOrderForm")[0]);
        formData.append('delete',JSON.stringify(singleItemDel))
        $.ajax({
            method: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if(response.errors){
                    if(response.errors.party_id){
                        $("#party_id_error").text(response.errors.party_id[0])
                    }
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.payment_type){
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }
                    for (var i = 0; i < tdRowCount  ; i++) {                        
                        if(response.errors["item_name."+i]){
                            $(".item_name_error_"+i).text(response.errors["item_name."+i][0])
                        }
                        if(response.errors["unit_id."+i]){
                            $(".unit_id_error_"+i).text(response.errors["unit_id."+i][0])
                        }
                        if(response.errors["qty."+i]){
                            $(".qty_error_"+i).text(response.errors["qty."+i][0])
                        }
                        if(response.errors["unit_price."+i]){
                            $(".unit_price_error_"+i).text(response.errors["unit_price."+i][0])
                        }
                        if(response.errors["amount."+i]){
                            $(".amount_error_"+i).text(response.errors["amount."+i][0])
                        }
                    }      
                }
                //on success
                else{
                    $('#purchase_order_table').DataTable().ajax.reload(); 
                    $("#modal").modal('hide')
                    $("#purchaseOrderForm")[0].reset()
                    $('.select2').select2({                       
                            initSelection: function(element, callback) {                   
                        }
                    });        
                    allPoItem = response.allPoItem             
                    let message = response.success;
                    snacbar(message)
                }
            }
        })
    })    
    /*------ PurchaseOrder Edit End ----------------*/ 
    /*------ Purchase order Item Delete Start ------*/
    $(document).on("click", "button.delete", function() {
        $("#id").val($(this).data("poid")) //have to use date regrad id 
        $(".modal-title").text("Order ID : #" + $(this).data("poid"))
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $("#purchase_order_table").DataTable().ajax.reload()
                    $("#confirmModal").modal("hide");
                    allPoItem = response.allPoItem     
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end
    })//Purchase order Item Delete function end
    /* ---- Purchase order Item Delete End ----*/

    /*------ Order Completion Function Start -----*/
    $(document).on('click',".over-due",function(){
        let po_id = $(this).attr('id');
        let date = moment($(this).data('date'), 'YYYY-MM-DD').format("DD-MM-YYYY");   
        $("#po_id").val(po_id)
        $("a.addRow").show()       
        $(".addedRow").remove()      
        $(".modal-title").text("Purchase Order Details #"+po_id)
        $('#addBtn').hide();
        $('#editBtn').hide();
        $('#convertPOBtn').show();
        let remove=true ;  
        showData(date,po_id,remove)    
    })
    $("#purchaseOrderForm").on("click", "#convertPOBtn", function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        var formData = new FormData($("#purchaseOrderForm")[0]);
        formData.append('delete',JSON.stringify(singleItemDel))
        $.ajax({
            method: "POST",
            url: routes.status,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                //on success
                $('#purchase_order_table').DataTable().ajax.reload(); 
                $("#modal").modal('hide')
                $("#purchaseOrderForm")[0].reset()
                $('.select2').select2({                       
                        initSelection: function(element, callback) {                   
                    }
                });      
                allPoItem = response.allPoItem             
                let message = response.success;
                snacbar(message)
                
            }
        })
    })  
    /*------ Order Completion Function Start -----*/

    /* ---- Function for Wiew & Edit details show start ----*/
    function showData(date,po_id,remove) {
        tdFormRowIndex=0 //to initial, without this data will not show        
        $(".unitList").empty()
        $('.select2').select2({width:"100%", tags:true, dropdownParent: $('#modal')});  
        let j =0;
        
        // var rowIndex = $(this).closest('td').parent()[0].sectionRowIndex 
        for(var count=0; count< allPoItem.length; count++){ //allPoItem variable declare in index.php
            if( allPoItem[count].po_id == po_id){   
                $("#date").val(date)
                $("#remarks").val(allPoItem[count].remarks)
                addRow(allPoItem[count])       
                if(remove == true){                    
                    $('a.btn-icon').remove() 
                }                            
                $('#party_id').val(allPoItem[count].party_id);
                if(allPoItem[count].item_name == allPoItem[count].product_id){
                    $('.productList'+j).select2({width:"100%" }).val(allPoItem[count].item_name).trigger("change");
                }
                else{
                    var newOption = new Option(allPoItem[count].item_name, allPoItem[count].item_name, true, true);
                    $(".productList"+j).append(newOption).trigger('change');
                }
                for(let uc=0; uc < units.length; uc++){
                    if(allPoItem[count].unit_id == units[uc][1].unit_id){ 
                        $('#unit_id'+window.rowCount).append('<option value="'+allPoItem[count].unit_id+'">'+units[uc][1].unit_name+'</option>') 
                    }            
                }                
                $('#payment_type').val(allPoItem[count].payment_type);
                $("#round_off").val(allPoItem[count].round_off) 
                $("#gst_amount").val(allPoItem[count].gst_amount) 
                $("#total").val(allPoItem[count].total) 
                $("#advance").val(allPoItem[count].advance) 
                $("#balance").val(allPoItem[count].balance) 
                $("#remarks").val(allPoItem[count].remarks) 
                j++
            }       
        }        
        $("#modal").modal("show") 
        $(".text-danger").html("")       
    }// show details function end here
    /*------------ Function for Wiew & Edit details show end--------*/
});