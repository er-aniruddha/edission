$(document).ready(function() {
    var base_url = "https://varneyatechnologies.com";
    $('.select2').select2({ width: "100%", tags: true }); //to initiatate select2  
    window.rowCount = 0;
    productsList(products)
    unitList(units)    
    console.log(purchaseOrder)
    /*Form modal Html Part Start*/
    $('.addRow').on('click', function() {
        var item = {};
        item.item_name = '';
        item.unit_name = '';
        item.qty = '';
        item.unit_price = '';
        item.total_price = '';
        item.purchase_id = '';
        addRow(item)
    })
    /* Add input row into Purchase Order Form Start */
    var i = 1;
    function addRow(item) {
        var tr = '<tr class="addedRow">' +
            '<td>' +
            '<select class="form-control select2 proChng productList'+i+'" name="item_name[' + i + ']" id="item_name' + i + '" value="' + item.item_name + '" tabindex="-1" aria-hidden="true">' +
            '</select>' +
            '<span class="text-danger item_name_error_' + i + '"></span> ' +
            '</td>' +
            '<td>' +
            '<select class="form-control select2 uniChng unitList'+i+'" name="unit_name[' + i + ']" id="unit_name' + i + '" value="' + item.unit_name + '" tabindex="-1" aria-hidden="true">' +
            '</select>' +
            '<div class="text-danger unit_name_error_' + i + '"></div> ' +
            '</td>' +

            '<td>' +
            '<input type="number" name="qty[' + i + ']" id="qty" value="' + item.qty + '"  class="form-control qty" placeholder="Quantity" oninput="this.value = Math.round(this.value);">' +
            '<span class="text-danger qty_error_' + i + '"></span> ' +
            '</td>' +

            '<td>' +
            '<input type="number" name="unit_price[' + i + ']" id="unit_price" value="' + item.unit_price + '"  class="form-control unitPrice" placeholder="Price">' +
            '<span class="text-danger unit_price_error_' + i + '"></span> ' +
            '</td>' +
            '<td>' +
            '<input type="number" name="amount[' + i + ']" id="amount" value="' + item.amount + '"  class="form-control amount" placeholder="Total" onchange="(function(el){el.value=parseFloat(el.value).toFixed(2);})(this)"readonly>' +
            '<span class="text-danger amount_error_' + i + '"></span> ' +
            '</td>' +
            '<td><a href="javascript:void(0)" class="btn btn-icon remove" id="' + item.purchase_id + '" data-date="' + item.date + '" data-count="' + i + '" style="border: 1px solid #f54394">' +
            '<svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="color: red;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
            '</a>' +
            '</td>' +
            '</tr>';
        window.rowCount = i;
        i++;
        $('#tdFormRow tbody').append(tr);
        productsList(products)
        unitList(units)
    }//Add row into purchase modal form end
    
    function productsList(products) {
        $(".productList"+window.rowCount).empty().append('<option selected="" value="">Select an option</option>');
        for (count = 0; count < products.length; count++) {
            $(".productList"+window.rowCount).append('<option value="' + products[count][1].product_id + '">' + products[count][1].product_name + '</option>')
        }
        // $('#item_name' + window.rowCount).off('productList:select');
        $('#item_name' + window.rowCount).select2({ width: "100%", tags: true }); //to initiatate select2  
    }//Product lsit end here

    function unitList(units) {
        $('.unitList'+window.rowCount).empty().append('<option selected="" value="">Select an option</option>');
        for (countUnit = 0; countUnit < units.length; countUnit++) {
            $(".unitList"+window.rowCount).append('<option value="' + units[countUnit][1].unit_name + '">' + units[countUnit][1].unit_name + '</option>')
        }
        $('#unit_name' + window.rowCount).select2({ width: "100%", tags: true }); //to initiatate select2  
    }//unit list end here   

    $("#tdFormRow").on('change','select.proChng',function(){
        for (count = 0; count < products.length; count++) {
            if(products[count][1].product_id == $(this).val()){
                var rowIndex = $(this).closest('td').parent()[0].sectionRowIndex
                $('.unitList'+rowIndex).select2({ width: "100%" }).val(products[count][1].primary_unit).trigger("change");
            }
        }
    })//Onchange product show primary unit

    /*Remove row start of FORM*/
    $(document).on('click', '.remove', function() {        
        $(this).parent().parent().remove();
        totalCalculation()
        // let id = $(this).attr('id')
        // let date = $(this).data('date')
        // let data = {};
        // data =
        // {  
        //     date : date,
        //     id : id,
        // }  
        // if(singleItemDel.length != 0 ){            
        //     if(singleItemDel[0].date == date){               
        //         singleItemDel.push(data)
        //     }
        //     else{
        //         singleItemDel = [];
        //         singleItemDel.push(data)
        //     }
        // }
        // else{
        //     singleItemDel.push(data)
        // }      
        // $("#singleItemDel").val(singleItemDel)
    });
    /*Remove row end of FORM*/

    /* Date Picker Start*/
    $('.date').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
        width: "100%",
        startDate: "01-04-2021",
        endDate: "0d",
        todayHighlight: true,
    })
    /* Date Picker End*/

    /* To prevent multi decimal input start */
    $('#unit_price').keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /* To prevent multi decimal input edn */

    /* Toatal calculation*/
    var total = 0;
    $('tbody').delegate('.qty, .unitPrice', 'keyup', function() {
        var tr = $(this).parent().parent();
        var qty = tr.find('.qty').val();
        var unitPrice = tr.find('.unitPrice').val();
        var amount = qty * unitPrice;
        tr.find('.amount').val(parseFloat(amount).toFixed(2));
        // var roundOff = $("#round_off").val()
        // total = total + amount - roundOff
        // $('#total').val(parseFloat(total).toFixed(2));
        // $('#advance').val(parseFloat(total).toFixed(2));
        totalCalculation()
    });

    $("#advance").on('keyup',function(){
        if($("#advance").val() != ''){
            totalCalculation()
        }   
        else{
            $("#advance").val(0)
        }     
    })
    $("#round_off").on('keyup',function(){
        if($("#round_off").val() != ''){
            totalCalculation()
        }  
    })
    $("#gst_amount").on('keyup',function(){
        if($("#gst_amount").val() != ''){
            totalCalculation()
        }
    })
    
    function totalCalculation() {
        var subTotal = 0;
        var advance = $("#advance").val()
        var roundOff = $("#round_off").val()
        var gstAmount = $("#gst_amount").val()

        $('.amount').each(function(i, e) {
            var amount = $(this).val() - 0;
            subTotal += amount;  
        });
        total = parseFloat(subTotal) + parseFloat(gstAmount);    
        total = parseFloat(total) - parseFloat(roundOff);    
        var balance = parseFloat(total) - parseFloat(advance);
        console.log(balance)
        $("#total").val(total)
        $("#balance").val(balance)     
    }//Toatal calculation  
    /*Form modal Html Part end*/
    /* PurchaseOrder Item DataTable Start Here*/
    var dataTable = $("#purchase_order_table").DataTable({
        processing: true,
        serverSide: true,
        buttons: [
            { 
                extend: 'csv',
                exportOptions: {
                    columns: [ 0, 1, 2, 3,4,5,6,7 ]
                }            
            },
            { 
                extend: 'excel',
                exportOptions: {
                    columns: [ 0, 1, 2, 3,4,5,6,7 ]
                }              
            },
            { 
                extend: 'pdf',
                exportOptions: {
                    columns: [ 0, 1, 2, 3,4,5,6,7 ]
                }              
            },
            { 
                extend: 'print',
                exportOptions: {
                    columns: [ 0, 1, 2, 3,4,5,6,7 ]
                }           
            }
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex",
            render: function(data){
                return '<small class="text-muted">'+data+'</small>'
            }
        }, {
            data: "po_id",
            name: "po_id",
            render: function(data, type, full, meta) {
                return '<a href="#" class="item-company ajax h-1x" data-pjax-state="">'+data+'</a>'
            },      
        }, {
            data: "date",
            name: "date",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        },{
            data: "party_id",
            name: "party_id"
        },{
            data: "total",
            name: "total",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        },{
            data: "advance",
            name: "advance",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        }, {
            data: "balance",
            name: "balance",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        },{
            data: "status",
            name: "status"
        }, {
            data: "action",
            name: "action"
        }]
    });
    /* PurchaseOrder Item DataTable End Here*/

    /* Add Modal Start */
    $(document).on('click','button.add',function(){ 
        i=1;
        $('.modal-title').text("Purchase Order");
        $('#addBtn').show();
        $('#editBtn').hide();
        $("input[type='text']").removeClass("text-capitalize")
        $('#purchaseOrderForm')[0].reset();        
        $('.select2').select2({                       
                initSelection: function(element, callback) {                   
            },
            width:"100%"
        }); 
        $("#purchaseOrderForm")[0].reset()
        $(".text-danger").html("")
        $("a.addRow").show()    
        $('a.btn-icon').show()    
        $(".addedRow").remove() 
        $(".row_0").show()

     });
    /* Add Modal end */

    /* Add PurchaseOrder Start */
    $('#purchaseOrderForm').on('click', '#addBtn', function (event) {
        event.preventDefault();
        $(".text-danger").html("") 
        var formData = new FormData($('#purchaseOrderForm')[0]);
        $.ajax({
            method: 'POST',
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function (response) {
                console.log(response)
                if(response.errors){
                    if(response.errors.party_id){
                        $("#party_id_error").text(response.errors.party_id[0])
                    }
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.payment_type){
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }
                    for (var i = 0; i < window.rowCount+1 || i < 1  ; i++) {
                        
                        if(response.errors["item_name."+i]){
                            $(".item_name_error_"+i).text(response.errors["item_name."+i][0])
                        }
                        if(response.errors["unit_name."+i]){
                            $(".unit_name_error_"+i).text(response.errors["unit_name."+i][0])
                        }
                        if(response.errors["qty."+i]){
                            $(".qty_error_"+i).text(response.errors["qty."+i][0])
                        }
                        if(response.errors["unit_price."+i]){
                            $(".unit_price_error_"+i).text(response.errors["unit_price."+i][0])
                        }
                        if(response.errors["amount."+i]){
                            $(".amount_error_"+i).text(response.errors["amount."+i][0])
                        }
                    }      
                }
                //on success
                else{
                    $('#purchase_order_table').DataTable().ajax.reload(); 
                    $("#modal").modal('hide')
                    $("#purchaseOrderForm")[0].reset()
                    $('.select2').select2({                       
                            initSelection: function(element, callback) {                   
                        }
                    });      
                    purchaseOrder = response.purchaseOrder             
                    let message = response.success;
                    snacbar(message)
                }
            },
            error:function(error){
                snacbar(error.statusText)
            }
        })//ajax end here
    })//Add product function end here
    /*Add PurchaseOrder End*/

    /* PurchaseOrder View Start*/
    $(document).on("click", "button.view", function(event) { 
        event.preventDefault();
        console.log("ok")
        $("a.addRow").hide()        
        $(".addedRow").remove() 
        $(".row_0").hide()
        i = 0;
        let j =0;
        let po_id = $(this).attr('id');
        let date = $(this).data('date');
        let dateSplit = date.split('-')
        let date_for_show = dateSplit[2]+'-'+dateSplit[1]+'-'+dateSplit[0]
        var rowIndex = $(this).closest('td').parent()[0].sectionRowIndex 
        for(var count=0; count< purchaseOrder.length; count++){ //purchaseOrder variable declare in index.php
            if( purchaseOrder[count].po_id == po_id){   
                $("#date").val(date_for_show)
                $("#remarks").val(purchaseOrder[count].remarks) 
                addRow(purchaseOrder[count])
                $('#party_id').val(purchaseOrder[count].party_id);
                $('.productList'+j).select2({width:"100%" }).val(purchaseOrder[count].item_name).trigger("change");
                $('.unitList'+j).select2({width:"100%" }).val(purchaseOrder[count].unit_name).trigger("change");
                $('#payment_type').val(purchaseOrder[count].payment_type);
                $("#round_off").val(purchaseOrder[count].round_off) 
                $("#gst_amount").val(purchaseOrder[count].gst_amount) 
                $("#total").val(purchaseOrder[count].total) 
                $("#advance").val(purchaseOrder[count].advance) 
                $("#balance").val(purchaseOrder[count].balance) 
                $("#remarks").val(purchaseOrder[count].remarks) 
                console.log(purchaseOrder[count])
                $('a.btn-icon').hide()    
                j++
            }             
           
        }        
        $(".modal-title").text("Purchase Order Details #"+po_id)
        $("#modal").modal("show") 
        $(".text-danger").html("")
        $("#addBtn").hide()
        $("#editBtn").hide()        
    })
    /* PurchaseOrder View End*/ 

});