$(document).ready(function() {
  var base_url = "https://varneyatechnologies.com";
  var prevBalance;
  $.fn.modal.Constructor.prototype._enforceFocus = function() {};
  /*------- input[type='number'] can't be null -------*/
  const numInputs = document.querySelectorAll('input[type=number]')
  numInputs.forEach(function(input) {
      input.addEventListener('change', function(e) {
          if (e.target.value == '') {
              e.target.value = 0
              totalCalculation()
          }
      })
  })
  /*------- input[type='number'] can't be null -------*/

  /*------- Credit Note DataTable Start Here -------*/
  var creditNoteTable = $("#credit_note_table").DataTable({
    processing: true,
    serverSide: true,
    lengthMenu: [
        [10, 25, 50,100, -1],
        [10, 25, 50,100, 'All'],
    ],
    buttons: [{ extend: 'csv', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
        { extend: 'excel', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
        { extend: 'pdf', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
        { extend: 'print', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } }
    ],
    ajax: {
        url: routes.index
    },
    columns: [{
        data: "DT_RowIndex",
        name: "DT_RowIndex",
        render: function(data) {
            return '<small class="text-muted">' + data + '</small>'
        }
    }, {
        data: "cr_order_date",
      name: "cr_order_date",
      render: function(data, type, full, meta) {
          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">' + moment(data).format('DD-MM-YYYY') + '</span>'
      }
  },{
      data: "cr_delivery_date",
      name: "cr_delivery_date",
      render: function(data, type, full, meta) {
        if(!data){
          return '<span class="item-badge badge text-uppercase bg-warning">Not Deliverd</span>';     
        } 
        else{
          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">' + moment(data).format('DD-MM-YYYY') + '</span>'
        }               
      }     
  },{
      data: "cr_trnx_id",
      name: "cr_trnx_id",
      render: function(data) {
        return '<span class="item-amount d-none d-sm-block text-sm text-success text-capitalize">CRN-' + data + '</span>'
      }
  },{
      data: "name",
      name: "name",
  },{
      data: "cr_payment_type",
      name: "cr_payment_type",
      render: function(data) {
        if (data == 1) {
          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Cash</span>'
        }
        if (data == 2) {
          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Online</span>'
        }
        if (data == 3) {
          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Cheque</span>'
        }
        if (data == 4) {
          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-danger">No Payment</span>'
        }
      }
  },{
      data: "cr_total",
      name: "cr_total",
      render: function(data) {
        return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) + '</span>'
      }
  },{
      data: "cr_prev_balance",
      name: "cr_prev_balance",
      render: function(data) {
        return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) + '</span>'
      }
  },{
      data: "cr_paid",
      name: "cr_paid",
      render: function(data) {
        return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) + '</span>'
      }
  },{
      data: "cr_balance",
      name: "cr_balance",
      render: function(data) {
        return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) + '</span>'
      }
  },{
      data: "cr_payment_status",
      name: "cr_payment_status",
      render: function(data) {
        if (data == 0) {
          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-danger">Unpaid</span>'
        }
        if (data == 1) {
          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-warning">Partial</span>'
        }
        if (data == 2) {
          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-success">Paid</span>'
        }
      }
  },{
    data: "status",
    name: "status",
  },{
    data: "action",
    name: "action",
  }],
});
/*------ Credit Note dataTable end here ------*/

/*------ Export Start ------*/
$(document).on('click', ".export", function() {
    var btn = $(this).attr('id').toString()
    creditNoteTable.button(btn).trigger();
})
/*------ Export End -------*/

/*--------- Add customer list start -------*/
function customerList() {
    $('#customer_id').empty().append('<option selected="" value="">Select customer</option>');
    for (let i = 0; i < customers.length; i++) {
        $("#customer_id").append('<option value="' + customers[i].customer_id + '" data-balance="' + customers[i].balance + '" data-type="' + customers[i].customer_type + '">' + customers[i].f_name + ' ' + customers[i].s_name +' ( '+customers[i].locality+' ) ( ' + customers[i].phone_1 + ' ) ' + ' (' + customers[i].shop_name + ')' + '</option>')
    }
    $('#customer_id').select2({ width: "100%" }); //to initiatate select2             
}
/*--------- Add customer list end -------*/

/*--------- Form modal Html Part Start ---------*/
$('.addRow').on('click', function() {
    var item = {
        item_name: '',
        unit_id: '',
        sale_qty: '',
        sale_unit_price: '',
        sale_amount: 0,
    }
    addRow(item)
    $("#tdFormRow tbody tr").children('td:nth-child(2)').addClass("unit-td")
})
/*-------- Add input row into Purchase Order Form Start -------*/
var tdFormRowIndex = 0;

function addRow(item) {
    var tr = '<tr class="addedRow row_' + tdFormRowIndex + '">' +
        '<td>' +
        '<select class="form-control text-capitalize select2 proChng productList' + tdFormRowIndex + '" name="item_name[' + tdFormRowIndex + ']" id="item_name' + tdFormRowIndex + '" value="' + item.item_name + '" tabindex="-1" aria-hidden="true">' +
        '</select>' +
        '<span class="text-danger text-sm item_name_error_' + tdFormRowIndex + '"></span> ' +
        '</td>' +
        '<td class="">' +
        '<select class="form-control text-capitalize unitList" name="unit_id[' + tdFormRowIndex + ']" id="unit_id' + tdFormRowIndex + '" value="' + item.unit_id + '" tabindex="-1" aria-hidden="true">' +
        '</select>' +
        '<div class="text-danger text-sm unit_id_error_' + tdFormRowIndex + '"></div> ' +
        '</td>' +
        '<td class="qty-td">' +
        '<input type="number" name="qty[' + tdFormRowIndex + ']" id="qty" value="' + item.cr_qty + '"  class="form-control qty" placeholder="Quantity" oninput="this.value = Math.round(this.value);">' +
        '<span class="text-danger text-sm qty_error_' + tdFormRowIndex + '"></span> ' +
        '</td>' +
        '<td class="unit-price-td">' +
        '<input type="number" name="unit_price[' + tdFormRowIndex + ']" id="unit_price" value="' + item.cr_unit_price + '"  class="form-control unit-price" placeholder="Price">' +
        '<span class="text-danger text-sm unit_price_error_' + tdFormRowIndex + '" ></span> ' +
        '</td>' +
        '<td class="amount-td">' +
        '<input type="number" name="amount[' + tdFormRowIndex + ']" id="amount" value="' + item.cr_amount + '"  class="form-control amount" placeholder="Amount" onchange="(function(el){el.value=parseFloat(el.value).toFixed(2);})(this)" readonly>' +
        '<span class="text-danger text-sm amount_error_' + tdFormRowIndex + '"></span> ' +
        '</td>' +
        '<td><a href="javascript:void(0)" class="btn btn-icon remove" id="remove' + tdFormRowIndex + '" style="border: 1px solid #f54394">' +
        '<svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="color: red;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
        '</a>' +
        '</td>' +
        '</tr>';
    window.rowCount = tdFormRowIndex;
    tdFormRowIndex++;
    $('#tdFormRow tbody').append(tr);
    productsList(products)
    tdRowCount()
} //Add row into purchase modal form end

$(document).on('change', 'select.customer', function(event) {
    event.preventDefault()
    // $("#balance").val($(this).find(':selected').data('balance'))
    prevBalance = $(this).find(':selected').data('balance')
    $("#prev_balance").val(parseFloat(prevBalance)) //this is to store
    $('.prev_bal').text("Previous balance: " + prevBalance)
    window.customerType = $(this).find(':selected').data('type')
    totalCalculation()
})

// Add list of product into form select
function productsList(products) {
    $(".productList" + window.rowCount).empty().append('<option selected="" value="">Select an option</option>');
    for (count = 0; count < products.length; count++) {
        $(".productList" + window.rowCount).append('<option value="' + products[count].product_id + '"' +
            'data-punitid="' + products[count].p_unit_id + '" data-sunitid="' + products[count].s_unit_id + '" ' +
            'data-punitname="' + products[count].p_unit_name + '" data-sunitname="' + products[count].s_unit_name + '" ' +
            'data-priunitrater="' + products[count].r_pri_unit_rate + '" data-secunitrater="' + products[count].r_sec_unit_rate + '"' +
            'data-priunitrated="' + products[count].d_pri_unit_rate + '" data-secunitrated="' + products[count].d_sec_unit_rate + '"' +
            'data-maxpri="' + products[count].in_hand_stock_primary + '" data-maxsec="' + products[count].in_hand_stock_second + '"' +
            'data-noofpcs="' + products[count].no_of_pcs + '"' +
            '>' + products[count].product_name + ' - ' + products[count].brand_name + '</option>')
    }
    $('#item_name' + window.rowCount).select2({ width: "100%" }); //to initiatate select2  
} //Product list end here 


$("#tdFormRow").on('change', 'select.proChng', function() {
    $(this).parents('.addedRow').children('.unit-td').children('.unitList').empty().append('<option selected="" value="">Select an option</option>');
    if (window.customerType == 1) {

        $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option value="' + $(this).find(':selected').data('punitid') + '"' +
            'data-max="' + $(this).find(':selected').data('maxpri') + '" data-unitrate="' + $(this).find(':selected').data('priunitrater') + '"' +
            '>' + $(this).find(':selected').data('punitname') + '</option>')

        $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option value="' + $(this).find(':selected').data('sunitid') + '"' +
            'data-max="' + $(this).find(':selected').data('maxsec') + '" data-unitrate="' + $(this).find(':selected').data('secunitrater') + '"' +
            '>' + $(this).find(':selected').data('sunitname') + '</option>')
    }
    if (window.customerType == 2) {

        $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option value="' + $(this).find(':selected').data('punitid') + '"' +
            'data-max="' + $(this).find(':selected').data('maxpri') + '" data-unitrate="' + $(this).find(':selected').data('priunitrated') + '"' +
            '>' + $(this).find(':selected').data('punitname') + '</option>')

        $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option value="' + $(this).find(':selected').data('sunitid') + '"' +
            'data-max="' + $(this).find(':selected').data('maxsec') + '" data-unitrate="' + $(this).find(':selected').data('secunitrated') + '"' +
            '>' + $(this).find(':selected').data('sunitname') + '</option>')

    }

})

$("#tdFormRow").on('change', 'select.unitList', function() {
    $(this).parents('.addedRow').children('.mrp-td').children('#product_mrp').val($(this).find(':selected').data('unitrate'))
    $(this).parents('.addedRow').children('.qty-td').children('#qty').attr({ "max": $(this).find(':selected').data('max'), "placeholder": "Max Qty: " + $(this).find(':selected').data('max') + "", })
    $(this).parents('.addedRow').children('.qty-td').children('#qty').val('')
    $(this).parents('.addedRow').children('.discount-td').children('#discount').val(0)
    $(this).parents('.addedRow').children('.amount-td').children('#amount').val('')
}) //Onchange unit show primary qty & mrp


/*------ Remove row start of FORM ------*/
$(document).on('click', '.remove', function() {
    $(this).parent().parent().remove()
    tdRowCount()
    // $(this).closest('table').children('tr').addClass('xxx');
    // $(this).closest('td').parent('tr').parent()[0].sectionRowIndex
    totalCalculation()
});
/*------ Remove row end of FORM ------*/

/*------ To prevent multi decimal input start ------*/
$('#unit_price').keypress(function(event) {
    if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
        //alert('hello');
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)) {
            alert('Multiple Decimals are not allowed');
        }
        event.preventDefault();
    }
});
/*------ To prevent multi decimal input edn ------*/

/* Toatal calculation*/
var total = 0; $('#tdFormRow tbody').delegate('.qty, .unit-price', 'keyup', function() {
    var tr = $(this).parent().parent();
    var qty = tr.find('.qty').val();
    var unitPrice = tr.find('.unit-price').val();
    var amount = qty * unitPrice;
    tr.find('.amount').val(parseFloat(amount).toFixed(2));
    totalCalculation()
});

$("#paid").on('keyup', function() {
    if ($("#paid").val() != '') {
        totalCalculation()
    }
}) 

$("#delivery_charges").on('keyup', function() {
    if ($("#delivery_charges").val() != '') {
        totalCalculation()
    }
}) 

$("#round_off").on('keyup', function() {
    if ($("#round_off").val() != '') {
        totalCalculation()
    }
}) 

$("#gst_amount").on('keyup', function() {
    if ($("#gst_amount").val() != '') {
        totalCalculation()
    }
})

function totalCalculation() {
    var subTotal = 0;
    var paid = $("#paid").val()
    var roundOff = $("#round_off").val()
    var deliveryCharges = $("#delivery_charges").val()
    var gstAmount = $("#gst_amount").val()
    $('.amount').each(function(i, e) {
        var amount = $(this).val() - 0;
        subTotal += amount;
    });
    total = parseFloat(subTotal) + parseFloat(gstAmount);
    total = parseFloat(total) + parseFloat(deliveryCharges);
    total = parseFloat(total) - parseFloat(roundOff);
    var balance = parseFloat(total) - parseFloat(paid);
    balance = parseFloat(prevBalance) - parseFloat(balance)
    $("#total").val(total)
    $("#balance").val(balance)
} //Toatal calculation  
/*------ Form modal Html Part end -------*/

/*------ Add Modal Start -------*/
$(document).on('click', 'button.add', function() {
    $(".addedRow").remove()
    tdFormRowIndex = 0;
    var item = {
        item_name: '',
        unit_id: '',
        sale_qty: '',
        sale_unit_price: '',
        sale_amount: 0,
    }
    addRow(item)
    $("#customer_id").prop('readonly',false)  
    $('#createAndEditModal .modal-title').text("New Credit Note");
    $('#saveBtn').show();
    $('#editBtn').hide();
    $("input[type='text']").removeClass("text-capitalize")
    $("#createAndEditForm")[0].reset()
    $("#createAndEditForm .text-danger").html("")
    $("a.addRow").show()
    $('a.btn-icon').show()
    $("#tdFormRow tbody tr").children('td:nth-child(2)').addClass("unit-td")
    customerList()
    $("#customer_id").prop('disabled',false) 
});
/*------ Add Modal end -------*/

/*------ Create New Cr. Note function start -------*/
$('#createAndEditForm').on('click', '#saveBtn', function(event) {
    event.preventDefault();
    $("#loader").show()
    $(".text-danger").html("")
    // var error = $('.is-invalid').length; uncommit after old enter
    // if( error == 0){
    var formData = new FormData($('#createAndEditForm')[0]);
    $.ajax({
        method: 'POST',
        url: routes.create,
        contentType: false,
        cache: false,
        processData: false,
        dataType: "json",
        data: formData,
        success: function(response) {
            $("#loader").hide()
            if (response.errors) {
                if (response.errors.customer_id) {
                    $("#customer_id_error").text(response.errors.customer_id[0])
                }
                if (response.errors.order_date) {
                    $("#order_date_error").text(response.errors.order_date[0])
                }
                if (response.errors.delivery_date) {
                    $("#delivery_date_error").text(response.errors.delivery_date[0])
                }
                if (response.errors.payment_type) {
                    $("#payment_type_error").text(response.errors.payment_type[0])
                }
                for (var i = 0; i < window.rowCount + 1 || i < 1; i++) {
                    if (response.errors["item_name." + i]) {
                        $(".item_name_error_" + i).text(response.errors["item_name." + i][0])
                    }
                    if (response.errors["unit_id." + i]) {
                        $(".unit_id_error_" + i).text(response.errors["unit_id." + i][0])
                    }
                    if (response.errors["qty." + i]) {
                        $(".qty_error_" + i).text(response.errors["qty." + i][0])
                    }
                    if (response.errors["unit_price." + i]) {
                        $(".unit_price_error_" + i).text(response.errors["unit_price." + i][0])
                    }
                    if (response.errors["amount." + i]) {
                        $(".amount_error_" + i).text(response.errors["amount." + i][0])
                    }
                }
            }
            // //on success
            else {
                $('#credit_note_table').DataTable().ajax.reload();
                $("#createAndEditModal").modal('hide')
                $("#createAndEditForm")[0].reset()
                $('.select2').select2({
                    initSelection: function(element, callback) {}
                });
                customers = response.customers
                products = response.products
                creditNotes = response.creditNotes
                let message = response.success;
                snacbar(message)
            }
        },
        error: function(error) {
            $("#loader").hide()
            snacbar(error.statusText)
        }
    }) //ajax end here
    // }
})
/*------ Create New Cr. Note function end -------*/

/*------ Edit Modal Start -------*/
$(document).on('click', 'a.edit', function() {
    let trnxId = $(this).data('trnxid');
    $("#cr_trnx_id").val(trnxId)
    $("a.addRow").show()
    $(".addedRow").remove()
    $("#createAndEditModal .modal-title").text("Credit Note Edit #CRN-" + trnxId)
    $("#saveBtn").hide()
    $("#editBtn").show()
    $("#tdFormRow tbody tr").children('td:nth-child(2)').addClass("unit-td")   
    customerList()
     productsList(products)
    $("#customer_id").prop('disabled',true) 
    showData(trnxId)
});
/*------ Add Modal end -------*/

/*------ Edit Cr. Note function start -------*/
$('#createAndEditForm').on('click', '#editBtn', function(event) {
    event.preventDefault();
    $("#loader").show()
    $(".text-danger").html("")
    // var error = $('.is-invalid').length; uncommit after old enter
    // if( error == 0){
    var formData = new FormData($('#createAndEditForm')[0]);
    $.ajax({
        method: 'POST',
        url: routes.update,
        contentType: false,
        cache: false,
        processData: false,
        dataType: "json",
        data: formData,
        success: function(response) {
            $("#loader").hide()
            if (response.errors) {
                if (response.errors.customer_id) {
                    $("#customer_id_error").text(response.errors.customer_id[0])
                }
                if (response.errors.order_date) {
                    $("#order_date_error").text(response.errors.order_date[0])
                }
                if (response.errors.delivery_date) {
                    $("#delivery_date_error").text(response.errors.delivery_date[0])
                }
                if (response.errors.payment_type) {
                    $("#payment_type_error").text(response.errors.payment_type[0])
                }
                for (var i = 0; i < window.rowCount + 1 || i < 1; i++) {
                    if (response.errors["item_name." + i]) {
                        $(".item_name_error_" + i).text(response.errors["item_name." + i][0])
                    }
                    if (response.errors["unit_id." + i]) {
                        $(".unit_id_error_" + i).text(response.errors["unit_id." + i][0])
                    }
                    if (response.errors["qty." + i]) {
                        $(".qty_error_" + i).text(response.errors["qty." + i][0])
                    }
                    if (response.errors["unit_price." + i]) {
                        $(".unit_price_error_" + i).text(response.errors["unit_price." + i][0])
                    }
                    if (response.errors["amount." + i]) {
                        $(".amount_error_" + i).text(response.errors["amount." + i][0])
                    }
                }
            }
            // //on success
            else {
                $('#credit_note_table').DataTable().ajax.reload();
                $("#createAndEditModal").modal('hide')
                $("#createAndEditForm")[0].reset()
                $('.select2').select2({
                    initSelection: function(element, callback) {}
                });
                customers = response.customers
                products = response.products
                creditNotes = response.creditNotes
                let message = response.success;
                snacbar(message)
            }
        },
        error: function(error) {
            $("#loader").hide()
            snacbar(error.statusText)
        }
    }) //ajax end here
    // }
})
/*------ Editr Cr. Note function end -------*/

function showData(trnxId) {
    tdFormRowIndex = 0;
    j = 0;
    for (var count = 0; count < creditNotes.length; count++){
        if(trnxId == creditNotes[count].cr_trnx_id){
            addRow(creditNotes[count])
            $('#item_name'+j).select2({ width: "100%" }).val(creditNotes[count].item_name).trigger("change");
            $('#unit_id'+j).append('<option value="' + creditNotes[count].unit_id + '">' + creditNotes[count].unit_name + '</option>')
            $('#customer_id').select2({ width: "100%" }).val(creditNotes[count].customer_id).trigger("change");
            $("#order_date").val(moment(creditNotes[count].cr_order_date, 'YYYY-MM-DD').format("DD-MM-YYYY"))            
            $('#payment_type').val(creditNotes[count].cr_payment_type);
            $("#round_off").val(creditNotes[count].cr_round_off)
            $("#delivery_charges").val(creditNotes[count].cr_delivery_charges )
            $("#gst_amount").val(creditNotes[count].cr_gst_amount)
            $("#total").val(creditNotes[count].cr_total)
            $("#advance").val(creditNotes[count].cr_advance)
            $("#paid").val(creditNotes[count].cr_paid)
            prevBalance = creditNotes[count].cr_prev_balance
            $(".prev_bal").text('Previous Balance: '+prevBalance)
            $("#prev_balance").val(parseFloat(prevBalance))//this is to store
            $("#balance").val(parseFloat(creditNotes[count].cr_balance))//this is to store
            $("#remarks").val(creditNotes[count].cr_remarks)
            j++
        }

    }

    $("#createAndEditModal").modal('show')
}

/*------ tdRowCount check -----*/
function tdRowCount() {
    let tdRowCount = $('#tdFormRow tr').length;
    if (tdRowCount == 1) {
        $("#saveBtn").prop('disabled', true)
        $("#editBtn").prop('disabled', true)
    } else {
        $("#saveBtn").prop('disabled', false)
        $("#editBtn").prop('disabled', false)
    }
}
/*------ tdRowCount check -----*/

/*------ Credit Note Order Delete Start ------*/
$(document).on("click", "a.delete", function() {
    $("#id").val($(this).data("trnxid"))
    $(".modal-title").text("Sale Order No: #CRN-" + $(this).data("trnxid"))
    $("#ok_button").text("YES")
    $("#confirmModal").modal("show")
})
$("#confirmModal").on("click", "#ok_button", function(event) {
    event.preventDefault();
    var formData = new FormData($("#confirmform")[0]);
    $.ajax({
        type: "POST",
        url: routes.delete,
        processData: false,
        contentType: false,
        data: formData,
        beforeSend: function() {
            $("#ok_button").text("Deleting...")
        },
        success: function(response) {
            if (response.success) {
                $('#credit_note_table').DataTable().ajax.reload();
                $("#confirmModal").modal("hide");
                $('.select2').select2({
                    initSelection: function(element, callback) {},
                    width: "100%"
                });
                customers = response.customers
                products = response.products
                creditNotes = response.creditNotes
                let message = response.success;
                snacbar(message)
            }
            if (response.error) {
                $("#ok_button").text("Yes")
                let message = response.error;
                snacbar(message)
            }
        },
        error: function(error) {
            snacbar(error.statusText)
        }
    }) //ajax end here
}) //form end here
/*------ Credit Note Order Delete End ------*/

})