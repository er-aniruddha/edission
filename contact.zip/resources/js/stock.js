$(document).ready(function() {    
     $("#searchProduct").on("keyup", function () {
        $(this).attr("placeholder", "Search");
        var value = $(this).val().toLowerCase();
        $("#productList .list-item").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1) //this to show if there is value
            //$(".no-result").toggle($(this).text().toLowerCase().indexOf(value) === -1) //if no values then show this div
        });
    });//search function end here

    $(document).on('click','a.product',function(e){
        e.preventDefault()
        let id = $(this).attr('id');
        let stockValue = 0
        $(".addedrow").remove()
        for(count=0; count < stocks.length; count++){
            if(id == stocks[count][1].item_name){
                $('.product-name').text(stocks[count][1].product_name)
                $('.sale-price').text(stocks[count][1].product_mrp)
                $('.purchase-price').text(stocks[count][1].purchase_price)
                $('.stock-qty').text(stocks[count][1].in_hand_stock_primary+'/'+stocks[count][1].in_hand_stock_second+'(pcs)')
                stockValue += stocks[count][1].stock_value
                $('.stock-val').text(stockValue)
                if(stocks[count][1].stock_stat == 0){
                    addRow("Unpaid")
                }
                else if(stocks[count][1].stock_stat == 1){ 
                    addRow("Partial")
                }
                if(stocks[count][1].stock_stat == 2){
                    addRow("Paid")
                }
            }
        }    
    })// on click show transaction

    /*----- add row to transaction table start ----*/
    function addRow(stat){
        let tr = '<tr class="v-middle addedrow" data-id="15">'
        +'<td><span class="item-amount d-none d-sm-block text-sm item-title text-color text-capitalize">'+stocks[count][1].stock_type+'</span></td>'
        +'<td><span class="item-amount d-none d-sm-block text-sm item-title text-color text-capitalize">'+stocks[count][1].party_id+'</span></td>'
        +'<td><span class="item-amount d-none d-sm-block text-sm item-title text-color text-capitalize">'+moment(stocks[count][1].date).format("DD-MM-YYYY")+'</span></td>'
        +'<td><span class="item-amount d-none d-sm-block text-sm item-title text-color text-capitalize">'+stocks[count][1].qty+'</span></td>'
        +'<td><span class="item-amount d-none d-sm-block text-sm item-title text-color text-capitalize">'+stocks[count][1].unit_name+'</span></td>'
        +'<td><span class="item-amount d-none d-sm-block text-sm item-title text-color text-capitalize">'+stocks[count][1].unit_price+'</span></td>'
        +'<td><span class="item-amount d-none d-sm-block text-sm item-title text-color text-capitalize">'+stocks[count][1].amount+'</span></td>'
        +'<td><span class="item-amount d-none d-sm-block text-sm item-title text-color text-capitalize">'+stat+'</span></td>'
        +'<td>'
            +'<div class="item-action dropdown"><a href="#" data-toggle="dropdown" class="text-muted"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical">'
                        +'<circle cx="12" cy="12" r="1"></circle>'
                        +'<circle cx="12" cy="5" r="1"></circle>'
                        +'<circle cx="12" cy="19" r="1"></circle>'
                    +'</svg></a>'
                +'<div class="dropdown-menu dropdown-menu-right bg-black" role="menu"><a class="dropdown-item" href="#">See detail </a><a class="dropdown-item download">Download </a><a class="dropdown-item edit">Edit</a>'
                    +'<div class="dropdown-divider"></div><a class="dropdown-item trash">Delete item</a>'
                +'</div>'
            +'</div>'
        +'</td>'
    +'</tr>'
    $("#transaction_table tbody").append(tr)
    }
    /*----- add row to transaction table end ----*/
});