<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id('product_id');
            $table->string('product_img')->nullable();
            $table->string('product_name');
            $table->string('product_desc');            
            $table->integer('brand_id');  
            $table->string('primary_unit');         
            $table->string('secondary_unit');
            $table->integer('unit_rate');
            $table->string('pro_type'); // 0->Not Own Manufacturing
            $table->integer('product_mrp');
            $table->integer('pri_unit_rate');
            $table->float('sec_unit_rate');
            $table->integer('product_stat'); // 0->not publish ; 1->Published
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
