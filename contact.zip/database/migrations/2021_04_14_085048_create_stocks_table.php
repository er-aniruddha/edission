<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStocksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('stocks', function (Blueprint $table) {
            $table->id('stock_id');
            $table->string('trnx_id');
            $table->string('stock_type');
            $table->string('item_name');
            $table->integer('party_id'); //show whom to buy or sale
            $table->date('date');
            $table->integer('qty');
            $table->integer('primary_qty')->nullable()->default(0);
            $table->integer('secondary_qty')->nullable()->default(0);
            $table->integer('unit_id');
            $table->integer('unit_price');
            $table->float('amount');
            $table->integer('delivered_qty')->nullable()->default(0);
            $table->integer('in_hand_stock')->nullable()->default(0);// In-Hand-Qty = In-hand-Qty - Order Qty 
            $table->integer('stock_value')->nullable()->default(0);
            $table->integer('stock_stat')->nullable()->default(0); //0-> Unpaid, 1->Partial, 2->Paid
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('stocks');
    }
}
