<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->bigIncrements('order_id');
            $table->integer('customer_id');
            $table->integer('product_id');
            $table->string('product_name');
            $table->string('product_img');
            $table->float('product_mrp');
            $table->integer('stock_id');
            $table->string('sku_code');
            $table->integer('sku_count');
            $table->string('order_qty');
            $table->float('discount');
            $table->date('order_date');
            $table->date('delivery_date');
            $table->string('invoice_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
