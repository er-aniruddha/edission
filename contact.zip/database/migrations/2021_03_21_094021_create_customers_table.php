<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCustomersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->id('customer_id');
            $table->string('f_name');
            $table->string('s_name');
            $table->string('shop_name');
            $table->string('phone_1')->unique();
            $table->string('phone_2')->unique()->nullable();
            $table->string('whatsapp_no')->unique()->nullable();
            $table->string('email')->nullable();
            $table->integer('route_id');
            $table->string('locality');
            $table->string('district');
            $table->string('state');
            $table->string('pin');
            $table->string('addline_1')->nullable();
            $table->string('addline_2')->nullable();
            $table->integer('balance')->nullable()->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('customers');
    }
}
