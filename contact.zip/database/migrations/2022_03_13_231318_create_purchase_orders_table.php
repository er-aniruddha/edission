<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePurchaseOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('purchase_orders', function (Blueprint $table) {
            $table->id('purchase_order_id');
            $table->string('po_id');            
            $table->string('party_id');
            $table->date('date');
            $table->string('item_name');
            $table->integer('unit_id');
            $table->integer('qty');
            $table->integer('primary_qty')->nullable()->default(0);
            $table->integer('secondary_qty')->nullable()->default(0);
            $table->float('unit_price');
            $table->float('amount');
            $table->string('payment_type');
            $table->float('round_off')->nullable()->default(0);
            $table->float('gst_amount')->nullable()->default(0);
            $table->float('total')->nullable()->default(0);
            $table->float('advance')->nullable()->default(0);
            $table->float('balance')->nullable()->default(0);
            $table->string('remarks')->nullable()->default("ok");
            $table->integer('status')->nullable()->default(0);//0->Order Not Complete,1->Order Complete            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('purchase_orders');
    }
}
