$(document).ready(function() {    
     $("#searchProduct").on("keyup", function () {
        $(this).attr("placeholder", "Search");
        var value = $(this).val().toLowerCase();
        $("#productList .list-item").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1) //this to show if there is value
            //$(".no-result").toggle($(this).text().toLowerCase().indexOf(value) === -1) //if no values then show this div
        });
    });//search function end here

    $(document).on('click','a.product',function(e){
        e.preventDefault()
        let id = $(this).attr('id');
        let stockValue = 0
        $(".addedrow").remove()
        $('.product-name').text($(this).data('name'))
        $('.sale-price').html('<div class="text-highlight text-md sale-price text-danger"><span style="font-weight: 400; font-size: 18px;">&#8377;</span> 0.00</div>')
        $('.purchase-price').html('<div class="text-highlight text-md sale-price text-primary"><span style="font-weight: 400; font-size: 18px;">&#8377;</span> 0.00</div>')
        $('.stock-qty').text("0/0")
        $('.stock-val').html('<div class="text-highlight text-md sale-price text-info"><span style="font-weight: 400; font-size: 18px;">&#8377;</span> 0.00</div>')
        
        for(count=0; count < stocks.length; count++){
            if(id == stocks[count].item_name){
                $('.sale-price').html('<div class="text-highlight text-md sale-price text-danger">'+
                    '<span style="font-weight: 400; font-size: 18px;" class="inr-sign"></span>'+
                    new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(stocks[count].product_r_mrp)+'/'+
                    new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(stocks[count].product_d_mrp)+' '+
                    '</div>')

                $('.purchase-price').html('<div class="text-highlight text-md text-primary"><span style="font-weight: 400; font-size: 18px;" class="inr-sign"></span>'+
                    new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(stocks[count].primary_pp_for_stock)+'/'+
                    new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(stocks[count].secondary_pp_for_stock)+''+
                    '</div>')
                $('.stock-qty').text(stocks[count].in_hand_stock_primary+'/'+stocks[count].in_hand_stock_second+'(pcs)')
                $('.stock-val').html('<div class="text-highlight text-md text-info sale-price"><span style="font-weight: 400; font-size: 18px;" class="inr-sign"></span>'+
                    new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(stocks[count].stock_value)+'</div>')
        
                if(stocks[count].stock_stat == 0){
                    addRow("Unpaid")
                }
                else if(stocks[count].stock_stat == 1){ 
                    addRow("Partial")
                }
                if(stocks[count].stock_stat == 2){
                    addRow("Paid")
                }
            }   
        }
    })// on click show transaction

    /*----- add row to transaction table start ----*/
    function addRow(stat){
        let tr,stockType,className,name,address,trnxId;
        if(stocks[count].stock_type == 1){     
            stockType = '<td><span class="item-amount text-sm text-color text-primary text-capitalize">Purchase</span></td>' 
            className = 'text-primary'
            name = stocks[count].supplier_name
            address = stocks[count].supplier_address
            trnxId = 'CPO-'+stocks[count].trnx_id
        }
        if(stocks[count].stock_type == "1R"){     
            stockType = '<td><span class="item-amount text-sm text-color text-info text-capitalize">Purchase Return</span></td>' 
            className = 'text-info'
            name = stocks[count].supplier_name
            address = stocks[count].supplier_address
            trnxId = 'DRN-'+stocks[count].trnx_id
        }
        if(stocks[count].stock_type == 2){     
            stockType = '<td><span class="item-amount text-sm text-color text-danger text-capitalize">Sale</span></td>' 
            className = 'text-danger'
            name = stocks[count].f_name+' '+stocks[count].s_name
            address = stocks[count].shop_name
            trnxId = 'INV-'+stocks[count].trnx_id
        }
        if(stocks[count].stock_type == "2R"){     
            stockType = '<td><span class="item-amount text-sm text-color text-warning text-capitalize">Sale Return</span></td>' 
            className = 'text-warning'
            name = stocks[count].f_name+' '+stocks[count].s_name
            address = stocks[count].shop_name
            trnxId = 'CRN-'+stocks[count].trnx_id
        }


        tr = '<tr class="v-middle addedrow" data-id="15">'+
            stockType
            +'<td>'+
                '<span class="item-amount text-sm text-color '+className+' text-capitalize">'+name+'</span>'+
                '<p class="item-amount text-sm text-color '+className+' text-capitalize">'+address+'</p>'+
            '</td>'
            +'<td><span class="item-amount text-sm text-color '+className+' text-capitalize">'+moment(stocks[count].order_date).format("DD-MM-YYYY")+'</span></td>'
            +'<td><span class="item-amount text-sm text-color '+className+' text-capitalize">'+moment(stocks[count].delivery_date).format("DD-MM-YYYY")+'</span></td>'
            +'<td><span class="item-amount text-sm text-color '+className+' text-capitalize">'+trnxId+'</span></td>'
            +'<td><span class="item-amount text-sm text-color '+className+' text-capitalize">'+stocks[count].qty+'</span></td>'
            +'<td><span class="item-amount text-sm text-color '+className+' text-capitalize">'+stocks[count].unit_name+'</span></td>'
            +'<td><span class="item-amount text-sm text-color '+className+' text-capitalize"><span class="inr-sign" style="font-weight: 400; font-size: 13px;"></span> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(stocks[count].unit_price)+'</span></td>'
            +'<td><span class="item-amount text-sm text-color '+className+' text-capitalize"><span class="inr-sign" style="font-weight: 400; font-size: 13px;"></span> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(stocks[count].amount.toString().replace('-',' ')) +'</span></td>'
            +'<td><span class="item-amount text-sm text-color '+className+' text-capitalize">'+stat+'</span></td>'
            +'<td>'
            +'<div class="item-action dropdown"><a href="#" data-toggle="dropdown" class="text-muted"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical">'
            +'<circle cx="12" cy="12" r="1"></circle>'
            +'<circle cx="12" cy="5" r="1"></circle>'
            +'<circle cx="12" cy="19" r="1"></circle>'
                    +'</svg></a>'
                +'<div class="dropdown-menu dropdown-menu-right bg-black" role="menu"><a class="dropdown-item" href="#">See detail </a><a class="dropdown-item download">Download </a><a class="dropdown-item edit">Edit</a>'
                    +'<div class="dropdown-divider"></div><a class="dropdown-item trash">Delete item</a>'
                +'</div>'
            +'</div>'
            +'</td>'
        +'</tr>'
    $("#transaction_table tbody").append(tr)
    }
    /*----- add row to transaction table end ----*/

    /*----- Search product -----*/
    $(document).on("keyup","#searchProduct", function() {
        var value = $(this).val().toLowerCase();
        $("#productList .item").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });  
    /*----- Search product -----*/
});