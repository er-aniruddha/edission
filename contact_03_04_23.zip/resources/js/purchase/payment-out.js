$(document).ready(function(){
	var prevBalance ;
	/* Sales DataTable Start Here*/
    var payments_table = $("#payments_table").DataTable({
        processing: true,
        serverSide: true,
        lengthMenu: [
            [10, 25, 50,100, -1],
            [10, 25, 50,100, 'All'],
        ],
        buttons: [{ extend: 'csv', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7,8 ]}},
            { extend: 'excel', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7,8]}},
            { extend: 'pdf', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7,8]}},
            { extend: 'print', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7,8 ]}}
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex",
            render: function(data){
                return '<small class="text-muted">'+data+'</small>'
            }
        }, {
            data: "date",
            name: "date",
            render: function(data, type, full, meta) {
                return '<a href="#" class="item-company ajax h-1x" data-pjax-state="">'+data+'</a>'
            },      
        }, {
            data: "payment_trnx_id",
            name: "payment_trnx_id",
            render: function(data){
                return '<span class="text-sm text-success text-capitalize">PAY-OUT-'+data+'</span>'
            }
        },{
            data: "supplier_name",
            name: "supplier_name",
            render: function(data){
                return '<span class="text-sm text-capitalize">'+data+'</span>'
            }
        },{
            data: "paymentType",
            name: "paymentType",
        },{
            data: "prev_balance",
            name: "prev_balance",
            render: function(data){
                return '<span class="text-sm inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
            }
        },{
            data: "paid",
            name: "paid",
            render: function(data){
                return '<span class="text-sm inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
            }
        }, {
            data: "balance",
            name: "balance",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
            }
        },{
            data: "remarks",
            name: "remarks",
            render: function(data){
                if(!data){
                    return '<span class="text-sm text-capitalize"></span>'
                }
                else{
                    return '<span class="text-sm text-capitalize">'+data+'</span>'
                }                
            }
        },{
            data: "action",
            name: "action"
        }],

    });
    /*------ Sale dataTable end here ------*/
    /*-------- Searching table on payment_out base start -------*/
    $(document).on('click', '.suppliers', function(event) {
        event.preventDefault()
        let name = $(this).data('name')
        payments_table.search(name).draw();
    })
    /*-------- Searching table on payment_out base end ---------*/
    /*------ Show due suppliers start ------*/    
    function supplierList_modal(){
        $("#s_id").empty().append('<option selected="" value="">Select suppliers</option>');
        for(let i=0; i < suppliers.length; i++){
            let name = suppliers[i].supplier_name.charAt(0).toUpperCase() + suppliers[i].supplier_name.slice(1)
            $("#s_id").append('<option value="'+suppliers[i].supplier_id+'" data-prevbal="'+suppliers[i].balance+'">'
                +'<span class="text-capitalize">'+name+' ('+suppliers[i].supplier_address+')</span></option>')
        }
    }
    function supplierList_side(){      
        $("#supplierList").empty().append('');
        for(let i=0; i < suppliers.length; i++){
            $("#supplierList").append('<li class="item">' 
            +'<a href="javascript:void(0);" class="b-b suppliers item-company text-primary" data-name="'+suppliers[i].supplier_name+'">'
                +'<span class="nav-text text-capitalize">'+suppliers[i].supplier_name+' '
                +'<p class="item-except text-muted text-sm h-1x">'+suppliers[i].supplier_address+'</p></span>'
                +'<span class="nav-badge">'
                    +'<span class="badge bg-primary-lt inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(suppliers[i].balance)+'</span>'
                +'</span>'
            +'</a>'
        +'</li>')
        }
    }
    supplierList_side()
    /*------ Show due supplier end ------*/
    /*------ Export Start ------*/
    $(document).on('click',".export",function(){
        var btn = $(this).attr('id').toString()
        payments_table.button(btn).trigger();
    })
    /*------ Export End -------*/ 
    /*------ On click supplier show in table start -------*/ 
    $(document).on('click','.supplier',function(event){
        event.preventDefault()
        let name = $(this).data('name')
        payments_table.search(name).draw();
    })
    /*------ On click cussuppliertomer show in table end -------*/ 

    /*------ Payment-IN start here --------*/
    $(document).on('click',"#paymentOut",function(event){
        event.preventDefault()   
        $('.select2').select2({ 
            width:"100%", tags:true, dropdownParent: $('#payMentModal')
        }); 
        $(".text-danger").html("")  
        $('.modal-title').text('Add Payment')
        $("#savePayBtn").show()
        $("#updateBtn").hide()    
        $("#payment-form")[0].reset()
        $("input").prop('disabled', false);
        $("textarea").prop('disabled', false);
        $("select").prop('disabled', false);
        $("#payMentModal").modal("show")
        supplierList_modal()
    })

    $("#payment-form").on('change','#s_id',function(){ 
        $("#prev_balance").val($(this).find(':selected').data('prevbal'))
    })

    $('#payment-form').on('click', '#savePayBtn', function (event) {
        event.preventDefault();
        $(".text-danger").html("") 
        var formData = new FormData($('#payment-form')[0]);
        $.ajax({
            method: 'POST',
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function (response) {
                if(response.errors){                    
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    } 
                    if(response.errors.paid){
                        $("#paid_error").text(response.errors.paid[0])
                    }
                    if(response.errors.balance){
                        $("#balance_error").text(response.errors.balance[0])
                    }
                    if(response.errors.payment_type){
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }                                    
                }
                //on success
                else{
                    suppliers = response.suppliers
                    $('#payments_table').DataTable().ajax.reload(); 
                    $("#payMentModal").modal('hide')   
                    supplierList_side()                 
                    $("#payment-form")[0].reset()
                    $('input.md-input').attr('value' , '')               
                    let message = response.success;
                    snacbar(message)
                }
            },
            error:function(error){
                snacbar(error.statusText)
            }
        })//ajax end here
    })
    /*------ Payment-IN end here --------*/

    /*------ check mul;tiple decimnl value start ------*/
    $("input[type='number']").keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /*------ check mul;tiple decimnl value end ------*/

    /*------ Toatal calculation -------*/
    $('.modal-body').delegate('#paid', 'keyup', function() {
        let prev_balance = $("#prev_balance").val()
        let paid = $("#paid").val()
        let balance = parseFloat(prev_balance) - parseFloat(paid)
        $("#balance").val(balance.toFixed(2))
    });
    /*----- Toatal calculation -------*/

    /*----- View function -------*/
    $(document).on('click','a.view',function(event){
        event.preventDefault()
        $('.modal-title').text('Payment Details: #PAY-OUT-'+$(this).data('paytrnxid'))
        let inputStat = true
        let data = $(this).data()
        $("#savePayBtn").hide()
        $("#updateBtn").hide()
        showDetails(data,inputStat)
    })
    /*----- View function -------*/

    /*----- edit function -------*/
    $(document).on('click','a.edit',function(event){
        event.preventDefault()
        $('.modal-title').text('Edit Payment: #PAY-OUT-'+$(this).data('paytrnxid'))
        $("#payMentModal #id").val($(this).attr('id'))     
        let inputStat = false
        let data = $(this).data()
        $("#savePayBtn").hide()
        $("#updateBtn").show()
        showDetails(data,inputStat)
    })

    $('#payment-form').on('click', '#updateBtn', function (event) {
        event.preventDefault();
        $(".text-danger").html("") 
        var formData = new FormData($('#payment-form')[0]);
        $.ajax({
            method: 'POST',
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function (response) {
                if(response.errors){
                    if(response.errors.paid){
                        $("#paid_error").text(response.errors.paid[0])
                    }
                    if(response.errors.balance){
                        $("#balance_error").text(response.errors.balance[0])
                    } 
                    if(response.errors.payment_type){
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }
                    if(response.errors.trnx_error){
                        let message = response.errors.trnx_error[0];
                        snacbar(message)
                    }  

                }
                //on success
                else{
                    suppliers = response.suppliers
                    $('#payments_table').DataTable().ajax.reload(); 
                    $("#payMentModal").modal('hide')   
                    supplierList_side()                 
                    $("#payment-form")[0].reset()
                    $('input.md-input').attr('value' , '')               
                    let message = response.success;
                    snacbar(message)
                }
            },
            error:function(error){
                snacbar(error.statusText)
            }
        })//ajax end here
    })
    /*----- edit function -------*/

    /*----- Purchase Item Delete Start ------*/
    $(document).on("click", "a.delete", function() {
        $("#confirmModal #id").val($(this).attr('id'))
        $(".modal-title").text("Payment Details: #PAY-OUT-" + $(this).data("paytrnxid"))
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $("#payments_table").DataTable().ajax.reload()
                    $("#confirmModal").modal("hide");
                    suppliers = response.suppliers
                    supplierList_side()             
                    let message = response.success;
                    snacbar(message)
                }
                if (response.error) {
                    $("#ok_button").text("Yes")
                    let message = response.error;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end
    })
    /*----- Purchase Item Delete End ------*/


    function showDetails(data,inputStat) {
        supplierList_modal() 
        $(".text-danger").html("")   
        $("#date").val(moment(data.date).format('DD-MM-YYYY'))
        $("#s_id").val(data.supplierid)
        $("#prev_balance").val(data.prevbal)
        $("#paid").val(data.paid)
        $("#balance").val(data.balance)
        $("#payment_type").val(data.paymenttype)
        $("#remarks").val(data.remarks)
        $("input").prop('disabled', inputStat);
        $("textarea").prop('disabled', inputStat);
        $("select").prop('disabled', inputStat);        
        $("#s_id").prop('disabled', 'disabled');   
        $("#date").prop('disabled', 'disabled');   
        $("#payMentModal").modal("show")
    }

    $(document).on('click','#modalCloseBtn',function(event){
        event.preventDefault()
        $("input").prop('disabled', false);
        $("textarea").prop('disabled', false);
        $("select").prop('disabled', false);
    })

    /*----- Search supplier -----*/
    $(document).on("keyup","#searchSuppliers", function() {
        var value = $(this).val().toLowerCase();
        $("#supplierList .item").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });  
    /*----- Search supplier -----*/

    $("option").each(function() {
    $(this).text($(this).text().charAt(0).toUpperCase() + $(this).text().slice(1));
});
})