$(document).ready(function() {
    window.rowCount = 0;
    var singleItemDel = []; // required at the time of edit
    var prevBalance
    $.fn.modal.Constructor.prototype._enforceFocus = function() {};

    /*------- input[type='number'] can't be null -------*/
    const numInputs = document.querySelectorAll('input[type=number]')
    numInputs.forEach(function(input) {
      input.addEventListener('keyup', function(e) {
        if (e.target.value == '') {
          e.target.value = 0.00
        }
      })
    })
    /*------- input[type='number'] can't be null -------*/
    // function supplierList(){
    //     $("#supplier_id").empty().append('<option value="" selected="">Select Supplier</option>')
    //     for(let count=0; count<suppliers.length; count++){
    //         if(suppliers[count].supplier_stat == 1){
    //             $("#supplier_id").append('<option value="'+suppliers[count].supplier_id+'" data-balance="'+suppliers[count].balance+'">'+suppliers[count].supplier_name+'</option>')
    //         }
    //         else{
    //             $("#supplier_id").append('<option value="'+suppliers[count].supplier_id+'" data-balance="'+suppliers[count].balance+'">'+suppliers[count].supplier_name+'</option>')
    //         }
    //     }
    // }
    // supplierList()
    /*------ On Supplier change filter product Start -------*/
    var filterProducts = {}
    $(document).on('change', 'select.supplier', function(event) {
        event.preventDefault()
        let supplier_id = $(this).val();        
        prevBalance = $(this).find(':selected').data('balance')
        $(".prev_bal").text('Previous Balance: '+prevBalance)
        $("#prev_balance").val(parseFloat(prevBalance).toFixed(2))//this is to store
        filterProducts = products.filter(elem => {
            return elem.supplier_id == supplier_id;
        })
        productsList()
        $('#tdFormRow tbody').append().empty();
        var item = {
            item_name :'',
            unit_id :'',
            qty :'',
            unit_price :'',
            total_price :'',
            purchase_id :'',
        }
        addRow(item)
        $('.addRow').show()
    })
    /*------ On Supplier change filter product End-------*/

    /*------ Add Row into modal Start -------*/
    $('.addRow').on('click', function() {
        var item = {
            item_name :'',
            unit_id :'',
            qty :'',
            unit_price :'',
            total_price :'',
            purchase_id :'',
        }
        addRow(item)
    })
    var tdFormRowIndex = 0;

    function addRow(item) {
        var tr = '<tr class="addedRow row_' + tdFormRowIndex + '">' +
            '<td style="vertical-align: top;">' +
            '<select class="form-control text-capitalize select2 proChng productList' + tdFormRowIndex + '" name="item_name[' + tdFormRowIndex + ']" id="item_name' + tdFormRowIndex + '" value="' + item.item_name + '" tabindex="-1" aria-hidden="true">' +
            '</select>' +
            '<span class="text-danger item_name_error_' + tdFormRowIndex + '"></span> ' +
            '</td>' +
            '<td class="unit-td" style="vertical-align: top;">' +
            '<select class="form-control text-capitalize unitList" name="unit_id[' + tdFormRowIndex + ']" id="unit_id' + tdFormRowIndex + '" value="" tabindex="-1" aria-hidden="true">' +
            '</select>' +
            '<div class="text-danger unit_id_error_' + tdFormRowIndex + '"></div> ' +
            '</td>' +
            '<td class="td-qty" style="vertical-align: top;">' +
            '<input type="number" name="qty[' + tdFormRowIndex + ']" id="qty" value="' + item.qty + '"  class="form-control qty" placeholder="Quantity" oninput="this.value = Math.round(this.value);">' +
            '<span class="text-danger qty_error_' + tdFormRowIndex + '"></span> ' +
            '</td>' +
            '<td style="vertical-align: top;">' +
            '<input type="number" name="unit_price[' + tdFormRowIndex + ']" id="unit_price" value="' + item.unit_price + '"  class="form-control unitPrice number" placeholder="Price">' +
            '<span class="text-danger unit_price_error_' + tdFormRowIndex + '"></span> ' +
            '<small class="text-muted prev-pp"></small>'+
            '</td>' +
            '<td style="vertical-align: top;">' +
            '<input type="number" name="amount[' + tdFormRowIndex + ']" id="amount" value="' + item.amount + '"  class="form-control amount" placeholder="Total" onchange="(function(el){el.value=parseFloat(el.value).toFixed(2);})(this)"readonly>' +
            '<span class="text-danger amount_error_' + tdFormRowIndex + '"></span> ' +
            '</td>' +
            '<td style="vertical-align: top;">' +
            '<a href="javascript:void(0)" class="btn btn-icon remove" id="' + item.purchase_order_id + '" id="remove' + tdFormRowIndex + '" style="border: 1px solid #f54394">' +
            '<svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="color: red;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
            '</a>' +
            '</td>' +
            '</tr>';
        window.rowCount = tdFormRowIndex;
        tdFormRowIndex++;
        $('#tdFormRow tbody').append(tr);
        productsList()
    }
    /*------ Add Row into modal End -------*/

    /*------ Show List of Product in modal Start -------*/
    function productsList() {
        $(".productList" + window.rowCount).empty().append('<option selected="" value="">Select an option</option>');
        for (count = 0; count < filterProducts.length; count++) {
            $(".productList" + window.rowCount).append('<option value="' + filterProducts[count].product_id + '"' +
                'data-punitid="' + filterProducts[count].p_unit_id + '" data-punitname="' + filterProducts[count].p_unit_name + '" data-sunitid="' + filterProducts[count].s_unit_id + '"' +
                'data-sunitname="' + filterProducts[count].s_unit_name + '" data-noofpcs="' + filterProducts[count].no_of_pcs + '"' + 
                'data-primarypp="' + filterProducts[count].primary_pp + '" data-secondarypp="' + filterProducts[count].secondary_pp + '"' + 
                '>' + filterProducts[count].product_name + ' - '+filterProducts[count].brand_name+'</option>')
        }
        // $('#item_name' + window.rowCount).off('productList:select');
        $('#item_name' + window.rowCount).select2({ width: "100%" }); //to initiatate select2  
    }
    /*------ Show List of Product in modal End -------*/

    /*------ On Product change set values in Unit Start -------*/
    $("#tdFormRow").on('change', 'select.proChng', function() {
        $(this).parents('.addedRow').children('td:nth-child(4)').children('.prev-pp').text('PP: '+$(this).find(':selected').data('primarypp')+'/'+ $(this).find(':selected').data('secondarypp'))
        // $(this).text('PP: '+$(this).find(':selected').data('primarypp')+'/'+ $(this).find(':selected').data('secondarypp'))
        $(this).parents('.addedRow').children('.unit-td').children('.unitList').empty().append('<option selected="" value="">Select an option</option>');
        $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option class="text-capitalize p-pcs" value="' + $(this).find(':selected').data('punitid') + '">' + $(this).find(':selected').data('punitname') + '</option>')
        $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option class="text-capitalize s-pcs" value="' + $(this).find(':selected').data('sunitid') + '">' + $(this).find(':selected').data('sunitname') + '</option>')
    })
    /*------ On Product change set values in Unit Start -------*/


    $("#tdFormRow").on('change', 'select.unitList', function() {
        $(this).parents('.addedRow').children('.td-qty').children('#qty').val('')
    }) //Onchange unit set value no_of_pcs 

    /*Remove row start of FORM*/
    $(document).on('click', '.remove', function() {
        $(this).parent().parent().remove()
        // $(this).closest('table').children('tr').addClass('xxx');
        // $(this).closest('td').parent('tr').parent()[0].sectionRowIndex
        totalCalculation()
    });
    /*Remove row end of FORM*/

    /* To prevent multi decimal input start */
    $('#tdFormRow').on('keypress','.unitPrice',function(event) {                 
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /* To prevent multi decimal input edn */

    /* Total calculation*/
    var total = 0;
    $('tbody').delegate('.qty, .unitPrice', 'keyup', function() {
        var tr = $(this).parent().parent();
        var qty = tr.find('.qty').val();
        var unitPrice = tr.find('.unitPrice').val();
        var amount = qty * unitPrice;
        tr.find('.amount').val(parseFloat(amount).toFixed(2));
        totalCalculation()
    });

    $("#advance").on('keyup', function() {        
        if ($("#advance").val() != '') {
            totalCalculation()
        } else {
            $("#advance").val(0)
        }
    })
    $("#round_off").on('keyup', function() {        
        if ($("#round_off").val() != '') {
            totalCalculation()
        }
    })
    $("#delivery_charges").on('keyup', function() {        
        if ($("#delivery_charges").val() != '') {
            totalCalculation()
        }
    })
    $("#gst_amount").on('keyup', function() {
        if ($("#gst_amount").val() != '') {
            totalCalculation()
        }
    })

    function totalCalculation() {
        var subTotal = 0;
        var advance = $("#advance").val()
        var roundOff = $("#round_off").val()
        var deliveryCharges = $("#delivery_charges").val()
        var gstAmount = $("#gst_amount").val()
        $('.amount').each(function(i, e) {
            var amount = $(this).val() - 0;
            subTotal += amount;
        });
        total = parseFloat(subTotal) + parseFloat(gstAmount);
        total = parseFloat(total) - parseFloat(roundOff);
        total = parseFloat(total) + parseFloat(deliveryCharges);
        var balance = parseFloat(total) - parseFloat(advance);
        balance = parseFloat(balance) + parseFloat(prevBalance)
        $("#total").val(parseFloat(total).toFixed(2))
        $("#balance").val(parseFloat(balance).toFixed(2))
    } //Toatal calculation  
    /*Form modal Html Part end*/

    /* PurchaseOrder Item DataTable Start Here*/
    var dataTable = $("#purchase_order_table").DataTable({
        processing: true,
        serverSide: true,
        buttons: [{ extend: 'csv', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
            { extend: 'excel', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
            { extend: 'pdf', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
            { extend: 'print', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } }
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex",
            render: function(data) {
                return '<small class="text-muted">' + data + '</small>'
            }
        }, {
            data: "po_id",
            name: "po_id",
            render: function(data, type, full, meta) {
                return '<a href="#" class="item-company ajax h-1x" data-pjax-state="">PO-' + data + '</a>'
            },
        }, {
            data: "order_date",
            name: "order_date",
            render: function(data) {
                return '<span class="item-amount d-none d-sm-block text-sm">' + data + '</span>'
            }
        },{
            data: "delivery_date",
            name: "delivery_date",
            render: function(data) {
                return '<span class="item-amount d-none d-sm-block text-sm">' + data + '</span>'
            }
        }, {
            data: "supplier_name",
            name: "supplier_name",
            render: function(data) {
                return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">' + data + '</span>'
            }
        }, {
            data: "payment_type",
            name: "payment_type",
            render: function(data){
                if(data == 1){
                    return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Cash</span>'
                }
                if(data == 2){
                    return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Online</span>'
                }
                if(data == 3){
                    return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Cheque</span>'
                }
                if(data == 4){
                    return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-danger">No Payment</span>'
                }
            }
        },{
            data: "total",
            name: "total",
            render: function(data) {
                return '<span class="item-amount d-none d-sm-block text-sm inr-sign">' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) + '</span>'
            }
        }, {
            data: "prev_balance",
            name: "prev_balance",
            render: function(data) {
                return '<span class="item-amount d-none d-sm-block text-sm inr-sign">' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) + '</span>'
            }
        }, {
            data: "advance",
            name: "advance",
            render: function(data) {
                return '<span class="item-amount d-none d-sm-block text-sm inr-sign">' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) + '</span>'
            }
        }, {
            data: "PO_balance",
            name: "PO_balance",
            render: function(data) {
                return '<span class="item-amount d-none d-sm-block text-sm">'+data+'</span>'
            }
        },{
            data: "payment_status",
            name: "payment_status",
            render: function(data){
                if(data == 0){
                    return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-danger">Unpaid</span>'
                }
                if(data == 1){
                    return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-warning">Partial</span>'
                }
                if(data == 2){
                    return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-success">Paid</span>'
                }
            }
        }, {
            data: "status",
            name: "status"
        }, {
            data: "action",
            name: "action"
        }]
    });
    /*------ Purchase Order dataTable end here ------*/
    /*------ Export Start ------*/
    $(document).on('click', ".export", function() {
        var btn = $(this).attr('id').toString()
        dataTable.button(btn).trigger();
    })
    /*------ Export End -------*/
    /* PurchaseOrder Item DataTable End Here*/
    /* Add Modal Start */
    $(document).on('click', 'button.add', function() {
        $(".addedRow").remove()
        tdFormRowIndex = 0;        
        $(".prev_bal").text('')
        $("#prev_balance").val(0)//this is to store
        $("input").prop('disabled', false);
        $("#supplier_id").prop('disabled',false)
        $("#payment_type").prop('disabled',false)
        $(".unitList").prop('disabled',false)
        $(".productList" + window.rowCount).empty().append('<option selected="" value="">Select an option</option>');
        $('.modal-title').text("Purchase Order");
        $('#addBtn').show();
        $('#editBtn').hide();
        $("input[type='text']").removeClass("text-capitalize")
        $("#purchaseOrderForm")[0].reset()
        $("#purchaseOrderForm .text-danger").html("")
        $('a.btn-icon').show()
        $("#tdFormRow tbody tr").children('td:nth-child(2)').addClass("unit-td")
        $('#supplier_id').select2({
        width: "100%",
        dropdownParent: $('#modal')
    });
    });
    /* Add Modal end */
    /* Add PurchaseOrder Start */
    $('#purchaseOrderForm').on('click', '#addBtn', function(event) {
        event.preventDefault();
        $("#purchaseOrderForm .text-danger").html("")
        $("#loader").show()
        var formData = new FormData($('#purchaseOrderForm')[0]);
        $.ajax({
            method: 'POST',
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                 $("#loader").hide()
                if (response.errors) {
                    if (response.errors.supplier_id) {
                        $("#supplier_id_error").text(response.errors.supplier_id[0])
                    }
                    if (response.errors.order_date) {
                        $("#order_date_error").text(response.errors.order_date[0])
                    }
                    if (response.errors.payment_type) {
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }
                    for (var i = 0; i < window.rowCount + 1 || i < 1; i++) {

                        if (response.errors["item_name." + i]) {
                            $(".item_name_error_" + i).text(response.errors["item_name." + i][0])
                        }
                        if (response.errors["unit_id." + i]) {
                            $(".unit_id_error_" + i).text(response.errors["unit_id." + i][0])
                        }
                        if (response.errors["qty." + i]) {
                            $(".qty_error_" + i).text(response.errors["qty." + i][0])
                        }
                        if (response.errors["unit_price." + i]) {
                            $(".unit_price_error_" + i).text(response.errors["unit_price." + i][0])
                        }
                        if (response.errors["amount." + i]) {
                            $(".amount_error_" + i).text(response.errors["amount." + i][0])
                        }
                    }
                }
                //on success
                if(response.success) {
                    $('#purchase_order_table').DataTable().ajax.reload();
                    $("#modal").modal('hide')
                    $("#purchaseOrderForm")[0].reset()
                    $('input.md-input').attr('value' , '')
                    $('.select2').select2({
                        initSelection: function(element, callback) {},
                        width: "100%"
                    });
                    $(".prev_bal").text('')
                    allPoItem = response.allPoItem
                    suppliers = response.suppliers
                    supplierList()
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                 $("#loader").hide()
                snacbar(error.statusText)
            }
        }) //ajax end here
    }) //Add product function end here
    /*Add PurchaseOrder End*/

    /* PurchaseOrder Edit Start*/
    $(document).on("click", "button.edit", function(event) {
        event.preventDefault();
        let po_id = $(this).attr('id');
        $("#po_id").val(po_id)
        $(".addedRow").remove()
        $(".modal-title").text("Purchase Order Edit #PO-" + po_id)
        $("#addBtn").hide()
        $("#editBtn").show()
        $("#tdFormRow tbody tr").children('td:nth-child(2)').addClass("unit-td")
        showData(po_id)
    })

    $("#purchaseOrderForm").on("click", "#editBtn", function(event) {
        event.preventDefault()
        $("#purchaseOrderForm .text-danger").html("")
        $("#loader").show()
        let tdRowCount = $('#purchase_order_table tr').length;
        var formData = new FormData($("#purchaseOrderForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                 $("#loader").hide()
                if (response.errors) {
                    if (response.errors.party_id) {
                        $("#party_id_error").text(response.errors.party_id[0])
                    }
                    if (response.errors.order_date) {
                        $("#order_date_error").text(response.errors.order_date[0])
                    }
                    if (response.errors.payment_type) {
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }
                    for (var i = 0; i < tdRowCount; i++) {
                        if (response.errors["item_name." + i]) {
                            $(".item_name_error_" + i).text(response.errors["item_name." + i][0])
                        }
                        if (response.errors["unit_id." + i]) {
                            $(".unit_id_error_" + i).text(response.errors["unit_id." + i][0])
                        }
                        if (response.errors["qty." + i]) {
                            $(".qty_error_" + i).text(response.errors["qty." + i][0])
                        }
                        if (response.errors["unit_price." + i]) {
                            $(".unit_price_error_" + i).text(response.errors["unit_price." + i][0])
                        }
                        if (response.errors["amount." + i]) {
                            $(".amount_error_" + i).text(response.errors["amount." + i][0])
                        }
                    }
                }
                //on success
                else {
                    $('#purchase_order_table').DataTable().ajax.reload();
                    $("#modal").modal('hide')
                    $("#purchaseOrderForm")[0].reset()
                    $('.select2').select2({
                        initSelection: function(element, callback) {},
                        width: "100%"
                    });
                    allPoItem = response.allPoItem
                    suppliers = response.suppliers
                    supplierList()
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                 $("#loader").hide()
                snacbar(error.statusText)
            }
        })
    })
    /*------ PurchaseOrder Edit End ----------------*/
    /*------ Purchase order Item Delete Start ------*/
    $(document).on("click", "button.delete", function() {
        $("#id").val($(this).data("poid")) //have to use date regrad id 
        $(".modal-title").text("Order ID : #" + $(this).data("poid"))
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $("#purchase_order_table").DataTable().ajax.reload()
                    $("#confirmModal").modal("hide");
                    allPoItem = response.allPoItem
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        }) //ajax end
    }) //Purchase order Item Delete function end
    /* ---- Purchase order Item Delete End ----*/

   
    /* ---- Function for Wiew & Edit details show start ----*/
    function showData(po_id) {
        tdFormRowIndex = 0 //to initial, without this data will not show        
        
        $(".unitList").empty()
        $('.select2').select2({ width: "100%", tags: true, dropdownParent: $('#modal') });
        let j = 0;
        // var rowIndex = $(this).closest('td').parent()[0].sectionRowIndex 
        for (var count = 0; count < allPoItem.length; count++) { //allPoItem variable declare in index.php
            if (allPoItem[count].po_id == po_id) {                
                filterProducts = products.filter(elem => {
                    return elem.supplier_id == allPoItem[count].supplier_id;
                })
                addRow(allPoItem[count])
                
                if (allPoItem[count].item_name == allPoItem[count].product_id) {
                    $('.productList' + j).select2({ width: "100%" }).val(allPoItem[count].item_name).trigger("change");
                } else {
                    var newOption = new Option(allPoItem[count].item_name, allPoItem[count].item_name, true, true);
                    $(".productList" + j).append(newOption).trigger('change');
                }
                for (let uc = 0; uc < units.length; uc++) {
                    if (allPoItem[count].unit_id == units[uc].unit_id) {
                        $('#unit_id' + window.rowCount).append('<option value="' + allPoItem[count].unit_id + '">' + units[uc].unit_name + '</option>')
                    }
                }
                $("#order_date").val(moment(allPoItem[count].order_date, 'YYYY-MM-DD').format("DD-MM-YYYY"))
                $("#remarks").val(allPoItem[count].remarks)
                $('#supplier_id').val(allPoItem[count].supplier_id);
                $('#payment_type').val(allPoItem[count].payment_type);
                $("#round_off").val(allPoItem[count].round_off)
                $("#delivery_charges").val(allPoItem[count].delivery_charges)
                $("#gst_amount").val(allPoItem[count].gst_amount)
                $("#total").val(allPoItem[count].total)
                $("#advance").val(allPoItem[count].advance)
                prevBalance = allPoItem[count].prev_balance
                $(".prev_bal").text('Previous Balance: '+prevBalance)
                $("#prev_balance").val(parseFloat(prevBalance).toFixed(2))//this is to store
                $("#balance").val(parseFloat(allPoItem[count].PO_balance).toFixed(2))//this is to store
                $("#remarks").val(allPoItem[count].remarks)
                j++
            }
        }
        $("#modal").modal("show")
        $("#purchaseOrderForm .text-danger").html("")
    } // show details function end here
    /*------------ Function for Wiew & Edit details show end--------*/
});