$(document).ready(function() {
    var base_url = "https://varneyatechnologies.com";
    /*------ Supplier DataTable Start Here -------*/
    var dataTable = $("#supplier_table").DataTable({
        processing: true,
        serverSide: true,
        lengthMenu: [
            [10, 25, 50,100, -1],
            [10, 25, 50,100, 'All'],
        ],
        buttons: [{ extend: 'csv', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'excel', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'pdf', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'print', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}}
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex",
            render: function(data){
                return '<small class="text-muted">'+data+'</small>'
            }
        }, {
            data: "supplier_name",
            name: "supplier_name",
            render: function(data, type, full, meta) {
                return '<a href="#" class="item-company ajax h-1x text-capitalize" data-pjax-state="">'+data+'</a>'
            },      
        }, {
            data: "supplier_address",
            name: "supplier_address",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'
            }
        },{
            data: "balance",
            name: "balance",
            render: function(data){
                if(data < 0){
                    return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-danger">'+data+'</span>'
                }
                if(data > 0){
                    return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-primary">'+data+'</span>'
                }
                if(data == 0){
                    return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-secondary">'+data+'</span>'
                }
                return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'
            }
        },{
            data: "status",
            name: "status"
        }, {
            data: "action",
            name: "action"
        }]
    });
    /*------ Supplier DataTable end here ------*/
    /*------ Export Start ------*/
    $(document).on('click',".export",function(){
        var btn = $(this).attr('id').toString()
        dataTable.button(btn).trigger();
    })
    /*------ Export End -------*/ 

    /*------ Status Change Start -------*/ 
    $('input[type="checkbox"]').click(function(event) {
		/* Act on the event */
		if($('#checkbox').is(':checked')){
			$("#supplier_stat").val(1)
		}
		else{
			$("#supplier_stat").val(0)
		}
	})
    /*------ Status Change End -------*/ 

    /*------ Create Supplier Start -------*/ 
    $(document).on('click','button.add',function(){         
        $('.modal-title').text("Add Supplier");
        $('#addBtn').show();
        $('#editBtn').hide();
        $("input[type='text']").removeClass("text-capitalize")
        $("#supplier-form")[0].reset()         
        $(".text-danger").html("")
     });
    $('#supplier-form').on('click', '#addBtn', function (event) {
        event.preventDefault();
        $(".text-danger").html("") 
        var formData = new FormData($('#supplier-form')[0]);
        $.ajax({
            method: 'POST',
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function (response) {
                if(response.errors){
                    if(response.errors.supplier_name){
                        $("#supplier_name_error").text(response.errors.supplier_name[0])
                    }
                    if(response.errors.supplier_address){
                        $("#supplier_address_error").text(response.errors.supplier_address[0])
                    } 
                    if(response.errors.supplier_stat){
                        $("#supplier_stat_error").text(response.errors.supplier_stat[0])
                    }                                    
                }
                //on success
                else{
                    $('#supplier_table').DataTable().ajax.reload(); 
                    $("#modal").modal('hide')              
                    $("#supplier-form")[0].reset()
                    $('input.md-input').attr('value' , '')               
                    let message = response.success;
                    snacbar(message)
                }
            },
            error:function(error){
                snacbar(error.statusText)
            }
        })//ajax end here
    })
    /*------ Create Supplier End -------*/ 

    /*------ View Supplier Start -------*/ 
    $(document).on("click", "button.view", function() {        
        $(".modal-title").text("Supplier Details")       
        $("#addBtn").hide()
        $("#editBtn").hide()
        showInModalDetails($(this).data())
    })
    /*------ View Supplier End -------*/ 

    /*------ Edit Supplier Start -------*/     
    $(document).on("click", "button.edit", function() {     	
       	$(".modal-title").text("Supplier Edit")          
        $("#addBtn").hide()
        $("#editBtn").show()
        $("#supplier_id").val($(this).attr('id'))
        showInModalDetails($(this).data())
    })

    $("#supplier-form").on("click", "#editBtn", function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        var formData = new FormData($("#supplier-form")[0]);
        $.ajax({
            method: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if(response.errors){
                    if(response.errors.supplier_name){
                        $("#supplier_name_error").text(response.errors.supplier_name[0])
                    }
                    if(response.errors.supplier_address){
                        $("#supplier_address_error").text(response.errors.supplier_address[0])
                    } 
                    if(response.errors.supplier_stat){
                        $("#supplier_stat_error").text(response.errors.supplier_stat[0])
                    }                                    
                }
                //on success
                else{
                    $('#supplier_table').DataTable().ajax.reload(); 
                    $("#modal").modal('hide')              
                    $("#supplier-form")[0].reset()
                    $('input.md-input').attr('value' , '')               
                    let message = response.success;
                    snacbar(message)
                }
            },//success end
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end here
    })
    /*------ Edit Supplier End -------*/ 
    
    /*------ Status Change Supplier Start -------*/ 
    $(document).on("click", ".status", function(event) {
        event.preventDefault()
        $.ajax({
            type: "GET",
            url: $(this).data("url"),
            success: function(response) {
                if (response.success) {
                    $("#supplier_table").DataTable().ajax.reload();
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end here
    })
    /*------ Status Change Supplier End -------*/

    /*------ Remove Supplier Start -------*/
    $(document).on("click", "button.delete", function() {
        $("#id").val($(this).attr("id")) 
        $(".modal-title").text("Expense Date : " + $(this).data("name"))
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                	$('#supplier_table').DataTable().ajax.reload(); 
                    $("#confirmModal").modal("hide");
                    let message = response.success;
                    snacbar(message)
                }
                if (response.error) {
                	$("#ok_button").text("Yes")
                    let message = response.error;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end
    })
    /*------ Remove Supplier End -------*/

    function showInModalDetails(data) {
    	if(data.status == 1){
            $('input[type="checkbox"]').prop("checked", true)
            $("#supplier_stat").val(1)
        }
        else{
            $('input[type="checkbox"]').prop("checked", false)
            $("#supplier_stat").val(0)
        }
        $("input[type='text']").addClass("text-capitalize")   
        $("#modal").modal("show") 
        $(".text-danger").html("")        
        $("#supplier_name").val(data.name)
        $("#supplier_address").val(data.address)
        $("#supplier_stat").val(data.status) 
    }
})