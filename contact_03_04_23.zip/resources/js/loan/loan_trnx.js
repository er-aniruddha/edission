$(document).ready(function(){
    /*-------- Loan Transaction table start -------*/
    var loan_trnx_table = $("#loan_trnx_table").DataTable({
        processing: true,
        serverSide: true,
        lengthMenu: [
            [10, 25, 50,100, -1],
            [10, 25, 50,100, 'All'],
        ],
        buttons: [{ extend: 'csv', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
            { extend: 'excel', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
            { extend: 'pdf', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
            { extend: 'print', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } }
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex",
            render: function(data) {
                return '<small class="text-muted">' + data + '</small>'
            }
        },{
            data: "account_name",
            name: "account_name",
            render: function(data) {
                return '<span class="text-sm text-capitalize">' + data + '</span>'
            }
        },{
            data: "loan_trnx_id",
            name: "loan_trnx_id",
            render: function(data, type, full, meta) {
                return '<span class="text-sm text-capitalize text-primary">LT-' + data + '</span>'
            },
        },  {
            data: "bill_date",
            name: "bill_date",
            render: function(data, type, full, meta) {
                return '<span class="text-sm text-capitalize">' + moment(data).format('DD-MM-YYYY') + '</span>'
            },
        },  {
            data: "payment_date",
            name: "payment_date",
            render: function(data, type, full, meta) {
                return '<span class="text-sm text-capitalize">' + moment(data).format('DD-MM-YYYY') + '</span>'
            },
        },  {
            data: "total_emi",
            name: "total_emi",
            render: function(data) {
                return '<span class="text-sm text-capitalize inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) +'</span>';  

            }
        }, {
            data: "paid_amount",
            name: "paid_amount",
            render: function(data) {
                return '<span class="text-sm text-capitalize inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) +'</span>';  

            }
        },{
            data: "loan_balance_after_paid",
            name: "loan_balance_after_paid",
            render: function(data) {
                return '<span class="text-sm text-capitalize inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) +'</span>';  

            }
        },{
            data: "paid_date",
            name: "paid_date",
            render: function(data, type, full, meta) {
                if(!data){
                    return '<span class="item-badge badge text-uppercase bg-secondary">Not Paid Yet</span>';
                }
                else{
                    return '<span class="text-sm text-capitalize text-primary">' + moment(data).format('DD-MM-YYYY') + '</span>';
                }
                
            },
        }, {
            data: "status",
            name: "status",
        },{
            data: "action",
            name: "action"
        }],

    });
    /*-------- Loan Transaction table end -------*/
    /*-------- Searching table on account base start -------*/
    $(document).on('click', '.loan-account', function(event) {
        event.preventDefault()
        let name = $(this).data('name')
        loan_trnx_table.search(name).draw();
    })
    /*-------- Searching table on account base end ---------*/
    /*-------- View transaction details Start ------------*/
    $(document).on("click", "button.view", function() {     
        $("#loanTrnxForm")[0].reset()   
        $(".modal-title").text("Loan Transaction Details : LT-"+$(this).data("trnxid"))
        $(".text-danger").html("")
        $("#trnx_ac_name").val($(this).data("name"))
        $("#bill_date").val(moment($(this).data("billdate")).format("DD-MM-YYYY"))
        $("#payment_date").val(moment($(this).data("paymentdate")).format("DD-MM-YYYY"))
        $("#trnx_emi").val($(this).data("emi")) 
        if($(this).data("paid") > 0){
            $("#paid_amount").val($(this).data("paid"))
        }
        if($(this).data("paiddate")){
            $("#paid_date").val(moment($(this).data("paiddate")).format("DD-MM-YYYY"))   
        }
        if($(this).data("remarks")){
            $("#trnx_remarks").val($(this).data("remarks"))
        }        
        $("#paidBtn").hide()
        $("#paidEmiModal").modal("show") 
    })
    /*-------- View transaction details End ------------*/
	/*-------- Paid EMI Start ------------*/
    $(document).on("click", "button.paid", function() {    
        $("#loanTrnxForm")[0].reset()    
        $(".modal-title").text("Loan Transaction Details : LT-"+$(this).data("trnxid"))
        $(".text-danger").html("")
        $("#trnx_ac_name").val($(this).data("name"))
        $("#bill_date").val(moment($(this).data("billdate")).format("DD-MM-YYYY"))
        $("#payment_date").val(moment($(this).data("paymentdate")).format("DD-MM-YYYY"))
        $("#trnx_emi").val($(this).data("emi")) 
        $("#loan_trnx_id").val($(this).data("trnxid"))
        $("#emi_loan_ac_id").val($(this).data("loanacid"))
        $("#paidBtn").show()
        $("#loanClsBtn").hide()
        $("#paidEmiModal").modal("show") 
    })
    $("#loanTrnxForm").on('click','#paidBtn',function(event){
        event.preventDefault()
        var formData = new FormData($("#loanTrnxForm")[0]); 
        $("#loader").show()
        $.ajax({
            method: "POST",
            url: routes.paidEmi,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(res) {
                $("#loader").hide()
                if (res.errors) {
                    if (res.errors.paid_amount) {
                        $("#paid_amount_error").text(res.errors.paid_amount[0])
                    }
                    if (res.errors.date) {
                        $("#paid_date_error").text(res.errors.date[0])
                    }
                } else {
                    $("#loanTrnxForm")[0].reset()
                    $("#loan_trnx_table").DataTable().ajax.reload()
                    $("#paidEmiModal").modal("hide")
                    let message = res.message;
                    loanaccounts = res.loanaccounts;
                    loanAcList(loanaccounts)
                    snacbar(message)
                }
            },
            error: function(err) {
                $("#loader").hide()
                snacbar(err.statusText)
            }
        })
    })
    /*-------- Paid EMI End ------------*/
})