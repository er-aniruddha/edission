$(document).ready(function() {
	/*-------- Show bank modal start -------*/
    $(document).on('click', '#addLoanAc', function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        $('.modal-title').text('Add Loan Account')
        $("#loanForm")[0].reset()
        $("#monthWiseTable tbody").append().empty()
        $("#c_account_name").text('NA')
        $("#c_loan_amount").text('0.00')
        $("#c_interest_rate").text('0.00%')   
        $("#c_month").text('0 year(s) and 0 month(s)')     
        $("#c_emi").text('0.00')
        $("#c_date").text('00-00-0000')
        $("#c_total_int").text('0.00')
        $("#total_payment").text('0.00')
        $("#addBtn").show()
        $("#editBtn").hide()
        $("#closeLoan").hide()
        $("#closeLoan").hide()
    })
    /*-------- Show bank modal start -------*/
    $("#loanForm").on('keyup', '#year', function(event) {
        event.preventDefault()
        let year = $("#year").val() 
        let month = year*12;
        $("#month").val(month);
    })

    $("#loanForm").on('keyup', '#month', function(event) {
        event.preventDefault()
        let month = $("#month").val() 
        let year = month/12;
        if(year >= 1){
        	$("#year").val(parseInt(year));
        }
        else{
        	$("#year").val(0);
        }        
    })
    /*-------- Save bank accounts start -------*/
    $("#loanForm").on('click', '#computeBtn', function(event) {
        event.preventDefault()
        $("#loader").show()
        $(".text-danger").html("")
        var formData = new FormData($("#loanForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.compute,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(res) {
                $("#loader").hide()
                if (res.errors) {
                    if (res.errors.account_name) {
                        $("#account_name_error").text(res.errors.account_name[0])
                    }
                    if (res.errors.loan_amount) {
                        $("#loan_amount_error").text(res.errors.loan_amount[0])
                    }
                    if (res.errors.interest_rate) {
                        $("#interest_rate_error").text(res.errors.interest_rate[0])
                    }
                    if (res.errors.month) {
                        $("#tenure_error").text(res.errors.month[0])
                    }
                    if (res.errors.date) {
                        $("#date_error").text(res.errors.date[0])
                    }
                } 
                else {
                    let year = res.month / 12
                    if(year < 1){
                        $("#c_month").text('0 year(s) and '+res.month+' month(s)')
                    }
                    else{
                        let month = res.month - parseInt(year)*12
                        $("#c_month").text(parseInt(year)+' year(s) and '+month+' month(s)')
                    }
                    $("#c_account_name").text(res.accountName)
                    $("#c_loan_amount").text(res.loanAmount)
                    $("#c_interest_rate").text(res.intRate+'%')
                    
                    $("#c_emi").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.emi))
                    $("#c_date").text(res.startDate)
                    $("#c_total_int").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.totalInt))
                    $("#total_payment").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.totalPayment))
                    $("#monthWiseTable tbody").append().empty()
                    for(let i=0; i<res.loanTableData.length; i++){
                        tr = '<tr>'
                            +'<td>'+res.loanTableData[i].month+'</td>'
                            +'<td>'+moment(res.loanTableData[i].billDate).format("DD-MM-YYYY")+'</td>'
                            +'<td>'+moment(res.loanTableData[i].paymentDate).format("DD-MM-YYYY")+'</td>'
                            +'<td class="inr-sign">'+res.loanTableData[i].principalPaid+'</td>'
                            +'<td class="inr-sign">'+res.loanTableData[i].interest+'</td>'
                            +'<td class="inr-sign">'+res.loanTableData[i].totalPayment+'</td>'
                            +'<td class="inr-sign">'+res.loanTableData[i].endingBalance+'</td>'                          
                        +'</tr>'
                        $("#monthWiseTable tbody").append(tr)
                    }                 
                    
                }

            },
            error: function(err) {
                $("#loader").hide()
                snacbar(err.statusText)
            }
        })

    })
    /*-------- Compute Loan end -------*/
    /*-------- Save loan accounts start -------*/
    $("#loanForm").on('click', '#addBtn', function(event) {
        event.preventDefault()
        $("#loader").show()
        $(".text-danger").html("")
        var formData = new FormData($("#loanForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                $("#loader").hide()
                if (response.errors) {
                    if (response.errors.account_name) {
                        $("#account_name_error").text(response.errors.account_name[0])
                    }
                    if (response.errors.loan_amount) {
                        $("#loan_amount_error").text(response.errors.loan_amount[0])
                    }
                    if (response.errors.interest_rate) {
                        $("#interest_rate_error").text(response.errors.interest_rate[0])
                    }
                    if (response.errors.month) {
                        $("#tenure_error").text(response.errors.month[0])
                    }
                    if (response.errors.date) {
                        $("#date_error").text(response.errors.date[0])
                    }
                } else {
                    $("#loanForm")[0].reset()
                    $("#loan_trnx_table").DataTable().ajax.reload()
                    $("#loanAccountModal").modal("hide")
                    let message = response.message;
                    loanaccounts = response.loanaccounts;
                    loanAcList()
                    snacbar(message)
                }

            },
            error: function(err) {
                $("#loader").hide()
                snacbar(err.statusText)
            }
        })

    })
    /*-------- Save loan accounts end -------*/
    /*-------- View loan accounts details start -------*/
    $(document).on('click','.loan-account-view',function(event){
        event.preventDefault();
        let lacId = $(this).data('lacid');
        let accDetails = loanaccounts.filter(elem => {
            return elem.loan_ac_id == lacId;
        })       
        
        $("#monthWiseTable tbody").append().empty()
        $("#loanAccountModal").modal('show')
        let loanBalance = accDetails[0].loan_amount; 
        let eRate = accDetails[0].interest_rate / (12*100);
        let time = accDetails[0].month;                 
        let emi = accDetails[0].emi;
        let totalInt = 0
        let totalPayment = 0
        for(let i=0; i < time; i++){
            let billDate = moment(accDetails[0].date).add((i+1),'months').startOf('month').add(1,'days').format("DD-MM-YYYY"); 
            let paymentDate = moment(accDetails[0].date).add((i+1),'months').startOf('month').add(9,'days').format("DD-MM-YYYY");                
            let monthlyInt = parseFloat(loanBalance) * parseFloat(eRate);
            let monthlyPrincipalPaid = parseFloat(emi) - parseFloat(monthlyInt);   
            let endingBalance = parseFloat(loanBalance) - parseFloat(monthlyPrincipalPaid)
            totalInt = totalInt + monthlyInt
            totalPayment = totalPayment + emi
            if(endingBalance < 0){
                endingBalance = 0
            }
            else{
                endingBalance = endingBalance
            }
            tr ='<tr>'
                    +'<td>'+(i+1)+'</td>'
                    +'<td>'+billDate+'</td>'
                    +'<td>'+paymentDate+'</td>'
                    +'<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(monthlyPrincipalPaid)+'</td>'
                    +'<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(monthlyInt)+'</td>'
                    +'<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(emi)+'</td>'
                    +'<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(endingBalance)+'</td>'                          
                +'</tr>'
            $("#monthWiseTable tbody").append(tr)
            loanBalance = endingBalance
        }
        let year = accDetails[0].month / 12
        if(year < 1){
            $("#c_month").text('0 year(s) and '+accDetails[0].month+' month(s)')
        }
        else{
            let month = accDetails[0].month - parseInt(year)*12
            $("#c_month").text(parseInt(year)+' year(s) and '+month+' month(s)')
        }
        $("#c_account_name").text(accDetails[0].account_name)
        $("#c_loan_amount").text(accDetails[0].loan_amount)
        $("#c_interest_rate").text(accDetails[0].interest_rate+'%')        
        $("#c_emi").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(accDetails[0].emi))
        $("#c_date").text(moment(accDetails[0].date).format("DD-MM-YYYY"))
        $("#c_total_int").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(totalInt))
        $("#total_payment").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(totalPayment))

        $("#account_name").val(accDetails[0].account_name)
        $("#loan_amount").val(accDetails[0].loan_amount)
        $("#interest_rate").val(accDetails[0].interest_rate)    
        $("#year").val(accDetails[0].year)    
        $("#month").val(accDetails[0].month)
        $("#date").val(moment(accDetails[0].date).format("DD-MM-YYYY"))
        $("#remarks").val(accDetails[0].remarks)
        $("#loan_ac_id").val(accDetails[0].loan_ac_id)
        $("#addBtn").hide()
        $("#editBtn").show()
        $("#closeLoan").show()
    })
    /*-------- View loan accounts details end -------*/
    /*-------- Edit loan accounts start -------*/
    $("#loanForm").on('click', '#editBtn', function(event) {
        event.preventDefault()
        $("#loader").show()
        $(".text-danger").html("")
        var formData = new FormData($("#loanForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.edit,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                $("#loader").hide()
                if (response.errors) {
                    if (response.errors.account_name) {
                        $("#account_name_error").text(response.errors.account_name[0])
                    }
                    if (response.errors.loan_amount) {
                        $("#loan_amount_error").text(response.errors.loan_amount[0])
                    }
                    if (response.errors.interest_rate) {
                        $("#interest_rate_error").text(response.errors.interest_rate[0])
                    }
                    if (response.errors.month) {
                        $("#tenure_error").text(response.errors.month[0])
                    }
                    if (response.errors.date) {
                        $("#date_error").text(response.errors.date[0])
                    }
                } else {
                    $("#loanForm")[0].reset()
                    $("#loan_trnx_table").DataTable().ajax.reload()
                    $("#loanAccountModal").modal("hide")
                    let message = response.success;
                    loanaccounts = response.loanaccounts;
                    loanAcList()
                    snacbar(message)
                }

            },
            error: function(err) {
                $("#loader").hide()
                snacbar(err.statusText)
            }
        })

    })
    /*-------- Edit loan accounts end -------*/
    /*-------- CLose loan accounts Start -------*/
    $("#loanForm").on('click', '#closeLoan', function(event) {
        event.preventDefault()
        $("#loader").show()
        $(".text-danger").html("")
        var formData = new FormData($("#loanForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.closeView,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(res) {
                $("#loader").hide()
                console.log(res)
                accDetails = res.loanAcDetails
                $("#loanTrnxForm")[0].reset()    
                $(".modal-title").text("Close Loan Details")
                $(".text-danger").html("")
                $("#trnx_ac_name").val(accDetails.account_name)
                $("#bill_date").val(moment().format("DD-MM-YYYY"))
                $("#payment_date").val(moment().format("DD-MM-YYYY"))
                $("#trnx_emi").val(res.totalCloseAmount.toFixed(2)) 
                $("#paid_amount").val(res.totalCloseAmount.toFixed(2)) 
                $("#emi_loan_ac_id").val(accDetails.loan_ac_id)
                $("#paidBtn").hide()
                $("#loanClsBtn").show()
                $("#loanAccountModal").modal('hide')
                $("#paidEmiModal").modal("show")
            },
            error: function(err) {
                $("#loader").hide()
                snacbar(err.statusText)
            }
        })
    })
    $("#loanTrnxForm").on('click','#loanClsBtn',function(event){
        event.preventDefault()
        var formData = new FormData($("#loanTrnxForm")[0]); 
        $("#loader").show()
        $.ajax({
            method: "POST",
            url: routes.confimClose,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(res) {
                $("#loader").hide()
                console.log(res)
                if (res.errors) {
                    if (res.errors.paid_amount) {
                        $("#paid_amount_error").text(res.errors.paid_amount[0])
                    }
                    if (res.errors.date) {
                        $("#paid_date_error").text(res.errors.date[0])
                    }
                } else {
                    $("#loanTrnxForm")[0].reset()
                    $("#loan_trnx_table").DataTable().ajax.reload()
                    $("#paidEmiModal").modal("hide")
                    let message = res.message;
                    loanaccounts = res.loanaccounts;
                    loanAcList()
                    snacbar(message)
                }
            },
            error: function(err) {
                $("#loader").hide()
                snacbar(err.statusText)
            }
        })
    })
    /*-------- CLose loan accounts end -------*/

    /*-------- Show  loan accounts start ------*/  
    window.loanAcList = function() {
        $("#loanAcList").empty().append('')
        for (let i = 0; i < loanaccounts.length; i++) {
            let amount
            if(loanaccounts[i].loan_balance >= 0){
                amount = '' 
            }
            if(loanaccounts[i].loan_balance < 0){
                amount = '<span class="badge bg-danger-lt inr-sign" style="float: right; margin-top: 12px;"> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(loanaccounts[i].loan_balance)  + '</span></br>' 
            }
            if(loanaccounts[i].loan_status == 0){
                $("#loanAcList").append('<li>' +
                    '<a href="javascript:void(0);" data-pjax-state="anchor" class="b-b item-company text-secondary loan-account" data-name="' + loanaccounts[i].account_name + '">' +
                    '<span class="nav-text text-capitalize">' + loanaccounts[i].account_name + '' +
                    '<p class="item-except text-muted text-sm h-1x m-0">' + moment(loanaccounts[i].date, 'YYYY-MM-DD').format("DD-MM-YYYY") + '</p>' +
                    '<p class="item-except text-secondary text-sm h-1x m-0">(Closed)</p></span>' +
                    '<span class="nav-badge">' +
                    '<span class="badge bg-secondary-lt inr-sign" style="float: right; margin-top: 12px;"> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(loanaccounts[i].loan_balance)  + '</span></br>'+      
                    '<span class="badge bg-secondary-lt loan-account-view" style="float: right;" data-lacid="'+loanaccounts[i].loan_ac_id+'">' +
                    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye mx-2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg></span>' +
                    '</span>' +
                    '</a>' +
                    '</li>')
                let loanAcList = '<option class="text-capitalize" value="'+loanaccounts[i].loan_ac_id+'">'+loanaccounts[i].account_name+'</option>'
            }
            else{
                 $("#loanAcList").append('<li>' +
                    '<a href="javascript:void(0);" data-pjax-state="anchor" class="b-b item-company text-primary loan-account" data-name="' + loanaccounts[i].account_name + '">' +
                    '<span class="nav-text text-capitalize">' + loanaccounts[i].account_name + '' +
                    '<p class="item-except text-muted text-sm h-1x m-0">' + moment(loanaccounts[i].date, 'YYYY-MM-DD').format("DD-MM-YYYY") + '</p>' +
                    '<p class="item-except text-primary text-sm h-1x m-0">(Active)</p></span>' +
                    '<span class="nav-badge">' + 
                    '<span class="badge bg-primary-lt inr-sign" style="float: right; margin-top: 12px;"> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(loanaccounts[i].loan_balance)  + '</span></br>' +         
                    '<span class="badge bg-secondary-lt loan-account-view" style="float: right;" data-lacid="'+loanaccounts[i].loan_ac_id+'">' +
                    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye mx-2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg></span>' +
                    '</span>' +
                    '</a>' +
                    '</li>')
                let loanAcList = '<option class="text-capitalize" value="'+loanaccounts[i].loan_ac_id+'">'+loanaccounts[i].account_name+'</option>'
            }
                  
        }

    }
    loanAcList()
    /*-------- Show  loan accounts end ------*/  
})