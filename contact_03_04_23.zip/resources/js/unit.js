$(document).ready(function() {
    var base_url = "https://varneyatechnologies.com";

    /* Unit DataTable Start Here*/
    $("#unit_table").DataTable({
        processing: true,
        serverSide: true,
        autoWidth: false,
        lengthMenu: [
            [10, 25, 50,100, -1],
            [10, 25, 50,100, 'All'],
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex"
        }, {
            data: "unit_name",
            name: "unit_name",
            className:"text-capitalize"
        }, {
            data: "unit_code",
            name: "unit_code"
        }, {
            data: "action",
            name: "action"
        }]
    });
    /* Unit DataTable End Here*/
    /* Unit Add Start*/
    $(document).on("click", "button.add", function() {
        $(".modal-title").text("Add Unit")
         $('#unitForm')[0].reset()
         $("#unit_name").removeClass('text-capitalize')
         $("#unit_code").removeClass('text-capitalize')
         $("#unit_id").val("")
         $("#addBtn").show()
         $(".text-danger").html("")
         $("#editBtn").hide()
    })//to show modal for add
    $("#unitForm").on("click", "#addBtn", function(event) {
        event.preventDefault()
         $(".text-danger").html("")
        var formData = new FormData($("#unitForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if(response.errors.unit_name){
                        $("#unit_name_error").text(response.errors.unit_name[0])
                    }
                    if(response.errors.unit_code){
                        $("#unit_code_error").text(response.errors.unit_code[0])
                    }
                }                    
                else {
                    $("#unitForm")[0].reset() 
                    $("#unit_table").DataTable().ajax.reload()
                    $("#modal").modal("hide")
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })
    })
    /* Unit Add End*/
    /*Unit Edit Start*/
    $(document).on("click", "button.edit", function() {  
        $("#unit_name").addClass("text-capitalize")
        $("#unit_code").addClass("text-capitalize")
        $(".modal-title").text("Edit Unit") 
        $("#unit_id").val($(this).attr("id"))
        $("#unit_name").val($(this).data("name")) 
        $("#unit_code").val($(this).data("code"))
        $("#addBtn").hide() 
        $("#editBtn").show()
        $("#modal").modal("show")
    })//Unit Edit show 
    $("#unitForm").on("click", "#editBtn", function(event) {
        event.preventDefault()
         $(".text-danger").html("")
        var formData = new FormData($("#unitForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors){
                    if(response.errors.unit_name){
                        $("#unit_name_error").text(response.errors.unit_name[0])
                    } 
                    if(response.errors.unit_code){
                        $("#unit_code_error").text(response.errors.unit_code[0])
                    }                   
                }
                else{
                    $("#unitForm")[0].reset() 
                    $("#unit_code").removeClass("text-capitalize")
                    $("#unit_table").DataTable().ajax.reload()
                    $("#modal").modal("hide");
                    let message = response.success;
                    snacbar(message)
                }
            },//success end
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end here
    })//Unit edit form function end here
    /*Unit Edit End*/    
    /* Unit Status Delete Start*/
    $(document).on("click", "button.delete", function() {
        $("#id").val($(this).data("id")) 
        $(".modal-title").text("Unit Name : " + $(this).data("name"))
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $("#unit_table").DataTable().ajax.reload()
                    $("#confirmModal").modal("hide");
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end
    })//Unit Delete function end
    /* Unit Status Delete End*/
    
});