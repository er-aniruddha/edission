$(document).ready(function() {
	/*------ Export Start ------*/
    $(document).on('click',".export",function(){
        var btn = $(this).attr('id').toString()
        dataTable.button(btn).trigger();
    })
    /*------ Export End -------*/   

    /*------- View Start Here -------------*/
    $(document).on('click','a.view', function(event){
        event.preventDefault()
        let trnxId = $(this).data('trnxid')
        $('#viewRow tbody').empty().append();       
        $('#viewModal .modal-title').text("Sale Details: #INV-"+trnxId);
        $('.delivery-date').hide()
        $('#convertSaleBtn').hide()
        $('#viewAndConvertForm input').prop('readonly',true)
        $('#viewAndConvertForm textarea').prop('readonly',true)
        viewModal(trnxId)
    })
    /*------- View End Here -------------*/

    function viewModal(trnxId) {
        for (var count = 0; count < sales.length; count++){
            if(trnxId == sales[count].sale_trnx_id){
                var tr = '<tr class="">' +
                        '<td>' +
                            '<input type="text" class="form-control text-capitalize" value="' + sales[count].product_name+' - '+sales[count].brand_name+ '" readonly>' +
                        '</td>' +
                        '<td>' +
                            '<input type="text" class="form-control text-capitalize" value="'+sales[count].unit_name+'" readonly>' +
                        '</td>' +
                        '<td class="td-qty">' +
                            '<input type="number" value="' + sales[count].sale_qty + '"  class="form-control" readonly>' +
                        '</td>' +
                        '<td>' +
                            '<input type="number" value="' + sales[count].sale_unit_price + '"  class="form-control" readonly>' +               
                        '</td>' +
                        '<td>' +
                            '<input type="number" value="' + sales[count].sale_discount_percentage.toFixed(2) + '"  class="form-control text-info" readonly>' +             
                        '</td>' +
                        '<td>' +
                            '<input type="number" value="' + sales[count].sale_discount + '"  class="form-control text-info" readonly>' +             
                        '</td>' +
                        '<td>' +
                            '<input type="number" value="' + sales[count].sale_amount + '"  class="form-control" readonly>' +
                        '</td>' +
                        '</tr>';
                    $('#viewRow tbody').append(tr);

            $("#view_customer_name").val(sales[count].f_name+' '+sales[count].s_name+' ('+sales[count].phone_1+') ('+sales[count].shop_name+') ('+sales[count].locality+')')
            $("#view_order_date").val(moment(sales[count].sale_order_date, 'YYYY-MM-DD').format("DD-MM-YYYY"))
            $("#view_delivery_date").val(moment(sales[count].sale_delivery_date, 'YYYY-MM-DD').format("DD-MM-YYYY"))
            $('#view_payment_type').val(sales[count].sale_payment_type);
            $("#view_round_off").val(sales[count].sale_round_off)
            $("#view_delivery_charges").val(sales[count].sale_delivery_charges )
            $("#view_gst_amount").val(sales[count].sale_gst_amount)
            $("#view_total").val(sales[count].sale_total)
            $("#view_received").val(sales[count].sale_received)
            prevBalance2 = sales[count].sale_prev_balance
            $(".prev_bal").text('Previous Balance: '+prevBalance2)
            $("#view_prev_balance").val(parseFloat(prevBalance2))//this is to store
            $("#view_balance").val(parseFloat(sales[count].sale_balance))//this is to store
            $("#view_remarks").val(sales[count].sale_remarks)
            $("input[type='text']").addClass("text-capitalize")
            }
        }
        $("#viewModal").modal('show')
    }

})