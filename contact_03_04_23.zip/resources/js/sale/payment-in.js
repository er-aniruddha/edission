$(document).ready(function() {
    var prevBalance ;
	/* Sales DataTable Start Here*/
    var payments_table = $("#payments_table").DataTable({
        processing: true,
        serverSide: true,
        lengthMenu: [
            [10, 25, 50,100, -1],
            [10, 25, 50,100, 'All'],
        ],
        buttons: [{ extend: 'csv', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'excel', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7]}},
            { extend: 'pdf', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}},
            { extend: 'print', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7 ]}}
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex",
            render: function(data){
                return '<small class="text-muted">'+data+'</small>'
            }
        }, {
            data: "date",
            name: "date",
            render: function(data, type, full, meta) {
                return '<a href="#" class="item-company ajax h-1x" data-pjax-state="">'+data+'</a>'
            },      
        }, {
            data: "payment_in_trnx_id",
            name: "payment_in_trnx_id",
            render: function(data){
                return '<span class="text-sm text-success text-capitalize">PAY-IN-'+data+'</span>'
            }
        },{
            data: "name",
            name: "name",
        },{
            data: "payment_type",
            name: "payment_type",
            render: function(data){
                if(data == 1){
                    return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Cash</span>'
                }
                if(data == 2){
                    return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Online</span>'
                }
                if(data == 3){
                    return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Cheque</span>'
                }
            }
        },{
            data: "prev_balance",
            name: "prev_balance",
            render: function(data){
                return '<span class="text-sm">&#8377; '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
            }
        },{
            data: "received",
            name: "received",
            render: function(data){
                return '<span class="text-sm">&#8377; '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
            }
        }, {
            data: "balance",
            name: "balance",
            render: function(data){
                return '<span class="item-amount d-none d-sm-block text-sm">&#8377; '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
            }
        },{
            data: "action",
            name: "action"
        }],

    });
    /*------ Sale dataTable end here ------*/
    /*-------- Searching table on payment_in start -------*/
    $(document).on('click', '.customer', function(event) {
        event.preventDefault()
        let name = $(this).data('name')
        payments_table.search(name).draw();
    })
    /*-------- Searching table on payment_in end ---------*/
    /*------ Show due customer start ------*/
    customerlist_side()
    function customerlist_modal(){
        $("#c_id").empty().append('<option selected="" value="">Select customer</option>');
        for(let i=0; i < customer.length; i++){
            $("#c_id").append('<option value="'+customer[i].customer_id+'" data-prevbal="'+customer[i].balance+'" class="text-capitalize">'
                +''+customer[i].f_name+' '+customer[i].s_name+' ('+customer[i].shop_name+') ('+customer[i].phone_1+')</option>')
        }
    }
    function customerlist_side(){      
        $("#customerList").empty().append('');
        for(let i=0; i < customer.length; i++){
            let showBal
            if(customer[i].balance < 0){
                showBal = '<span class="badge bg-primary-lt inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(customer[i].balance)+'</span>'
            }
            else{
                showBal = '<span class="badge bg-danger-lt inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(customer[i].balance)+'</span>'                
            }
            $("#customerList").append('<li>' 
            +'<a href="javascript:void(0);" data-pjax-state="anchor" class="b-b customer item-company text-primary" data-name="'+customer[i].f_name+' '+customer[i].s_name+'">'
                +'<span class="nav-text text-capitalize">'+customer[i].f_name+' '+customer[i].s_name+''
                +'<p class="item-except text-muted text-sm h-1x">'+customer[i].shop_name+'</p></span>'
                +'<span class="nav-badge">'
                    +showBal
                +'</span>'
            +'</a>'
        +'</li>')
        }
    }
    /*------ Show due customer end ------*/
    /*------ Export Start ------*/
    $(document).on('click',".export",function(){
        var btn = $(this).attr('id').toString()
        dataTable.button(btn).trigger();
    })
    /*------ Export End -------*/ 
    /*------ On click customer show in table start -------*/ 
    $(document).on('click','.customer',function(event){
        event.preventDefault()
        let name = $(this).data('name')
        payments_table.search(name).draw();
    })
    /*------ On click customer show in table end -------*/ 

    /*------ Payment-IN start here --------*/
    $(document).on('click',"#paymentin",function(event){
        event.preventDefault()        
        $('.select2').select2({ 
            width:"100%", tags:true, dropdownParent: $('#payMentModal')
        }); 
        $(".text-danger").html("")  
        $('.modal-title').text('Add Payment')
        $("#savePayBtn").show()
        $("#updateBtn").hide()    
        $("#payment-form")[0].reset()
        $("input").prop('disabled', false);
        $("textarea").prop('disabled', false);
        $("select").prop('disabled', false);
        $("#payMentModal").modal("show")
        customerlist_modal()
    })

    $("#payment-form").on('change','select.customer',function(){ 
        $("#prev_balance").val($(this).find(':selected').data('prevbal'))
    })

    /* Add Product Start */
    $('#payment-form').on('click', '#savePayBtn', function (event) {
        event.preventDefault();
        $(".text-danger").html("") 
        var formData = new FormData($('#payment-form')[0]);
        $.ajax({
            method: 'POST',
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function (response) {
                if(response.errors){
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.received){
                        $("#received_error").text(response.errors.received[0])
                    }
                    if(response.errors.balance){
                        $("#balance_error").text(response.errors.balance[0])
                    } 
                    if(response.errors.payment_type){
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }                                    
                }
                //on success
                else{
                    customer = response.customers
                    $('#payments_table').DataTable().ajax.reload(); 
                    $("#payMentModal").modal('hide')   
                    customerlist_side()                 
                    $("#payment-form")[0].reset()
                    $('input.md-input').attr('value' , '')               
                    let message = response.success;
                    snacbar(message)
                }
            },
            error:function(error){
                snacbar(error.statusText)
            }
        })//ajax end here
    })//Add product function end here
    /*Add Product End*/

    /*------ Payment-IN end here --------*/

    /*------ check mul;tiple decimnl value start ------*/
    $('#received').keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /*------ check mul;tiple decimnl value end ------*/

    /*------ Toatal calculation -------*/
    $('.modal-body').delegate('#received', 'keyup', function() {
        let prev_balance = $("#prev_balance").val()
        let received = $("#received").val()
        let balance = parseFloat(prev_balance) - parseFloat(received)
        $("#balance").val(balance.toFixed(2))
    });
    /*----- Toatal calculation -------*/

    /*----- View function -------*/
    $(document).on('click','a.view',function(event){
        event.preventDefault()
        $('.modal-title').text('Payment Details: #PAY-IN-'+$(this).data('paytrnxid'))
        let inputStat = true
        let data = $(this).data()
        $("#savePayBtn").hide()
        $("#updateBtn").hide()
        showDetails(data,inputStat)
    })
    /*----- View function -------*/

    /*----- edit function -------*/
    $(document).on('click','a.edit',function(event){
        event.preventDefault()
        $('.modal-title').text('Edit Payment: #PAY-IN-'+$(this).data('paytrnxid'))
        $("#payMentModal #id").val($(this).attr('id'))     
        let inputStat = false
        let data = $(this).data()
        $("#savePayBtn").hide()
        $("#updateBtn").show()
        showDetails(data,inputStat)
    })

    $('#payment-form').on('click', '#updateBtn', function (event) {
        event.preventDefault();
        $(".text-danger").html("") 
        var formData = new FormData($('#payment-form')[0]);
        $.ajax({
            method: 'POST',
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function (response) {
                if(response.errors){
                    if(response.errors.received){
                        $("#received_error").text(response.errors.received[0])
                    }
                    if(response.errors.balance){
                        $("#balance_error").text(response.errors.balance[0])
                    }
                    if(response.errors.payment_type){
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }
                    if(response.errors.trnx_error){
                        let message = response.errors.trnx_error[0];
                        snacbar(message)
                    }  

                }
                //on success
                else{
                    customer = response.customers
                    $('#payments_table').DataTable().ajax.reload(); 
                    $("#payMentModal").modal('hide')   
                    customerlist_side()                 
                    $("#payment-form")[0].reset()
                    $('input.md-input').attr('value' , '')               
                    let message = response.success;
                    snacbar(message)
                }
            },
            error:function(error){
                snacbar(error.statusText)
            }
        })//ajax end here
    })
    /*----- edit function -------*/

    /*----- Purchase Item Delete Start ------*/
    $(document).on("click", "a.delete", function() {
        $("#confirmModal #id").val($(this).attr('id'))
        $(".modal-title").text("Payment Details: #PAY-IN-" + $(this).data("paytrnxid"))
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $("#payments_table").DataTable().ajax.reload()
                    $("#confirmModal").modal("hide");
                    customers = response.customers
                    customerlist_side()             
                    let message = response.success;
                    snacbar(message)
                }
                if (response.error) {
                    $("#ok_button").text("Yes")
                    let message = response.error;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })//ajax end
    })
    /*----- Purchase Item Delete End ------*/

    function showDetails(data,inputStat) {
        customerlist_modal() 
        $(".text-danger").html("")   
        $("#date").val(moment(data.date).format('DD-MM-YYYY'))
        $("#c_id").val(data.cid)
        $("#prev_balance").val(data.prevbal)
        $("#received").val(data.received)
        $("#balance").val(data.balance)
        $("#payment_type").val(data.paymenttype)
        $("#remarks").val(data.remarks)
        $("input").prop('disabled', inputStat);
        $("textarea").prop('disabled', inputStat);
        $("select").prop('disabled', inputStat);        
        $("#c_id").prop('disabled', 'disabled');   
        $("#date").prop('disabled', 'disabled');   
        $("#payMentModal").modal("show")
    }

    $(document).on('click','#modalCloseBtn',function(event){
        event.preventDefault()
        $("input").prop('disabled', false);
        $("textarea").prop('disabled', false);
        $("select").prop('disabled', false);
    })

    /*----- Search customers -----*/
    $(document).on("keyup","#searchCustomer", function() {
        var value = $(this).val().toLowerCase();
        $("#customerList .customer").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });  
    /*----- Search customers -----*/
})