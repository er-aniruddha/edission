@section('page_title','Error')
@extends('portal.layouts.main')
@section('content')

<div class="text-center p-5 w-100">
    <h1 class="display-5 my-5">Sorry! the page you are looking for doesn't exist.</h1>
    <p>Go back to <a href="{{url('/')}}" class="b-b b-white">Dashboard</a> 
        <!-- <a href="#" class="b-b b-white">contactus</a> about a problem.</p> -->
    <p class="my-5 text-muted h4">-- 404 --</p>
</div>

@endsection
 
