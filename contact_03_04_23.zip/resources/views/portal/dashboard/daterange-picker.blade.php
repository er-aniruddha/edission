<div class="daterangepicker ltr show-ranges opensleft show-calendar" style="display: none; top: 553.4px; right: 345px; left: auto;">
    <div class="ranges">
        <ul>
            <li data-range-key="Today" class="">Today</li>
            <li data-range-key="Yesterday" class="">Yesterday</li>
            <li data-range-key="Last 7 Days">Last 7 Days</li>
            <li data-range-key="Last 30 Days" class="">Last 30 Days</li>
            <li data-range-key="This Month" class="">This Month</li>
            <li data-range-key="Last Month" class="">Last Month</li>
            <li data-range-key="Custom Range" class="active">Custom Range</li>
        </ul>
    </div>
    <div class="drp-calendar left">
        <div class="calendar-table">
            <table class="table-condensed">
                <thead>
                    <tr>
                        <th class="prev available"><span></span></th>
                        <th colspan="5" class="month">Jan 2022</th>
                        <th></th>
                    </tr>
                    <tr>
                        <th>Su</th>
                        <th>Mo</th>
                        <th>Tu</th>
                        <th>We</th>
                        <th>Th</th>
                        <th>Fr</th>
                        <th>Sa</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="weekend off available" data-title="r0c0">26</td>
                        <td class="off available" data-title="r0c1">27</td>
                        <td class="off available" data-title="r0c2">28</td>
                        <td class="off available" data-title="r0c3">29</td>
                        <td class="off available" data-title="r0c4">30</td>
                        <td class="off available" data-title="r0c5">31</td>
                        <td class="weekend active start-date available" data-title="r0c6">1</td>
                    </tr>
                    <tr>
                        <td class="weekend in-range available" data-title="r1c0">2</td>
                        <td class="in-range available" data-title="r1c1">3</td>
                        <td class="in-range available" data-title="r1c2">4</td>
                        <td class="in-range available" data-title="r1c3">5</td>
                        <td class="in-range available" data-title="r1c4">6</td>
                        <td class="in-range available" data-title="r1c5">7</td>
                        <td class="weekend in-range available" data-title="r1c6">8</td>
                    </tr>
                    <tr>
                        <td class="weekend in-range available" data-title="r2c0">9</td>
                        <td class="in-range available" data-title="r2c1">10</td>
                        <td class="in-range available" data-title="r2c2">11</td>
                        <td class="in-range available" data-title="r2c3">12</td>
                        <td class="in-range available" data-title="r2c4">13</td>
                        <td class="in-range available" data-title="r2c5">14</td>
                        <td class="weekend in-range available" data-title="r2c6">15</td>
                    </tr>
                    <tr>
                        <td class="weekend in-range available" data-title="r3c0">16</td>
                        <td class="in-range available" data-title="r3c1">17</td>
                        <td class="in-range available" data-title="r3c2">18</td>
                        <td class="in-range available" data-title="r3c3">19</td>
                        <td class="in-range available" data-title="r3c4">20</td>
                        <td class="in-range available" data-title="r3c5">21</td>
                        <td class="weekend in-range available" data-title="r3c6">22</td>
                    </tr>
                    <tr>
                        <td class="weekend in-range available" data-title="r4c0">23</td>
                        <td class="in-range available" data-title="r4c1">24</td>
                        <td class="in-range available" data-title="r4c2">25</td>
                        <td class="in-range available" data-title="r4c3">26</td>
                        <td class="in-range available" data-title="r4c4">27</td>
                        <td class="in-range available" data-title="r4c5">28</td>
                        <td class="weekend in-range available" data-title="r4c6">29</td>
                    </tr>
                    <tr>
                        <td class="weekend in-range available" data-title="r5c0">30</td>
                        <td class="in-range available" data-title="r5c1">31</td>
                        <td class="off in-range available" data-title="r5c2">1</td>
                        <td class="off in-range available" data-title="r5c3">2</td>
                        <td class="off in-range available" data-title="r5c4">3</td>
                        <td class="off in-range available" data-title="r5c5">4</td>
                        <td class="weekend off in-range available" data-title="r5c6">5</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="calendar-time" style="display: none;"></div>
    </div>
    <div class="drp-calendar right">
        <div class="calendar-table">
            <table class="table-condensed">
                <thead>
                    <tr>
                        <th></th>
                        <th colspan="5" class="month">Feb 2022</th>
                        <th class="next available"><span></span></th>
                    </tr>
                    <tr>
                        <th>Su</th>
                        <th>Mo</th>
                        <th>Tu</th>
                        <th>We</th>
                        <th>Th</th>
                        <th>Fr</th>
                        <th>Sa</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="weekend off in-range available" data-title="r0c0">30</td>
                        <td class="off in-range available" data-title="r0c1">31</td>
                        <td class="in-range available" data-title="r0c2">1</td>
                        <td class="in-range available" data-title="r0c3">2</td>
                        <td class="in-range available" data-title="r0c4">3</td>
                        <td class="in-range available" data-title="r0c5">4</td>
                        <td class="weekend in-range available" data-title="r0c6">5</td>
                    </tr>
                    <tr>
                        <td class="weekend in-range available" data-title="r1c0">6</td>
                        <td class="in-range available" data-title="r1c1">7</td>
                        <td class="in-range available" data-title="r1c2">8</td>
                        <td class="in-range available" data-title="r1c3">9</td>
                        <td class="in-range available" data-title="r1c4">10</td>
                        <td class="in-range available" data-title="r1c5">11</td>
                        <td class="weekend in-range available" data-title="r1c6">12</td>
                    </tr>
                    <tr>
                        <td class="weekend in-range available" data-title="r2c0">13</td>
                        <td class="in-range available" data-title="r2c1">14</td>
                        <td class="in-range available" data-title="r2c2">15</td>
                        <td class="in-range available" data-title="r2c3">16</td>
                        <td class="in-range available" data-title="r2c4">17</td>
                        <td class="in-range available" data-title="r2c5">18</td>
                        <td class="weekend in-range available" data-title="r2c6">19</td>
                    </tr>
                    <tr>
                        <td class="weekend in-range available" data-title="r3c0">20</td>
                        <td class="in-range available" data-title="r3c1">21</td>
                        <td class="in-range available" data-title="r3c2">22</td>
                        <td class="in-range available" data-title="r3c3">23</td>
                        <td class="in-range available" data-title="r3c4">24</td>
                        <td class="in-range available" data-title="r3c5">25</td>
                        <td class="weekend in-range available" data-title="r3c6">26</td>
                    </tr>
                    <tr>
                        <td class="weekend in-range available" data-title="r4c0">27</td>
                        <td class="in-range available" data-title="r4c1">28</td>
                        <td class="off in-range available" data-title="r4c2">1</td>
                        <td class="off in-range available" data-title="r4c3">2</td>
                        <td class="off in-range available" data-title="r4c4">3</td>
                        <td class="off in-range available" data-title="r4c5">4</td>
                        <td class="weekend off in-range available" data-title="r4c6">5</td>
                    </tr>
                    <tr>
                        <td class="weekend off in-range available" data-title="r5c0">6</td>
                        <td class="off in-range available" data-title="r5c1">7</td>
                        <td class="off in-range available" data-title="r5c2">8</td>
                        <td class="off in-range available" data-title="r5c3">9</td>
                        <td class="off in-range available" data-title="r5c4">10</td>
                        <td class="off in-range available" data-title="r5c5">11</td>
                        <td class="weekend off in-range available" data-title="r5c6">12</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="calendar-time" style="display: none;"></div>
    </div>
    <div class="drp-buttons"><span class="drp-selected">01/01/2022 - 03/31/2022</span><button class="cancelBtn btn btn-sm btn-default" type="button">Cancel</button><button class="applyBtn btn btn-sm btn-primary" type="button">Apply</button> </div>
</div>