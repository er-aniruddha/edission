@extends('portal.layouts.main')
@section('content')

    @switch (Auth::User()->user_permission) 

        @case ('1')
            @include('portal.dashboard.admin')
        @break

        @case ('2')
            @include('portal.layouts.error')
        @break

        @default
            @include('portal.layouts.blocked')
        @break
    @endswitch

@endsection
 
