<div id="viewModal" class="modal fade" aria-modal="true" data-keyboard="false" data-backdrop="static" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog text-dark modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white"></h5>          
                <button class="close" data-dismiss="modal">×</button>      
            </div>
            <div class="modal-body p-4">
                <form id="" method="POST">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group row mb-3" style="float: left;">
                                <label class="col-sm-3 col-form-label">Party</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control text-capitalize" name="supplier_name" id="supplier_name" readonly>
                                </div>                            
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group row mb-3">
                                <label class="col-sm-3 col-form-label text-dark">Order Date</label>
                                <div class="col-sm-5">
                                    <input id="c2p_order_date" name="order_date" type="text" class="form-control" placeholder="Date" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group row mb-3">
                                <label class="col-sm-3 col-form-label text-dark">Delivery Date</label>
                                <div class="col-sm-5">
                                    <input data-provide="datepicker" id="c2p_delivery_date" name="delivery_date" type="text" class="form-control date" placeholder="Date">
                                    <span class="text-danger" id="c2p_delivery_date_error"></span>
                                </div>
                            </div>                            
                        </div>
                    </div>
                    <div class="t-wrp">
                        <table class="table-bordered table table-theme table-row v-middle" id="view">
                            <thead>
                                <tr>
                                    <th style="width: 40%;">Item Name</th>
                                    <th style="width: 10%;">Unit Name/Primary Unit</th>
                                    <th style="width: 10%;">Quantity</th>
                                    <th style="width: 20%;">Unit Price</th>
                                    <th style="width: 20%;">Amount</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                    <div style="bottom: 0; position: fixed; width: 100%;">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group mb-3">
                                    <label class="text-muted">Payment Type</label>
                                    <select class="form-control col-sm-8" name="payment_type" id="c2p_payment_type" disabled>
                                        <option value="" selected="">Select an option</option>
                                        <option value="1">Cash</option>
                                        <option value="2">Online</option>
                                        <option value="3">Cheque</option>
                                        <option value="4">Not Paid</option>
                                    </select>
                                    <span class="text-danger" id="payment_type_error"></span>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Remarks</label>
                                    <div class="col-sm-9">
                                        <textarea id="c2p_remarks" name="remarks" class="form-control" rows="3" disabled></textarea>
                                        <span class="text-danger" id="remarks_error"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4" style="left: 50%;">
                                <div class="input-group mb-3" style="width: 50%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 100px;">Round Off</span>
                                    </div>
                                    <input type="number" class="form-control number" id="c2p_round_off" readonly>
                                </div>
                                <div class="input-group mb-3" style="width: 50%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 100px;">Delivery Charges</span>
                                    </div>
                                    <input type="number" class="form-control number" id="c2p_delivery_charges" readonly>
                                </div>
                                <div class="input-group mb-3" style="width: 50%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 100px;">GST Amount</span>
                                    </div>
                                    <input type="number" class="form-control number" id="c2p_gst_amount" readonly>
                                </div>
                                <div class="input-group mb-3" style="width: 50%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 100px;">Total</span>
                                    </div>
                                    <input type="number" class="form-control total" id="c2p_total"  value="0.00" readonly="">
                                </div>
                                <div class="input-group mb-3" style="width: 50%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 100px;">Advance</span>
                                    </div>
                                    <input type="number" class="form-control number advance" id="c2p_advance" readonly>
                                </div>
                                <div class="input-group mb-3" style="width: 50%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 100px;">Balance</span>
                                    </div>
                                    <input type="number" class="form-control" id="c2p_balance" readonly="">
                                </div>
                                <span class="text-sm prev_bal" style="color: #f44336; font-weight:600;"></span>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.modal-content -->
</div>