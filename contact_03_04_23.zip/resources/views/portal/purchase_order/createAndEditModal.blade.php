<div id="modal" class="modal fade" aria-modal="true" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog text-dark modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white"></h5>   
                <button class="close" data-dismiss="modal">×</button>             
            </div>
            <div class="modal-body p-4">
                <form id="purchaseOrderForm" method="POST">
                    @csrf                   

                    <div class="form-group row mb-3">
                        <label class="col-sm-1 col-form-label text-dark">Party</label>
                        <div class="col-sm-10">
                            <select class="form-control text-capitalize supplier select2" name="supplier_id" id="supplier_id">
                                <option value="" selected="">Select Supplier</option>
                                @foreach($suppliers as $supplier)
                                @if($supplier->supplier_stat == 1)
                                    <option value="{{ $supplier->supplier_id}}" data-balance="{{ $supplier->balance}}">{{ $supplier->supplier_name }}</option>
                                @else
                                    <option value="{{ $supplier->supplier_id}}" disabled="">{{ $supplier->supplier_name }}</option>
                                @endif                                
                                @endforeach
                            </select>
                            <span class="text-danger" id="supplier_id_error"></span>
                        </div>
                        <div class="col-sm-1">
                            <a href="javascript:void(0)" class="addRow hide" style="text-align: center;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
                                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                    <line x1="12" y1="8" x2="12" y2="16"></line>
                                    <line x1="8" y1="12" x2="16" y2="12"></line>
                                </svg>
                            </a>
                        </div>
                    </div>
                    <div class="t-wrp">
                        <table class="table-bordered table table-theme table-row v-middle" id="tdFormRow">
                            <thead>
                                <tr>
                                    <th style="width: 60%;">Item Name</th>
                                    <th style="width: 10%;">Unit Name/Primary Unit</th>
                                    <th style="width: 10%;">Quantity</th>
                                    <th style="width: 10%;">Unit Price</th>
                                    <th style="width: 10%;">Amount</th>
                                    <th>
                                    </th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                    <div class="bottom-calculation">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group mb-3">
                                    <label class="text-muted">Payment Type</label>
                                    <select class="form-control col-sm-8" name="payment_type" id="payment_type">
                                        <option value="" selected="">Select an option</option>
                                        <option value="1">Cash</option>
                                        <option value="2">Online</option>
                                        <option value="3">Cheque</option>
                                        <option value="4">Not Paid</option>
                                    </select>
                                    <span class="text-danger" id="payment_type_error"></span>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Order Date</label>
                                    <div class="col-sm-9">
                                        <input data-provide="datepicker" id="order_date" name="order_date" type="text" class="form-control date" placeholder="Date">
                                        <span class="text-danger text-sm" id="order_date_error"></span>
                                    </div>
                                </div>
                                
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Remarks</label>
                                    <div class="col-sm-9">
                                        <textarea id="remarks" name="remarks" class="form-control" rows="3"></textarea>
                                        <span class="text-danger" id="remarks_error"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4" style="left: 45%;">
                                <div class="input-group mb-3" style="width: 80%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 120px;">Round Off</span>
                                    </div>
                                    <input type="number" class="form-control number" min="0" placeholder="0.00" name="round_off" id="round_off" value="0.00" >
                                </div>
                                <div class="input-group mb-3" style="width: 80%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 120px;">Delivery Charges</span>
                                    </div>
                                    <input type="number" class="form-control number" min="0" placeholder="0.00" name="delivery_charges" id="delivery_charges" value="0.00" >
                                </div>
                                <div class="input-group mb-3" style="width: 80%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 120px;">GST Amount</span>
                                    </div>
                                    <input type="number" class="form-control number" min="0" placeholder="0.00" name="gst_amount" id="gst_amount" value="0.00" >
                                </div>
                                <div class="input-group mb-3" style="width: 80%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 120px;">Total</span>
                                    </div>
                                    <input type="number" class="form-control total" min="0" placeholder="0.00" name="total" id="total"  value="0.00" readonly="">
                                </div>
                                <div class="input-group mb-3" style="width: 80%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 120px;">Advance</span>
                                    </div>
                                    <input type="number" class="form-control number advance" min="0" placeholder="0.00" name="advance" id="advance" value="0.00" >
                                </div>
                                <div class="input-group mb-3" style="width: 80%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 120px;">Balance</span>
                                    </div>
                                    <input type="number" class="form-control" min="0" placeholder="0.00" name="balance" id="balance"  value="0.00" readonly="">
                                </div>
                                <span class="text-sm prev_bal" style="color: #f44336; font-weight:600;"></span>
                            </div>
                        </div>
                    </div>
                    <div class="footer-form">
                        <input type="hidden" name="po_id" id="po_id">         
                        <input type="hidden" name="prev_balance" id="prev_balance">         
                        <div class="flex">
                            <div class="row">
                                <div class="col-md-6 d-flex justify-content-center" data-dismiss="modal" style="width: 80%;">
                                     <button class="btn btn-raised btn-wave mb-2 w-xs btn-outline-dark" data-dismiss="modal">Cancel</button>   
                                    
                                </div>
                                <div class="col-md-6 d-flex justify-content-center" style="width: 80%;">
                                    <button class="btn btn-raised btn-wave mb-2 w-xs blue text-white" id="addBtn">Save</button>
                                    <button class="btn btn-raised btn-wave mb-2 w-xs deep-orange text-white hide" id="editBtn">Update</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.modal-content -->
</div>