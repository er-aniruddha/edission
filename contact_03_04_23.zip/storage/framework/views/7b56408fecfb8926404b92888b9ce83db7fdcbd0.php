<form action="<?php echo e(route('stock.create')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div id="createModal" class="modal fade modal-open-aside show" data-backdrop="true" style="display: none; padding-right: 17px;" aria-hidden="true" data-class="modal-open-aside">
    <div class="modal-dialog modal-right w-xl">
        <div class="modal-content h-100 no-radius">
            <div class="modal-header">
                <div class="modal-title text-md">Add SKU</div>
                <button class="close" data-dismiss="modal">×</button></div>
                <div class="modal-body">

                <div class="row row-sm">
                    <div class="col-md-12">    
                        <div class="col-sm-12">
                            <div class="md-form-group float-label" style="padding-bottom: 7px">
                                <input type="text" class="md-input" value="" name="stock_name" id="stock_name" 
                                onkeyup="this.setAttribute('value', this.value);" required=""><label>SKU Name *</label>
                                <span class="text-danger mr-2" id="sku_name_error"></span>
                            </div>                            
                        </div>

                        <!-- <div class="col-sm-12">
                            <div class="form-group">
                                <label class="text-muted">Product Name</label>
                                <select class="form-control proSelect" data-placeholder="Select an option" name="product_name" id="product_name" tabindex="-1" aria-hidden="true">
                                    <option value="1" >Product 1 </option>
                                    <option value="2" >Product 2</option> 
                                    <option value="3" >Product 3 </option>
                                    <option value="4" >Select 4</option>
                                </select>
                                <span class="text-danger mr-2" id="product_name_error"></span>
                            </div>                           
                        </div> -->
                        <div class="col-sm-12">
                            <label class="text-muted">Date</label>
                            <input type="text" class="form-control mb-3 date" data-provide="datepicker" 
                            id="date" name="date" value="">
                        </div>                
                        <!-- <div class="col-sm-12">
                            <div class="md-form-group float-label">
                                <input type="text" class="md-input" value="" name="" id="" 
                                onkeyup="this.setAttribute('value', this.value);" required=""><label>Purchasing\Manufacturing Cost</label>
                                <span class="text-danger mr-2" id="sku_name_error"></span>
                            </div>                            
                        </div> -->

                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-dismiss="modal">Close</button> 
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
</div>
</form>
<script type="text/javascript">
    // In your Javascript (external .js resource or <script> tag)
$(document).ready(function() {
    $('.proSelect').select2({
        width:"272px" 
    });
    
    $('.date').datepicker({
        format: "dd/mm/yyyy",
        autoclose: true,
        width:"272px",
        startDate:"-15d",
        endDate:"0d",        
    }).on('changeDate', function(){
        $("#date").change()
        console.log($("#date").val())
    });
});
</script>


<?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/sku/createModal.blade.php ENDPATH**/ ?>