<?php echo e($slot); ?>

<?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>