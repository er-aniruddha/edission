<div id="bankAccountModal" class="modal fade show"  aria-modal="true">
    <div class="modal-dialog text-dark">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white text-capitalize"></h5><button class="close" data-dismiss="modal">×</button>
            </div>
            <div class="modal-body">
                <form id="bankForm" method="POST">  
                    <?php echo csrf_field(); ?>  
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Account Name </label>
                        <div class="col-sm-9">
                            <input id="account_name" name="account_name" type="text" class="form-control text-capitalize" placeholder="Diplay A/C name">
                            <span class="text-danger" id="account_name_error"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Opening Balance </label>
                        <div class="col-sm-9">
                            <input id="opening_balance" name="opening_balance" type="number" class="form-control" placeholder="Opening balance" oninput="this.value = Math.round(this.value);">
                            <span class="text-danger" id="opening_balance_error"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Date</label>
                        <div class="col-sm-9">
                            <input data-provide="datepicker" id="date" name="date" type="text" class="form-control date" placeholder="Date">
                            <span class="text-danger" id="date_error"></span>
                        </div>                        
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Remarks</label>
                        <div class="col-sm-9">
                            <input id="remarks" name="remarks" type="text" class="form-control " placeholder="Remarks">
                        </div>                        
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="baccount_id" id="baccount_id"/>
                        <button class="btn gd-primary text-white btn-rounded" id="addBtn">Save</button>
                        <button class="btn gd-warning text-white btn-rounded hide" id="editBtn">Update</button>
                    </div>   
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
</div><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/bank/bankAccountModal.blade.php ENDPATH**/ ?>