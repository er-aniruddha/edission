<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo $__env->yieldContent('page_title'); ?> | United Enterprise </title>
	<meta name="description" content="Responsive, Bootstrap, BS4">
	<meta name="_token" content="<?php echo e(csrf_token()); ?>" />
	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
	<!-- style -->
	<link rel="stylesheet" href="<?php echo e(asset('public/portal/css/bootstrap.min.css')); ?>">	
	<script src="<?php echo e(asset('public/portal/js/jquery-3.5.1.min.js')); ?>"></script>
	<!-- Select2 CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('public/portal/css/select2.min.css')); ?>">
	<!-- Datepicker CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('public/portal/css/bootstrap-datepicker.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/portal/css/daterangepicker.css')); ?>" />
	<!-- DataTables CSS -->
    <!-- <link type="text/css" rel="stylesheet" href="<?php echo e(asset('public/portal/DataTables/datatables.min.css')); ?>" > -->
    <!-- DataTables Responsive CSS -->
    <link href="<?php echo e(asset('public/portal/dataTables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/portal/dataTables/buttons.dataTables.min.css')); ?>" rel="stylesheet"> 
    
	<link rel="stylesheet" href="<?php echo e(asset('public/portal/css/snackbar.css')); ?>">
	<script type="text/javascript" src="<?php echo e(asset('public/portal/js/snackbar.js')); ?>"></script> 
  <!--   <script type="text/javascript" src="<?php echo e(asset('public/portal/js/select2.js')); ?>"></script>  -->
	<link rel="stylesheet" href="<?php echo e(asset('public/portal/css/fullcalendar.min.css')); ?>">
	<script src="https://raw.githack.com/eKoopmans/html2pdf/master/dist/html2pdf.bundle.js"></script>

    
</head>
<body class="layout-row">
<!-- loader -->
    <div id="loader">
        <div class="spinner-border text-primary" role="status"></div>
    </div>
    <!-- * loader --> <?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/layouts/header.blade.php ENDPATH**/ ?>