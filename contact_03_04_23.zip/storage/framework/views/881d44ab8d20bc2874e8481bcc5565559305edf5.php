<div id="b2cModal" class="modal fade"  aria-modal="true" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog text-dark">
        <div class="modal-content">
            <div class="modal-header red">
                <h5 class="modal-title text-white text-capitalize">Bank to Cash transfer</h5><button class="close" data-dismiss="modal">×</button>
            </div>
            <div class="modal-body">
                <form id="b2cTrnsferForm" method="POST">  
                    <?php echo csrf_field(); ?>  
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">From</label>
                        <div class="col-sm-9">
                        	<select class="form-control select2 text-capitalize" id="b2c_baccount_id" name="baccount_id">
                        		
                        	</select>
                            <span class="text-danger" id="b2c_baccount_id_error"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">To</label>
                        <div class="col-sm-9">
                        	<select class="form-control" id="b2c_cash" name="cash">
                        		<option selected="" value="cash">Cash</option>
                        	</select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Amount</label>
                        <div class="col-sm-9">
                            <input id="b2c_amount" name="amount" type="number" class="form-control" placeholder="Amount" oninput="this.value = Math.round(this.value);">
                            <span class="text-danger" id="b2c_amount_error"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Date</label>
                        <div class="col-sm-9">
                            <input data-provide="datepicker" id="b2c_date" name="date" type="text" class="form-control date" placeholder="Date">
                            <span class="text-danger" id="b2c_date_error"></span>
                        </div>                        
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Remarks</label>
                        <div class="col-sm-9">
                            <input id="b2c_remarks" name="remarks" type="text" class="form-control " placeholder="Remarks">
                        </div>                        
                    </div>
                    <div class="modal-footer">
                        <button class="btn red text-white btn-raised btn-wave" id="cashTrnsBtn">Cash Withdraw</button>
                    </div>   
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
</div><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/bank/b2cModal.blade.php ENDPATH**/ ?>