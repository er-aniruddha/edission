<?php $__env->startSection('page_title','Dashboard'); ?>
<div id="content" class="flex">
    <div class="">
        <div class="page-content" id="page-content">
            <div class="padding">
                <div class="row row-sm sr">
                    <div class="col-md-9">
                        <!-- Sales Start -->
                        <div class="row row-sm">
                            <div class="col-md-6">
                                <div class="card p-3 r-3x b-b b-b-2x b-b-success mr-3" id="sale-card" style="visibility: visible; transform: none; opacity: 1; transition: none 0s ease 0s;">
                                    <div class="card-body text-center">
                                        <h4 class="text-center text-success"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file mx-2 mb-1">
                                                <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path>
                                                <polyline points="13 2 13 9 20 9"></polyline>
                                            </svg>Sales</h4>
                                            <input type="text" id="date_range" name="date_range" class="btn mb-1 btn-light date-range" data-name="sales" style="width: 55%;">
                                        <div class="b-b mb-2 mt-3"></div>
                                        <h2 style="font-weight: 500; color: #535c78;" class="text-highlight sales-amount"></h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <!-- Card Body Start -->
                                <div class="card p-3 r-3x b-b b-b-2x b-b-info mr-3" id="sale-card" style="visibility: visible; transform: none; opacity: 1; transition: none 0s ease 0s;">
                                    <div class="card-body text-center">
                                        <h4 class="text-center text-info"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file-text mx-2 mb-1">
                                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                                <polyline points="14 2 14 8 20 8"></polyline>
                                                <line x1="16" y1="13" x2="8" y2="13"></line>
                                                <line x1="16" y1="17" x2="8" y2="17"></line>
                                                <polyline points="10 9 9 9 8 9"></polyline>
                                            </svg>Sales Order</h4>
                                        <input type="text" id="date_range" name="date_range" class="btn mb-1 btn-light date-range" data-name="sales-o" style="width: 55%;">
                                        <div class="b-b mb-2 mt-3"></div>
                                        <h2 style="font-weight: 500; color: #535c78;" class="text-highlight sales-o-amount"></h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Sales End -->
                        <!-- Purchase Start -->
                        <div class="row row-sm">
                            <div class="col-md-6">
                                <div class="card p-3 r-3x b-b b-b-2x b-b-primary mr-3" id="sale-card" style="visibility: visible; transform: none; opacity: 1; transition: none 0s ease 0s;">
                                    <div class="card-body text-center">
                                        <h4 class="text-center text-primary"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-cart mx-2 mb-1">
                                                <circle cx="9" cy="21" r="1"></circle>
                                                <circle cx="20" cy="21" r="1"></circle>
                                                <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                                            </svg>Purchase</h4>
                                        <input type="text" id="date_range" name="date_range" class="btn mb-1 btn-light date-range" data-name="purchase" style="width: 55%;">
                                        <div class="b-b mb-2 mt-3"></div>
                                        <h2 style="font-weight: 500; color: #535c78;" class="text-highlight purchase-amount"></h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card p-3 r-3x b-b b-b-2x b-b-warning mr-3" id="sale-card" style="visibility: visible; transform: none; opacity: 1; transition: none 0s ease 0s;">
                                    <div class="card-body text-center">
                                        <h4 class="text-center text-warning"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-truck mx-2 mb-1">
                                                <rect x="1" y="3" width="15" height="13"></rect>
                                                <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                                                <circle cx="5.5" cy="18.5" r="2.5"></circle>
                                                <circle cx="18.5" cy="18.5" r="2.5"></circle>
                                            </svg>Purchase Order</h4>
                                        <input type="text" id="date_range" name="date_range" class="btn mb-1 btn-light date-range" data-name="purchase-o" style="width: 55%;">
                                        <div class="b-b mb-2 mt-3"></div>
                                        <h2 style="font-weight: 500; color: #535c78;" class="text-highlight purchase-o-amount"></h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Purchase End -->
                        <div class="row row-sm">
                            <!-- Expense Body Start -->
                            <div class="col-md-4">
                                <div class="card p-3 r-3x b-b b-b-2x b-b-danger mr-3" id="expense-card" style="visibility: visible; transform: none; opacity: 1; transition: none 0s ease 0s;">
                                    <div class="card-body text-center">
                                        <h4 class="text-center text-danger">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-dollar-sign mb-1">
                                                <line x1="12" y1="1" x2="12" y2="23"></line>
                                                <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                                            </svg>
                                            Expense
                                        </h4>
                                        <input type="text" id="date_range" name="date_range" class="btn mb-1 btn-light date-range" data-name="expense" style="width: 55%;">
                                        <div class="b-b mb-2 mt-3"></div>
                                        <h2 style="font-weight: 500; color: #535c78;" class="text-highlight expense-amount"></h2>
                                    </div>
                                </div>
                            </div>
                            <!-- Expense Body End -->
                            <div class="col-md-4">
                                <div class="card p-3 r-3x b-b b-b-2x b-b-success mr-3" id="receive-card" style="visibility: visible; transform: none; opacity: 1; transition: none 0s ease 0s;">
                                    <div class="card-body text-center">
                                        <h4 class="text-center text-success" style="padding-top: 20px;">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-down mb-1">
                                                <line x1="12" y1="5" x2="12" y2="19"></line>
                                                <polyline points="19 12 12 19 5 12"></polyline>
                                            </svg>
                                            You Will Receive
                                        </h4>
                                        <!-- <input type="text" id="date_range" name="date_range" class="btn mb-1 btn-light date-range" style="width: 65%;"> -->
                                        <div class="b-b mb-2 mt-4" style="padding-bottom: 20px;"></div>
                                        <h2 style="font-weight: 500; color: #535c78;" class="text-highlight receive-amount"></h2>
                                    </div>
                                </div>
                            </div>
                            <!-- You Will Receive End -->
                            <!-- You Will Pay Start -->
                            <div class="col-md-4">
                                <div class="card p-3 r-3x b-b b-b-2x b-b-danger mr-3" id="pay-card" style="visibility: visible; transform: none; opacity: 1; transition: none 0s ease 0s;">
                                    <div class="card-body text-center">
                                        <h4 class="text-center text-danger" style="padding-top: 20px;">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-up mb-1">
                                                <line x1="12" y1="19" x2="12" y2="5"></line>
                                                <polyline points="5 12 12 5 19 12"></polyline>
                                            </svg>
                                            You Will Pay
                                        </h4>
                                        <!-- <input type="text" id="date_range" name="date_range" class="btn mb-1 btn-light date-range" style="width: 65%;"> -->
                                        <div class="b-b mb-2 mt-4" style="padding-bottom: 20px;"></div>
                                        <h2 style="font-weight: 500; color: #535c78;" class="text-highlight pay-amount"></h2>
                                    </div>
                                </div>
                            </div>
                            <!-- You Will Pay End -->
                        </div>
                    </div>
                    <div class="col-md-3">
                        <!-- Stock Inventory Start -->
                        <h2 class="text-md text-highlight" style="font-weight: 600; color: #535c78;">Stock Inventory</h2>
                        <div class="b-b mb-3"></div>
                        <!-- Stock Value Start -->
                        <div class="card" id="stock-card" style="visibility: visible; transform: none; opacity: 1; transition: none 0s ease 0s;">
                            <div class="card-body">
                                <div class="text-highlight text-md stock-amount">00</div><small>Stock Value</small>
                            </div>
                        </div>
                        <!-- Stock Value End -->
                        <!-- Low Stocks Start -->
                        <div class="card" id="low-stock-card" style="visibility: visible; transform: none; opacity: 1; transition: none 0s ease 0s;">
                            <span style="font-weight: 600; color: #535c78;" class="mb-2 ml-3 mt-2 mr-3">Low Stocks
                                <span class="text-sm" style="float: right;">Total item(s) : <small class="text-dark" style="font-weight: 600;"><?php echo e($lowStocks->total()); ?></small></span>
                            </span>
                            <ul class="list-group list-group-flush">
                                <?php $__currentLoopData = $lowStocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lowStock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item text-capitalize text-sm text-muted"><?php echo e($lowStock->product_name); ?>

                                    <span style="float: right;" class="text-danger text-capitalize text-sm"><?php echo e($lowStock->in_hand_stock_primary); ?>(<?php echo e($lowStock->primary_unit_name); ?>)/<?php echo e($lowStock->in_hand_stock_second); ?>(<?php echo e($lowStock->secondary_unit_name); ?>)</span>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <!-- Low Stocks End -->
                        <!-- Stock Inventory End -->
                        <!-- Cash & Bank Start -->
                        <h2 class="text-md text-highlight" style="font-weight: 600; color: #535c78;">Cash & Bank</h2>
                        <div class="b-b mb-3"></div>
                        <!-- Cash In Hand Start -->
                        <div class="card" id="cash-in-hand-card" style="visibility: visible; transform: none; opacity: 1; transition: none 0s ease 0s;">
                            <div class="card-body">
                               <div class="cash-in-hand"> </div> <small>Cash In Hand</small>
                            </div>
                        </div>
                        <!-- Cash In Hand End -->
                        <!-- Bank Accounts Start -->
                        <div class="card" id="bank-account-card" style="visibility: visible; transform: none; opacity: 1; transition: none 0s ease 0s;">
                            <span style="font-weight: 600; color: #535c78;" class="mb-2 ml-3 mt-2 mr-3">Bank Accounts
                                <span class="text-sm" style="float: right;">A/C Balance: <small class="text-dark account-value" style="font-weight: 600;"></small></span>
                            </span>
                            <ul class="list-group list-group-flush account-list">
                               
                            </ul>
                            
                        </div>
                       
                        <!-- Bank Accounts End -->
                        <div class="card" style="visibility: visible; transform: none; opacity: 1; transition: none 0s ease 0s;">
                            <div class="card-body">
                                <div class="text-highlight text-md credit-note">00</div><small>Credit Note</small>
                            </div>
                        </div>
                        <!-- Cash & Bank End -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
$(document).ready(function() {
    // global app configuration object
    var routes = [
        { "id":"index", "name": "<?php echo e(route('dashboard')); ?>" },
        { "id":"sales", "name": "<?php echo e(route('sale.date.range')); ?>" },
        { "id":"sales-o", "name": "<?php echo e(route('sale.order.date.range')); ?>" },
        { "id":"purchase", "name": "<?php echo e(route('purchase.date.range')); ?>" },
        { "id":"purchase-o", "name": "<?php echo e(route('purchase.order.date.range')); ?>" },
        { "id":"expense", "name": "<?php echo e(route('expense.date.range')); ?>" }
    ];

    getValuesOnDate("sales")
    getValuesOnDate("sales-o")
    getValuesOnDate("purchase")
    getValuesOnDate("purchase-o")
    getValuesOnDate("expense")

    showAllItemDetails(startDate, endDate)
    function showAllItemDetails(startDate, endDate) {
        $.ajax({
            method: "GET",
            url: routes[0].name,
            dataType: "json",
            data:{ startDate: startDate.format('YYYY-MM-DD'), endDate: endDate.format('YYYY-MM-DD')},
            success: function(res) {
               if(res.cashInHand < 0){
                    $('.cash-in-hand').html('<div class="text-highlight text-md text-danger"><span style="font-weight: 400; font-size: 18px;">&#8377;</span> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.cashInHand)+'</div>')
                }
                else{
                    $('.cash-in-hand').html('<div class="text-highlight text-md text-success"><span style="font-weight: 400; font-size: 18px;">&#8377;</span> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.cashInHand)+'</div>')
                }
                for(let i=0; i < res.bankAccounts.length; i++){
                    $('.account-list').append('<li class="list-group-item text-capitalize text-sm text-muted">'+ res.bankAccounts[i].account_name+''+
                            '<span style="float: right;" class="text-sm text-dark">&#8377 '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.bankAccounts[i].account_balance)+'</span>'+
                        '</li>')
                }
                $('.credit-note').html('<div class="text-highlight text-md text-danger"><span style="font-weight: 400; font-size: 18px;">&#8377;</span> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.totalCrNote)+'</div>')
               
                $('.receive-amount').html('<span style="font-weight: 400; font-size: 20px;">&#8377;</span> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.totalDue))
                $('.pay-amount').html('<span style="font-weight: 400; font-size: 20px;">&#8377;</span> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.totalPay))
                $('.stock-amount').html('<span style="font-weight: 400; font-size: 16px;">&#8377;</span> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.totalStockValue))
                $('.account-value').html('<span style="font-weight: 600; font-size: 13px;">&#8377;</span> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.bankAccountBal))
                storeUserValue()
            }
        })
    }

    var loginUser = <?php echo json_encode($user, 15, 512) ?>;
    function storeUserValue(argument) {
        localStorage.setItem('f_name', loginUser.f_name)
        localStorage.setItem('s_name', loginUser.s_name)
        localStorage.setItem('email', loginUser.email)
        localStorage.setItem('image', loginUser.user_img)
    }
    
    $(document).on('change','input[name="date_range"]',function(event){
        let ri = $(this).data('name') 
        getValuesOnDate(ri)
    }) 
        
    
    function getValuesOnDate(ri) {
        let url = routes.filter(elem => {
            return elem.id == ri;
        })
        $.ajax({
            method: "GET",
            url: url[0].name,
            dataType: "json",
            data:{ startDate: startDate.format('YYYY-MM-DD'), endDate: endDate.format('YYYY-MM-DD')},
            success: function(res) {
                $('.'+ri+'-amount').html('<span style="font-weight: 400; font-size: 20px;">&#8377;</span> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res))
            }
        })
    }
        
    


})
</script><?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/dashboard/admin.blade.php ENDPATH**/ ?>