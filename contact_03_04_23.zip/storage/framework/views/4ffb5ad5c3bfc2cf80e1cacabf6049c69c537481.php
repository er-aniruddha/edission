<?php $__env->startSection('page_title','Bank Accounts'); ?>
<!-- CONTENT START -->
<div id="content" class="flex">
    <div class="d-flex flex fixed-content">
        <div class="aside aside-sm" id="content-aside">
            <div class="d-flex flex-column w-xl modal-dialog bg-body" id="chat-nav">
                <div class="navbar">
                    <span class="text-md mx-2">Bank Accounts</span>
                    <div class="dropdown dropright">
                        <button class="btn btn-sm btn-raised btn-wave blue" id="addBankAc" data-toggle="modal" data-target="#bankAccountModal">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user-plus mx-2">
                                <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                <circle cx="8.5" cy="7" r="4"></circle>
                                <line x1="20" y1="8" x2="20" y2="14"></line>
                                <line x1="23" y1="11" x2="17" y2="11"></line>
                            </svg>
                            Add Bank
                        </button>
                    </div>
                </div>
                <div class="scrollable hover">
                    <div class="sidenav p-2">
                        <nav class="nav-active-text-primary" data-nav="">
                            <ul class="nav" id="bankAcList">
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex flex pr-md-3">
            <div class="d-flex flex-column flex m-0 mb-md-3">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="dropdown mb-2 mt-5 show" style="float: right;">
                            <button class="btn btn-raised btn-wave mb-2 blue text-white dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Deposite / Withdraw</button>
                            <div class="dropdown-menu " role="menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(-45px, 34px, 0px); top: 0px; left: 0px; will-change: transform;">
                                <a class="dropdown-item b-c-trns" data-toggle="modal" data-target="#b2cModal">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-minus">
                                        <line x1="5" y1="12" x2="19" y2="12"></line>
                                    </svg>Cash Withdraw
                                </a>
                                <a class="dropdown-item c-b-trns" data-toggle="modal" data-target="#c2bModal">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus">
                                        <line x1="12" y1="5" x2="12" y2="19"></line>
                                        <line x1="5" y1="12" x2="19" y2="12"></line>
                                    </svg>Cash Deposite
                                </a>
                                <a class="dropdown-item b-b-trns">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right-circle">
                                        <circle cx="12" cy="12" r="10"></circle>
                                        <polyline points="12 16 16 12 12 8"></polyline>
                                        <line x1="8" y1="12" x2="16" y2="12"></line>
                                    </svg> Bank to Bank Transfer
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="bank_trnx_table">
                        <thead>
                            <tr>
                                <th style="width: 26px;"><span class="text-muted">#</span></th>
                                <th><span class="text-muted">Date</span></th>
                                <th><span class="text-muted">Transction Id</span></th>
                                <th><span class="text-muted">Type</span></th>
                                <th><span class="text-muted">Account Name</span></th>
                                <th><span class="text-muted">Amount</span></th>
                                <th><span class="text-muted">Remakrs</span></th>
                                <th style="width:50px"></th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- CONTENT END -->
<?php echo $__env->make('portal.bank.bankAccountModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('portal.bank.b2cModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('portal.bank.c2bModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('portal.bank.editModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('portal.layouts.deleteModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<script>
// global app configuration object
var routes = {
    index: "<?php echo e(route('bank.index')); ?>",
    create: "<?php echo e(route('bank.account.create')); ?>",
    update: "<?php echo e(route('bank.account.update')); ?>",
    b2c: "<?php echo e(route('bank.transaction.b2c')); ?>",
    c2b: "<?php echo e(route('bank.transaction.c2b')); ?>",
    trnxUpdate: "<?php echo e(route('bank.transaction.update')); ?>",
    trnxDelete: "<?php echo e(route('bank.transaction.delete')); ?>",
};
var bankaccounts = <?php echo json_encode($bankaccounts, 15, 512) ?>

// All the vaiables are required for end
</script>
<script type="text/javascript" src="<?php echo e(asset('resources/js/bank/bank.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('resources/js/bank/bank-transaction.js')); ?>"></script><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/bank/admin/index.blade.php ENDPATH**/ ?>