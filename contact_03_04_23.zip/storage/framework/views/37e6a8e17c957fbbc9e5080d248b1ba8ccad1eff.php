<div id="modal" class="modal fade show" aria-modal="true">
    <div class="modal-dialog text-dark">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white"></h5><button class="close" data-dismiss="modal">×</button>
            </div>
            <div class="modal-body">
                <div class="modal-body p-4">
                    <form id="brandForm" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mb-3">
                            <label class="text-muted">Brand Name</label>
                            <input class="form-control" type="text" id="brand_name" name="brand_name">
                            <span class="text-danger" id="brand_name_error"></span>
                        </div>
                        <div class="form-group mb-3">
                            <label class="text-muted">Brand Description</label>
                            <input class="form-control" type="text" id="brand_desc" name="brand_desc">
                            <span class="text-danger" id="brand_desc_error"></span>
                        </div>
                        <div class="form-group mb-3">
                            <label class="text-muted">Brand Image</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="image" name="image">
                                <span class="text-danger mr-2" id="image_error"></span>
                                <label class="custom-file-label" for="image">Choose file</label>
                            </div>
                            <img id="show-img" style="padding: 10px; width: 100px;" />
                        </div>
                        <div class="form-group mb-3">
                            <label class="text-muted" style="margin-right: 50px;">Publication Status</label>
                            <label class="ui-switch ui-switch-md info m-t-xs" style="top:5px;">
                                <input type="checkbox" id="checkbox"> <i></i>
                                <input type="hidden" name="brand_stat" id="brand_stat" value="0">
                            </label>
                        </div>
                        <div class="modal-footer">
                            <input type="hidden" name="brand_id" id="brand_id" />
                            <input type="hidden" name="image_update" id="image-update">
                            <button class="btn btn-outline-dark" data-dismiss="modal" onclick=" 
                        document.getElementById('show-img').removeAttribute('src'); this.form.reset()">Close</button>
                            <button class="btn btn-primary" id="addBtn">Save Changes</button>
                            <button class="btn btn-primary hide" id="editBtn">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
</div><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/brand/modal.blade.php ENDPATH**/ ?>