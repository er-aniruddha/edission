<script>
    $(document).ready(function () {
        //To get category id 
        $('#_categoriesDiv').on('change', 'input.custom-control-input', function () {
            $('input.custom-control-input').not(this).prop('checked', false);
            $('#category_id').val($(this).val()); // put category id(foreign key of Product) into the form 
        });//category id end 

        $('#addNewCategoryForm').on('click', '#addCategoryBtn', function (e) {
            e.preventDefault();
            $('.loading').show()
            $('#_categoriesDiv').hide()
            if (!$('#category_name').val()) {
                var message = "The category name field is required.";
               // warning(message);                
                let snackbar  = new SnackBar;
                    snackbar.make("message",
                    [
                        message,
                        null,
                        "bottom",
                        "center"
                    ], 4000);
                    $('.loading').hide()
                    $('#_categoriesDiv').show()
                
            }
            else {
                var formData = new FormData($('#addNewCategoryForm')[0]);
                $.ajax({
                    method: 'POST',
                    url: "<?php echo e(route('category.create')); ?>",
                    contentType: false,
                    cache: false,
                    processData: false,
                    dataType: "json",
                    data: formData,
                    success: function (response) {
                        if (response.errors) {
                            let message = response.errors.category_name[0];
                            warning(message);
                            $('.loading').hide()
                            $('#_categoriesDiv').show()
                        }//if end
                        else {
                            let message = response.success;
                            success(message);
                            $('.loading').hide()
                            $('#_categoriesDiv').show()
                            $("#_categoriesDiv").load(window.location + " #_categoriesDiv");
                        }// else end
                    },//success end
                    error: function (error) {
                        $('.loading').hide()
                        $('#_categoriesDiv').show()
                        if (error.status == 500) {
                            let message = "Something went wrong !!"
                            danger(message)
                        }
                    }//ajax error end
                });//ajax end 
            }
        });//Add Category form end



        $('#productSaved').click(function () {            
            $('#product_stat').val(0); //create product as draft 
            var proDesc = tinyMCE.get('product_desc').getContent(); //get product description from tinyMCE editor
            $('#product_desc').val(proDesc)
            createProduct(proDesc);
        }); // Saved Product end here

        $('#productPublished').click(function () {
            $('#product_stat').val(1); //create product as published/active 
            var proDesc = tinyMCE.get('product_desc').getContent(); //get product description from tinyMCE editor
            $('#product_desc').val(proDesc)
            createProduct(proDesc);
        }); // Published Product end here

        function createProduct(data) {
            var catChkVal = $('#category_id').val();
            var image = $('#image').val();
            var proDesc = data;

            if (!$("#product_name").val() && !proDesc.replace(/\s/g, '').length && !catChkVal && !image) {
                let message = "The Product name and Description field are required.";
                warning(message);
            }
            else {
                if (!$("#product_name").val()) {
                    let message = "The Product name field is required.";
                    warning(message);
                }
                if (!proDesc.replace(/\s/g, '').length) {
                    let message = "The Product Description field is required.";
                    warning(message);
                }
                if (!image) {
                    let message = "The image field is required.";
                    warning(message);
                }
                if (!catChkVal) {
                    let message = "Please select Category.";
                    warning(message);
                }
            }//validation end here

            if ($("#product_name").val() && proDesc.replace(/\s/g, '').length && catChkVal && image) {
                var formData = new FormData($('#addNewProductForm')[0]);
                $.ajax({
                    method: 'POST',
                    url: "<?php echo e(route('product.create')); ?>",
                    contentType: false,
                    cache: false,
                    processData: false,
                    dataType: "json",
                    data: formData,
                    success: function (response) {
                        if (response.errors) {
                            if (response.errors.product_name) {
                                let message = response.errors.product_name[0];
                                warning(message);
                            }
                            if (response.errors.product_desc) {
                                let message = response.errors.product_desc[0];
                                warning(message);
                            }
                            if (response.errors.image) {
                                let message = response.errors.image[0];
                                warning(message);
                            }
                            if (response.errors.category_id) {
                                let message = response.errors.category_id[0];
                                warning(message);
                            }
                        }
                        else {
                            let message = response.success;
                            success(message);
                            $("#addNewProductForm")[0].reset();   
                            $('#show-img').removeAttr('src'); 
                            $("#category_id").val("");
                            $("#_categoriesDiv").load(window.location + " #_categoriesDiv");
                        }// else end
                    },//ajax success end
                    error: function (error) {
                        if (error.status == 500) {
                            let message = "Something went wrong !!"
                            danger(message)
                        }
                    }//ajax error end
                });//ajax end 
            }//validation if condition end here        

        } //create product end here

        /*
            Category Delete Start
        */
        $(document).on('click','#_delCat', function(event){
            event.preventDefault()
            $('.loading').show()
            $('#_categoriesDiv').hide()
            let url = $(this).data('url')
            $.ajax({
                method:'GET',
                url:url,
                dataType:'json',
                success:function(response){
                    if(response.success){
                        let message = response.success;
                        warning(message)
                        $('.loading').hide()
                        $('#_categoriesDiv').show()
                         $("#_categoriesDiv").load(window.location + " #_categoriesDiv");
                    }
                },//ajax success end
                error:function(error){
                    $('.loading').hide()
                    $('#_categoriesDiv').show()
                    $("#_categoriesDiv").load(window.location + " #_categoriesDiv");
                    if (error.status == 500) {
                        let message = "Something went wrong !!"
                        danger(message)
                    }
                }//ajax error end
            })//ajax end
        })//remove category end here

    });


</script><?php /**PATH C:\xampp\htdocs\contact\resources\views/portal/product/JsProCreate.blade.php ENDPATH**/ ?>