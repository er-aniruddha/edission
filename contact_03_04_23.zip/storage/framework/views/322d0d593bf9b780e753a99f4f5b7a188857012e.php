<div id="content" class="flex">
    <div class="">
        <div class="page-hero page-container" id="page-hero">
            <div class="padding d-flex">
                <div class="page-title">
                    <h2 class="text-md text-highlight">Setting</h2>
                    <small class="text-muted">Configure thethings</small>
                </div>
                <div class="flex"></div>
            </div>
        </div>
        <div class="page-content page-container" id="page-content">
            <div class="padding">
                <div id="accordion">
                    <p class="text-muted"><strong>Account</strong></p>
                    <div class="card">
                        <div class="d-flex align-items-center px-4 py-3 b-t pointer" data-toggle="collapse"
                            data-parent="#accordion" data-target="#c_1">
                            <div>
                                <span class="w-32 avatar gd-primary _userImg" data-toggle-class="loading">
                                    <img src="<?php echo e(asset(Auth::User()->user_img)); ?>" alt=".">
                                </span>
                            </div>
                            <div class="mx-3 d-none d-md-block" >
                                <div id="_proInfo">
                                    <strong><?php echo e(Auth::User()->f_name); ?> <?php echo e(Auth::User()->s_name); ?></strong>
                                    <div class="text-sm text-muted"><?php echo e(Auth::User()->email); ?></div>
                                </div>
                            </div>
                            <div class="flex"></div>
                            <div>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="feather feather-chevron-right">
                                    <polyline points="9 18 15 12 9 6"></polyline>
                                </svg>
                            </div>
                        </div>
                        <div class="collapse p-4" id="c_1">
                            <!-- User Profile Form Start -->
                            <form role="form" id="profileUpdate" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Profile picture</label>
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="image" name="image">
                                        <label class="custom-file-label" for="customFile">
                                            Choose file
                                        </label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>First Name</label>
                                    <input type="text" class="form-control" name="f_name" id="f_name" value="<?php echo e($user->f_name); ?>">
                                </div>
                                <div class="form-group">
                                    <label>Surname</label>
                                    <input type="text" class="form-control" name="s_name" id="s_name" value="<?php echo e($user->s_name); ?>">
                                </div>
                                <button type="button" class="btn btn-primary mt-2 updateBtn">Update</button>
                            </form>
                            <!-- User Profile Form End -->
                        </div>
                        <div class="d-flex align-items-center px-4 py-3 b-t pointer" data-toggle="collapse"
                            data-parent="#accordion" data-target="#c_2"><svg xmlns="http://www.w3.org/2000/svg"
                                width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                class="feather feather-lock">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                            </svg>
                            <div class="px-3">
                                <div>Password</div>
                            </div>
                            <div class="flex"></div>
                            <div><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="feather feather-chevron-right">
                                    <polyline points="9 18 15 12 9 6"></polyline>
                                </svg></div>
                        </div>
                        <div class="collapse p-4" id="c_2">
                            <!-- User Password Form Start -->
                            <form role="form" id="passChngForm" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Old Password</label>
                                    <input type="password" class="form-control" name="old_password" placeholder="********">
                                </div>
                                <div class="form-group">
                                    <label>New Password</label>
                                    <input type="password" class="form-control" name="new_password" placeholder="********">
                                </div>
                                <div class="form-group">
                                    <label>New Password Again</label>
                                    <input type="password" class="form-control" name="new_password_confirmation" placeholder="********">
                                </div>
                                <button type="button" class="btn btn-primary mt-2" id="chngPassBtn">Update</button>
                            </form>
                            <!-- User Password Form End -->
                        </div>
                        <div class="d-flex align-items-center px-4 py-3 b-t pointer" data-toggle="collapse"
                            data-parent="#accordion" data-target="#c_4"><svg xmlns="http://www.w3.org/2000/svg"
                                width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                class="feather feather-map-pin">
                                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                <circle cx="12" cy="10" r="3"></circle>
                            </svg>
                            <div class="px-3">
                                <div>Addresses and more</div>
                            </div>
                            <div class="flex"></div>
                            <div><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="feather feather-chevron-right">
                                    <polyline points="9 18 15 12 9 6"></polyline>
                                </svg></div>
                        </div>
                        <div class="collapse p-4" id="c_4">
                            <form role="form">
                                <div class="form-group"><label>URL</label><input type="text" class="form-control"></div>
                                <div class="form-group"><label>Company</label><input type="text" class="form-control">
                                </div>
                                <div class="form-group"><label>Location</label><input type="text" class="form-control">
                                </div><button type="submit" class="btn btn-primary mt-2">Update</button>
                            </form>
                        </div>
                    </div>
                    <p class="text-muted"><strong>Notifications</strong></p>
                    <div class="card">
                        <div class="d-flex align-items-center px-4 py-3">
                            <div>Anyone seeing my profile page</div>
                            <div class="flex"></div><span><label class="ui-switch ui-switch-md"><input type="checkbox">
                                    <i></i></label></span>
                        </div>
                        <div class="d-flex align-items-center px-4 py-3 b-t">
                            <div>Anyone follow me</div>
                            <div class="flex"></div><span><label class="ui-switch ui-switch-md"><input type="checkbox"
                                        checked="checked"> <i></i></label></span>
                        </div>
                        <div class="d-flex align-items-center px-4 py-3 b-t">
                            <div>Anyone send me a message</div>
                            <div class="flex"></div><span><label class="ui-switch ui-switch-md"><input type="checkbox"
                                        checked="checked"> <i></i></label></span>
                        </div>
                        <div class="d-flex align-items-center px-4 py-3 b-t">
                            <div>Anyone invite me to group</div>
                            <div class="flex"></div><span><label class="ui-switch ui-switch-md"><input type="checkbox">
                                    <i></i></label></span>
                        </div>
                        <div class="d-flex align-items-center px-4 py-3 b-t">
                            <div>Update</div>
                            <div class="flex"></div><span><label class="ui-switch ui-switch-md"><input type="checkbox"
                                        checked="checked"> <i></i></label></span>
                        </div>
                    </div>
                    <p class="text-muted"><strong>Emails</strong></p>
                    <div class="card">
                        <div class="d-flex align-items-center px-4 py-3">
                            <div>Anyone posts a comment on my post</div>
                            <div class="flex"></div><span><label class="ui-switch ui-switch-md"><input type="checkbox">
                                    <i></i></label></span>
                        </div>
                        <div class="d-flex align-items-center px-4 py-3 b-t">
                            <div>Anyone follow me</div>
                            <div class="flex"></div><span><label class="ui-switch ui-switch-md"><input type="checkbox"
                                        checked="checked"> <i></i></label></span>
                        </div>
                        <div class="d-flex align-items-center px-4 py-3 b-t">
                            <div>Anyone repost</div>
                            <div class="flex"></div><span><label class="ui-switch ui-switch-md"><input type="checkbox">
                                    <i></i></label></span>
                        </div>
                    </div>
                    <p class="text-muted"><strong>Security</strong></p>
                    <div class="card">
                        <div class="d-flex align-items-center px-4 py-3 b-t pointer" data-toggle="collapse"
                            data-parent="#accordion" data-target="#c_5">
                            <div>Delete account?</div>
                            <div class="flex"></div>
                            <div><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="feather feather-chevron-right">
                                    <polyline points="9 18 15 12 9 6"></polyline>
                                </svg></div>
                        </div>
                        <div class="collapse p-4" id="c_5">
                            <div class="py-3">
                                <p>Are you sure to delete your account?</p><button type="button"
                                    class="btn btn-white">No</button> <button type="button"
                                    class="btn btn-danger">Yes</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        /*To shoe choosen file name on input field*/
        $('#image').on('change',function(){
                //get the file name
                var fileName = $(this).val();
                //replace the "Choose a file" label
                $(this).next('.custom-file-label').html(fileName);
        }) //input field file name show function end

        /*Profile info update Form Start*/
        $("#profileUpdate").on('click','.updateBtn',function (event) {
            event.preventDefault()
            var postData = new FormData($("#profileUpdate")[0]);

            $.ajax({
                method:"POST",
                url: "<?php echo e(route('user.profile.update')); ?>",
                contentType: false,
                cache: false,
                processData: false,
                dataType: "json",
                data: postData,
                success:function (response) {
                    if(response.errors){
                        if(response.errors.f_name){
                        let message = response.errors.f_name[0];
                        warning(message)
                        }
                        if(response.errors.s_name){
                            let message = response.errors.s_name[0];
                            warning(message)
                        }
                        if(response.errors.image){
                            let message = response.errors.image[0];
                            warning(message)
                        }
                    }
                    if(response.success){
                        let message = response.success;
                        info(message)
                        localStorage.setItem('image',response.img_url)
                        $("#_proInfo").load(window.location + " #_proInfo");
                        $("._userImg").load(window.location + " ._userImg");
                        $("#navImg").load(window.location + " #navImg");
                        $(".custom-file-label").html("Choose file")
                        $("#c_1").collapse('toggle');
                    }
                },  
                error:function(error){
                    if (error.status == 500) {
                        let message = "Something went wrong !!"
                        danger(message)
                    }
                }//ajax error end here
            })//ajax end here
        })//profile info update function end here

        /*Password update here*/
        $("#passChngForm").on('click','#chngPassBtn',function(event){
            event.preventDefault()
            var postData = new FormData($("#passChngForm")[0])
            $.ajax({
                method:"POST",
                url:"<?php echo e(route('user.password.chnage')); ?>",
                contentType: false,
                cache: false,
                processData: false,
                dataType: "json",
                data: postData,
                success:function(response){
                    if(response.errors){
                       
                        if(response.errors.old_password){
                            let message = response.errors.old_password[0];
                            warning(message)
                        }
                        if(response.errors.new_password){
                            let message = response.errors.new_password[0];
                            warning(message)
                        }
                    }
                    if(response.error){
                            let message = response.error;
                            warning(message)
                        }
                    if(response.success){
                        let message = response.success;
                        info(message)     
                        $("#passChngForm")[0].reset();                     
                        $("#c_2").collapse('toggle');
                    }
                },  
                error:function(error){
                    if (error.status == 500) {
                        let message = "Something went wrong !!"
                        danger(message)
                    }
                }//ajax error end here
            })//aja end here
        })//chnage password function end here
    })
</script><?php /**PATH C:\xampp\htdocs\anwesh\portal\resources\views\portal\user\profile\userProfile.blade.php ENDPATH**/ ?>