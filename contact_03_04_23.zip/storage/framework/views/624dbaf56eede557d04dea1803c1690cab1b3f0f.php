<?php echo $__env->make('portal.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('portal.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="main" class="layout-column flex">

	<!-- Navbar Start -->
		<?php echo $__env->make('portal.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- Navbar End -->

	<!-- Content Start -->
		<?php echo $__env->yieldContent('content'); ?>
	<!-- Content Start -->

</div>
<?php echo $__env->make('portal.layouts.tinymce', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('portal.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('portal.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\anwesh\portal\resources\views\portal\layouts\main.blade.php ENDPATH**/ ?>