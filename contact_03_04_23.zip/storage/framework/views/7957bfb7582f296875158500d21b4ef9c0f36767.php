<?php $__env->startSection('page_title','Sale'); ?>
<div id="content" class="flex">
    <div class="">
        <div class="page-hero" id="page-hero">
            <div class="padding d-flex">
                <div class="page-title">
                    <h2 class="text-md text-highlight">All Sales</h2>
                    <!-- <small class="text-muted">Products</small> -->
                </div>
                <div class="flex"></div>
                <div>
                    <button class="btn btn-raised btn-wave blue text-white add" 
                    data-toggle="modal" data-target="#createAndEditModal">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                        Add Sale
                    </button>
                    <button class="btn btn-raised btn-wave btn-outline-primary" data-toggle="dropdown">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-download-cloud">
                        <polyline points="8 17 12 21 16 17"></polyline>
                        <line x1="12" y1="12" x2="12" y2="21"></line>
                        <path d="M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29"></path>
                    </svg>
                    Export
                </button>
                <div class="dropdown-menu" role="menu" x-placement="bottom-start">
                    <a class="dropdown-item export" id=".buttons-csv">
                        <i class="badge badge-circle text-primary"></i> CSV
                    </a>
                    <a class="dropdown-item export" id=".buttons-excel">
                        <i class="badge badge-circle text-primary"></i> EXCEL
                    </a>
                    <a class="dropdown-item export" id=".buttons-pdf">
                        <i class="badge badge-circle text-primary"></i> PDF
                    </a>
                    <a class="dropdown-item export" id=".buttons-print">
                        <i class="badge badge-circle text-primary"></i> Print
                    </a>
                </div>
                </div>                
            </div>
        </div>
        <div class="page-content" id="page-content">
            <div class="padding">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="sale_table">
                        <thead>
                            <tr>
                                <th style="width: 26px;"><span class="text-muted">#</span></th>                                
                                <th><span class="text-muted">Order Date</span></th>
                                <th><span class="text-muted">Delivery Date</span></th>
                                <th><span class="text-muted">Invoice No</span></th>
                                <th><span class="text-muted">Customer Name</span></th>
                                <th><span class="text-muted">Payment Type</span></th>
                                <th><span class="text-muted">Amount</span></th>
                                <th><span class="text-muted">Prev. Due</span></th>
                                <th><span class="text-muted">Paid/Received</span></th>
                                <th><span class="text-muted">Balance Due</span></th>
                                <th><span class="text-muted">Payment Status</span></th>
                                <th><span class="text-muted">Status</span></th>
                                <th style="width:50px"><span class="text-muted">Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('portal.sale_order.createAndEditModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('portal.sale_order.viewAndConvertModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('portal.layouts.deleteModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<script>
    // global app configuration object
    var routes = {
            index: "<?php echo e(route('sale.order.index')); ?>",
            create: "<?php echo e(route('sale.order.create')); ?>",
            update: "<?php echo e(route('sale.order.update')); ?>",
            convert: "<?php echo e(route('sale.order.convert')); ?>",
            delete: "<?php echo e(route('sale.order.delete')); ?>",
        };
var sales = <?php echo json_encode($sales, 15, 512) ?>;
var customers = <?php echo json_encode($customers, 15, 512) ?>;
var products = <?php echo json_encode($products, 15, 512) ?>;
// All the vaiables are required for end
</script>
<script type="text/javascript" src="<?php echo e(asset('resources/js/sale/sale-table.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('resources/js/sale/sale-order.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('resources/js/sale/view-convert.js')); ?>"></script>
<?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/sale_order/admin/index.blade.php ENDPATH**/ ?>