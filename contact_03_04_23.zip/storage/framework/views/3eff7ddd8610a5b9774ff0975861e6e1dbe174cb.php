<?php $__env->startSection('page_title','Payment-Out'); ?>
<!-- CONTENT START -->
<div id="content" class="flex">
    <div class="d-flex flex fixed-content">
        <div class="aside aside-sm" id="content-aside">
            <div class="d-flex flex-column w-xl modal-dialog bg-body" id="chat-nav">
                <div class="navbar">
                    <div class="input-group flex bg-light rounded">                        
                        <input type="text" class="form-control no-bg no-border no-shadow search" placeholder="Search" required="" id="searchProduct">
                        <span class="input-group-append">
                            <button class="btn no-bg no-shadow" type="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search text-fade">
                                    <circle cx="11" cy="11" r="8"></circle>
                                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                </svg>
                            </button>                            
                        </span>
                    </div>
                </div>
                <div class="scrollable hover">
                    <div class="sidenav p-2">
                        <nav class="nav-active-text-primary" >
                            <ul class="nav" id="supplierList">
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex flex pr-md-3" id="content-body">
            <div class="d-flex flex-column flex m-0 mb-md-3" id="chat-list">
                <div class="row" style="padding-top: 50px;">
                    <div class="col-md-11 m-0 p-0" >
                        <div class="md-3" style="float: right;">
                            <button class="btn btn-raised btn-wave mb-2 blue text-white"  id="paymentOut">Add Payment-Out</button>
                        </div>
                    </div>
                    <div class="col-md-1 m-0 pl-2">
                        <button class="btn btn-raised btn-wave mb-2 btn-outline-primary" data-toggle="dropdown">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-download-cloud">
                                <polyline points="8 17 12 21 16 17"></polyline>
                                <line x1="12" y1="12" x2="12" y2="21"></line>
                                <path d="M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29"></path>
                            </svg>
                            Export
                        </button>
                        <div class="dropdown-menu" role="menu" x-placement="bottom-start">
                            <a class="dropdown-item export" id=".buttons-csv">
                                <i class="badge badge-circle text-primary"></i> CSV
                            </a>
                            <a class="dropdown-item export" id=".buttons-excel">
                                <i class="badge badge-circle text-primary"></i> EXCEL
                            </a>
                            <a class="dropdown-item export" id=".buttons-pdf">
                                <i class="badge badge-circle text-primary"></i> PDF
                            </a>
                            <a class="dropdown-item export" id=".buttons-print">
                                <i class="badge badge-circle text-primary"></i> Print
                            </a>
                        </div>      
                    </div>
                    
                                  
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="payments_table">
                        <thead>
                            <tr>
                                <th style="width: 26px;"><span class="text-muted">#</span></th>
                                <th><span class="text-muted">Date</span></th>
                                <th><span class="text-muted">Payment Id</span></th>
                                <th><span class="text-muted">Supplier Name</span></th>
                                <th><span class="text-muted">Payment Type</span></th>
                                <th><span class="text-muted">Prev. Due</span></th>
                                <th><span class="text-muted">Received/Paid</span></th>
                                <th><span class="text-muted">Balance</span></th>
                                <th><span class="text-muted">Remarks</span></th>
                                <th style="width:50px"></th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- CONTENT END -->
<?php echo $__env->make('portal.purchase_payment_out.paymentModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('portal.layouts.deleteModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<script>
// global app configuration object
var routes = {
    index: "<?php echo e(route('payment.out.index')); ?>",
    create: "<?php echo e(route('payment.out.create')); ?>",
    update: "<?php echo e(route('payment.out.update')); ?>",
    delete: "<?php echo e(route('payment.out.delete')); ?>",
};
var suppliers = <?php echo json_encode($suppliers, 15, 512) ?>;
// All the vaiables are required for end
</script>
<script type="text/javascript" src="<?php echo e(asset('resources/js/purchase/payment-out.js')); ?>"></script><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/purchase_payment_out/admin/index.blade.php ENDPATH**/ ?>