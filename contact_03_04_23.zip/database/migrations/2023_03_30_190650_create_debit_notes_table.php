<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDebitNotesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('debit_notes', function (Blueprint $table) {
            $table->id("dr_note_id");
            $table->date("dr_order_date");
            $table->date("dr_delivery_date");
            $table->integer("dr_trnx_id");
            $table->integer("supplier_id");
            $table->integer("item_name");
            $table->integer("unit_id");
            $table->integer("dr_qty");
            $table->integer("dr_primary_qty");
            $table->integer("dr_secondary_qty");
            $table->float("dr_unit_price",'255','2');
            $table->float("dr_primary_pp",'255','2');
            $table->float("dr_secondary_pp",'255','2');
            $table->float("dr_amount",'255','2');
            $table->integer("dr_payment_type");
            $table->float("dr_delivery_charges",'255','2');
            $table->float("dr_round_off");
            $table->float("dr_gst_amount",'255','2');
            $table->float("dr_total",'255','2');
            $table->float("dr_prev_balance",'255','2');
            $table->float("dr_advance",'255','2');
            $table->float("dr_balance",'255','2');
            $table->string("dr_remarks");
            $table->integer("dr_payment_status");
            $table->integer("dr_status");       
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('debit_notes');
    }
}
