<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLoanTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('loan_transactions', function (Blueprint $table) {
            $table->id();
            $table->string("loan_trnx_id");
            $table->string("loan_ac_id");
            $table->date("bill_date");
            $table->date("payment_date");
            $table->float("prev_loan_balance"); // previous amount
            $table->float("interest_of_emi");
            $table->float("principal_of_emi");
            $table->float("total_emi");
            $table->float("paid_amount")->default(0);
            $table->float("interest_paid")->default(0);
            $table->float("principal_paid")->default(0);
            $table->float("loan_balance")->default(0);
            $table->date("paid_date")->default(null);
            $table->integer("status")->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('loan_transactions');
    }
}
