<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStocksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('stocks', function (Blueprint $table) {
            $table->id('stock_id');
            $table->integer('product_id');
            $table->string('maker_name');
            $table->date('date');
            $table->string('sku_code');
            $table->integer('cost_id');
            $table->string('order_qty')->default(0);
            $table->string('delivered_qty')->default(0);
            $table->string('in_hand_stock')->default(0);// In-Hand-Qty = In-hand-Qty - Order Qty 
            $table->integer('sku_count');
            $table->integer('stock_stat')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('stocks');
    }
}
