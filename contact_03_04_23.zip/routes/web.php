<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\web\BrandController;
use App\Http\Controllers\web\ProductController;
use App\Http\Controllers\web\SaleController;
use App\Http\Controllers\web\SaleOrderController;
use App\Http\Controllers\web\CreditNoteController;
use App\Http\Controllers\web\PaymentIncontroller;
use App\Http\Controllers\web\UserAccessController;
use App\Http\Controllers\web\CustomerController;
use App\Http\Controllers\web\CustomerRouteController;
use App\Http\Controllers\web\CalenderController;
use App\Http\Controllers\web\ExpenseController;
use App\Http\Controllers\web\BankController;
use App\Http\Controllers\web\BankTransactionController;
use App\Http\Controllers\web\LoanController;
use App\Http\Controllers\web\LoanTransactionController;
use App\Http\Controllers\web\UnitController;
use App\Http\Controllers\web\PurchaseController;
use App\Http\Controllers\web\PurchaseOrderController;
use App\Http\Controllers\web\DebitNoteController;
use App\Http\Controllers\web\PaymentOutController;
use App\Http\Controllers\web\SupplierController;
use App\Http\Controllers\web\StockController;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group whic
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect()->route('dashboard');
});
Route::group(['middleware' => 'prevent-back-history'],function(){
    Auth::routes(['verify' => true]);
    Route::get('/dashboard', [HomeController::class, 'index'])->middleware('verified')->name('dashboard');
});
//Error page or Page not found
Route::get('/error',[HomeController::class, 'error'])->name('error');
Route::get('/coming-soon',[HomeController::class, 'commingSoon'])->name('coming.soon');

//Brands Routes are here
Route::get('/brands', [BrandController::class, 'index'])->name('brand.index');
Route::post('/brand/create', [BrandController::class, 'create'])->name('brand.create');
Route::post('/brand/update', [BrandController::class, 'update'])->name('brand.update');
Route::post('/brand/delete', [BrandController::class, 'destroy'])->name('brand.delete');
Route::get('/brand/status/{brand_id}', [BrandController::class, 'status'])->name('brand.status');

//Products Routes are here
Route::get('/products', [ProductController::class, 'index'])->name('product.index');
Route::post('/product/create', [ProductController::class, 'create'])->name('product.create');
Route::post('/product/update', [ProductController::class, 'update'])->name('product.update');
Route::post('/product/delete', [ProductController::class, 'destroy'])->name('product.delete');
Route::get('/product/status/{product_id}', [ProductController::class, 'status'])->name('product.status');

//Sales Routes are here
Route::get('/sale/all', [SaleController::class, 'index'])->name('sale.index');
Route::get('/sale/date/range', [SaleController::class, 'dateRange'])->name('sale.date.range');

//Sale Order route here
Route::get('/sale/order', [SaleOrderController::class, 'index'])->name('sale.order.index');
Route::post('/sale/order/create', [SaleOrderController::class, 'create'])->name('sale.order.create');
Route::post('/sale/order/update', [SaleOrderController::class, 'update'])->name('sale.order.update');
Route::post('/sale/order/convert', [SaleOrderController::class, 'convert'])->name('sale.order.convert');
Route::post('/sale/order/delete', [SaleOrderController::class, 'destroy'])->name('sale.order.delete');
Route::get('/sale/order/date/range', [SaleOrderController::class, 'dateRange'])->name('sale.order.date.range');

//Credit Note route here
Route::get('/credit/note', [CreditNoteController::class, 'index'])->name('credit.note.index');
Route::post('/credit/note/create', [CreditNoteController::class, 'create'])->name('credit.note.create');
Route::post('/credit/note/update', [CreditNoteController::class, 'update'])->name('credit.note.update');
Route::post('/credit/note/convert', [CreditNoteController::class, 'convert'])->name('credit.note.convert');
Route::post('/credit/note/delete', [CreditNoteController::class, 'destroy'])->name('credit.note.delete');

// Payment-In Controller
Route::get('/payment-in',[PaymentIncontroller::class, 'index'])->name('payment.in.index');
Route::post('/payment-in/create',[PaymentInController::class, 'create'])->name('payment.in.create');
Route::post('/payment-in/update',[PaymentInController::class, 'update'])->name('payment.in.update');
Route::post('/payment-in/delete',[PaymentInController::class, 'destroy'])->name('payment.in.delete');

//All Purchase Routes are here
Route::get('/purchase/all', [PurchaseController::class, 'index'])->name('purchase.index');
Route::get('/purchase/date/range', [PurchaseController::class, 'dateRange'])->name('purchase.date.range');

//Purchase Order Routes are here
Route::get('/purchase/order', [PurchaseOrderController::class, 'index'])->name('purchase.order.index');
Route::post('/purchase/create', [PurchaseOrderController::class, 'create'])->name('purchase.order.create');
Route::post('/purchase/update', [PurchaseOrderController::class, 'update'])->name('purchase.order.update');
Route::post('/purchase/delete', [PurchaseOrderController::class, 'destroy'])->name('purchase.order.delete');
Route::post('/purchase/status', [PurchaseOrderController::class, 'status'])->name('purchase.order.status');
Route::get('/purchase/order/date/range', [PurchaseOrderController::class, 'dateRange'])->name('purchase.order.date.range');

// Purchase return or Debit Note
Route::get('debit/note',[DebitNoteController::class, 'index'])->name('debit.note.index');
Route::post('debit/note/create',[DebitNoteController::class, 'create'])->name('debit.note.create');
Route::post('debit/note/update',[DebitNoteController::class, 'update'])->name('debit.note.update');
Route::post('debit/note/delete',[DebitNoteController::class, 'destroy'])->name('debit.note.delete');
Route::post('debit/note/status',[DebitNoteController::class, 'status'])->name('debit.note.status');

// Payment-Out Controller
Route::get('/payment-out',[PaymentOutcontroller::class, 'index'])->name('payment.out.index');
Route::post('/payment-out/create',[PaymentOutController::class, 'create'])->name('payment.out.create');
Route::post('/payment-out/update',[PaymentOutController::class, 'update'])->name('payment.out.update');
Route::post('/payment-out/delete',[PaymentOutController::class, 'destroy'])->name('payment.out.delete');

//Supplier Routes are here
Route::get('/supplier', [SupplierController::class, 'index'])->name('supplier.index');
Route::post('/supplier/create', [SupplierController::class, 'create'])->name('supplier.create');
Route::post('/supplier/update', [SupplierController::class, 'update'])->name('supplier.update');
Route::post('/supplier/delete', [SupplierController::class, 'destroy'])->name('supplier.delete');
Route::get('/supplier/status/{supplier_id}', [SupplierController::class, 'status'])->name('supplier.status');

//Inventory Routes are here
Route::get('/stock',[StockController::class, 'index'])->name('stock.index');

//Expenses Route are here
Route::get('/expense',[ExpenseController::class, 'index'])->name('expense.index');
Route::post('/expense/create',[ExpenseController::class, 'create'])->name('expense.create');
Route::post('/expense/update',[ExpenseController::class, 'update'])->name('expense.update');
Route::post('/expense/delete',[ExpenseController::class, 'destroy'])->name('expense.delete');
Route::get('/expense/details',[ExpenseController::class, 'details'])->name('expense.details');
Route::get('/expense/date/range', [ExpenseController::class, 'dateRange'])->name('expense.date.range');

//Cash & Banks Route are here
Route::get('/bank',[BankController::class, 'index'])->name('bank.index');
Route::post('/bank/account/crate',[BankController::class, 'create'])->name('bank.account.create');
Route::post('/bank/account/update',[BankController::class, 'update'])->name('bank.account.update');

//Bank Transaction Route are here
Route::post('bank/translation/b2c',[BankTransactionController::class, 'b2cTransaction'])->name('bank.transaction.b2c');
Route::post('bank/translation/c2b',[BankTransactionController::class, 'c2bTransaction'])->name('bank.transaction.c2b');
Route::post('bank/translation/update',[BankTransactionController::class, 'update'])->name('bank.transaction.update');
Route::post('bank/translation/delete',[BankTransactionController::class, 'destroy'])->name('bank.transaction.delete');

//Loan Account Route are here
Route::get('/loan/accounts',[LoanController::class, 'index'])->name('loan.account.index');
Route::post('/loan/compute',[LoanController::class, 'compute'])->name('loan.compute');
Route::post('/loan/accounts/create',[LoanController::class, 'create'])->name('loan.account.create');
Route::post('/loan/accounts/edit',[LoanController::class, 'edit'])->name('loan.account.edit');
Route::post('/loan/accounts/close/loan/view',[LoanController::class, 'closeView'])->name('loan.account.close.view');
Route::post('/loan/accounts/close/loan/confirm',[LoanController::class, 'closeConfirm'])->name('loan.account.close.confirm');

//Loans Transaction Route are here
Route::post('/loan/transaction/paid/emi',[LoanTransactionController::class, 'paidEmi'])->name('loan.transaction.paidEmi');
Route::post('/loan/transaction/edit',[LoanTransactionController::class, 'edit'])->name('loan.transaction.edit');
Route::post('/loan/transaction/delete',[LoanTransactionController::class, 'destroy'])->name('loan.transaction.delete');

//User Access Routes are here
Route::get('/users' , [UserAccessController::class, 'index'])->name('user.index');
Route::get('/user/profile' , [UserAccessController::class, 'profile'])->name('user.profile');
Route::post('/user/profile/update' , [UserAccessController::class, 'profileUpdate'])->name('user.profile.update');
Route::post('/user/chnage/permission' , [UserAccessController::class, 'chnagePermission'])->name('user.permission.chnage');
Route::post('/user/chnage/password' , [UserAccessController::class, 'chnagePassword'])->name('user.password.chnage');
Route::post('/user/remove', [UserAccessController::class, 'remove'])->name('user.remove');

//Add Customer Routes are here
Route::get('/customer/all',[CustomerController::class, 'all'])->name('customer.all');
Route::match(['get','post'], '/add/customer',[CustomerController::class, 'create'])->name('customer.create');
Route::post('/add/update',[CustomerController::class, 'update'])->name('customer.update');
Route::get('/details/customer/{customer_id}',[CustomerController::class, 'details'])->name('customer.details');
Route::post('/details/customer/delete',[CustomerController::class, 'destroy'])->name('customer.delete');
		//Customer Routes 
Route::post('/customer/routes/add',[CustomerController::class, 'createRoutes'])->name('customer.route.create');
Route::post('/customer/routes/edit',[CustomerController::class, 'editRoutes'])->name('customer.route.update');
Route::post('/customer/routes/planing',[CustomerController::class, 'editRoutes'])->name('customer.route.planing');
Route::get('/customer/data_table/bill/{customer_id}', [CustomerController::class, 'data_table_bill'])->name('customer.data.table.bill');
Route::get('/customer/data_table/product/{customer_id}', [CustomerController::class, 'data_table_product'])->name('customer.data.table.product');
Route::get('/customer/payments/{customer_id}', [CustomerController::class, 'payments'])->name('customer.payments');
Route::get('/customer/calender',[CalenderController::class, 'index'])->name('calender.index');


//Settings Routes are here
Route::get('/settings', function(){
    return view('portal.settings.index');
})->middleware('auth')->name('settings.index');

//Unit Routes are here
Route::get('/unit' , [UnitController::class, 'index'])->name('unit.index');
Route::post('/create' , [UnitController::class, 'create'])->name('unit.create');
Route::post('/update' , [UnitController::class, 'update'])->name('unit.update');
Route::post('/delete' , [UnitController::class, 'destroy'])->name('unit.delete');

Route::get('/clear-cache', function() {
    $exitCode = Artisan::call('config:cache');
    // return what you want
    Artisan::call('key:generate');
    dd($exitCode);
});
