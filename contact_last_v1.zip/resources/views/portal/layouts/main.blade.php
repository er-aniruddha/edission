@include('portal.layouts.header')
@include('portal.layouts.sidebar')
<div id="main" class="layout-column flex">

	<!-- Navbar Start -->
		@include('portal.layouts.navbar')
	<!-- Navbar End -->

	<!-- Content Start -->
		@yield('content')
	<!-- Content Start -->
	
	
</div>
@include('portal.layouts.notification')
@include('portal.layouts.footer')