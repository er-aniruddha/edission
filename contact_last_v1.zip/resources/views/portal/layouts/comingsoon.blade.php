@extends('portal.layouts.main')
@section('content')

<div class="text-center p-5 w-100" style="margin-top: 14%;">
    <h1 class="display-5 my-5 text-theme">Coming Soon.</h1>
    <p>Go back to <a href="{{url('/')}}" class="b-b b-white">Dashboard</a> 
        <!-- <a href="#" class="b-b b-white">contactus</a> about a problem.</p> -->
    <p class="my-5 text-muted h4">-- 404 --</p>
</div>

@endsection
 
