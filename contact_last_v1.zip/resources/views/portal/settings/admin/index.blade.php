@section('page_title','Settings')
<div id="content" class="flex">
    <!-- ############ Main START-->
    <div class="page-content page-container" id="page-content">
        <div class="padding">
            <div class="row row-sm sr">
                <div class="col-md-12 col-lg-12">
                    <div class="row row-sm">
                        <a href="{{ route('unit.index')}}" class="col-md-4 d-flex" style="width: 50%;">
                            <div class="card flex card-home">
                                <div class="card-body text-center">
                                    <div style="margin: 10px;">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="32px" height="32px" style="color:rgb(68, 139, 255);" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-database mx-2"><ellipse cx="12" cy="5" rx="9" ry="3"></ellipse><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path></svg>
                                    </div>
                                    <span class="text-dark mr-2">Unit</span>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ############ Main END-->
</div>