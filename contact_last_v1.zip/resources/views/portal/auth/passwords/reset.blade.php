@section('page_title','Verify')
@include('portal.layouts.header')

<div id="ajax-content" class="dark h-v d-flex flex align-items-center">
    <div class="mx-auto w-xl w-auto-xs animate fadeIn text-center">
       
    <div class="p-4 d-flex flex-column h-100">
            <!-- brand --> 
            <a href="{{url('/')}}" class="navbar-brand align-self-center">
                <img src="{{asset('public/portal/images/logo.png')}}" alt="..."> 
            </a>
            <!-- / brand -->
        </div>
        
        <form method="POST" action="{{ route('password.update') }}">
            @csrf
            <input type="hidden" name="token" value="{{ $token }}">
            <div class="md-form-group">
                <input type="email" class="md-input text-center @error('email') is-invalid @enderror" id="email"
                    name="email" value="{{ $email ?? old('email') }}" autocomplete="email" autofocus>
                <label class="d-block w-100">Enter Your email</label>

                @error('email')
                <p class="text-danger">{{ $message }}</p>
                @enderror
            </div>

            <div class="md-form-group">
                <input type="password" class="md-input text-center @error('password') is-invalid @enderror" id="password"
                    name="password" value="{{ $password ?? old('password') }}" autocomplete="password" autofocus>
                <label class="d-block w-100">Enter New Password</label>

                @error('password')
                <p class="text-danger">{{ $message }}</p>
                @enderror
            </div>

            <div class="md-form-group">
                <input type="password" class="md-input text-center @error('password') is-invalid @enderror" id="password-confirm"
                    name="password_confirmation" >
                <label class="d-block w-100">Confirm New Password</label>
            </div>

            <div class="mt-3">
                <button type="submit" class="btn btn-rounded btn-primary">Save Password</button>
            </div>
        </form>
    </div>
</div>
@include('portal.layouts.footer')