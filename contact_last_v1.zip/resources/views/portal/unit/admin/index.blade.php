@section('page_title','Unit')
<div id="content" class="flex">
    <div class="page-hero page-container" id="page-hero">
        <div class="padding d-flex">
            <div class="page-title">
                <h2 class="text-md text-highlight">All Units</h2>
                <!-- <small class="text-muted">Products</small> -->
            </div>
            <div class="flex"></div>
            <div>
                <button class="btn btn-raised btn-wave blue text-white add" data-toggle="modal" data-target="#modal">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                    Add
                </button>                
            </div>

                           
        </div>
    </div>

    <div class="page-content page-container" id="page-content">        
        <div class="padding">
            <!-- <div class="col-md-4">
                <div class="input-group input-daterange mb-3">
                    <input type="text" class="form-control date-range-filter" data-date-format="dd-mm-yyyy" id="min-date">
                    <div class="input-group-prepend">
                        <span class="input-group-text">to</span>
                    </div>
                    <input type="text" class="form-control date-range-filter" data-date-format="dd-mm-yyyy" id="max-date">
                </div>
            </div> -->
            <div class="table-responsive">
                <table id="unit_table" class="table table-theme table-row v-middle" >
                    <thead>
                        <tr>
                            <th>
                                <span class="text-muted">SL No</span>
                            </th>
                            <th>
                                <span class="text-muted">Unit Name</span>
                            </th>
                            <th>
                                <span class="text-muted">Unit Code</span>
                            </th>                            
                            <th style="width: 16%;"><span class="text-muted">Action</span></th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>
@include('portal.unit.modal')
</div>
@include('portal.layouts.deleteModal')
<script>
    // global app configuration object
    var routes = {
            index: "{{ route('unit.index') }}",
            create: "{{ route('unit.create') }}",
            update: "{{ route('unit.update') }}",
            delete: "{{ route('unit.delete') }}",
        };
        
</script>
<script type="text/javascript" src="{{asset('resources/js/unit.js')}}"></script>
