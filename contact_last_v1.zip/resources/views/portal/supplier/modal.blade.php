<div id="modal" class="modal fade"  aria-modal="true" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog text-dark">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white"></h5><button class="close" data-dismiss="modal">×</button>
            </div>
            <div class="modal-body">
                <form id="supplier-form" method="POST">  
                    @csrf                   
                    <div class="form-group row">
                        <label class="col-sm-3 text-muted">Supplier Name</label>
                        <div class="col-sm-9">
                            <input class="form-control" type="text" name="supplier_name" id="supplier_name" placeholder="Supplier Name">  
                            <span class="text-danger" id="supplier_name_error"></span>   
                        </div>      
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Address</label>
                        <div class="col-sm-9">
                            <input id="supplier_address" name="supplier_address" type="text" class="form-control" placeholder="Supplier Address">
                            <span class="text-danger" id="supplier_address_error"></span>
                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label class="text-muted" style="margin-right: 50px;">Status</label>
                        <label class="ui-switch ui-switch-md info m-t-xs" style="top:5px;">
                            <input type="checkbox" id="checkbox"> <i></i>
                            <input type="hidden" name="supplier_stat" id="supplier_stat" value="0">
                        </label>
                    </div>                    
                    <div class="modal-footer">
                        <input type="hidden" name="supplier_id" id="supplier_id"/>
                        <button class="btn gd-primary text-white btn-rounded" id="addBtn">Save</button>
                        <button class="btn gd-warning text-white btn-rounded hide" id="editBtn">Update</button>
                    </div>   
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
</div>