@section('page_title','Loan Accounts')
<!-- CONTENT START -->
<div id="content" class="flex">
    <div class="d-flex flex fixed-content">
        <div class="aside aside-sm" id="content-aside">
            <div class="d-flex flex-column w-xl modal-dialog bg-body" id="chat-nav">
                <div class="navbar">
                    <span class="text-md mx-2">Loan Accounts</span>
                    <div class="dropdown dropright">
                        <button class="btn btn-sm btn-raised btn-wave blue" id="addLoanAc" data-toggle="modal" data-target="#loanAccountModal">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-credit-card mx-2"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>
                            Add Loan AC
                        </button>
                    </div>
                </div>
                <div class="scrollable hover">
                    <div class="sidenav p-2">
                        <nav class="nav-active-text-primary" data-nav="">
                            <ul class="nav" id="loanAcList">
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex flex pr-md-3">
            <div class="d-flex flex-column flex mt-5 mb-md-3">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="loan_trnx_table">
                        <thead>
                            <tr>
                                <th><span class="text-muted">SL NO</span></th>
                                <th><span class="text-muted">A/c Name</span></th>
                                <th><span class="text-muted">Transction Id</span></th>
                                <th><span class="text-muted">Bill Date</span></th>
                                <th><span class="text-muted">Payment/Due Date</span></th>
                                <th><span class="text-muted">EMI</span></th>
                                <th><span class="text-muted">Paid Amount</span></th>
                                <th><span class="text-muted">Balance</span></th>
                                <th><span class="text-muted">Paid Date</span></th>
                                <th><span class="text-muted">Status</span></th>
                                <th><span class="text-muted">Action</span></th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- CONTENT END -->
</div>
@include('portal.loan.account_modal')
@include('portal.loan.paid_emi_modal')
<script>
// global app configuration object
var routes = {
    index: "{{ route('loan.account.index') }}",
    compute: "{{ route('loan.compute') }}",
    create: "{{ route('loan.account.create') }}",
    closeView: "{{ route('loan.account.close.view') }}",
    confimClose: "{{ route('loan.account.close.confirm') }}",
    edit: "{{ route('loan.account.edit') }}",
    paidEmi: "{{ route('loan.transaction.paidEmi') }}",
};
var loanaccounts = @json($loanaccounts)
// All the vaiables are required for end
</script>
<script type="text/javascript" src="{{asset('resources/js/loan/loan.js')}}"></script>
<script type="text/javascript" src="{{asset('resources/js/loan/loan_trnx.js')}}"></script>