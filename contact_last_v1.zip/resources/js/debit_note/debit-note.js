$(document).ready(function(){
	var debitNoteTable
	var prevBalance;
	var filterProducts={} , item = {}
  	// $.fn.modal.Constructor.prototype._enforceFocus = function() {};
  	/*------- input[type='number'] can't be null -------*/
	const numInputs = document.querySelectorAll('input[type=number]')
	  	numInputs.forEach(function(input) {
	      	input.addEventListener('change', function(e) {
	          	if (e.target.value == '') {
	              	e.target.value = 0
	              	totalCalculation()
	          	}
	      })
	})
	/*------- input[type='number'] can't be null -------*/
    load_table(startDate,endDate);
	/*------- Debit Note DataTable Start Here -------*/
  	function load_table(argument) {
  		debitNoteTable = $("#debit_note_table").DataTable({
		    processing: true,
		    serverSide: true,
		    lengthMenu: [
		        [10, 25, 50,100, -1],
		        [10, 25, 50,100, 'All'],
		    ],
		    buttons: [{ extend: 'csv', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
		        { extend: 'excel', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
		        { extend: 'pdf', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
		        { extend: 'print', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } }
		    ],
		    ajax: {
		        url: routes.index,
		        dataType: "json",
                data:{ startDate: startDate.format('YYYY-MM-DD'), endDate: endDate.format('YYYY-MM-DD')},
		    },
		    columns: [{
		        data: "DT_RowIndex",
		        name: "DT_RowIndex",
		        render: function(data) {
		            return '<small class="text-muted">' + data + '</small>'
		        }
		    }, {
		      	data: "dr_trnx_id",
		      	name: "dr_trnx_id",
		      	render: function(data) {
		        	return '<span class="item-amount d-none d-sm-block text-sm text-primary text-capitalize">DRN-' + data + '</span>'
		      	}
		  	},{
		        data: "dr_order_date",
		      	name: "dr_order_date",
		      	render: function(data, type, full, meta) {
		          	return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">' + moment(data).format('DD-MM-YYYY') + '</span>'
		      	}
		  	},{
		      	data: "dr_delivery_date",
		      	name: "dr_delivery_date",
		      	render: function(data, type, full, meta) {
			        if(!data){
			          	return '<span class="item-badge badge text-uppercase bg-warning">Not Deliverd</span>';     
			        } 
			        else{
			          	return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">' + moment(data).format('DD-MM-YYYY') + '</span>'
			        }               
		      	}     
		  	}, {
		        data: "supplier_name",
		      	name: "supplier_name",
		      	render: function(data, type, full, meta) {
		          	return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">' + data + '</span>'
		      	}
		  	},{
		      	data: "dr_payment_type",
		      	name: "dr_payment_type",
		      	render: function(data) {
			        if (data == 1) {
			          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Cash</span>'
			        }
			        if (data == 2) {
			          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Online</span>'
			        }
			        if (data == 3) {
			          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Cheque</span>'
			        }
			        if (data == 4) {
			          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-danger">No Payment</span>'
			        }
		      	}
		  	},{
		      	data: "dr_total",
		      	name: "dr_total",
		      	render: function(data) {
		        	return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) + '</span>'
		      	}
		  	},{
		      	data: "dr_prev_balance",
		      	name: "dr_prev_balance",
		      	render: function(data) {
		        	return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) + '</span>'
		      	}
		  	},{
		      	data: "dr_received",
		      	name: "dr_received",
		      	render: function(data) {
		        	return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) + '</span>'
		      	}
		  	},{
		      	data: "dr_balance",
		      	name: "dr_balance",
		      	render: function(data) {
		        	return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) + '</span>'
		      	}
		  	},{
		      	data: "dr_payment_status",
		      	name: "dr_payment_status",
		      	render: function(data) {
			        if (data == 0) {
			          	return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-danger">Unpaid</span>'
			        }
			        if (data == 1) {
			          	return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-warning">Partial</span>'
			        }
			        if (data == 2) {
			          	return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-success">Paid</span>'
			        }
		      	}
		  	},{
		    	data: "status",
		    	name: "status",
		  	},{
		    	data: "action",
		    	name: "action",
		  }],
		});
  	}
	/*------ Debit Note dataTable end here ------*/
	/*------ Export Start ------*/
	$(document).on('click', ".export", function() {
	    var btn = $(this).attr('id').toString()
	    debitNoteTable.button(btn).trigger();
	})
	/*------ Export End -------*/
	/*------ On Date Change Load Table Start -------*/
  	$(document).on('change','input[name="date_range"]',function(event){
        debitNoteTable.destroy();
        load_table(startDate,endDate);
    }) 
	/*------ On Date Change Load Table End -------*/

  	/*------ Supplier List Start -------*/ 
    function supplierList(){
        $("#supplier_id").empty().append('<option value="" selected="">Select Supplier</option>')
        for(let count=0; count<suppliers.length; count++){
            if(suppliers[count].supplier_stat == 1){
                $("#supplier_id").append('<option value="'+suppliers[count].supplier_id+'" data-balance="'+suppliers[count].balance+'">'+suppliers[count].supplier_name+'</option>')
            }
            else{
                $("#supplier_id").append('<option value="'+suppliers[count].supplier_id+'" data-balance="'+suppliers[count].balance+'">'+suppliers[count].supplier_name+'</option>')
            }
        }
    }
    supplierList()
    /*------ Supplier List Start -------*/ 
    
	/*------ Select supplier get balance start ------*/
	$(document).on('change', '#supplier_id', function(event) {
	    event.preventDefault()
	    prevBalance = $(this).find(':selected').data('balance')
	    let supplier_id = $(this).val()
	    $("#prev_balance").val(parseFloat(prevBalance)) //this is to store
	    $('.prev_bal').text("Previous balance: " + parseFloat(prevBalance).toFixed(2))
	    filterProducts = products.filter(elem => {
            return elem.supplier_id == supplier_id;
        })  
        $('#tdFormRow tbody').append().empty();
        item = {
	        item_name :'',
	        unit_id :'',
	        qty :'',
	        unit_price :'',
	        amount :''
	    }
        addRow(item)
        $('.addRow').show()
	    totalCalculation()
	})
	/*------ Select supplier get balance End ------*/

	/*------ Add Row into modal Start -------*/
    $('.addRow').on('click', function() {
    	item = {
	        item_name :'',
	        unit_id :'',
	        qty :'',
	        unit_price :'',
	        amount :''
	    }
        addRow(item)
    })
    var tdFormRowIndex = 0;

    function addRow(item) {
        var tr = '<tr class="addedRow row_' + tdFormRowIndex + '">' +
            '<td style="vertical-align: top;">' +
            '<select class="form-control text-capitalize select2 productList" name="item_name[' + tdFormRowIndex + ']" id="item_name'+tdFormRowIndex+'" value="'+item.item_name+'" tabindex="-1" aria-hidden="true">' +
            '</select>' +
            '<span class="text-danger item_name_error_' + tdFormRowIndex + '"></span> ' +
            '</td>' +
            '<td class="unit-td" style="vertical-align: top;">' +
            '<select class="form-control text-capitalize unitList" name="unit_id[' + tdFormRowIndex + ']" id="unit_id'+tdFormRowIndex+'" value="' + item.unit_id + '" tabindex="-1" aria-hidden="true">' +
            '</select>' +
            '<div class="text-danger unit_id_error_' + tdFormRowIndex + '"></div> ' +
            '</td>' +
            '<td class="td-qty" style="vertical-align: top;">' +
            '<input type="number" class="form-control qty" name="qty[' + tdFormRowIndex + ']" id="qty'+tdFormRowIndex+'" value="' + item.qty + '" placeholder="Quantity" oninput="this.value = Math.round(this.value);">' +
            '<span class="text-danger qty_error_' + tdFormRowIndex + '"></span> ' +
            '</td>' +
            '<td style="vertical-align: top;">' +
            '<input type="number" class="form-control unitPrice" name="unit_price[' + tdFormRowIndex + ']" id="unit_price'+tdFormRowIndex+'" value="' + item.unit_price + '" placeholder="Price">' +
            '<span class="text-danger unit_price_error_' + tdFormRowIndex + '"></span> ' +
            '<small class="text-muted prev-pp"></small>'+
            '</td>' +
            '<td style="vertical-align: top;">' +
            '<input type="number" class="form-control amount" name="amount[' + tdFormRowIndex + ']" id="amount'+tdFormRowIndex+'" value="' + item.amount + '" placeholder="Total" onchange="(function(el){el.value=parseFloat(el.value).toFixed(2);})(this)"readonly>' +
            '<span class="text-danger amount_error_' + tdFormRowIndex + '"></span> ' +
            '</td>' +
            '<td style="vertical-align: top;">' +
            '<a href="javascript:void(0)" class="btn btn-icon remove" style="border: 1px solid #f54394">' +
            '<svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="color: red;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
            '</a>' +
            '</td>' +
            '</tr>';        
        $('#tdFormRow tbody').append(tr);
        productsList()
        tdFormRowIndex++;
    }
    /*------ Add Row into modal End -------*/

    /*------ Show List of Product in modal Start -------*/
    function productsList() {
        $("#item_name" + tdFormRowIndex).empty().append('<option selected="" value="" data-primarypp="0.00" data-secondarypp="0.00">Select an option</option>');
        for (count = 0; count < filterProducts.length; count++) {
            $("#item_name" + tdFormRowIndex).append('<option value="' + filterProducts[count].product_id + '"' +
                'data-punitid="' + filterProducts[count].p_unit_id + '" data-punitname="' + filterProducts[count].p_unit_name + '" data-sunitid="' + filterProducts[count].s_unit_id + '"' +
                'data-sunitname="' + filterProducts[count].s_unit_name + '" data-noofpcs="' + filterProducts[count].no_of_pcs + '"' + 
                'data-primarypp="' + filterProducts[count].primary_pp + '" data-secondarypp="' + filterProducts[count].secondary_pp + '"' + 
                '>' + filterProducts[count].product_name + ' - '+filterProducts[count].brand_name+'</option>')
        }
        // $('#item_name' + tdFormRowIndex).off('productList:select');
        // $('#item_name' + tdFormRowIndex).select2({ width: "100%" }); //to initiatate select2  
        $('#item_name'+tdFormRowIndex).select2({ width: "100%" }).val(item.item_name).trigger("change");
    }
    /*------ Show List of Product in modal End -------*/

    /*------ On Product change set values in Unit Start -------*/
    $("#tdFormRow").on('change', 'select.productList', function() {
        $(this).parents('.addedRow').children('td:nth-child(4)').children('.prev-pp').text('PP: '+$(this).find(':selected').data('primarypp')+'/'+ $(this).find(':selected').data('secondarypp'))
        $(this).parents('.addedRow').children('.unit-td').children('.unitList').empty().append('<option selected="" value="">Select a product</option>');
        if($(this).val()){
        	$(this).parents('.addedRow').children('.unit-td').children('.unitList').append().empty()
        	$(this).parents('.addedRow').children('.unit-td').children('.unitList').empty().append('<option selected="" value="">Select an unit</option>');
        	$(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option class="text-capitalize p-pcs" value="' + $(this).find(':selected').data('punitid') + '">' + $(this).find(':selected').data('punitname') + '</option>')
	        $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option class="text-capitalize s-pcs" value="' + $(this).find(':selected').data('sunitid') + '">' + $(this).find(':selected').data('sunitname') + '</option>')
	        $(this).parents('.addedRow').children('.unit-td').children('.unitList').val(item.unit_id);
        }       
    })
    /*------ On Product change set values in Unit Start -------*/

    /*------ On Unit change get No_Pcs of product Start -------*/
    $("#tdFormRow").on('change', 'select.unitList', function() {
        $(this).parents('.addedRow').children('.td-qty').children('#qty').val('')
        totalCalculation()
    })
    /*------ On Unit change get No_Pcs of product End -------*/

    /*------ Remove row Start -------*/
    $(document).on('click', '.remove', function() {
        $(this).parent().parent().remove()
        totalCalculation()
    });
    /*------ Remove row End -------*/

    /*------ To prevent multi decimal input start -------*/
    $('#tdFormRow').on('keypress','.unitPrice',function(event) {                 
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /*------ To prevent multi decimal input edn -------*/

    /*------ Total calculation start -------*/
    var total = 0;
    $('tbody').delegate('.qty, .unitPrice', 'keyup', function() {
        var tr = $(this).parent().parent();
        var qty = tr.find('.qty').val();
        var unitPrice = tr.find('.unitPrice').val();
        var amount = qty * unitPrice;
        tr.find('.amount').val(parseFloat(amount).toFixed(2));
        totalCalculation()
    });

    $("#received").on('keyup', function() {        
        if ($("#received").val() != '') {
            totalCalculation()
        } else {
            $("#received").val(0)
        }
    })
    $("#round_off").on('keyup', function() {        
        if ($("#round_off").val() != '') {
            totalCalculation()
        }
    })
    $("#delivery_charges").on('keyup', function() {        
        if ($("#delivery_charges").val() != '') {
            totalCalculation()
        }
    })
    $("#gst_amount").on('keyup', function() {
        if ($("#gst_amount").val() != '') {
            totalCalculation()
        }
    })

    function totalCalculation() {
        var subTotal = 0;
        var received = $("#received").val()
        var roundOff = $("#round_off").val()
        var deliveryCharges = $("#delivery_charges").val()
        var gstAmount = $("#gst_amount").val()
        $('.amount').each(function(i, e) {
            var amount = $(this).val() - 0;
            subTotal += amount;
        });
        total = parseFloat(gstAmount) - parseFloat(subTotal);
        total = parseFloat(total) - parseFloat(roundOff);
        total = parseFloat(total) + parseFloat(deliveryCharges);
        var balance = parseFloat(total) + parseFloat(received);
        balance = parseFloat(balance) + parseFloat(prevBalance)
        $("#total").val(parseFloat(total).toFixed(2))
        $("#balance").val(parseFloat(balance).toFixed(2))
    } 
    /*------ Total calculation end -------*/

    /*------- Create dr. note Start -----*/
    $(document).on('click', 'button.add', function() {
        $(".addedRow").remove()
        tdFormRowIndex = 0;        
        $(".prev_bal").text('')
        $("#prev_balance").val(0)//this is to store
     	$('select').prop('disabled',false)
     	$('input').prop('disabled',false)
     	$('textarea').prop('disabled',false)
     	$('#supplier_id').prop('disabled',false)        
        $('.modal-title').text("Create Dr Note");
        $('#addBtn').show();
        $('#editBtn').hide();
        $('#convertBtn').hide();
        $("#debitNoteForm")[0].reset()
        $("#debitNoteForm .text-danger").html("")
        $('a.btn-icon').show()
        $('a.addRow').hide()
        $(".delivery-date").hide()
        $('#supplier_id').select2({
	        width: "100%",
	        dropdownParent: $('#modal')
	    });
    });

    $('#debitNoteForm').on('click', '#addBtn', function(event) {
        event.preventDefault();
        $("#debitNoteForm .text-danger").html("")
        $("#loader").show()
        var formData = new FormData($('#debitNoteForm')[0]);
        $.ajax({
            method: 'POST',
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                 $("#loader").hide()
                if (response.errors) {
                    if (response.errors.supplier_id) {
                        $("#supplier_id_error").text(response.errors.supplier_id[0])
                    }
                    if (response.errors.order_date) {
                        $("#order_date_error").text(response.errors.order_date[0])
                    }
                    if (response.errors.payment_type) {
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }
                    for (var i = 0; i < tdFormRowIndex + 1 || i < 1; i++) {
                        if (response.errors["item_name." + i]) {
                            $(".item_name_error_" + i).text(response.errors["item_name." + i][0])
                        }
                        if (response.errors["unit_id." + i]) {
                            $(".unit_id_error_" + i).text(response.errors["unit_id." + i][0])
                        }
                        if (response.errors["qty." + i]) {
                            $(".qty_error_" + i).text(response.errors["qty." + i][0])
                        }
                        if (response.errors["unit_price." + i]) {
                            $(".unit_price_error_" + i).text(response.errors["unit_price." + i][0])
                        }
                        if (response.errors["amount." + i]) {
                            $(".amount_error_" + i).text(response.errors["amount." + i][0])
                        }
                    }
                }
                //on success
                if(response.success) {
                    $('#debit_note_table').DataTable().ajax.reload();
                    $("#modal").modal('hide')
                    $("#debitNoteForm")[0].reset()
                    $('input.md-input').attr('value' , '')
                    $(".prev_bal").text('')
                    allDrNotes = response.allDrNotes
                    suppliers = response.suppliers
                    supplierList()
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                 $("#loader").hide()
                snacbar(error.statusText)
            }
        }) //ajax end here
    })
    /*------- Create Dr. Note End -------*/
    var inputStat
    /*------- Show Dr. Note Start -------*/    
	$(document).on('click', 'a.view', function() {
	    let trnxId = $(this).data('trnxid');
	    let status = $(this).data('status')
	    if(status == 1){
	    	$('.delivery-date').show()
	    }
	    else{
	    	$('.delivery-date').hide()
	    }
	    $("#dr_trnx_id").val(trnxId)	    
        inputStat = true
        $('.modal-title').text("Dr Note Details : #DRN-"+trnxId);
        $('#addBtn').hide();
        $('#editBtn').hide();
        $('#convertBtn').hide();        
        $("input[type='text']").addClass("text-capitalize")
        $("#debitNoteForm .text-danger").html("")        
	    let thisTrnxDetails = {}	 
	    thisTrnxDetails = allDrNotes.filter(elem => {
            return elem.dr_trnx_id == trnxId;
        })
	    showData(thisTrnxDetails)  
	    $('a.btn-icon').hide()
        $('a.addRow').hide()
	});
	/*------- Show Dr. Note End -------*/
	/*------- Edit Dr. Note Start -------*/
	$(document).on('click', 'a.edit', function() {
	    let trnxId = $(this).data('trnxid');
	    $('.delivery-date').hide()
	    $("#dr_trnx_id").val(trnxId)
	  	inputStat = false
        $('.modal-title').text("Edit Dr Note : #DRN-"+trnxId);        
        $("input[type='text']").addClass("text-capitalize")
        $("#debitNoteForm .text-danger").html("")
        $('#addBtn').hide();
        $('#editBtn').show();
        $('#convertBtn').hide();        
	    let thisTrnxDetails = {}
	 
	    thisTrnxDetails = allDrNotes.filter(elem => {
            return elem.dr_trnx_id == trnxId;
        })
	    showData(thisTrnxDetails)  
	    $('a.btn-icon').show()
        $('a.addRow').show()
	});
	/*------- Edit Dr. Note end -------*/	
	/*------- Update Dr. Note Start -------*/
    $('#debitNoteForm').on('click', '#editBtn', function(event) {
        event.preventDefault();
        $("#debitNoteForm .text-danger").html("")
        $('#supplier_id').prop('disabled',false)
        $("#loader").show()
        var formData = new FormData($('#debitNoteForm')[0]);
        $.ajax({
            method: 'POST',
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
            	$('#supplier_id').prop('disabled',true)
                $("#loader").hide()
                if (response.errors) {
                    if (response.errors.supplier_id) {
                        $("#supplier_id_error").text(response.errors.supplier_id[0])
                    }
                    if (response.errors.order_date) {
                        $("#order_date_error").text(response.errors.order_date[0])
                    }
                    if (response.errors.payment_type) {
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }
                    for (var i = 0; i < tdFormRowIndex + 1 || i < 1; i++) {
                        if (response.errors["item_name." + i]) {
                            $(".item_name_error_" + i).text(response.errors["item_name." + i][0])
                        }
                        if (response.errors["unit_id." + i]) {
                            $(".unit_id_error_" + i).text(response.errors["unit_id." + i][0])
                        }
                        if (response.errors["qty." + i]) {
                            $(".qty_error_" + i).text(response.errors["qty." + i][0])
                        }
                        if (response.errors["unit_price." + i]) {
                            $(".unit_price_error_" + i).text(response.errors["unit_price." + i][0])
                        }
                        if (response.errors["amount." + i]) {
                            $(".amount_error_" + i).text(response.errors["amount." + i][0])
                        }
                    }
                }
                //on success
                if(response.success) {
                    $('#debit_note_table').DataTable().ajax.reload();
                    $("#supplier_id").load(window.location +" #supplier_id")
                    $("#modal").modal('hide')
                    $("#debitNoteForm")[0].reset()
                    $('input.md-input').attr('value' , '')
                    $(".prev_bal").text('')
                    allDrNotes = response.allDrNotes
                    suppliers = response.suppliers
                    supplierList()
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
            	$('#supplier_id').prop('disabled',true)
                 $("#loader").hide()
                snacbar(error.statusText)
            }
        }) //ajax end here
    })
    /*------- Update Dr. Note End -------*/

    /*------- Convert Dr. Note Start -------*/    
	$(document).on('click', 'a.over-due', function() {
	    let trnxId = $(this).data('trnxid');
	    $("#dr_trnx_id").val(trnxId)	    
        inputStat = true
        $('.modal-title').text("Convert Dr Note : #DRN-"+trnxId);
        $('#addBtn').hide();
        $('#editBtn').hide();
        $('#convertBtn').show();
        $(".delivery-date").show()         
        $("input[type='text']").addClass("text-capitalize")
        $("#debitNoteForm .text-danger").html("")        
	    let thisTrnxDetails = {}	 
	    thisTrnxDetails = allDrNotes.filter(elem => {
            return elem.dr_trnx_id == trnxId;
        })
	    showData(thisTrnxDetails)  
	    $('a.btn-icon').hide()
        $('a.addRow').hide()
	});
    $('#debitNoteForm').on('click', '#convertBtn', function(event) {
        event.preventDefault();
        $("input").prop('disabled',false) // this is for send dr_trnx_id
        $("#debitNoteForm .text-danger").html("")
        $("#loader").show()
        var formData = new FormData($('#debitNoteForm')[0]);
        $.ajax({
            method: 'POST',
            url: routes.status,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                $("#loader").hide()
                if (response.errors) {
                    if (response.errors.delivery_date) {
                        $("#delivery_date_error").text(response.errors.delivery_date[0])
                    } 
                }
                //on success
                if(response.success) {
                    $('#debit_note_table').DataTable().ajax.reload();
                    $("#modal").modal('hide')
                    $("#debitNoteForm")[0].reset()
                    $('input.md-input').attr('value' , '')
                    $(".prev_bal").text('')
                    allDrNotes = response.allDrNotes
                    suppliers = response.suppliers
                    supplierList()
                    products = response.products
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) { 
                $("#loader").hide()
                snacbar(error.statusText)
            }
        }) //ajax end here
    })
    /*------- Convert Dr. Note End -------*/

    /*------- Delete Dr. Note End -------*/
    $(document).on("click", "a.delete", function() {
        $("#id").val($(this).data("trnxid")) //have to use date regrad id 
        $(".modal-title").text("Dr. Note Transaction ID : #DRN-" + $(this).data("trnxid"))
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
            	$("#ok_button").text("YES")
                if (response.success) {
                    $("#debit_note_table").DataTable().ajax.reload()
                    $("#confirmModal").modal("hide");
                    $("#supplier_id").load(window.location +" #supplier_id")
                    allDrNotes = response.allDrNotes
                    suppliers = response.suppliers
                    supplierList()
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
            	$("#ok_button").text("YES")
                snacbar(error.statusText)
            }
        }) //ajax end
    }) //Purchase order Item Delete function end
    /*------- Delete Dr. Note End -------*/

    /*------- Show Dr. Note Details Start -------*/	
	function showData(thisTrnxDetails) {
    	tdFormRowIndex = 0;
    	$('#supplier_id').select2({ width: "100%" }).val(thisTrnxDetails[0].supplier_id).trigger("change");
    	$('#tdFormRow tbody').append().empty(); 
  		for(let count=0; count < thisTrnxDetails.length; count++){	 			
  			item = {
	            item_name :thisTrnxDetails[count].item_name,
	            unit_id :thisTrnxDetails[count].unit_id,
	            qty :thisTrnxDetails[count].dr_qty,
	            unit_price :thisTrnxDetails[count].dr_unit_price,
	            amount :thisTrnxDetails[count].dr_amount,
	        }
			addRow(item)
	        $("#order_date").val(moment(thisTrnxDetails[count].dr_order_date, 'YYYY-MM-DD').format("DD-MM-YYYY"))    
	        if(thisTrnxDetails[count].dr_delivery_date){
	        	$("#delivery_date").val(moment(thisTrnxDetails[count].dr_delivery_date, 'YYYY-MM-DD').format("DD-MM-YYYY")) 
	        }     	                   
	        $('#payment_type').val(thisTrnxDetails[count].dr_payment_type);
	        $("#round_off").val(thisTrnxDetails[count].dr_round_off)
	        $("#delivery_charges").val(thisTrnxDetails[count].dr_delivery_charges )
	        $("#gst_amount").val(thisTrnxDetails[count].dr_gst_amount)
	        $("#total").val(thisTrnxDetails[count].dr_total)
	        $("#received").val(thisTrnxDetails[count].dr_received)
	        prevBalance = thisTrnxDetails[count].dr_prev_balance
	        $(".prev_bal").text('Previous Balance: '+prevBalance)
	        $("#prev_balance").val(parseFloat(prevBalance))//this is to store
	        $("#balance").val(parseFloat(thisTrnxDetails[count].dr_balance))//this is to store
	        $("#remarks").val(thisTrnxDetails[count].dr_remarks)
  		}
  		$("#debitNoteForm select").prop('disabled', inputStat);
        $("#debitNoteForm input").prop('disabled',inputStat)
        $('#debitNoteForm textarea').prop('disabled',inputStat)
        if(inputStat == true){
            $('a.btn-icon').hide()
            $('a.addRow').hide()
        }
        else
        {
            $('a.btn-icon').show()
            $('a.addRow').show()
        }
        $('#supplier_id').prop('disabled',true)
        $('#delivery_date').prop('disabled',false)
	    $("#modal").modal('show')
	}
	/*------- Show Dr. Note Details End -------*/
	
})