$(document).ready(function(){
	/*------ Sales DataTable Start Here ------*/
	var salesTable

	load_table(startDate,endDate);

	function load_table(startDate, endDate) {
		salesTable= $("#sale_table").DataTable({
		    processing: true,
		    serverSide: true,
		    responsive: true,
		    autoWidth: true,
		    lengthMenu: [
	            [10, 25, 50,100, -1],
	            [10, 25, 50,100, 'All'],
	        ],
	     	// pageLength : 100,
		    buttons: [{ extend: 'csv', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7,8,9 ]}},
		        { extend: 'excel', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7,8,9 ]}},
		        { extend: 'pdf', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7,8,9 ]}},
		        { extend: 'print', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7,8,9 ]}}
		    ],
		    ajax: {
		        url: routes.index,
		        dataType: "json",
		        data:{ startDate: startDate.format('YYYY-MM-DD'), endDate: endDate.format('YYYY-MM-DD')},
		    },
		    columns: [{
			        data: "DT_RowIndex",
			        name: "DT_RowIndex",
			        render: function(data){
			            return '<small class="text-muted">'+data+'</small>'
			        }
			    }, {
			        data: "sale_order_date",
			        name: "sale_order_date",
			        render: function(data, type, full, meta) {
			            return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+moment(data).format('DD-MM-YYYY')+'</span>'
			        },      
			    }, {
			        data: "sale_delivery_date",
			        name: "sale_delivery_date",
			        render: function(data, type, full, meta) {
			            if(data){
			                return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+moment(data).format('DD-MM-YYYY')+'</span>'
			            }
			            if(!data){
			                return '<span class="item-badge badge text-uppercase bg-warning">Not Deliverd</span>';     
			            }
			        },      
			    }, {
			        data: "trnxid",
			        name: "trnxid",
			    },{
			        data: "name",
			        name: "name",
			    },{
			        data: "sale_payment_type",
			        name: "sale_payment_type",
			        render: function(data) {
				        if (data == 1) {
				          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Cash</span>'
				        }
				        if (data == 2) {
				          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Online</span>'
				        }
				        if (data == 3) {
				          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Cheque</span>'
				        }
				        if (data == 4) {
				          return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-danger">No Payment</span>'
				        }
				      }
			        
			    },{
			        data: "sale_total",
			        name: "sale_total",
			        render: function(data){
			            return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
			        }
			    },{
			        data: "sale_prev_balance",
			        name: "sale_prev_balance",
			        render: function(data){
			            return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
			        }
			    },{
			        data: "sale_received",
			        name: "sale_received",
			        render: function(data){
			            return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
			        }
			    }, {
			        data: "sale_balance",
			        name: "sale_balance",
			        render: function(data){
			            return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
			        }
			    },{
			        data: "sale_payment_status",
			        name: "sale_payment_status",
			        render: function(data){
			            if(data == 0){
			                return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-danger">Unpaid</span>'
			            }
			            if(data == 1){
			                return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-warning">Partial</span>'
			            }
			            if(data == 2){
			                return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-success">Paid</span>'
			            }
			        }
			    },{
			        data: "status",
			        name: "status",
			    },{
			        data: "action",
			        name: "action"
		    }],
		    "footerCallback":function(row, data){
		        var api = this.api(), data;
		        var intVal = function(i){
		          return typeof i === 'string' ?
		          i.replace(/[\$,]/g, '')*1 :
		          typeof i === 'number' ?
		          i:0;
		        };
		        
		        var column = 6;
		        while(column < 10){
		       total = api.column( column, {page: 'current'} )
		        .data().reduce( function (a,b){
		          return intVal(a) + intVal(b);
		        }, 0)
		        $(api.column(column).footer()).html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(total));
		            column++;
		        }
		    }
		});
	}
	/*------ Sale dataTable end here ------*/

	/*------ Export Start ------*/
	$(document).on('click',".export",function(){
	    var btn = $(this).attr('id').toString()
	    salesTable.button(btn).trigger();
	})
	/*------ Date change load sale table start -------*/  
	$(document).on('change','input[name="date_range"]',function(event){
		salesTable.destroy();
	    load_table(startDate,endDate);
	}) 
	/*------ Date change load sale table end -------*/  

})