$(document).ready(function() {
    var prevBalance,cType ;
    var filterProducts=[] , item = {}
    // $.fn.modal.Constructor.prototype._enforceFocus = function() {};

    /*------- input[type='number'] can't be null -------*/
    const numInputs = document.querySelectorAll('input[type=number]')
    numInputs.forEach(function(input) {
      input.addEventListener('change', function(e) {
        if (e.target.value == '') {
          e.target.value = 0
          totalCalculation()
        }
      })
    })
    /*------- input[type='number'] can't be null -------*/
    /*--------- Add customer list start -------*/
    function customerList(){
        $('#customer_id').empty().append('<option selected="" value="">Select customer</option>');               
        for(let i=0; i < customers.length; i++){
            $("#customer_id").append('<option value="'+customers[i].customer_id+'" data-balance="'+customers[i].balance+'" data-type="'+customers[i].customer_type+'" style="width: 100%;">'+customers[i].f_name+' '+customers[i].s_name+' ('+customers[i].phone_1+')'+' ('+customers[i].shop_name+')' +' (' +customers[i].locality +')'+'</option>')
        }
        $('#customer_id').select2({ width: "100%"}); //to initiatate select2             
    }     
    customerList()
    /*--------- Add customer list end -------*/
    $(document).on('change','#customer_id',function(event){ 
        event.preventDefault()
        prevBalance = $(this).find(':selected').data('balance')
        $("#prev_balance").val(parseFloat(prevBalance))//this is to store
        $('.prev_bal').text("Previous balance: "+prevBalance) 
        cType = $(this).find(':selected').data('type')        
        $('#tdFormRow tbody').append().empty();
        item = {
            item_name: '',
            unit_id: '',
            sale_qty: '',
            sale_unit_price: '',
            sale_discount_percentage: 0.00,
            sale_discount: 0.00,
            sale_amount: 0.00,
        }
        addRow(item)
        $('.addRow').show()
        totalCalculation() 
    })

    /*Form modal Html Part Start*/
    $('.addRow').on('click', function() {
        item = {
            item_name: '',
            unit_id: '',
            sale_qty: '',
            sale_unit_price: '',
            sale_discount_percentage: 0.00,
            sale_discount: 0.00,
            sale_amount: 0.00,
        }
        addRow(item)
    })
    /* Add input row into Purchase Order Form Start */
    var tdFormRowIndex = 0;
    function addRow(item) {
        var tr = '<tr class="addedRow row_'+tdFormRowIndex+'">' +
            '<td>' +
            '<select class="form-control text-capitalize select2 productList" name="item_name[' + tdFormRowIndex + ']" id="item_name'+tdFormRowIndex+'" value="'+item.item_name+'" tabindex="-1" aria-hidden="true">' +
            '</select>' +
            '<span class="text-danger text-sm item_name_error_'+tdFormRowIndex+'"></span> ' +
            '</td>' +
            '<td class="unit-td">' +
            '<select class="form-control text-capitalize unitList" name="unit_id['+tdFormRowIndex+']" id="unit_id' +tdFormRowIndex+ '" value="'+item.unit_id+'" tabindex="-1" aria-hidden="true">' +
            '</select>' +
            '<div class="text-danger text-sm unit_id_error_' +tdFormRowIndex+ '"></div> ' +
            '</td>' +
            '<td class="qty-td">' +
            '<input class="form-control qty" type="number" name="qty['+tdFormRowIndex+']" id="qty'+tdFormRowIndex+'" value="'+item.sale_qty+'"   placeholder="Quantity" oninput="this.value = Math.round(this.value);">' +
            '<span class="text-danger text-sm qty_error_'+tdFormRowIndex+'"></span> ' +
            '</td>' +
            '<td class="mrp-td">' +
            '<input class="form-control mrp" type="number" name="product_mrp['+tdFormRowIndex+']" id="product_mrp'+tdFormRowIndex+'" value="'+item.sale_unit_price+'"  placeholder="Price">' +
            '<span class="text-danger text-sm product_mrp_error_'+tdFormRowIndex+'" ></span> ' +
            '</td>' +
            '<td class="discount-percentage-td">' +
            '<input class="form-control discount-percentage percent text-info" type="number" name="discount_percentage['+tdFormRowIndex+']" id="discount_percentage'+tdFormRowIndex+'" value="'+item.sale_discount_percentage+'">' +
            '</td>' +
            '<td class="discount-td">' +
            '<input class="form-control discount text-info" type="number" name="discount['+tdFormRowIndex+']" id="discount'+tdFormRowIndex+'" value="'+item.sale_discount+'">' +
            '</td>' +
            '<td class="amount-td">' +
            '<input class="form-control amount" type="number" name="amount['+tdFormRowIndex+']" id="amount'+tdFormRowIndex+'" value="'+item.sale_amount+'"  class="form-control amount" placeholder="Amount" onchange="(function(el){el.value=parseFloat(el.value).toFixed(2);})(this)" readonly>' +
            '</td>' +
            '<td><a href="javascript:void(0)" class="btn btn-icon remove" id="remove'+tdFormRowIndex+'" style="border: 1px solid #f54394">' +
            '<svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x" style="color: red;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
            '</a>' +
            '</td>' +
            '</tr>';        
        $('#tdFormRow tbody').append(tr);
        productsList()
        tdFormRowIndex++;
    }//Add row into purchase modal form end
    // Add list of product into form select
    function productsList() {
        filterProducts = []
        if(cType == 1 || cType == 3){
            for (var i = 0; i < products.length; i++) {
                let productForThisCustomer = {
                    product_id:products[i].product_id,
                    product_name:products[i].product_name,
                    brand_name:products[i].brand_name,
                    p_unit_id:products[i].p_unit_id,
                    s_unit_id:products[i].s_unit_id,
                    p_unit_name:products[i].p_unit_name,
                    s_unit_name:products[i].s_unit_name,
                    p_rate:products[i].r_pri_unit_rate,
                    s_rate:products[i].r_sec_unit_rate, 
                    in_hand_stock_primary:products[i].in_hand_stock_primary,
                    in_hand_stock_second:products[i].in_hand_stock_second,
                    no_of_pcs:products[i].no_of_pcs,
                }
                filterProducts.push(productForThisCustomer);
            }            
        }
        if(cType == 2){
            for (var i = 0; i < products.length; i++) {
                let productForThisCustomer = {
                        product_id:products[i].product_id,
                        product_name:products[i].product_name,
                        brand_name:products[i].brand_name,
                        p_unit_id:products[i].p_unit_id,
                        s_unit_id:products[i].s_unit_id,
                        p_unit_name:products[i].p_unit_name,
                        s_unit_name:products[i].s_unit_name,
                        p_rate:products[i].d_pri_unit_rate,
                        s_rate:products[i].d_sec_unit_rate,    
                        in_hand_stock_primary:products[i].in_hand_stock_primary,
                        in_hand_stock_second:products[i].in_hand_stock_second,                    
                        no_of_pcs:products[i].no_of_pcs,
                }
                filterProducts.push(productForThisCustomer);
            }
        }
        $("#item_name"+tdFormRowIndex).empty().append('<option selected="" value="">Select an option</option>');      
        for (count = 0; count < filterProducts.length; count++) {
            $("#item_name"+tdFormRowIndex).append('<option value="'+filterProducts[count].product_id+'"'
                +'data-punitid="'+filterProducts[count].p_unit_id+'" data-sunitid="'+filterProducts[count].s_unit_id+'" '
                +'data-punitname="'+filterProducts[count].p_unit_name+'" data-sunitname="'+filterProducts[count].s_unit_name+'" '
               
                +'data-priunitrate="'+filterProducts[count].p_rate+'" data-secunitrate="'+filterProducts[count].s_rate+'"'
                +'data-maxpri="'+filterProducts[count].in_hand_stock_primary+'" data-maxsec="'+filterProducts[count].in_hand_stock_second+'"'
                +'data-noofpcs="'+filterProducts[count].no_of_pcs+'"'
                +'>'+filterProducts[count].product_name+' - '+filterProducts[count].brand_name+'</option>')
        }
        $('#item_name'+tdFormRowIndex).select2({ width: "100%" }).val(item.item_name).trigger("change");
    }//Product list end here 

    
    $("#tdFormRow").on('change','select.productList',function(){ 
        console.log("pro list change")
        $(this).parents('.addedRow').children('.unit-td').children('.unitList').empty().append('<option selected="" value="">Select a product</option>');
        if($(this).val()){
            $(this).parents('.addedRow').children('.unit-td').children('.unitList').empty().append('<option selected="" value="">Select an unit</option>');
            $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option value="'+$(this).find(':selected').data('punitid')+'"'
            +'data-max="'+$(this).find(':selected').data('maxpri')+'" data-unitrate="'+$(this).find(':selected').data('priunitrate')+'"'
            +'>'+$(this).find(':selected').data('punitname')+'</option>')

            $(this).parents('.addedRow').children('.unit-td').children('.unitList').append('<option value="'+$(this).find(':selected').data('sunitid')+'"'
            +'data-max="'+$(this).find(':selected').data('maxsec')+'" data-unitrate="'+$(this).find(':selected').data('secunitrate')+'"'
                +'>'+$(this).find(':selected').data('sunitname')+'</option>')
            $(this).parents('.addedRow').children('.unit-td').children('.unitList').val(item.unit_id);
        }     
       
    })
    
    $("#tdFormRow").on('change','select.unitList',function(){   
        $(this).parents('.addedRow').children('.mrp-td').children('.mrp').val($(this).find(':selected').data('unitrate'))
        $(this).parents('.addedRow').children('.qty-td').children('.qty').attr({"max": $(this).find(':selected').data('max'), "placeholder":"Max Qty: "+$(this).find(':selected').data('max')+"",})        
        $(this).parents('.addedRow').children('.qty-td').children('.qty').val('')        
        $(this).parents('.addedRow').children('.discount-td').children('.discount').val(0)        
        $(this).parents('.addedRow').children('.amount-td').children('.amount').val('')
    })//Onchange unit show primary qty & mrp

    /*------ Remove row start of FORM ------*/
    $(document).on('click', '.remove', function() {        
        $(this).parent().parent().remove()
        totalCalculation()   
    });
    /*------ Remove row end of FORM ------*/

    /*------ To prevent multi decimal input start ------*/
    $('#product_mrp, #discount, #discount_percentage').keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /*------ To prevent multi decimal input edn ------*/
    
    // Input type Quantity change function Start
    $('#tdFormRow tbody').delegate('.qty','keyup', function() { 
        var tr = $(this).parent().parent();      
        let max = $(this).attr("max");
        let val = parseInt($(this).val(), 10);   
        if(max){            
            if(val > max || val < 1){
                $(this).addClass('is-invalid')
                // $("#cartInputTable thead th:last").children('.addRow1').prop('disabled', true); //disable add button
            }
            else{
                $(this).removeClass('is-invalid')
                $(this).addClass('is-valid')
                // $("#cartInputTable thead th:last").children('.addRow1').prop('disabled', false); //enable add button
            }            
        }
        // else{
        //     snacbar("Select respective SKU first")
        //     $(this).addClass('is-invalid')
        // }
    })
    // Input type Quantity change function End

    /* Toatal calculation*/   
    $('#tdFormRow tbody').on('keyup','.qty',function(){
        var tr = $(this).parent().parent();
        amountCalculation(tr)
    })
    $('#tdFormRow tbody').on('keyup','.mrp',function(){
        var tr = $(this).parent().parent();
        amountCalculation(tr)
    })

    $('#tdFormRow tbody').on('keyup','.percent',function(){
        var tr = $(this).parent().parent();
        var percent = tr.find('.percent').val();
        var mrp = tr.find('.mrp').val();
        var discount = (mrp*percent)/100;
        tr.children('.discount-td').children('.discount').val(parseFloat(discount).toFixed(2))
        amountCalculation(tr)
        
    })

    $('#tdFormRow tbody').on('keyup','.discount',function(){
        var tr = $(this).parent().parent();
        var discount = tr.find('.discount').val();
        var mrp = tr.find('.mrp').val();
        var percent = 100 - (((mrp - discount)/mrp)*100);
        tr.children('.discount-percentage-td').children('.percent').val(parseFloat(percent).toFixed(2))
         amountCalculation(tr)
    })

    function amountCalculation(tr){
        var qty = tr.find('.qty').val();
        var mrp = tr.find('.mrp').val();
        var discount = tr.find('.discount').val();
        var amount = qty * (mrp - discount);
        tr.find('.amount').val(parseFloat(amount).toFixed(2));
        totalCalculation()       
    }

    $("#received").on('keyup',function(){
        if($("#received").val() != ''){
            totalCalculation()
        }    
    })

    $("#delivery_charges").on('keyup',function(){
        if($("#delivery_charges").val() != ''){
            totalCalculation()
        }    
    })

    $("#round_off").on('keyup',function(){
        if($("#round_off").val() != ''){
            totalCalculation()
        }  
    })

    $("#gst_amount").on('keyup',function(){
        if($("#gst_amount").val() != ''){
            totalCalculation()
        }
    })

    function totalCalculation() {
        var subTotal = 0;
        var total = 0;
        var received = $("#received").val()
        var roundOff = $("#round_off").val()
        var deliveryCharges = $("#delivery_charges").val()
        var gstAmount = $("#gst_amount").val()
        $('.amount').each(function(i, e) {
            var amount = $(this).val() - 0;
            subTotal += amount;  
        });
        total = parseFloat(subTotal) + parseFloat(gstAmount);   
        total = parseFloat(total) + parseFloat(deliveryCharges);  
        total = parseFloat(total) - parseFloat(roundOff);    
        var balance = parseFloat(total) - parseFloat(received);
        balance = parseFloat(balance) + parseFloat(prevBalance)
        $("#total").val(total)
        $("#balance").val(balance)
    }//Toatal calculation  
    /*------ Form modal Html Part end -------*/

    /*------ Create New Sale start -------*/
    $(document).on('click','button.add',function(){ 
        $(".prev_bal").text('')
        $("#prev_balance").val(0)//this is to store
        $('select').prop('disabled',false)
        $('input').prop('disabled',false)
        $('textarea').prop('disabled',false)
        $('#customer_id').prop('disabled',false)        
        $('.modal-title').text("New Sale");
        $('#addBtn').show();
        $('#editBtn').hide();
        $('#convertBtn').hide();
        $("#saleOrderForm")[0].reset()
        $("#saleOrderForm .text-danger").html("")
        $('a.btn-icon').show()
        $('a.addRow').hide()
        $(".delivery-date").hide()
        $('#customer_id').select2({
            width: "100%",
            dropdownParent: $('#modal')
        });
     });
    $('#saleOrderForm').on('click', '#addBtn', function (event) {
        event.preventDefault();
        $("#loader").show()
        $("#saleOrderForm .text-danger").html("")
        // var error = $('.is-invalid').length; uncommit after old enter
        // if( error == 0){
            var formData = new FormData($('#saleOrderForm')[0]);
            $.ajax({
                method: 'POST',
                url: routes.create,
                contentType: false,
                cache: false,
                processData: false,
                dataType: "json",
                data: formData,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content'),
                },
                success: function (response) {
                    $("#loader").hide()
                    if(response.errors){
                        if(response.errors.customer_id){
                            $("#customer_id_error").text(response.errors.customer_id[0])
                        }
                        if(response.errors.order_date){
                            $("#order_date_error").text(response.errors.order_date[0])
                        }
                        if(response.errors.delivery_date){
                            $("#delivery_date_error").text(response.errors.delivery_date[0])
                        }
                        if(response.errors.payment_type){
                            $("#payment_type_error").text(response.errors.payment_type[0])
                        }
                        for (var i = 0; i < tdFormRowIndex+1 || i < 1  ; i++) {
                            
                            if(response.errors["item_name."+i]){
                                $(".item_name_error_"+i).text(response.errors["item_name."+i][0])
                            }
                            if(response.errors["unit_id."+i]){
                                $(".unit_id_error_"+i).text(response.errors["unit_id."+i][0])
                            }
                            if(response.errors["qty."+i]){
                                $(".qty_error_"+i).text(response.errors["qty."+i][0])
                            }
                            if(response.errors["product_mrp."+i]){
                                $(".product_mrp_error_"+i).text(response.errors["product_mrp."+i][0])
                            }
                            if(response.errors["amount."+i]){
                                $(".amount_error_"+i).text(response.errors["amount."+i][0])
                            }
                        }      
                    }
                    // //on success
                    else{
                        $('#sale_table').DataTable().ajax.reload(); 
                        $("#modal").modal('hide')
                        $("#saleOrderForm")[0].reset()
                        $('.select2').select2({                       
                                initSelection: function(element, callback) {                   
                            }
                        });
                        sales = response.sales      
                        let message = response.success;
                        snacbar(message)
                    }
                },
                error:function(error){
                    $("#loader").hide()
                    snacbar(error.statusText)
                }
            })//ajax end here
        // }
    })
    /*------ Create New Sale end -------*/

    var inputStat
    /*------- Show Sale Start -------*/    
    $(document).on('click', 'a.view', function() {
        let trnxId = $(this).data('trnxid');
        let status = $(this).data('status')
        if(status == 1){
            $('.delivery-date').show()
        }
        else{
            $('.delivery-date').hide()
        }
        $("#sale_trnx_id").val(trnxId)        
        inputStat = true
        $(".modal-title").text("Sale Details : #OD-" + trnxId)
        $('#addBtn').hide();
        $('#editBtn').hide();
        $('#convertBtn').hide();        
        $("input[type='text']").addClass("text-capitalize")
        $("#saleOrderForm .text-danger").html("")        
        let thisTrnxDetails = {}     
        thisTrnxDetails = sales.filter(elem => {
            return elem.sale_trnx_id == trnxId;
        })
        showData(thisTrnxDetails)  
        $('a.btn-icon').hide()
        $('a.addRow').hide()
    });
    /*------- Show Sale End -------*/

    /*------- Edit Sale Order Start -------*/
    $(document).on("click", "a.edit", function(event) {
        let trnxId = $(this).data('trnxid');
        $('.delivery-date').hide()
        $("#sale_trnx_id").val(trnxId)
        inputStat = false
        $('.modal-title').text("Edit Sale Order : #OD-"+trnxId);        
        $("input[type='text']").addClass("text-capitalize")
        $("#saleOrderForm .text-danger").html("")
        $('#addBtn').hide();
        $('#editBtn').show();
        $('#convertBtn').hide();        
        let thisTrnxDetails = {}     
        thisTrnxDetails = sales.filter(elem => {
            return elem.sale_trnx_id == trnxId;
        })
        showData(thisTrnxDetails)  
        $('a.btn-icon').show()
        $('a.addRow').show()
    })

    $("#saleOrderForm").on("click", "#editBtn", function(event) {
        event.preventDefault()
        $('#customer_id').prop('disabled',false)
        $("#saleOrderForm .text-danger").html("")
        $("#loader").show()
        var formData = new FormData($("#saleOrderForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {                
                $("#loader").hide()
                $('#customer_id').prop('disabled',true)
                if(response.errors){
                    if(response.errors.customer_id){
                        $("#customer_id_error").text(response.errors.customer_id[0])
                    }
                    if(response.errors.order_date){
                        $("#order_date_error").text(response.errors.order_date[0])
                    }
                    if(response.errors.payment_type){
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }
                    for (var i = 0; i < tdFormRowIndex+1 || i < 1  ; i++) {
                        
                        if(response.errors["item_name."+i]){
                            $(".item_name_error_"+i).text(response.errors["item_name."+i][0])
                        }
                        if(response.errors["unit_id."+i]){
                            $(".unit_id_error_"+i).text(response.errors["unit_id."+i][0])
                        }
                        if(response.errors["qty."+i]){
                            $(".qty_error_"+i).text(response.errors["qty."+i][0])
                        }
                        if(response.errors["product_mrp."+i]){
                            $(".product_mrp_error_"+i).text(response.errors["product_mrp."+i][0])
                        }
                        if(response.errors["amount."+i]){
                            $(".amount_error_"+i).text(response.errors["amount."+i][0])
                        }
                    }      
                }
                //on success
                else {
                    $('#sale_table').DataTable().ajax.reload();
                    $("#modal").modal('hide')
                    $("#saleOrderForm")[0].reset()
                    $('.select2').select2({
                        initSelection: function(element, callback) {},
                        width: "100%"
                    });
                    sales = response.sales
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                $('#customer_id').prop('disabled',true)
                $("#loader").hide()
                snacbar(error.statusText)
            }
        })
    })
    /*------- Edit Sale Order End -------*/

    /*------- Convert Dr. Note Start -------*/    
    $(document).on('click', 'a.over-due', function() {
        let trnxId = $(this).data('trnxid');
        $("#sale_trnx_id").val(trnxId)        
        inputStat = true
        $('.modal-title').text("Convert to Sale : #OD-"+trnxId);
        $('#addBtn').hide();
        $('#editBtn').hide();
        $('#convertBtn').show();
        $(".delivery-date").show()         
        $("input[type='text']").addClass("text-capitalize")
        $("#saleOrderForm .text-danger").html("")        
        let thisTrnxDetails = {}     
        thisTrnxDetails = sales.filter(elem => {
            return elem.sale_trnx_id == trnxId;
        })
        showData(thisTrnxDetails)  
        $('a.btn-icon').hide()
        $('a.addRow').hide()
    });
    $('#saleOrderForm').on('click', '#convertBtn', function(event) {
        event.preventDefault();
        $("input").prop('disabled',false) // this is for send dr_trnx_id
        $("#saleOrderForm .text-danger").html("")
        $("#loader").show()
        var formData = new FormData($('#saleOrderForm')[0]);
        $.ajax({
            method: 'POST',
            url: routes.status,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                $("#loader").hide()
                if (response.errors) {
                    if (response.errors.delivery_date) {
                        $("#delivery_date_error").text(response.errors.delivery_date[0])
                    } 
                }
                //on success
                if(response.success) {
                    $('#sale_table').DataTable().ajax.reload();
                    $("#modal").modal('hide')
                    $("#saleOrderForm")[0].reset()
                    $('input.md-input').attr('value' , '')
                    $(".prev_bal").text('')
                    sales = response.sales
                    customers = response.customers
                    customerList()
                    products = response.products
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) { 
                $("#loader").hide()
                snacbar(error.statusText)
            }
        }) //ajax end here
    })
    /*------- Convert Dr. Note End -------*/
    
    /*------- Show Sale Details Start -------*/ 
    function showData(thisTrnxDetails) {
        tdFormRowIndex = 0;
        filterProducts = []
        $('#customer_id').select2({ width: "100%" }).val(thisTrnxDetails[0].customer_id).trigger("change");
        cType = thisTrnxDetails[0].customer_type
        $('#tdFormRow tbody').append().empty(); 
        for (var count = 0; count < thisTrnxDetails.length; count++){
                item = {
                        item_name: thisTrnxDetails[count].item_name,
                        unit_id: thisTrnxDetails[count].unit_id,
                        sale_qty: thisTrnxDetails[count].sale_qty,
                        sale_unit_price: thisTrnxDetails[count].sale_unit_price,
                        sale_discount_percentage: thisTrnxDetails[count].sale_discount_percentage,
                        sale_discount: thisTrnxDetails[count].sale_discount,
                        sale_amount: thisTrnxDetails[count].sale_amount,
                }
                addRow(item)
                $("#order_date").val(moment(thisTrnxDetails[count].sale_order_date, 'YYYY-MM-DD').format("DD-MM-YYYY"))            
                if(thisTrnxDetails[count].dr_delivery_date){
                    $("#delivery_date").val(moment(thisTrnxDetails[count].dr_delivery_date, 'YYYY-MM-DD').format("DD-MM-YYYY")) 
                }  
                $('#payment_type').val(thisTrnxDetails[count].sale_payment_type);
                $("#round_off").val(thisTrnxDetails[count].sale_round_off)
                $("#delivery_charges").val(thisTrnxDetails[count].sale_delivery_charges )
                $("#gst_amount").val(thisTrnxDetails[count].sale_gst_amount)
                $("#total").val(thisTrnxDetails[count].sale_total)
                $("#received").val(thisTrnxDetails[count].sale_received)
                prevBalance = thisTrnxDetails[count].sale_prev_balance
                $(".prev_bal").text('Previous Balance: '+prevBalance)
                $("#prev_balance").val(parseFloat(prevBalance))//this is to store
                $("#balance").val(parseFloat(thisTrnxDetails[count].sale_balance))//this is to store
                $("#remarks").val(thisTrnxDetails[count].sale_remarks)

        }

        $("#saleOrderForm select").prop('disabled', inputStat);
        $("#saleOrderForm input").prop('disabled',inputStat)
        $('#saleOrderForm textarea').prop('disabled',inputStat)
        if(inputStat == true){
            $('a.btn-icon').hide()
            $('a.addRow').hide()
        }
        else
        {
            $('a.btn-icon').show()
            $('a.addRow').show()
        }
        $('#customer_id').prop('disabled',true)
        $('#delivery_date').prop('disabled',false)
        $("#modal").modal('show')
    }
    /*------- Show Sale Details End -------*/ 
   
   /* Sale Order Delete Start */
    $(document).on("click", "a.delete", function() {
        $("#id").val($(this).data("trnxid"))
        $(".modal-title").text("Sale Order No: #OD" + $(this).data("trnxid"))
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $('#sale_table').DataTable().ajax.reload();
                    $("#confirmModal").modal("hide");
                    $('.select2').select2({
                        initSelection: function(element, callback) {},
                        width: "100%"
                    });
                    sales = response.sales
                    customers = response.customers
                    products = response.products
                    let message = response.success;
                    snacbar(message)
                }
                if (response.error) {
                    $("#ok_button").text("Yes")
                    let message = response.error;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        }) //ajax end here
    }) //form end here
    /* Sale Order Delete End */

    /*---------- This function is from customer balde --------*/
    $(document).on("click", "#addSalesFromCustomerBtn", function(event) {
        event.preventDefault();
        let customer_id = $(this).data('cid');
        $('#modal .modal-title').text("New Sale");
        $('#saveBtn').show();
        $('#editBtn').hide();
        $("input[type='text']").removeClass("text-capitalize")
        $("#createAndEditForm")[0].reset()   
        $('.prev_bal').text("Previous balance: 00")   
        $("#createAndEditForm .text-danger").html("")
        $('a.btn-icon').show()  
        
        customers = customers.filter(elem => {
            return elem.customer_id == customer_id;
        })
        customerList()
        $("#customer_id").select2({ width: "100%" }).val(customer_id).trigger("change");
        
    })
    /*---------- This function is from customer balde --------*/

    $(document).on('keydown', '.select2', function(e) {
        if (e.originalEvent && e.which == 40) {
            e.preventDefault();
            $(this).siblings('select').select2('open');
        }
    });

    $('.select2').select2({
        selectOnClose: true
    });
})