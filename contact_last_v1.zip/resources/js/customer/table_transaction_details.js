$(document).ready(function(){
	/*------- View Start Here -------------*/
    $(document).on('click','a.view', function(event){
        event.preventDefault()
        let saletrnxId = $(this).data('saletrnxid')
        let crtrnxId = $(this).data('crtrnxid')
        let payintrnxid = $(this).data('payintrnxid')
        let status = $(this).data('status')
        $('#viewRow tbody').empty().append();  
        if(saletrnxId){
        	if(status == 1){
        		$(".modal-header").addClass('bg-primary')
        		$('#viewModal .modal-title').text("Sale Details: #INV-"+saletrnxId);
        	}
        	else{
        		$(".modal-header").addClass('bg-secondary')
        		$('#viewModal .modal-title').text("Sale Details: #OD-"+saletrnxId);
        	}
        	viewSaleDetails(saletrnxId)
        }
        if(crtrnxId){
        	if(status == 1){
        		$(".modal-header").addClass('bg-primary')
        		$('#viewModal .modal-title').text("Credit Note Details: #CRN-"+crtrnxId);
        	}
        	else{
        		$(".modal-header").addClass('bg-secondary')
        		$('#viewModal .modal-title').text("Credit Note Details: #CRN-OD"+crtrnxId);
        	}
        	viewCreditNoteDetails(crtrnxId)        	
        }
        if(payintrnxid){        	
        	$(".modal-header").addClass('bg-primary')
        	$('#viewModal .modal-title').text("Credit Note Details: #PAY-IN"+payintrnxid);
        	viewPaymentInDetails(payintrnxid)
        }
        
    })
    /*------- View End Here -------------*/

    function viewSaleDetails(trnxId) {
    	$('#viewRow thead').append().empty()
    	$('#viewRow thead').append('<tr>'+
                                '<th style="width: 40%;">Item Name</th>'+
                                '<th style="width: 10%;">Unit Name</th>'+
                                '<th style="width: 10%;">Quantity</th>'+
                                '<th style="width: 10%;">MRP</th>'+
                                '<th style="width: 10%;" class="text-info">% Discount</th>'+
                                '<th style="width: 10%;" class="text-info">Discount</th>'+
                                '<th style="width: 10%;">Amount</th>'+
                            '</tr>')
    	for (var count = 0; count < allTableData.length; count++){
    		if(trnxId == allTableData[count].sale_trnx_id){
    			var tr = '<tr class="">' +
			            '<td>' +
			            	'<input class="form-control text-capitalize" value="' + allTableData[count].product_name + ' - '+allTableData[count].brand_name+ '" readonly>' +
			            '</td>' +
			            '<td>' +
			            	'<input class="form-control text-capitalize" value="'+allTableData[count].unit_name+'" readonly>' +
			            '</td>' +
			            '<td class="td-qty">' +
			            	'<input type="number" value="' + allTableData[count].sale_qty + '"  class="form-control" readonly>' +
			            '</td>' +
			            '<td>' +
			            	'<input type="number" value="' + allTableData[count].sale_unit_price + '"  class="form-control" readonly>' +	            
			            '</td>' +
			            '<td>' +
			            	'<input type="number" value="' + allTableData[count].sale_discount_percentage.toFixed(2) + '"  class="form-control text-info" readonly>' +	            
			            '</td>' +
			            '<td>' +
			            	'<input type="number" value="' + allTableData[count].sale_discount.toFixed(2) + '"  class="form-control text-info" readonly>' +	            
			            '</td>' +
			            '<td>' +
			            	'<input type="number" value="' + allTableData[count].sale_amount + '"  class="form-control" readonly>' +
			            '</td>' +
			            '</tr>';
			        $('#viewRow tbody').append(tr);

			$("#view_customer_name").val(allTableData[count].f_name+' '+allTableData[count].s_name+' ('+allTableData[count].phone_1+') ('+allTableData[count].shop_name+')')
			$("#view_order_date").val(moment(allTableData[count].sale_order_date, 'YYYY-MM-DD').format("DD-MM-YYYY"))
			if(allTableData[count].sale_delivery_date	){
				$("#view_delivery_date").val(moment(allTableData[count].sale_delivery_date, 'YYYY-MM-DD').format("DD-MM-YYYY"))
			}
			else{
				$("#view_delivery_date").val("NOT DELIVERED")
			}
			
            $('#view_payment_type').val(allTableData[count].sale_payment_type);
            $("#view_round_off").val(allTableData[count].sale_round_off)
            $("#view_delivery_charges").val(allTableData[count].sale_delivery_charges)
            $("#view_gst_amount").val(allTableData[count].sale_gst_amount)
            $("#view_total").val(allTableData[count].sale_total)
            $("#view_received").val(allTableData[count].sale_received)
            prevBalance = allTableData[count].sale_prev_balance
            $(".prev_bal").text('Previous Balance: '+prevBalance)
            $("#view_prev_balance").val(parseFloat(prevBalance))//this is to store
            $("#view_balance").val(parseFloat(allTableData[count].sale_balance))//this is to store
            $("#view_remarks").val(allTableData[count].sale_remarks)

    		}
    	}
    	$("#viewModal").modal('show')
    }

    function viewCreditNoteDetails(trnxId) {
    	$('#viewRow thead').append().empty()
    	$('#viewRow thead').append('<tr>'+
                                '<th style="width: 30%;">Item Name</th>'+
                                '<th style="width: 10%;">Unit Name</th>'+
                                '<th style="width: 10%;">Quantity</th>'+
                                '<th style="width: 20%;">MRP</th>'+
                                '<th style="width: 20%;">Amount</th>'+
                            '</tr>')
    	for (var count = 0; count < allTableData.length; count++){
    		if(trnxId == allTableData[count].cr_trnx_id){
    			var tr = '<tr class="">' +
			            '<td>' +
			            	'<input class="form-control text-capitalize" value="' + allTableData[count].product_name + '" readonly>' +
			            '</td>' +
			            '<td>' +
			            	'<input class="form-control text-capitalize" value="'+allTableData[count].unit_name+'" readonly>' +
			            '</td>' +
			            '<td class="td-qty">' +
			            	'<input type="number" value="' + allTableData[count].cr_qty + '"  class="form-control" readonly>' +
			            '</td>' +
			            '<td>' +
			            	'<input type="number" value="' + allTableData[count].cr_unit_price + '"  class="form-control" readonly>' +	            
			            '</td>' +
			            
			            '<td>' +
			            	'<input type="number" value="' + allTableData[count].cr_amount + '"  class="form-control" readonly>' +
			            '</td>' +
			            '</tr>';
			        $('#viewRow tbody').append(tr);

			$("#view_customer_name").val(allTableData[count].f_name+' '+allTableData[count].s_name+' ('+allTableData[count].phone_1+') ('+allTableData[count].shop_name+')')
			$("#view_order_date").val(moment(allTableData[count].cr_order_date, 'YYYY-MM-DD').format("DD-MM-YYYY"))
			if(allTableData[count].cr_delivery_date	){
				$("#view_delivery_date").val(moment(allTableData[count].cr_delivery_date, 'YYYY-MM-DD').format("DD-MM-YYYY"))
			}
			else{
				$("#view_delivery_date").val("NOT DELIVERED")
			}
            $('#view_payment_type').val(allTableData[count].cr_payment_type);
            $("#view_round_off").val(allTableData[count].cr_round_off)
            $("#view_delivery_charges").val(allTableData[count].cr_delivery_charges)
            $("#view_gst_amount").val(allTableData[count].cr_gst_amount)
            $("#view_total").val(allTableData[count].cr_total)
            $("#view_received").val(allTableData[count].cr_advance)
            prevBalance = allTableData[count].cr_prev_balance
            $(".prev_bal").text('Previous Balance: '+prevBalance)
            $("#view_prev_balance").val(parseFloat(prevBalance))//this is to store
            $("#view_balance").val(parseFloat(allTableData[count].cr_balance))//this is to store
            $("#view_remarks").val(allTableData[count].cr_remarks)

    		}
    	}
    	$("#viewModal").modal('show')
    }

    function viewPaymentInDetails(trnxId){
    	for (var count = 0; count < allTableData.length; count++){
    		if(trnxId == allTableData[count].payment_in_trnx_id){
    			console.log(allTableData[count].payment_in_trnx_id)
    			$("#customer_name").val(allTableData[count].f_name+' '+allTableData[count].s_name+' ('+allTableData[count].phone_1+') ('+allTableData[count].shop_name+')')
		        $("#date").val(moment(allTableData[count].date).format('DD-MM-YYYY'))
		        $("#prev_balance").val(allTableData[count].prev_balance)
		        $("#received").val(allTableData[count].received)
		        $("#balance").val(allTableData[count].balance)
		        $("#payment_type").val(allTableData[count].payment_type)
		        $("#remarks").val(allTableData[count].remarks)  
    		}
    	}         
        $('#payMentModal input').prop('disabled',true)
        $('#payMentModal textarea').prop('disabled',true)
        $('#payMentModal select').prop('disabled',true)
        $("#savePayBtn").hide()
        $("#payMentModal").modal("show")
    }

    
})