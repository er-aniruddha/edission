$(document).ready(function(){
    /* Choose Whats App no Start*/
    $('.select2').select2();
        //To get whatsapp no 
    $('.checkbox').on('change', 'input.custom-control-input', function () {
        $('input.custom-control-input').not(this).prop('checked', false);
        if ($(this).val() == 1 && $("#phone_1").val() != "") {
            $("#whatsapp_no").attr('value', $("#phone_1").val())    }
        if ($(this).val() == 2 && $("#phone_2").val() != "") {
            $("#whatsapp_no").attr('value', $("#phone_2").val())
        }
        if ($('input.custom-control-input').prop('checked') == false) {
            $("#whatsapp_no").attr('value', "")
        }
    });
    /* Choose Whats App no End*/
    /* Add Customer Start*/
    $('#addCustomerForm').on('click', '#addCustomerBtn', function (e) {
        e.preventDefault();
        $( '.text-danger' ).html( "" );
        var formData = new FormData($('#addCustomerForm')[0]);
        $.ajax({
            method: 'POST',
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function (response) {
                if(response.errors){
                    if(response.errors.f_name){
                        $("#f_name_error").text(response.errors.f_name[0])
                    }
                    if(response.errors.s_name){
                        $("#s_name_error").text(response.errors.s_name[0])
                    }
                    if(response.errors.shop_name){
                        $("#shop_name_error").text(response.errors.shop_name[0])
                    }
                    if(response.errors.phone_1){
                        $("#phone_1_error").text(response.errors.phone_1[0])
                    }
                    if(response.errors.phone_2){
                        $("#phone_2_error").text(response.errors.phone_2[0])
                    }
                    if(response.errors.whatsapp_no){
                        $("#whatsapp_no_error").text(response.errors.whatsapp_no[0])
                    }
                    if(response.errors.customer_type){
                        $("#customer_type_error").text(response.errors.customer_type[0])
                    }
                    if(response.errors.customer_routes_id){
                        $("#route_error").text(response.errors.customer_routes_id[0])
                    }
                    if(response.errors.locality){
                        $("#locality_error").text(response.errors.locality[0])
                    }
                    if(response.errors.district){
                        $("#district_error").text(response.errors.district[0])
                    }
                    if(response.errors.pin){
                        $("#pin_error").text(response.errors.pin[0])
                    }
                    if(response.errors.email){
                        $("#email_error").text(response.errors.email[0])
                    }
                }
                //on success
                else{
                    $("#addCustomerForm")[0].reset()
                    $('input.md-input').attr('value' , '')
                    $("#state").attr({'value': 'West Bengal'})
                    $('.select2').select2({
                        initSelection: function(element, callback) {}
                    });
                    let message = response.success;
                    snacbar(message)
                }                
            },
            error:function(error){
                snacbar(error.statusText)
            }
        })
    })
    /*Add Customer End*/
})