$(document).ready(function() {
    /*-------- Bank Transaction table start -------*/
    var bank_trnx_table = $("#bank_trnx_table").DataTable({
        processing: true,
        serverSide: true,
        lengthMenu: [
            [10, 25, 50,100, -1],
            [10, 25, 50,100, 'All'],
        ],
        buttons: [{ extend: 'csv', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
            { extend: 'excel', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
            { extend: 'pdf', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } },
            { extend: 'print', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7] } }
        ],
        ajax: {
            url: routes.index
        },
        columns: [{
            data: "DT_RowIndex",
            name: "DT_RowIndex",
            render: function(data) {
                return '<small class="text-muted">' + data + '</small>'
            }
        }, {
            data: "date",
            name: "date",
            render: function(data, type, full, meta) {
                return '<span class="text-sm text-capitalize">' + data + '</span>'
            },
        }, {
            data: "bank_trnx_id",
            name: "bank_trnx_id",
            render: function(data, type, full, meta) {
                return '<span class="text-sm text-capitalize text-primary">' + data + '</span>'
            },
        }, {
            data: "trnx_type",
            name: "trnx_type",
            render: function(data) {
                if (data == 0) {
                    return '<span class="text-sm text-capitalize text-info">opening banlance</span>'
                } else if (data == 1) {
                    return '<span class="text-sm text-capitalize text-danger">cash withdraw</span>'
                } else {
                    return '<span class="text-sm text-capitalize text-success">cash deposite</span>'
                }

            }
        }, {
            data: "account_name",
            name: "account_name",
            render: function(data) {
                return '<span class="text-sm text-capitalize">' + data + '</span>'
            }
        }, {
            data: "amount",
            name: "amount",
            render: function(data) {
                var data = data.split('/')
                var amount = data[0]
                var trnx_type = data[1]
                if( trnx_type == 0)
                {
                    return '<span class="text-sm text-capitalize text-info inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount.toString().replace('-',' ')) +'</span>';  
                }
                if( trnx_type == 1)
                {
                    return '<span class="text-sm text-capitalize text-danger inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount.toString().replace('-',' ')) +'</span>';  
                }
                else
                {
                    return '<span class="text-sm text-capitalize text-success inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount.toString().replace('-',' ')) +'</span>';   
                }
            }
        }, {
            data: "action",
            name: "action"
        }],

    });
    /*-------- Bank Transaction table end -------*/
    /*-------- Show bank modal start -------*/
    $(document).on('click', '#addBankAc', function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        $('.modal-title').text('Add Bank Account')
        $("#bankForm")[0].reset()
        $("#addBtn").show()
        $("#editBtn").hide()
    })
    /*-------- Show bank modal start -------*/
    /*-------- Save bank accounts start -------*/
    $("#bankForm").on('click', '#addBtn', function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        var formData = new FormData($("#bankForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if (response.errors.account_name) {
                        $("#account_name_error").text(response.errors.account_name[0])
                    }
                    if (response.errors.opening_balance) {
                        $("#opening_balance_error").text(response.errors.opening_balance[0])
                    }
                    if (response.errors.date) {
                        $("#date_error").text(response.errors.date[0])
                    }
                } else {
                    $("#bankForm")[0].reset()
                    $("#bank_trnx_table").DataTable().ajax.reload()
                    $("#bankAccountModal").modal("hide")
                    let message = response.success;
                    bankaccounts = response.bankaccounts;
                    bankAcList()
                    snacbar(message)
                }

            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })

    })
    /*-------- Save bank accounts end -------*/
    /*-------- Show  bank accounts start ------*/
    bankAcList()

    function bankAcList() {
        $("#bankAcList").empty().append('')
        $("#b2c_baccount_id").empty().append('<option selected="" value="">Select account</option>')
        $("#c2b_baccount_id").empty().append('<option selected="" value="">Select account</option>')
        $("#edit_baccount_id").empty().append('<option selected="" value="">Select account</option>')
        for (let i = 0; i < bankaccounts.length; i++) {
            $("#bankAcList").append('<li>' +
                '<a href="javascript:void(0);" data-pjax-state="anchor" class="b-b item-company text-primary b-account" data-name="' + bankaccounts[i].account_name + '">' +
                '<span class="nav-text text-capitalize">' + bankaccounts[i].account_name + '' +
                '<p class="item-except text-muted text-sm h-1x">' + moment(bankaccounts[i].date, 'YYYY-MM-DD').format("DD-MM-YYYY") + '</p></span>' +
                '<span class="nav-badge">' +
                '<span class="badge bg-primary-lt" style="float: right; margin-top: 12px;">&#8377; ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(bankaccounts[i].account_balance)  + '</span></br>' +
                '<span class="badge bg-secondary-lt b-account-view" style="float: right;" id="' + bankaccounts[i].baccount_id + '" data-name="' + bankaccounts[i].account_name + '" data-obal="' + bankaccounts[i].opening_balance + '" data-date="' + bankaccounts[i].date + '">' +
                '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye mx-2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg></span>' +
                '</span>' +
                '</a>' +
                '</li>')
            let bankAcList = '<option class="text-capitalize" value="'+bankaccounts[i].baccount_id+'">'+bankaccounts[i].account_name+'</option>'
            $("#b2c_baccount_id").append(bankAcList)
            $("#c2b_baccount_id").append(bankAcList)
            $("#edit_baccount_id").append(bankAcList)
        }

    }
    /*-------- Show  bank accounts end ------*/
    /*-------- Searching table on account base start -------*/
    $(document).on('click', '.b-account', function(event) {
        event.preventDefault()
        let name = $(this).data('name')
        bank_trnx_table.search(name).draw();
    })
    /*-------- Searching table on account base end ---------*/

    /*-------- Bank account update start ------*/
    $(document).on('click', '.b-account-view', function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        $('input.form-controll').attr('value', '')
        $('.modal-title').text('Edit Bank Account #' + $(this).data('name'))
        $("#baccount_id").val($(this).attr('id'))
        $("#account_name").val($(this).data('name'))
        $("#opening_balance").val($(this).data('obal'))
        $("#date").val(moment($(this).data('date'), 'YYYY-MM-DD').format("DD-MM-YYYY"))
        $("#bankAccountModal").modal("show")
        $("#addBtn").hide()
        $("#editBtn").show()
    })

    $("#bankForm").on('click', '#editBtn', function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        var formData = new FormData($("#bankForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if (response.errors.account_name) {
                        $("#account_name_error").text(response.errors.account_name[0])
                    }
                    if (response.errors.opening_balance) {
                        $("#opening_balance_error").text(response.errors.opening_balance[0])
                    }
                    if (response.errors.date) {
                        $("#date_error").text(response.errors.date[0])
                    }
                } else {
                    $("#bankForm")[0].reset()
                    $("#bank_trnx_table").DataTable().ajax.reload()
                    $("#bankAccountModal").modal("hide")
                    let message = response.success;
                    bankaccounts = response.bankaccounts;
                    bankAcList()
                    snacbar(message)
                }

            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })
    })
    /*-------- Bank account update end ------*/
    /*-------- B-C transfer start ------*/
    $(document).on('click', '.b-c-trns', function(event) {
        event.preventDefault()
        $('.select2').select2({
            initSelection: function(element, callback) {},
            width: "100%",
            tags: true,
            dropdownParent: $('#b2cModal')
        });
        $("#b2cTrnsferForm")[0].reset()
    })

    $("#b2cTrnsferForm").on('click', '#cashTrnsBtn', function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        var formData = new FormData($("#b2cTrnsferForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.b2c,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if (response.errors.baccount_id) {
                        $("#b2c_baccount_id_error").text(response.errors.baccount_id[0])
                    }
                    if (response.errors.amount) {
                        $("#b2c_amount_error").text(response.errors.amount[0])
                    }
                    if (response.errors.date) {
                        $("#b2c_date_error").text(response.errors.date[0])
                    }
                } else {
                    $("#b2cTrnsferForm")[0].reset()
                    $("#bank_trnx_table").DataTable().ajax.reload()
                    $("#b2cModal").modal("hide")
                    let message = response.success;
                    bankaccounts = response.bankaccounts;
                    bankAcList()
                    snacbar(message)
                }

            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })
    })
    /*-------- B-C transfer end ------*/

    /*-------- C-B transfer start ------*/
    $(document).on('click', '.c-b-trns', function(event) {
        event.preventDefault()
        $('.select2').select2({
            initSelection: function(element, callback) {},
            width: "100%",
            tags: true,
            dropdownParent: $('#c2bModal')
        });
        $("#c2bTrnsferForm")[0].reset()
    })

    $("#c2bTrnsferForm").on('click', '#cashTrnsBtn', function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        var formData = new FormData($("#c2bTrnsferForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.c2b,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                console.log(response)
                if (response.errors) {
                    if (response.errors.baccount_id) {
                        $("#c2b_baccount_id_error").text(response.errors.baccount_id[0])
                    }
                    if (response.errors.amount) {
                        $("#c2b_amount_error").text(response.errors.amount[0])
                    }
                    if (response.errors.date) {
                        $("#c2b_date_error").text(response.errors.date[0])
                    }
                } else {
                    $("#c2bTrnsferForm")[0].reset()
                    $("#bank_trnx_table").DataTable().ajax.reload()
                    $("#c2bModal").modal("hide")
                    let message = response.success;
                    bankaccounts = response.bankaccounts;
                    bankAcList()
                    snacbar(message)
                }

            },
            error: function(error) {
                snacbar(error.statusText)
            }
        })
    })
    /*-------- C-B transfer end ------*/

    /*-------- B-B transfer start ------*/
    $(document).on('click', '.b-b-trns', function(event) {
        event.preventDefault()
        console.log("b-b")
    })
    /*-------- B-B transfer end ------*/

    /*-------- edit transfer start ------*/
    $(document).on('click','a.edit',function(event){
        event.preventDefault()      
        $("#editModal").modal('show')
        $('.to-element, .from-element').empty().append()
        let trnxtype = $(this).data('trnxtype')
        let trnxid = $(this).data('trnxid')
        let bank_id = $(this).data('bacid')
        let name = $(this).data('name')
        let id = $(this).data('id')
        // b2c transaction
        if(trnxtype == 1){
            $("#editModal .modal-header, .update-btn").removeClass('bg-success')
            $("#editModal .modal-header, #_upDateBtn").addClass('red')
            $("#editModal .modal-title").text('Bank to Cash transfer edit: #'+trnxid)
            $("#_upDateBtn").prop('value','Cash Withdraw Update')
            $('.from-element').append('<input type="text" value="'+name+'" class="form-control text-capitalize" readonly>')
            $('.to-element').append('<select class="form-control" disabled id="edit_cash" name="cash"><option selected="" value="cash">Cash</option></select>')

        }
        // c2b transaction
        if(trnxtype == 2){
            $("#editModal .modal-header, .update-btn").removeClass('red')
            $("#editModal .modal-header, .update-btn").addClass('bg-success')
            $("#editModal .modal-title").text('Bank to Cash transfer edit: #'+trnxid)
            $("#_upDateBtn").prop('value','Cash Deposite Update')
            $('.from-element').append('<select class="form-control" disabled id="edit_cash" name="cash"><option selected="" value="cash">Cash</option></select>')
            $('.to-element').append('<input type="text" value="'+name+'" class="form-control text-capitalize" readonly>')
        }
        $("#baccount_id").val(bank_id)
        $("#edit_amount").val($(this).data('amount'))
        $("#edit_date").val(moment($(this).data('date')).format('DD-MM-YYYY') )
        bankAcList()
    })
    /*-------- edit transfer end ------*/
})