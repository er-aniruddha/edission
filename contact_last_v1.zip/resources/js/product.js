$(document).ready(function() {
    $.fn.modal.Constructor.prototype._enforceFocus = function() {};
    $('#product_r_mrp').on('keyup',function(event) {        
        if ($(this).val() != '') {
            // multiDeciamlInputCheck($(this).val()) // this function is in footer
            $(".unitpricer").show()
            $("#priUnit_price_r").val($("#product_r_mrp").val())
            $("#secUnit_price_r").val($("#product_r_mrp").val() / $("#no_of_pcs").val())
        } else {
            $(".unitpricer").hide()
        }
    });

    $('#product_d_mrp').on('keyup',function(event) {        
        if ($(this).val() != '') {
            // multiDeciamlInputCheck($(this).val()) // this function is in footer
            $(".unitpriced").show()
            $("#priUnit_price_d").val($("#product_d_mrp").val())
            $("#secUnit_price_d").val($("#product_d_mrp").val() / $("#no_of_pcs").val())
        } else {
            $(".unitpriced").hide()
        }
    });
    
    /* On Change of Unit Start*/
    $('#no_of_pcs').on('keyup', function(event) {
        if ($("#product_mrp").val() != '') {
            $(".unitpricer, .unitpriced").show()
            $("#priUnit_price_r").val($("#product_r_mrp").val())
            $("#secUnit_price_r").val($("#product_r_mrp").val() / $("#no_of_pcs").val())
            $("#priUnit_price_d").val($("#product_d_mrp").val())
            $("#secUnit_price_d").val($("#product_d_mrp").val() / $("#no_of_pcs").val())
        } else {
            $(".unitpricer, .unitpriced").hide()
        }
    });

    $(".priUnit").on('change', function() {
        var data = $(".priUnit option:selected").text();

        if (data == '') {
            onChangeSelectOption()
        } else {
            $("#selectedPriUnit").text('1 ' + data)
            $("#selectedPriUnit2R").text('Price/' + data)
            $("#selectedPriUnit2D").text('Price/' + data)
            conversionUnitChngCount()
        }
    })

    $(".secUnit").on('change', function() {
        var data = $(".secUnit option:selected").text();
        if (data == '') {
            onChangeSelectOption()
        } else {
            $("#selectedSecUnit").text(data)
            $("#selectedSecUnit2R").text('Price/' + data)
            $("#selectedSecUnit2D").text('Price/' + data)
            conversionUnitChngCount()
        }
    })

    function conversionUnitChngCount() {
        if ($(".priUnit option:selected").val() != '' && $(".secUnit option:selected").val() != '') {
            $("#convBtn").addClass('enable')
            $("#convBtn").removeClass('disabled')
            $("#product_r_mrp").prop('disabled', false)
            $("#product_d_mrp").prop('disabled', false)
        }
    }

    $('#convBtn').click(function(event) {
        event.preventDefault()
        if ($("#convBtn").hasClass('enable')) {
            $("#convBtn").hide()
            $(".conversion").show()
        }

    })

    function onChangeSelectOption() {
        $("#convBtn").addClass('disabled')
        $("#convBtn").removeClass('enable')
        $("#product_mrp").prop('disabled', true)
        $("#convBtn").show()
        $(".conversion").hide()
        $(".unitpricer, .unitpriced").hide()
    }
    /* On Change of Unit End*/

    /* To prevent multi decimal input edn */
    $('input[type="checkbox"]').click(function(event) {
        /* Act on the event */
        if ($('#checkbox').is(':checked')) {
            $("#product_stat").val(1)
        } else {
            $("#product_stat").val(0)
        }
    }) //set publication status

    /* Show Brand Table Start */
    var productTable = $('#product_table').DataTable({
        processing: true,
        serverSide: true,
        lengthMenu: [
            [10, 25, 50,100, -1],
            [10, 25, 50,100, 'All'],
        ],
        buttons: [
            { 
                extend: 'csv',
                exportOptions: {
                    columns: [ 0, 1, 2, 3,4,5,6,7,8 ]
                }            
            },
            { 
                extend: 'excel',
                exportOptions: {
                    columns: [ 0, 1, 2, 3,4,5,6,7,8 ]
                }              
            },
            { 
                extend: 'pdf',
                exportOptions: {
                    columns: [ 0, 1, 2, 3,4,5,6,7,8 ]
                }              
            },
            { 
                extend: 'print',
                exportOptions: {
                    columns: [ 0, 1, 2, 3,4,5,6,7,8 ]
                }           
            }
        ],
        ajax: {
            url: routes.list,
        },
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex' },
            { data: 'product_name', name: 'product_name', className: "text-capitalize" },
            { data: 'brand_name', name: 'brand_name', className: "text-capitalize" },
            { data: 'qty', name: 'qty', className: "text-capitalize" },
            {
                data: 'product_r_mrp',
                name: 'product_r_mrp',
                render: function(data) {
                    return '<span class="item-amount d-none d-sm-block text-sm inr-sign">' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) + '</span>'
                }
            },
            {
                data: 'r_sec_unit_rate',
                name: 'r_sec_unit_rate',
                render: function(data) {
                    return '<span class="item-amount d-none d-sm-block text-sm inr-sign">' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) + '</span>'
                }
            },
            {
                data: 'product_d_mrp',
                name: 'product_d_mrp',
                render: function(data) {
                    return '<span class="item-amount d-none d-sm-block text-sm inr-sign">' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) + '</span>'
                }
            },
            {
                data: 'd_sec_unit_rate',
                name: 'd_sec_unit_rate',
                render: function(data) {
                    return '<span class="item-amount d-none d-sm-block text-sm inr-sign">' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) + '</span>'
                }
            },
            {
                data: 'in_hand_stock_second',
                name: 'in_hand_stock_second',
                render: function(data) {
                    if(data < 0){
                        return '<span class="item-amount d-none d-sm-block text-sm text-danger">' + data + '</span>'
                    }
                    else{
                        return '<span class="item-amount d-none d-sm-block text-sm text-primary">' + data + '</span>'
                    }
                }
            },
            { data: 'status', name: 'status', },
            { data: 'action', name: 'action', },
        ]
    });
    /* Show Brand Table End */

    /* Export Start*/
    $(document).on('click',".export",function(){
        var btn = $(this).attr('id').toString()
        console.log(btn)
        productTable.button(btn).trigger();
    })
    /* Export End*/

    /* Add Modal Start */
    $(document).on('click', 'button.add', function() {
        $('.modal-title').text("Add Product");
        $('#brand_id').val("");
        $('#addBtn').show();
        $('#editBtn').hide();
        $('#show-img').removeAttr('src');
        $("input[type='text']").removeClass("text-capitalize")
        $('#productForm')[0].reset();
        $('.select2').select2({
            initSelection: function(element, callback) {},
            width: "100%"
        });
        $("#convBtn").addClass('disabled')
        $("#convBtn").show()
        $("#product_mrp").prop('disabled', true)
        $(".unitpricer, .unitpriced").hide()
        $(".conversion").hide()
        $(".text-danger").html("")

    });

    $(document).on('change', 'select.brand', function(event) {
        event.preventDefault()
        let brand_id = $(this).val();
        let filterProducts = products.filter(elem => {
            return elem.brand_id == brand_id;
        })
        productsList(filterProducts)
    })

    function productsList(filterProducts) {
        $(".productList").empty().append('<option selected="" value="">Select an option</option>');
        for (let count = 0; count < filterProducts.length; count++) {
            $(".productList").append('<option value="' + filterProducts[count].product_name + '">' + filterProducts[count].product_name + '</option>')
        }
        $('.select2').select2({
            width: "100%",
            tags: true,
            dropdownParent: $('#modal')
        }); // to init selec2
    }
    /* Add Modal end */

    /* Add Product Start */
    $('#productForm').on('click', '#addBtn', function(event) {
        event.preventDefault();
        $(".text-danger").html("")
        var formData = new FormData($('#productForm')[0]);
        $.ajax({
            method: 'POST',
            url: routes.create,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if (response.errors.product_name) {
                        $("#product_name_error").text(response.errors.product_name[0])
                    }
                    if (response.errors.product_desc) {
                        $("#product_desc_error").text(response.errors.product_desc[0])
                    }
                    if (response.errors.brand_id) {
                        $("#brand_id_error").text(response.errors.brand_id[0])
                    }
                    if (response.errors.primary_unit) {
                        $("#primary_unit_error").text(response.errors.primary_unit[0])
                    }
                    if (response.errors.secondary_unit) {
                        $("#secondary_unit_error").text(response.errors.secondary_unit[0])
                    }
                    if (response.errors.no_of_pcs) {
                        $("#no_of_pcs_error").text(response.errors.no_of_pcs[0])
                    }
                    if (response.errors.product_r_mrp) {
                        $("#product_mrp_r_error").text(response.errors.product_r_mrp[0])
                    }
                    if (response.errors.product_d_mrp) {
                        $("#product_mrp_d_error").text(response.errors.product_d_mrp[0])
                    }
                    if (response.errors.image) {
                        $("#image_error").text(response.errors.image[0])
                    }
                    if (response.errors.pro_type) {
                        $("#pro_type_error").text(response.errors.pro_type[0])
                    }
                }
                //on success
                else {
                    $('#product_table').DataTable().ajax.reload();
                    $("#modal").modal('hide')
                    $("#productForm")[0].reset()
                    $('input.md-input').attr('value', '')
                    $('.select2').select2({
                        initSelection: function(element, callback) {}
                    });
                    $("#convBtn").addClass('disabled')
                    products = response.products
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        }) //ajax end here
    }) //Add product function end here
    /*Add Product End*/
    /* Product Show Start*/
    $(document).on("click", "button.view", function() {
        $(".modal-title").text("Product Details")
        $("#editBtn").hide()
        showProduct($(this).data())

    }) //Product Edit show 
    /* Product Show End*/
    /*Product Edit Start*/
    $(document).on("click", "button.edit", function() {
        $(".modal-title").text("Edit Product")
        $("#editBtn").show()
        $("#product_id").val($(this).data("id"))
        showProduct($(this).data())
    }) //Product Edit show 
    $("#productForm").on("click", "#editBtn", function(event) {
        event.preventDefault()
        $(".text-danger").html("")
        var formData = new FormData($("#productForm")[0]);
        $.ajax({
            method: "POST",
            url: routes.update,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            success: function(response) {
                if (response.errors) {
                    if (response.errors.product_name) {
                        $("#product_name_error").text(response.errors.product_name[0])
                    }
                    if (response.errors.product_desc) {
                        $("#product_desc_error").text(response.errors.product_desc[0])
                    }
                    if (response.errors.brand_id) {
                        $("#brand_id_error").text(response.errors.brand_id[0])
                    }
                    if (response.errors.product_mrp) {
                        $("#product_mrp_error").text(response.errors.product_mrp[0])
                    }
                    if (response.errors.image) {
                        $("#image_error").text(response.errors.image[0])
                    }
                    if (response.errors.pro_type) {
                        $("#pro_type_error").text(response.errors.pro_type[0])
                    }
                }
                //on success
                else {
                    $('#product_table').DataTable().ajax.reload();
                    $("#modal").modal('hide')
                    $("#productForm")[0].reset()
                    $('input.md-input').attr('value', '')
                    $('.select2').select2({
                        initSelection: function(element, callback) {}
                    });
                    products = response.products
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        }) //ajax end here
    }) //Product edit form function end here
    /*Product Edit End*/

    /* Product Status Start */
    $(document).on("click", ".status", function(event) {
        event.preventDefault()
        $.ajax({
            type: "GET",
            url: $(this).data("url"),
            success: function(response) {
                if (response.success) {
                    $("#product_table").DataTable().ajax.reload();
                    let message = response.success;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        }) //ajax end here
    }) //function end here    
    /* Product Status End */

    /* Product Delete Start */
    $(document).on("click", "button.delete", function() {
        $("#id").val($(this).data("id"))
        $(".modal-title").text("Product: " + $(this).data("name"))
        $("#ok_button").text("YES")
        $("#confirmModal").modal("show")
    })
    $("#confirmModal").on("click", "#ok_button", function(event) {
        event.preventDefault();
        var formData = new FormData($("#confirmform")[0]);
        $.ajax({
            type: "POST",
            url: routes.delete,
            processData: false,
            contentType: false,
            data: formData,
            beforeSend: function() {
                $("#ok_button").text("Deleting...")
            },
            success: function(response) {
                if (response.success) {
                    $("#product_table").DataTable().ajax.reload();
                    $("#confirmModal").modal("hide");
                    let message = response.success;
                    snacbar(message)
                }
                if (response.error) {
                    $("#ok_button").text("Yes")
                    let message = response.error;
                    snacbar(message)
                }
            },
            error: function(error) {
                snacbar(error.statusText)
            }
        }) //ajax end here
    }) //form end here
    /* Product Delete End */
    /* Add && Show functions start*/
    function showProduct(data) {
        
        if (data.status == 1) {
            $('input[type="checkbox"]').prop("checked", true)
            $("#product_stat").val(1)
        } else {
            $('input[type="checkbox"]').prop("checked", false)
            $("#product_stat").val(0)
        }
        $("input[type='text']").addClass("text-capitalize")
        $("#product_desc").val(data.desc)
        $("#product_r_mrp").val(data.mrpr)
        $("#product_d_mrp").val(data.mrpd)
        $("#brand_id").select2({ width: "100%" }).val(data.brand).trigger("change");
        $("#product_name").select2({ width: "100%" }).val(data.name).trigger("change");
        $("#production").select2({ width: "100%" }).val(data.production).trigger("change");
        $("#primary_unit").select2({ width: "100%" }).val(data.punitid).trigger("change");
        $("#secondary_unit").select2({ width: "100%" }).val(data.sunitid).trigger("change");
        $("#show-img").attr("src", data.image)
        $("#addBtn").hide()
        $("#convBtn").hide()
        $("#selectedPriUnit").text('1 ' + data.punitname)
        $("#selectedPriUnit2R").text('RPrice/' + data.punitname)
        $("#selectedPriUnit2D").text('DPrice/' + data.punitname)
        $("#priUnit_price_r").val(data.primaryunitrater)
        $("#priUnit_price_d").val(data.primaryunitrated)
        $("#selectedSecUnit").text(data.sunitname)
        $("#selectedSecUnit2R").text('RPrice/' + data.sunitname)
        $("#selectedSecUnit2D").text('DPrice/' + data.sunitname)
        $("#secUnit_price_r").val(data.secondaryunitrater)
        $("#secUnit_price_d").val(data.secondaryunitrated)
        $("#no_of_pcs").val(data.noofpcs)
        $(".unitpricer, .unitpriced").show()
        $(".conversion").show()
        $('.select2').select2({ width: "100%", tags: true, dropdownParent: $('#modal') });
        $("#modal").modal("show")
    }
    /* Add && Show functions end*/
});