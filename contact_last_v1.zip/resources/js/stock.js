$(document).ready(function() {    
    $("#searchProduct").on("keyup", function () {
        $(this).attr("placeholder", "Search");
        var value = $(this).val().toLowerCase();
        $("#productList .list-item").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1) //this to show if there is value
            //$(".no-result").toggle($(this).text().toLowerCase().indexOf(value) === -1) //if no values then show this div
        });
    });//search function end here
    var productId='',stockTable,stockType
    var className 
  	load_table(moment('01-01-2021'),moment());
	/*------- Debit Note DataTable Start Here -------*/
  	function load_table(sDate,eDate) {
  		stockTable = $("#stock_table_trnx").DataTable({
		    processing: true,
		    serverSide: true,
		    order: [[1, 'desc']],
		    lengthMenu: [
		        [10, 25, 50,100, -1],
		        [10, 25, 50,100, 'All'],
		    ],
		    buttons: [{ extend: 'csv', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7,8] } },
		        { extend: 'excel', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7,8] } },
		        { extend: 'pdf', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7,8] } },
		        { extend: 'print', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7,8] } }
		    ],
		    ajax: {
		        url: routes.index,
		        dataType: "json",
                data:{ startDate: sDate.format('YYYY-MM-DD'), endDate: eDate.format('YYYY-MM-DD') ,productId:productId},                
		    },
		    columns: [{
		      	data: "stock_type",
		      	name: "stock_type",
		      	render: function(data) {
		      		if(data == 1){
		      			className = 'text-primary'
		      			stockType = '<span class="item-amount text-sm text-color text-primary text-capitalize">purchase</span>';		      			
		      		}
		      		if(data == '1R'){
		      			className = 'text-info'
		      			stockType = '<span class="item-amount text-sm text-color text-info text-capitalize">purchase return</span>';		      			
		      		}
		      		if(data == 2){
		      			className = 'text-danger'
		      			stockType = '<span class="item-amount text-sm text-color text-danger text-capitalize">sale</span>'	      			
		      		}
		      		if(data == '2R'){
		      			className = 'text-warning'
		      			stockType = '<span class="item-amount text-sm text-color text-warning text-capitalize">sale return</span>';		      			
		      		}
		      		return stockType;
		      	}
		  	},{
		        data: "order_date",
		      	name: "order_date",
		      	render: function(data, type, full, meta) {
		          	return '<span class="item-amount text-sm text-color '+className+' text-capitalize">' + moment(data).format('DD-MM-YYYY') + '</span>'
		      	}
		  	},{
		      	data: "delivery_date",
		      	name: "delivery_date",
		      	render: function(data, type, full, meta) {
		          	return '<span class="item-amount text-sm text-color '+className+' text-capitalize">' + moment(data).format('DD-MM-YYYY') + '</span>'
		        }              
		      	     
		  	}, {
		        data: "transaction",
		      	name: "transaction",
		  	},{
		      	data: "qty",
		      	name: "qty",
		      	render: function(data) {
			        return '<span class="item-amount text-sm text-color '+className+' text-capitalize">' + data + '</span>'
		      	}
		  	},{
		      	data: "unit_name",
		      	name: "unit_name",
		      	render: function(data) {
		        	return '<span class="item-amount text-sm text-color '+className+' text-capitalize">' + data + '</span>'
		      	}
		  	},{
		      	data: "unit_price",
		      	name: "unit_price",
		      	render: function(data) {
		        	return '<span class="item-amount text-sm text-color '+className+' text-capitalize"><span class="inr-sign" style="font-weight: 400; font-size: 13px;"></span>'+ new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data) + '</span>'
		      	}
		  	},{
		      	data: "amount",
		      	name: "amount",
		      	render: function(data) {
		        	return '<span class="item-amount text-sm text-color '+className+' text-capitalize"><span class="inr-sign" style="font-weight: 400; font-size: 13px;"></span>'+ new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data.toString().replace('-',' ')) + '</span>'
		      	}
		  	},{
		      	data: "stock_stat",
		      	name: "stock_stat",
		      	render: function(data) {
		        	if (data == 0) {
			          	return '<span class="item-amount text-sm text-color '+className+' text-capitalize">unpaid</span>'
			        }
			        if (data == 1) {
			          	return '<span class="iitem-amount text-sm text-color '+className+' text-capitalize">partial</span>'
			        }
			        if (data == 2) {
			          	return '<span class="iitem-amount text-sm text-color '+className+' text-capitalize">paid</span>'
			        }
		      	}
		  	},{
		      	data: "action",
		      	name: "action",		      	
		  	}],
		});
  		
  	}
	/*------ Debit Note dataTable end here ------*/
	/*------ Export Start ------*/
	$(document).on('click', ".export", function() {
	    var btn = $(this).attr('id').toString()
	    stockTable.button(btn).trigger();
	})
	/*------ Export End -------*/
	/*------ On Date Change Load Table Start -------*/
  	$(document).on('change','input[name="date_range"]',function(event){
        stockTable.destroy();
        load_table(startDate,endDate);
    }) 
	/*------ On Date Change Load Table End -------*/

    /*----- Search product -----*/
    $(document).on("keyup","#searchProduct", function() {
        var value = $(this).val().toLowerCase();
        $("#productList .item").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });  
    /*----- Search product -----*/

    $(document).on('click','a.product',function(e){
        e.preventDefault()
        productId = $(this).attr('id');
        let stockValue = 0
        $(".addedrow").remove()
        $('.product-name').text($(this).data('name'))
        $('.sale-price').html('<div class="text-highlight text-md sale-price text-danger"><span style="font-weight: 400; font-size: 18px;">&#8377;</span> 0.00</div>')
        $('.purchase-price').html('<div class="text-highlight text-md sale-price text-primary"><span style="font-weight: 400; font-size: 18px;">&#8377;</span> 0.00</div>')
        $('.stock-qty').text("0/0")
        $('.stock-val').html('<div class="text-highlight text-md sale-price text-info"><span style="font-weight: 400; font-size: 18px;">&#8377;</span> 0.00</div>')
        
        for(count=0; count < products.length; count++){
            if(productId == products[count].product_id){
                $('.sale-price').html('<div class="text-highlight text-md sale-price text-danger">'+
                    '<span style="font-weight: 400; font-size: 18px;" class="inr-sign"></span>'+
                    new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(products[count].product_r_mrp)+'/'+
                    new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(products[count].product_d_mrp)+' '+
                    '</div>')

                $('.purchase-price').html('<div class="text-highlight text-md text-primary"><span style="font-weight: 400; font-size: 18px;" class="inr-sign"></span>'+
                    new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(products[count].primary_pp_for_stock)+'/'+
                    new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(products[count].secondary_pp_for_stock)+''+
                    '</div>')
                $('.stock-qty').text(products[count].in_hand_stock_primary+'/'+products[count].in_hand_stock_second+'(pcs)')
                $('.stock-val').html('<div class="text-highlight text-md text-info sale-price"><span style="font-weight: 400; font-size: 18px;" class="inr-sign"></span>'+
                    new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(products[count].stock_value)+'</div>')
            }   
        }
        stockTable.destroy();
        load_table(moment('01-01-2021'),moment())
    })// on click show transaction
});