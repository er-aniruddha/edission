$(document).ready(function() {
    var purchaseTable
    load_table(startDate,endDate);
    /* Purchase DataTable Start Here*/
    function load_table(startDate,endDate) {
        purchaseTable = $("#purchase_bill_table").DataTable({
            processing: true,
            serverSide: true,
            responsive: true,
            lengthMenu: [
                [10, 25, 50,100, -1],
                [10, 25, 50,100, 'All'],
            ],
            buttons: [{ extend: 'csv', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7,8,9 ]}},
                { extend: 'excel', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7,8,9 ]}},
                { extend: 'pdf', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7,8,9 ]}},
                { extend: 'print', exportOptions: { columns: [ 0, 1, 2, 3,4,5,6,7,8,9 ]}}
            ],
            ajax: {
                url: routes.index,
                dataType: "json",
                data:{ startDate: startDate.format('YYYY-MM-DD'), endDate: endDate.format('YYYY-MM-DD')},
            },
            
            columns: [{
                data: "DT_RowIndex",
                name: "DT_RowIndex",
                render: function(data){
                    return '<small class="text-muted">'+data+'</small>'
                }
            }, {
                data: "po_id",
                name: "po_id",
                render: function(data, type, full, meta) {
                    return '<a href="#" class="item-company ajax h-1x" data-pjax-state="">CPO-'+data+'</a>'
                },      
            }, {
                data: "order_date",
                name: "order_date",
                render: function(data){
                    return '<span class="item-amount d-none d-sm-block text-sm">'+moment(data).format('DD-MM-YYYY')+'</span>'
                }
            },{
                data: "delivery_date",
                name: "delivery_date",
                render: function(data){
                    if(!data){
                        return '<span class="item-badge badge text-uppercase bg-warning">Not Deliverd</span>';
                    }
                    else{
                        return '<span class="item-amount d-none d-sm-block text-sm">'+moment(data).format('DD-MM-YYYY')+'</span>'
                    }
                }
            },{
                data: "supplier_name",
                name: "supplier_name",
                render: function(data){
                    return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">'+data+'</span>'
                }
            },{
                data: "payment_type",
                name: "payment_type",
                render: function(data){
                    if(data == 1){
                        return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Cash</span>'
                    }
                    if(data == 2){
                        return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Online</span>'
                    }
                    if(data == 3){
                        return '<span class="item-amount d-none d-sm-block text-sm text-capitalize">Cheque</span>'
                    }
                    if(data == 4){
                        return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-danger">No Payment</span>'
                    }
                }
            },{
                data: "total",
                name: "total",
                render: function(data){
                    return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                }
            },{
                data: "prev_balance",
                name: "prev_balance",
                render: function(data){
                    return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                }
            },{
                data: "advance",
                name: "advance",
                render: function(data){
                    return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                }
            }, {
                data: "PO_balance",
                name: "PO_balance",
                render: function(data){
                    return '<span class="item-amount d-none d-sm-block text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                }
            },{
                data: "payment_status",
                name: "payment_status",
                render: function(data){
                    if(data == 0){
                        return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-danger">Unpaid</span>'
                    }
                    if(data == 1){
                        return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-warning">Partial</span>'
                    }
                    if(data == 2){
                        return '<span class="item-amount d-none d-sm-block text-sm text-capitalize text-success">Paid</span>'
                    }
                }
            }, {
                data: "status",
                name: "status"
            }, {
                data: "action",
                name: "action"
            }],
            "footerCallback":function(row, data){
                var api = this.api(), data;
                var intVal = function(i){
                  return typeof i === 'string' ?
                  i.replace(/[\$,]/g, '')*1 :
                  typeof i === 'number' ?
                  i:0;
                };
                
                var column = 6;
                while(column < 10){
               total = api.column( column, {page: 'current'} )
                .data().reduce( function (a,b){
                  return intVal(a) + intVal(b);
                }, 0)
                $(api.column(column).footer()).html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(total));
                    column++;
                }
            }

        });
    }
    /*------ Purchase Bill dataTable end here ------*/
    /*------ Export Start ------*/
    $(document).on('click',".export",function(){
        var btn = $(this).attr('id').toString()
        purchaseTable.button(btn).trigger();
    })
    /*------ Export End -------*/ 
    /*----- On print Button click start -----*/
    $(document).on('click','#printBtn',function(){
        document.title = $(".po_id").text();
        window.print();
    })
    /*----- On print Button click start -----*/
    $(document).on('change','input[name="date_range"]',function(event){
        purchaseTable.destroy();
        load_table(startDate,endDate);
    }) 
})