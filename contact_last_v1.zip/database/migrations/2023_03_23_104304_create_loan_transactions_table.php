<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLoanTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('loan_transactions', function (Blueprint $table) {
            $table->id();
            $table->string("loan_trnx_id");
            $table->string("loan_ac_id");
            $table->date("bill_date");
            $table->date("payment_date");
            $table->float("prev_loan_balance"); // previous amount
            $table->float("interest_paid");
            $table->float("principal_paid");
            $table->float("total_emi");
            $table->float("paid_emi");
            $table->float("loan_balance");
            $table->date("paid_date");
            $table->integer("status");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('loan_transactions');
    }
}
