<?php $__env->startSection('page_title','Loan Accounts'); ?>
<!-- CONTENT START -->
<div id="content" class="flex">
    <div class="d-flex flex fixed-content">
        <div class="aside aside-sm" id="content-aside">
            <div class="d-flex flex-column w-xl modal-dialog bg-body" id="chat-nav">
                <div class="navbar">
                    <span class="text-md mx-2">Loan Accounts</span>
                    <div class="dropdown dropright">
                        <button class="btn btn-sm btn-raised btn-wave blue" id="addLoanAc" data-toggle="modal" data-target="#loanAccountModal">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-credit-card mx-2"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>
                            Add Loan AC
                        </button>
                    </div>
                </div>
                <div class="scrollable hover">
                    <div class="sidenav p-2">
                        <nav class="nav-active-text-primary" data-nav="">
                            <ul class="nav" id="loanAcList">
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex flex pr-md-3">
            <div class="d-flex flex-column flex mt-5 mb-md-3">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="loan_trnx_table">
                        <thead>
                            <tr>
                                <th><span class="text-muted">SL NO</span></th>
                                <th><span class="text-muted">A/c Name</span></th>
                                <th><span class="text-muted">Transction Id</span></th>
                                <th><span class="text-muted">Bill Date</span></th>
                                <th><span class="text-muted">Payment/Due Date</span></th>
                                <th><span class="text-muted">EMI</span></th>
                                <th><span class="text-muted">Paid Amount</span></th>
                                <th><span class="text-muted">Balance</span></th>
                                <th><span class="text-muted">Paid Date</span></th>
                                <th><span class="text-muted">Status</span></th>
                                <th><span class="text-muted">Action</span></th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- CONTENT END -->
</div>
<?php echo $__env->make('portal.loan.account_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('portal.loan.paid_emi_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
// global app configuration object
var routes = {
    index: "<?php echo e(route('loan.account.index')); ?>",
    compute: "<?php echo e(route('loan.compute')); ?>",
    create: "<?php echo e(route('loan.account.create')); ?>",
    closeView: "<?php echo e(route('loan.account.close.view')); ?>",
    confimClose: "<?php echo e(route('loan.account.close.confirm')); ?>",
    edit: "<?php echo e(route('loan.account.edit')); ?>",
    paidEmi: "<?php echo e(route('loan.transaction.paidEmi')); ?>",
};
var loanaccounts = <?php echo json_encode($loanaccounts, 15, 512) ?>
// All the vaiables are required for end
</script>
<script type="text/javascript" src="<?php echo e(asset('resources/js/loan/loan.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('resources/js/loan/loan_trnx.js')); ?>"></script><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/loan/admin/index.blade.php ENDPATH**/ ?>