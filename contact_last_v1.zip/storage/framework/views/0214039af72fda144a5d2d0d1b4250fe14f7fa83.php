<div id="createAndEditModal" class="modal fade" aria-modal="true" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog text-dark modal-lg" style="max-width: 95%;">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white"></h5>                
            </div>
            <div class="modal-body p-4">
                <form id="createAndEditForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row mb-3">
                        <label class="col-sm-2 col-form-label">Customer</label>
                        <div class="col-sm-10">
                            <select class="form-control select2 customer text-capitalize" name="customer_id" id="customer_id">
                                
                            </select>
                            <span class="text-danger text-sm" id="customer_id_error"></span>
                        </div>
                    </div>
                    <table class="table-bordered table table-theme table-row v-middle" id="tdFormRow">
                        <thead>
                            <tr>
                                <th style="width: 30%;">Item Name</th>
                                <th style="width: 10%;">Unit Name</th>
                                <th style="width: 10%;">Quantity</th>
                                <th style="width: 20%;">MRP</th>
                                <th style="width: 10%;">Discount</th>
                                <th style="width: 20%;">Amount</th>
                                <th>
                                    <a href="javascript:void(0)" class="addRow">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
                                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                            <line x1="12" y1="8" x2="12" y2="16"></line>
                                            <line x1="8" y1="12" x2="16" y2="12"></line>
                                        </svg>
                                    </a>
                                </th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group mb-3">
                                <label class="text-muted">Payment Type</label>
                                <select class="form-control col-sm-8" name="payment_type" id="payment_type" tabindex="-1" aria-hidden="true">
                                    <option value="" selected="">Select an option</option>
                                    <option value="1">Cash</option>
                                    <option value="2">Online</option>
                                    <option value="3">Cheque</option>
                                </select>
                                <span class="text-danger text-sm" id="payment_type_error"></span>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Order Date</label>
                                <div class="col-sm-9">
                                    <input data-provide="datepicker" id="order_date" name="order_date" type="text" class="form-control date" placeholder="Date">
                                    <span class="text-danger text-sm" id="order_date_error"></span>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Remarks</label>
                                <div class="col-sm-9">
                                    <textarea id="remarks" name="remarks" class="form-control" rows="3"></textarea>
                                    <span class="text-danger text-sm" id="remarks_error"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4" style="left: 50%;">
                            <div class="input-group mb-3" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">Round Off</span>
                                </div>
                                <input type="number" class="form-control" placeholder="0.00" name="round_off" id="round_off" value="0.00" >
                            </div>
                            <div class="input-group mb-3" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">Delivery Charges</span>
                                </div>
                                <input type="number" class="form-control" placeholder="0.00" name="delivery_charges" id="delivery_charges" value="0.00" >
                            </div>
                            <div class="input-group mb-3" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">GST Amount</span>
                                </div>
                                <input type="number" class="form-control" min="0" placeholder="0.00" name="gst_amount" id="gst_amount" value="0.00" >
                            </div>
                            <div class="input-group mb-3" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">Total</span>
                                </div>
                                <input type="number" class="form-control total" min="0" placeholder="0.00" name="total" id="total"  value="0.00" readonly="">
                            </div>
                            <div class="input-group mb-3" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">Received</span>
                                </div>
                                <input type="number" class="form-control received" min="0" placeholder="0.00" name="received" id="received" value="0.00" >
                            </div>
                            <div class="input-group" style="width: 50%">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="width: 100px;">Balance</span>
                                </div>
                                <input type="number" class="form-control" min="0" placeholder="0.00" name="balance" id="balance"  value="0.00" readonly="">
                            </div>
                            <span class="text-sm prev_bal" style="color: #f44336; font-weight:600;"></span>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="sale_trnx_id" id="sale_trnx_id">
                        <input type="hidden" name="prev_balance" id="prev_balance">
                        <input type="button" class="btn btn-outline-dark" data-dismiss="modal" value="Close">
                        <button class="btn btn-primary" id="saveBtn">Save Changes</button>
                        <button class="btn btn-primary hide" id="editBtn">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.modal-content -->
</div><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/sale_order/createAndEditModal.blade.php ENDPATH**/ ?>