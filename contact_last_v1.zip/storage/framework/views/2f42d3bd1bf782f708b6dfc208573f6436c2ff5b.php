<?php echo $__env->make('portal.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('pageTitle','Verify'); ?>

<div id="ajax-content" class="dark h-v d-flex flex align-items-center">
    <div class="mx-auto w-xl w-auto-xs animate fadeIn text-center">
        <div class="mb-3">
            <!-- <img src="../assets/img/a3.jpg" class="w-72 circle">
            <div class="mt-3 font-bold">Jacqueline Reid</div> -->
            <!-- brand --> 
            <a href="<?php echo e(url('/')); ?>" class="navbar-brand align-self-center">
                <img src="<?php echo e(asset('public/portal/images/logo.png')); ?>" alt="..."> 
                <!-- span class="hidden-folded d-inline l-s-n-1x align-self-center">Omnipresenceway</span> --> 
            </a>
            <!-- / brand -->
        </div>
        <form method="POST" action="<?php echo e(route('password.confirm')); ?>">
            <?php echo csrf_field(); ?>
            <div class="md-form-group">
                <input type="password" class="md-input text-center <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email"
                    name="email" value="<?php echo e($email ?? old('email')); ?>" autocomplete="email" autofocus>
                <label class="d-block w-100">Enter New Password</label>
    
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mt-3">
                <button type="submit" class="btn btn-rounded btn-primary">Confirm Password</button>
                <?php if(Route::has('password.request')): ?>
                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                    <?php echo e(__('Forgot Your Password?')); ?>

                </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>


<?php echo $__env->make('portal.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\anwesh\portal\resources\views\portal\auth\passwords\confirm.blade.php ENDPATH**/ ?>