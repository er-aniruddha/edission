<div id="modal" class="modal fade" data-backdrop="true" style="display: none; padding-right: 17px;" aria-modal="true">
    <div class="modal-dialog modal-lg-size">
        <div class="modal-content box-shadow mb-4">
            <div class="modal-header">
                <h5 class="modal-title"></h5>
            </div>
            <div class="modal-body p-4">
                <form id="productForm" method="POST">
                	<?php echo csrf_field(); ?>
                    <div class="md-form-group float-label">
                    	<input class="md-input" value="" name="product_name" id="product_name" onkeyup="this.setAttribute('value', this.value);" required="">
                    	<label>Product Name</label>
                    	<span class="text-danger mr-2" id="product_name_error"></span>
                    </div>

                    <div class="md-form-group float-label">
                    	<input class="md-input" value="" id="product_desc" name="product_desc" onkeyup="this.setAttribute('value', this.value);" required="">
                    	<label>Product Description</label>
                    	<span class="text-danger mr-2" id="product_desc_error"></span>
                    </div>

                    

                    <div class="form-group">
                        <label class="text-muted">Brand</label>
                        <select class="form-control" name="brand_id" id="brand_id" 
                        tabindex="-1" aria-hidden="true">
                            <option value="0" selected>Select Brand</option>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($brand->brand_stat == 1): ?>
                                <option value="<?php echo e($brand->brand_id); ?>"><?php echo e($brand->brand_name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($brand->brand_id); ?>" disabled="disabled"><?php echo e($brand->brand_name); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                        </select>
                        <span class="text-danger mr-2" id="brand_id_error"></span>
                    </div>    

                    <div class="form-group">
                    	<label class="text-muted">Product Image</label>                    	
                		<div class="custom-file">
                			<input type="file" class="custom-file-input" id="image" name="image">
                            <span class="text-danger mr-2" id="image_error"></span>
                			<label class="custom-file-label" for="image">Choose file</label>
                		</div>    
                        <img id="show-img" style="padding: 10px; width: 100px;" />              	
                    </div>	

                     <div class="form-group">
                        <div class="row">
                            <div class="col-md-6">
                            	<div class="form-group">
                            		<label class="text-muted">Product Type</label>
                                    <select class="form-control" name="pro_type" id="pro_type" tabindex="-1" aria-hidden="true">
                                        <option value="0" selected>Select Product Type</option>
                                        <option value="Manufacturing">Manufacturing</option>
                                        <option value="Purchasing">Purchasing</option>
                                    </select>	                                    
                            	</div>  
                            	<span class="text-danger mr-2" id="pro_type_error"></span>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="text-muted" style="margin-right: 50px;">Publication Status</label>
                                    <label class="ui-switch ui-switch-md info m-t-xs" style="top:5px;">
                                        <input type="checkbox" id="checkbox"> <i></i>
                                    </label>
                                    <input type="hidden" name="product_stat" id="product_stat" value="0">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <input type="hidden" name="product_id" id="product_id"/>
                        <input type="hidden" name="image_update" id="image-update"> 
                    	<button class="btn btn-outline-dark" data-dismiss="modal" onclick=" 
                        document.getElementById('show-img').removeAttribute('src'); this.form.reset()">Close</button> 
                    	<button class="btn btn-primary" id="addBtn">Save Changes</button>
                    	<button class="btn btn-primary hide" id="editBtn">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.modal-content -->
</div><?php /**PATH C:\xampp\htdocs\edission\contact\resources\views/portal/product/modal.blade.php ENDPATH**/ ?>