<!-- Confirm Modal -->
<div id="descModal" class="modal fade" data-backdrop="true" style="padding-right: 17px;" aria-modal="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title text-md">Product details</div>
                <button class="close" data-dismiss="modal">×</button>
            </div>
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="form-group">
                            <label>Product Name</label>
                            <input type="text" class="form-control" placeholder="Name" id="product_name">
                        </div>
                        <div class="form-group">
                            <label>Category Name</label>
                            <input type="text" class="form-control" id="category_name">
                        </div>
                        <div class="form-group">
                            <label>Your website</label>
                            <input type="url" class="form-control" id="">
                        </div>
                        <div class="form-group">
                            <label>Description</label>
                            <textarea class="form-control" rows="6" data-minwords="6" required=""
                                placeholder="Type your message">
                            </textarea>
                        </div>
                    </div>
                </div>
            </div>
            <input type="hidden" name="product_id" id="product_id">
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
            </div>
        </div><!-- /.modal-content -->
    </div>
</div><?php /**PATH C:\xampp\htdocs\contact\resources\views/portal/product/descriptionModal.blade.php ENDPATH**/ ?>