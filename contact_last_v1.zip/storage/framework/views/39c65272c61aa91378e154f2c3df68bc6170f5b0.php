<div id="paidEmiModal" class="modal fade"  aria-modal="true" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog text-dark">
        <div class="modal-content">
            <div class="modal-header bg-secondary">
                <h5 class="modal-title text-white"></h5><button class="close" data-dismiss="modal">×</button>
            </div>
            <div class="modal-body">
                <form id="loanTrnxForm" method="POST">  
                    <?php echo csrf_field(); ?>  
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Account Name</label>
                        <div class="col-sm-9">
                            <input id="trnx_ac_name" name="trnx_ac_name" type="text" class="form-control text-capitalize" placeholder="Account Name" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Bill Date</label>
                        <div class="col-sm-9">
                            <input id="bill_date" name="bill_date" type="text" class="form-control" placeholder="Bill Date" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Payment Date</label>
                        <div class="col-sm-9">
                            <input id="payment_date" name="payment_date" type="text" class="form-control" placeholder="Payment Date" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">EMI</label>
                        <div class="col-sm-9">
                            <input id="trnx_emi" name="trnx_emi" type="number" class="form-control" placeholder="EMI" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Paid\Received</label>
                        <div class="col-sm-9">
                            <input id="paid_amount" name="paid_amount" type="text" class="form-control" placeholder="Paid\Received">
                            <span class="text-danger" id="paid_amount_error"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Paid Date</label>
                        <div class="col-sm-9">
                            <input data-provide="datepicker" id="paid_date" name="date" type="text" class="form-control date" placeholder="Date">
                            <span class="text-danger" id="paid_date_error"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Remarks</label>
                        <div class="col-sm-9">
                            <input id="trnx_remarks" name="trnx_remarks" type="text" class="form-control" placeholder="Remarks">
                            <span class="text-danger" id="trnx_remarks_error"></span>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="loan_trnx_id" id="loan_trnx_id">
                    	<input type="hidden" name="loan_ac_id" id="emi_loan_ac_id">
                        <button class="btn light-blue text-white btn-raised btn-wave" id="paidBtn">Paid</button>
                        <button class="btn red text-white btn-raised btn-wave" id="loanClsBtn">CLose Loan</button>
                    </div>   
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
</div><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/loan/paid_emi_modal.blade.php ENDPATH**/ ?>