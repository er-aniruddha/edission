<div id="loanAccountModal" class="modal fade" aria-modal="true" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog text-dark modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white"></h5>   
                <button class="close" data-dismiss="modal">×</button>          
            </div>
            <div class="modal-body p-4">
                <form id="loanForm">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <table id="loanInfoTable" width="100%">
                                <tr>
                                    <td colspan="3">
                                        <b>Enter Loan Information:</b>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        &nbsp;
                                    </td>
                                    <td width="48%">
                                        Account Name:<span class="err">*</span>
                                    </td>
                                    <td>
                                        <input id="account_name" name="account_name" type="text" class="form-control text-capitalize" placeholder="Diplay A/C name">
                                        <span class="text-danger" id="account_name_error"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        &nbsp;
                                    </td>
                                    <td>
                                        Loan Amount: 
                                        <span class="err">*</span>
                                    </td>
                                    <td>
                                        <input id="loan_amount" name="loan_amount" type="number" class="form-control" placeholder="Loan Amount">
                                        <span class="text-danger" id="loan_amount_error"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        &nbsp;
                                    </td>
                                    <td>
                                        Rate of Interest: 
                                        <span class="err">*</span>
                                    </td>
                                    <td>
                                        <input id="interest_rate" name="interest_rate" type="number" class="form-control" placeholder="Interest Rate" >
                                        <span class="text-danger" id="interest_rate_error"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        &nbsp;
                                    </td>
                                    <td>
                                       Tenure: 
                                        <span class="err">*</span>
                                    </td>
                                    <td>
                                        <input id="year" name="year" type="number" class="form-control" placeholder="Year" oninput="this.value = Math.round(this.value);" minlength="1" min="1">
                                        <input id="month" name="month" type="number" class="form-control" placeholder="Month" oninput="this.value = Math.round(this.value);">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        &nbsp;
                                    </td>
                                    <td>
                                        Start Date: 
                                        <span class="err">*</span>
                                    </td>
                                    <td>
                                        <input data-provide="datepicker" id="date" name="date" type="text" class="form-control date" placeholder="Date">
                                        <span class="text-danger" id="date_error"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        &nbsp;
                                    </td>
                                    <td>
                                        Remarks:
                                    </td>
                                    <td>
                                       <input id="remarks" name="remarks" type="text" class="form-control" placeholder="Remarks">
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="3">
                                        <button id="computeBtn" class="btn btn-primary" style="float: right;">Compute</button>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-striped table-sm" id="loanComputedTable" width="100%">
                                <tr>
                                    <td colspan="3">
                                        <b class="ml-2">Calculated EMI & Others:</b>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <b class="ml-2">Account Name: </b>
                                    </td>
                                    <td>
                                        <p class="m-2 text-capitalize" style="text-align: end;" id="c_account_name">NA</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <b class="ml-2">Loan Amount: </b>
                                    </td>
                                    <td>
                                        <p class="m-2 inr-sign" style="text-align: end;" id="c_loan_amount">0.00</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <b class="ml-2">Rate of Interest: </b>
                                    </td>
                                    <td>
                                        <p class="m-2" style="text-align: end;" id="c_interest_rate">0.00%</p>                      
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                       <b class="ml-2">Tenure(month): </b>
                                    </td>
                                    <td>
                                        <p class="m-2" style="text-align: end;" id="c_month">0</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <b class="ml-2">Start Date: </b>
                                    </td>
                                    <td>
                                        <p class="m-2" style="text-align: end;" id="c_date">00-00-0000</p>
                                    </td>
                                </tr>                                
                                <tr>
                                    <td>
                                        <b class="ml-2">Monthly EMI:</b>
                                    </td>
                                    <td>
                                        <p class="m-2 inr-sign" style="text-align: end;" id="c_emi">0.00</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <b class="ml-2">Total Interest: </b>
                                    </td>
                                    <td>
                                        <p class="m-2 inr-sign" style="text-align: end;" id="c_total_int">0.00</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <b class="ml-2">Total Payment:</b>
                                    </td>
                                    <td>
                                        <p class="m-2 inr-sign" style="text-align: end;" id="total_payment">0.00</p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="t-wrp">
                        <table class="table-bordered table table-theme table-row v-middle" id="monthWiseTable">
                            <thead >
                                <tr>
                                    <th>#</th>
                                    <th>Bill Date</th>
                                    <th>Payment/Due Date</th>
                                    <th>Principal</th>
                                    <th>Interest</th>
                                    <th>Total Payment</th>
                                    <th>Ending Balance</th>
                                </tr>
                            </thead>
                            <tbody>                                
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="footer-form">
                        <input type="hidden" name="loan_ac_id" id="loan_ac_id"/>       
                        <div class="flex">
                            <div class="row">
                                <div class="col-md-6 d-flex justify-content-center" data-dismiss="modal" style="width: 80%;">
                                     <button class="btn btn-raised btn-wave mb-2 w-xs btn-outline-dark" data-dismiss="modal">Cancel</button>   
                                    
                                </div>                                
                                <div class="col-md-6 d-flex justify-content-center" style="width: 80%;">
                                    <button class="btn btn-raised btn-wave mb-2 w-xs blue text-white" id="addBtn">Save</button>
                                    <button class="btn btn-raised btn-wave mb-2 w-xs deep-orange text-white hide" id="editBtn">Update</button>
                                    <button class="btn btn-raised btn-wave mb-2 ml-4 grey text-white hide" id="closeLoan">Close Loan</button>
                                </div>
                            </div>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
    <!-- /.modal-content -->
</div><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/loan/account_modal.blade.php ENDPATH**/ ?>