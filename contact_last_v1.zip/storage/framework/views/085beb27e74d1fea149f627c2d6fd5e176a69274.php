<div id="createModal" class="modal fade" data-backdrop="true" style="display: none; padding-right: 17px;" aria-modal="true">
	<div class="modal-dialog modal-lg-size">
		<div class="modal-content">
			<div class="modal-header">
				<div class="modal-title text-md">Add Product</div>
				<button class="close" data-dismiss="modal">×</button>
			</div>
			<div class="modal-body">
				<div class="col-md-12">
					<strong>Product Type</strong>
					<div style="float: right; display: inline-flex; position: relative;">
						<div class="radio 1" style="margin-right: 10px;">
							<label class="ui-check">
								<input type="radio" name="a" value="1" id="radio1"> 
								<i class="dark-white"></i> Manufacturing
							</label>
						</div>
						<div class="radio 2">
							<label class="ui-check">
								<input type="radio" name="a" value="2" id="radio2"> 
								<i class="dark-white"></i> Purchasing
							</label>
						</div>
					</div>
						<div class="manufacturing hide">
							<div class="col-sm-12">
								<div class="md-form-group float-label">
									<input type="text" class="md-input" value="" onkeyup="this.setAttribute('value', this.value);" required="" name="product_name" id="product_name">
									<label>Product Name</label>
								</div>
								<span class="text-danger mr-2" id="product_name_error"></span>
							</div>
							<div class="col-sm-12">
								<div class="md-form-group float-label">
									<input type="text" class="md-input" value="" onkeyup="this.setAttribute('value', this.value);" required="" name="product_descx" id="product_descx">
									<label>Product Description</label>
								</div>
								<span class="text-danger mr-2" id="product_desc_error"></span>
							</div>
							<div class="col-sm-12">
								<div class="md-form-group float-label">
									<input type="text" class="md-input" value="Manufacturing" onkeyup="this.setAttribute('value', this.value);" readonly>
									<label>Product Type</label>
								</div>
							</div>
							<div class="col-sm-12">
		                        <label class="text-muted">Brand Name</label>
			                        <select class="form-control select2-hidden-accessible" name="barbd_id" id="barbd_id" 
			                        tabindex="-1" aria-hidden="true">
			                            <option value="0" selected>Select Route</option>	
		                                <option value="Eddission">Eddission</option>  
		                                <option value="Phillips">Phillips</option>              
			                        </select>
		                        <span class="text-danger mr-2" id="barbd_id_error"></span>

		                    </div>
							<div class="col-sm-12">
								<label class="text-muted" style="margin-right: 50px;">Publication Status</label>
									
								<label class="ui-switch ui-switch-md info m-t-xs" style="top:5px;">
									<input type="checkbox" id="statCheck1"> <i></i>
								</label>
								
							</div>
						</div>
				<div class="purchasing hide">
							<div class="col-sm-12">
								<div class="md-form-group float-label">
									<input type="text" class="md-input" value="" onkeyup="this.setAttribute('value', this.value);" required="" name="product_name" id="product_name">
									<label>Product Name</label>
								</div>
								<span class="text-danger mr-2" id="product_name_error"></span>
							</div>
							<div class="col-sm-12">
								<div class="md-form-group float-label">
									<input type="text" class="md-input" value="" onkeyup="this.setAttribute('value', this.value);" required="" name="product_descx" id="product_descx">
									<label>Product Description</label>
								</div>
								<span class="text-danger mr-2" id="product_desc_error"></span>
							</div>
							<div class="col-sm-12">
								<div class="md-form-group float-label">
									<input type="text" class="md-input" value="Purchasing" onkeyup="this.setAttribute('value', this.value);" readonly>
									<label>Product Type</label>
								</div>
							</div>
							<div class="col-sm-12">
		                        <label class="text-muted">Brand Name</label>
			                        <select class="form-control select2-hidden-accessible" name="barbd_id" id="barbd_id" 
			                        tabindex="-1" aria-hidden="true">
			                            <option value="0" selected>Select Route</option>	
		                                <option value="Eddission">Eddission</option>  
		                                <option value="Phillips">Phillips</option>              
			                        </select>
		                        <span class="text-danger mr-2" id="barbd_id_error"></span>

		                    </div>
							<div class="col-sm-12">
								<label class="text-muted" style="margin-right: 50px;">Publication Status</label>
								<label class="ui-switch ui-switch-md info m-t-xs" style="top:5px;">
									<input type="checkbox" id="statCheck2"> <i></i>
								</label>
								
							</div>
						</div>
					</div>

			</div>
			<div class="modal-footer"><button type="button" class="btn btn-light" data-dismiss="modal">Close</button> <button type="button" class="btn btn-primary" data-dismiss="modal">Save Changes</button></div>
		</div>
	</div>		<!-- /.modal-content -->
</div>
<script>
	$(document).ready(function() {
		$('.radio').on('change', 'input.radio', function () {
			$('input.radio').not(this).prop('checked', false);	
		})

		$("#radio1").click(function(event) {
			/* Act on the event */
			$('.manufacturing').show()
			$('.purchasing').hide()
		})

		$("#radio2").click(function(event) {
			/* Act on the event */
			$('.manufacturing').hide()
			$('.purchasing').show()
		})
		  
		$("#statCheck1").click(function(event) {
			/* Act on the event */
			if($('#statCheck1').is(':checked')){
				console.log("checked")
			}
			else{
				console.log("not checked")
			}
			

			// if ($("#statCheck1").prop("checked") == "checked") {
		 //            alert("checked");
		 //      }

		 //      $('input.checkbox').not(this).prop('checked', false);
		})
		

		
		
	});
</script><?php /**PATH C:\xampp\htdocs\contact\resources\views/portal/product/createModal.blade.php ENDPATH**/ ?>