<div id="content" class="flex">
    <div class="">
        <div class="page-hero page-container" id="page-hero">
            <div class="padding d-flex">
                <div class="page-title">
                    <h2 class="text-md text-highlight">Production Costs</h2>
                    <!-- <small class="text-muted">Products</small> -->
                </div>
                <div class="flex"></div>
                <div>
                    <button class="btn btn-raised btn-wave blue text-white add" data-toggle="modal" data-target="#modal">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus">
                            <line x1="12" y1="5" x2="12" y2="19"></line>
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                        </svg>
                        Add
                    </button>
                </div>
            </div>
        </div>
        <div class="page-content page-container" id="page-content">
            <div class="padding">
                <div class="table-responsive">
                    <table class="table table-theme table-row v-middle dataTable no-footer" id="cost_table">
                        <thead>
                            <tr>
                                <th style="width: 26px;">
                                    <span class="text-muted">SL No</span>
                                </th>
                                <th>
                                    <span class="text-muted">Cost Name</span>
                                </th>
                                <th>
                                    <span class="text-muted">Amount</span>
                                </th>
                                <th style="width: 2%;">
                                    <span class="text-muted">Status</span>
                                </th>
                                <th style="width: 17%;">
                                    <span class="text-muted d-none d-sm-block">Action</span>
                                </th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('portal.production_cost.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('portal.layouts.deleteModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<script>
// global app configuration object
var routes = {
    index: "<?php echo e(route('productionCost.index')); ?>",
    create: "<?php echo e(route('cost.create')); ?>",
    update: "<?php echo e(route('cost.update')); ?>",
    delete: "<?php echo e(route('productionCost.delete')); ?>",
};
</script>
<script type="text/javascript" src="<?php echo e(asset('resources/js/cost.production.js')); ?>"></script>
<?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/production_cost/admin/index.blade.php ENDPATH**/ ?>