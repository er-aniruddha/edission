<div id="viewAndConvertModal" class="modal fade" aria-modal="true" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog text-dark modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white"></h5>    
                <button class="close" data-dismiss="modal">×</button>              
            </div>
            <div class="modal-body p-4">
                <form id="viewAndConvertForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row mb-3">
                        <label class="col-sm-2 col-form-label text-dark">Customer</label>
                         <div class="col-sm-10">
                            <input type="text" class="form-control text-capitalize" id="view_customer_name" readonly>
                        </div>
                    </div>
                    <div class="t-wrp">
                        <table class="table-bordered table table-theme table-row v-middle" id="viewRow">
                            <thead>
                                <tr>
                                    <th style="width: 60%;">Item Name</th>
                                    <th style="width: 10%;">Unit Name</th>
                                    <th style="width: 10%;">Quantity</th>
                                    <th style="width: 10%;">Cr. Price</th>
                                    <th style="width: 10%;">Amount</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                    <div class="bottom-calculation">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group mb-3">
                                    <label class="text-muted">Payment Type</label>
                                    <select class="form-control col-sm-8" id="view_payment_type" tabindex="-1" aria-hidden="true">
                                        <option value="" selected="">Select an option</option>
                                        <option value="1">Cash</option>
                                        <option value="2">Online</option>
                                        <option value="3">Cheque</option>
                                        <option value="4">Not Paid</option>
                                    </select>
                                    <span class="text-danger text-sm" id="payment_type_error"></span>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Order Date</label>
                                    <div class="col-sm-9">
                                        <input data-provide="datepicker" id="view_order_date" name="order_date" type="text" class="form-control date" placeholder="Date">
                                        <span class="text-danger text-sm" id="order_date_error"></span>
                                    </div>
                                </div>
                                <div class="form-group row delivery-date">
                                    <label class="col-sm-4 col-form-label">Delivery Date</label>
                                    <div class="col-sm-9">
                                        <input data-provide="datepicker" id="delivery_date" name="delivery_date" type="text" class="form-control date " placeholder="Date">
                                        <span class="text-danger text-sm" id="delivery_date_error"></span>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label">Remarks</label>
                                    <div class="col-sm-9">
                                        <textarea id="view_remarks" name="remarks" class="form-control" rows="3"></textarea>
                                        <span class="text-danger text-sm" id="remarks_error"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4" style="left: 45%;">
                                <div class="input-group mb-3" style="width: 80%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 120px;">Round Off</span>
                                    </div>
                                    <input type="number" class="form-control" placeholder="0.00" name="round_off" id="view_round_off" value="0.00" >
                                </div>
                                <div class="input-group mb-3" style="width: 80%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 120px;">Delivery Charges</span>
                                    </div>
                                    <input type="number" class="form-control" placeholder="0.00" name="delivery_charges" id="view_delivery_charges" value="0.00" >
                                </div>
                                <div class="input-group mb-3" style="width: 80%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 120px;">GST Amount</span>
                                    </div>
                                    <input type="number" class="form-control" min="0" placeholder="0.00" name="gst_amount" id="view_gst_amount" value="0.00" >
                                </div>
                                <div class="input-group mb-3" style="width: 80%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 120px;">Total</span>
                                    </div>
                                    <input type="number" class="form-control total" min="0" placeholder="0.00" name="total" id="view_total"  value="0.00" readonly="">
                                </div>
                                <div class="input-group mb-3" style="width: 80%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 120px;">Paid</span>
                                    </div>
                                    <input type="number" class="form-control paid" min="0" placeholder="0.00" name="paid" id="view_paid" value="0.00" >
                                </div>
                                <div class="input-group" style="width: 80%">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="width: 120px;">Balance</span>
                                    </div>
                                    <input type="number" class="form-control" min="0" placeholder="0.00" name="balance" id="view_balance"  value="0.00" readonly="">
                                </div>
                                <div class="mt-4">
                                    <span class="text-sm prev_bal" style="color: #f44336; font-weight:600;"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="footer-form">
                        <input type="hidden" name="prev_balance" id="view_prev_balance">
                        <input type="hidden" name="cr_trnx_id" id="convert_cr_trnx_id">             
                        <div class="flex">
                            <div class="row">
                                <div class="col-md-6 d-flex justify-content-center" data-dismiss="modal" style="width: 80%;">
                                     <button class="btn btn-raised btn-wave mb-2 w-xs btn-outline-dark" data-dismiss="modal">Cancel</button>   
                                    
                                </div>
                                <div class="col-md-6 d-flex justify-content-center" style="width: 80%;">
                                    <button type="submit" class="btn btn-warning text-uppercase" id="convertDueBtn">Convert to Sale</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.modal-content -->
</div><?php /**PATH /home/u249463727/domains/varneyatechnologies.com/public_html/account/resources/views/portal/credit_note/viewAndConvertModal.blade.php ENDPATH**/ ?>