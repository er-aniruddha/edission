<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Sale;
use App\Models\Portal\Product;
use App\Models\Portal\Unit;
use App\Models\Portal\Brand;
use App\Models\Portal\Customer;
use App\Models\Portal\Stock;
use App\Models\Portal\PaymentIn;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;

class SaleController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        // $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
        //                     ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
        //                     ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
        //                     ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*'))
        //                     ->orderBy('product_id','DESC')
        //                     ->get();
        
        if(request()->ajax())
        {
            $startDate = $_GET['startDate']; 
            $endDate = $_GET['endDate'];

            $saleTable = Sale::where('sale_delivery_date', '>=', $startDate)
                                ->where('sale_delivery_date', '<=', $endDate)
                                ->leftJoin('customers','sales.customer_id','=','customers.customer_id')
                                ->select(array('sales.*','customers.*'))
                                ->where('sale_status',1)
                                ->orderBy('sale_order_date','desc')
                                ->get()->unique('sale_trnx_id'); 

            return datatables()->of($saleTable)  
                ->addColumn('name', function($data){                  
                    $name = '<a href="'. route('customer.details',$data->customer_id).'" class="item-company ajax h-1x text-capitalize" data-pjax-state="">'.$data->f_name.' '.$data->s_name.'</a>
                            <div class="item-mail text-muted h-1x d-none d-sm-block text-capitalize">'.$data->shop_name.'</div>'; 
                  return $name;
                })         
                ->addColumn('action', function($data){                  
                    $action = '<div class="item-action dropdown">
                                    <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right bg-black" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                        <a class="dropdown-item view" data-trnxid="'.$data->sale_trnx_id.'" data-toggle="modal" data-target="#viewModal">See detail </a>
                                    </div>
                                </div>'; 
                  return $action;
                })
                ->addColumn('trnxid', function($data){
                    if( $data->sale_status == 1)
                    {
                        $status = '<span class="item-amount d-none d-sm-block text-sm text-success text-capitalize">INV-'.$data->sale_trnx_id.'</span>';  
                    }
                    else
                    {
                        $status = '<span class="item-amount d-none d-sm-block text-sm text-success text-capitalize">OD-'.$data->sale_trnx_id.'</span>';   
                    }
                    return $status;
                })
                ->addColumn('status', function($data){
                    if( $data->sale_status == 1)
                    {
                        $status = '<span class="item-badge badge text-uppercase bg-success">Order Complete</span>';  
                    }
                    else
                    {
                        $status = '<a class="item-badge badge text-uppercase bg-secondary convert-to-sale" data-trnxid="'.$data->sale_trnx_id.'" data-date="'.$data->order_date.'">Convert to Sale</a>';   
                    }
                    return $status;
                })
                ->addIndexColumn()    
                ->rawColumns(['action','name','trnxid','status'])                   
                ->make(true); 
        } 
        else{
            $sales = Sale::leftJoin('products','sales.item_name','=','products.product_id')
                                ->leftJoin('customers','sales.customer_id','=','customers.customer_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units','sales.unit_id','=','units.unit_id')
                                ->select(array('sales.*','products.*','customers.*','units.*','brands.*'))
                                ->orderBy('sale_id','asc')
                                ->get();           
            return view('portal.sale.index',['sales' =>$sales]);
        }    
    }

    
    public function paymentIndex()
    {
        $payments = PaymentIn::leftJoin('customers','payment_ins.customer_id','customers.customer_id')
                            ->select(array('payment_ins.*','customers.*','payment_ins.balance'))
                            ->orderBy('payment_ins.date','desc')
                            ->get();
        $customers = Customer::where('customers.balance','>',0)->get();  

        if(request()->ajax())
        {
          return datatables()->of($payments)
                ->editColumn('date', function ($data) {
                    return date('d-m-Y', strtotime($data->date));
                })  
                ->addColumn('name', function($data){                  
                    $name = '<a href="#" class="item-company ajax h-1x" data-pjax-state="">'.$data->f_name.' '.$data->s_name.'</a>
                            <div class="item-mail text-muted h-1x d-none d-sm-block">'.$data->shop_name.'</div>'; 
                  return $name;
                })         
                ->addColumn('action', function($data){                  
                    $action = '<div class="item-action dropdown">
                                    <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right bg-black" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                        <a class="dropdown-item view" href="#" id="'.$data->invoice_id.'">See detail </a>
                                        <a class="dropdown-item edit">Edit</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item trash">Delete item</a>
                                    </div>
                                </div>'; 
                  return $action;
                })
                ->addIndexColumn()    
                ->rawColumns(['action','name'])                   
                ->make(true); 
        } 
        else{   
                         
            return view('portal.sale_payment_in.index',['customers' => $customers]);
        }
    }

    
    public function dateRange()
    {
        $startDate = $_GET['startDate']; 
        $endDate = $_GET['endDate'];
        // $x = Carbon::now()->subDays(30);
        //  $totalAmount = Sale::where('sale_delivery_date', '>=', $startDate)->where('sale_delivery_date', '<=', $endDate)->where('sale_status',1)->sum('sale_amount');
        // $totalGst = Sale::where('sale_delivery_date', '>=', $startDate)->where('sale_delivery_date', '<=', $endDate)->where('sale_status',1)->sum('sale_gst_amount');
        // $totalDeliveryChrg = Sale::where('sale_delivery_date', '>=', $startDate)->where('sale_delivery_date', '<=', $endDate)->where('sale_status',1)->sum('sale_delivery_charges');
        // $totalRoundOff = Sale::where('sale_delivery_date', '>=', $startDate)->where('sale_delivery_date', '<=', $endDate)->where('sale_status',1)->sum('sale_round_off');

        // $totalSale = $totalAmount + $totalGst + $totalDeliveryChrg - $totalRoundOff;

        $sales = Sale::where('sale_delivery_date', '>=', $startDate)->where('sale_delivery_date', '<=', $endDate)->where('sale_status',1)->get()->unique('sale_trnx_id');
        $total = 0;
        foreach ($sales as $sale) {
            $total = $total+ $sale->sale_total;
        }
        return response()->json($total);
    }
    
}
