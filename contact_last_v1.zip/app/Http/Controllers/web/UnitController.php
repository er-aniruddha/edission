<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Unit;
use App\Models\Portal\Product;
use Illuminate\Support\Str;
use Validator;

class UnitController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        if(request()->ajax())
        {
          return datatables()->of(Unit::orderBy('unit_id','DESC')->get())
                ->addColumn('action', function($data){                  
                  $button = '<button type="button" name="edit" id="'.$data->unit_id.'" data-name="'.$data->unit_name.'" data-code="'.$data->unit_code.'" class="edit btn btn-outline-primary btn-sm">Edit</button>';
                  $button .= '&nbsp;';
                  $button .= '<button type="button" data-id="'.$data->unit_id.'" data-name="'.$data->unit_name.'" class="delete btn btn-outline-danger btn-sm">Del</button>';
                  return $button;
                })                
                ->addIndexColumn()
                ->rawColumns(['action'])
                ->make(true);       
                    
        }        
        return view('portal.unit.index');
    }

    public function create(Request $request)
    {
        if(request()->ajax())
        {
            $validator = \Validator::make($request->all(), [
            'unit_name' => 'required|max:255|unique:units,unit_name',
            'unit_code' => 'required|max:255'
            ]);

            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }

            $unit = new Unit;
            
            $unit->unit_name = Str::lower($request->unit_name);
            $unit->unit_code = Str::lower($request->unit_code);
            $is_saved = $unit->save();

            if($is_saved)
            {
                $success = array('success' => 'Unit saved successfully');
                return response()->json($success);
            }
        }
    }

    public function update(Request $request)
    {      
      if(request()->ajax())
      {
        $unit = Unit::find($request->unit_id);
        
        $validator = \Validator::make($request->all(), [
            'unit_name' => 'required|max:255|unique:units,unit_name',
            'unit_code' => 'required|max:255'
        ]);

        if ($validator->fails())         
        {
          return response()->json(['errors' => $validator->errors()]);
        }

        if($validator->passes())
        {
            $unit->unit_name = Str::lower($request->unit_name);
            $unit->unit_code = Str::lower($request->unit_code);
            $is_save = $unit->update();

            if($is_save)
            {
                $success = array('success' => 'Unit update successfully');
                return response()->json($success);
            }
        } 
      }
    }

    public function destroy(Request $request)
    {
        $data = Unit::find($request->id);
        $product = Product::where('unit_id', $request->id)->first();
        if($product)
        {
            $error = array('error' => "This unit can't be deleted.");
            return response()->json($error);
        }
        else
        {
            $data->delete();
            $success = array('success' => 'Unit deleted successfullly');
            return response()->json($success);
        }


    }


}
