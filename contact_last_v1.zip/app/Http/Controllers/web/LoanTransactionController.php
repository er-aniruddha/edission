<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\LoanAccount;
use App\Models\Portal\LoanTransaction;
use Illuminate\Support\Str;
use Validator;
use Carbon\Carbon;

class LoanTransactionController extends Controller
{
    public function paidEmi(Request $request)
    {  
        if(request()->ajax())
        {
            $validator = \Validator::make($request->all(), [
                'paid_amount' => 'required|numeric|min:'.$request->trnx_emi.'',
                'date' => 'required|date|before:tomorrow',  
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }
            if($validator->passes())
            {
                $loanAcDetails = LoanAccount::where('loan_ac_id',$request->loan_ac_id)->first();
                $emiDetails = LoanTransaction::where('loan_trnx_id',$request->loan_trnx_id)->first();
                $intPaid = (float)$emiDetails->interest_of_emi; 
                $paidAmount = (float)$request->paid_amount;
                
                $principalPaid = $paidAmount - $intPaid;
                $loanBalance = (float)$loanAcDetails->loan_balance - $principalPaid;


                $emiDetails->paid_amount = $request->paid_amount;
                $emiDetails->interest_paid = $intPaid;
                $emiDetails->principal_paid = $principalPaid;
                $emiDetails->loan_balance_after_paid = $loanBalance;
                $emiDetails->paid_date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
                if($loanBalance <= 0)
                {
                    $emiDetails->status = '2';
                }
                else
                {
                    $emiDetails->status = '1';
                }                
                $emiDetails->trnx_remarks = $request->trnx_remarks;
                $emiDetails->update(); //loan_transaction update

                $loanAcDetails->loan_balance = $loanBalance;
                if($loanBalance <= 0)
                {
                    $loanAcDetails->loan_status = 0;
                }
                $loanAcDetails->update(); //loan_account update

                $loanaccounts = LoanAccount::orderBy('id','asc')->get();
                $success = array('message' => 'EMI paid successfully.','loanaccounts' => $loanaccounts);
                return response()->json($success);
            }
        }  	    	
    	
    }

    public function edit(Request $request)
    {
    	// code...
    }

    public function chk(Request $request)
    {
    }
}
