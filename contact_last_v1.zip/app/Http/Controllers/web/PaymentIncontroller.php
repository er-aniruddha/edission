<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Customer;
use App\Models\Portal\PaymentIn;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;

class PaymentIncontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $payments = PaymentIn::leftJoin('customers','payment_ins.customer_id','customers.customer_id')
                            ->select(array('payment_ins.*','customers.*','payment_ins.balance'))
                            ->orderBy('payment_ins.date','desc')
                            ->get();
        $customers = Customer::get();  

        if(request()->ajax())
        {
          return datatables()->of($payments)
                ->editColumn('date', function ($data) {
                    return date('d-m-Y', strtotime($data->date));
                })  
                ->addColumn('name', function($data){                  
                    $name = '<a href="#" class="item-company ajax h-1x text-capitalize" data-pjax-state="">'.$data->f_name.' '.$data->s_name.'</a>
                            <div class="item-mail text-muted h-1x d-none d-sm-block text-capitalize">'.$data->shop_name.'</div>'; 
                  return $name;
                })         
                ->addColumn('action', function($data){                  
                    $action = '<div class="item-action dropdown">
                                    <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right bg-black" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                        <a class="dropdown-item view" href="#" id="'.$data->id.'" data-date="'.$data->date.'" data-paytrnxid="'.$data->payment_in_trnx_id.'" data-cid="'.$data->customer_id.'" data-prevbal="'.$data->prev_balance.'" data-received="'.$data->received.'" data-balance="'.$data->balance.'" data-paymenttype="'.$data->payment_type.'" data-remarks="'.$data->remarks.'">See detail </a>
                                        <a class="dropdown-item edit" id="'.$data->id.'" data-date="'.$data->date.'" data-paytrnxid="'.$data->payment_in_trnx_id.'" data-cid="'.$data->customer_id.'" data-prevbal="'.$data->prev_balance.'" data-received="'.$data->received.'" data-balance="'.$data->balance.'" data-paymenttype="'.$data->payment_type.'" data-remarks="'.$data->remarks.'">Edit</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item delete" id="'.$data->id.'" data-paytrnxid="'.$data->payment_in_trnx_id.'">Delete</a>
                                    </div>
                                </div>'; 
                  return $action;
                })
                ->addIndexColumn()    
                ->rawColumns(['action','name'])                   
                ->make(true); 
        } 
        else{   
                         
            return view('portal.sale_payment_in.index',['customers' => $customers]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        if($request->date)
        {
            $date = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
            $validator_date = \Validator::make($date, [
                'date' => 'required|date|before:tomorrow',         
            ],[
                'date.before' => 'The date mustbe today or before.',
                'date.unique' => 'Can not add two item on same date',
            ]);
            if ($validator_date->fails())         
            {
                return response()->json(['errors' => $validator_date->errors()]);
            }
        }

        $validator = \Validator::make($request->all(), [
            'customer_id' => 'required|not_in:0',
            'date' => 'required|date|before:tomorrow',   
            'payment_type' => 'required|not_in:0',
            'received' => 'required|not_in:0',
            ],[
              'date.before' => 'The date mustbe today or before.',                  
        ]);

        if ($validator->fails())         
        {
            return response()->json(['errors' => $validator->errors()]);
        }
        
        if($validator->passes())
        {
            
            $paymentIn = new PaymentIn;
            $paymentIn->payment_in_trnx_id = 1000000000+strtotime("now"); 
            $paymentIn->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');            
            $paymentIn->customer_id = $request->customer_id;
            $paymentIn->received = $request->received;
            $paymentIn->balance = $request->balance;
            $paymentIn->prev_balance = $request->prev_balance;
            $paymentIn->payment_type = $request->payment_type;
            $paymentIn->remarks = $request->remarks;                    
            $paymentIn->save();

            $findCustomer = Customer::find($request->customer_id);
            $findCustomer->balance = $request->balance;
            $findCustomer->update();
        }
            
        $customers = Customer::where('customers.balance','>',0)->get(); 
        $success = array('success' => "Payment save successfully.", 'customers' => $customers);
        return response()->json($success);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $thisPayment = PaymentIn::find($request->id); // this is require bcs #s_id disabled  
        $thisValue = PaymentIn::where('customer_id',"=",$thisPayment->customer_id)->whereDate('date','>', $thisPayment->date)->count();

        if($thisValue > 0)
        {
            $errors = array('errors'=> array('trnx_error' => array('0'=>"This customer has payment transaction, after this date.")));
            return response()->json($errors);
        }
        else
        {     

            $validator = \Validator::make($request->all(), [ 
                'payment_type' => 'required|not_in:0',
                'received' => 'required|not_in:0',
            ]);

            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }
            
            if($validator->passes())
            {              
                
                $thisPayment->received = $request->received;
                $thisPayment->balance = $request->balance;
                $thisPayment->payment_type = $request->payment_type;
                $thisPayment->remarks = Str::lower($request->remarks);                    
                $thisPayment->update();

                $findCustomer = Customer::find($thisPayment->customer_id);
                $findCustomer->balance = $request->balance;
                $findCustomer->update();
            }
                
            $customers = Customer::all(); 

            $success = array('success' => "Payment save successfully.", 'customers' => $customers);
            return response()->json($success);       
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $thisPayment = PaymentIn::find($request->id); // this is require bcs #s_id disabled  
        $thisValue = PaymentIn::where('customer_id',"=",$thisPayment->customer_id)->whereDate('date','>', $thisPayment->date)->count();

        if($thisValue > 0)
        {
            $error = array('error' => "Customer has more transaction, after this date.");
            return response()->json($error);
        }
        else
        {
            $findCustomer = Customer::find($thisPayment->customer_id);
            $findCustomer->balance = $findCustomer->balance + $thisPayment->received;
            $findCustomer->update();

            $thisPayment->delete();

            $customers = Customer::all(); 
            $success = array('success' => 'Payment deleted successfully', 'customers' => $customers);
            return response()->json($success); 
        }
    }
}
