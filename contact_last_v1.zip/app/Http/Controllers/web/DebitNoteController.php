<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Product;
use App\Models\Portal\Unit;
use App\Models\Portal\Supplier;
use App\Models\Portal\DebitNote;
use App\Models\Portal\Stock;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;

class DebitNoteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(request()->ajax())
        {
            $startDate = $_GET['startDate']; 
            $endDate = $_GET['endDate'];
            $drUnique = DebitNote::where('dr_order_date', '>=', $startDate)
                                ->where('dr_order_date', '<=', $endDate)
                                ->leftJoin('products','debit_notes.item_name','=','products.product_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units', 'debit_notes.unit_id','=','units.unit_id') 
                                ->leftJoin('suppliers','debit_notes.supplier_id','=','suppliers.supplier_id')
                                ->select(array('debit_notes.*','products.*','units.*','suppliers.*','brands.*'))
                                ->orderBy('dr_note_id','desc')
                                ->get()->unique('dr_trnx_id');
            return datatables()->of($drUnique)       
                ->addColumn('action', function($data){      
                    if($data->dr_status == 1)
                    {
                        $action = '<div class="item-action dropdown">
                                    <a href="javascript:void(0)" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right bg-light" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                        <a class="dropdown-item view" data-trnxid="'.$data->dr_trnx_id.'" data-status="'.$data->dr_status.'">See detail </a>
                                    </div>
                                </div>'; 
                    }          
                    else
                    {
                        $action = '<div class="item-action dropdown">
                                    <a href="javascript:void(0)" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right bg-light" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                        <a class="dropdown-item view" data-trnxid="'.$data->dr_trnx_id.'" data-status="'.$data->dr_status.'">See detail </a>
                                        <a class="dropdown-item edit" data-trnxid="'.$data->dr_trnx_id.'" data-status="'.$data->dr_status.'">Edit</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item delete" data-trnxid="'.$data->dr_trnx_id.'">Delete item</a>
                                    </div>
                                </div>'; 
                    }  
                    
                  return $action;
                })
                ->addColumn('status', function($data){
                    if( $data->dr_status == 1)
                    {
                        $status = '<span class="item-badge badge text-uppercase bg-success">Order Complete</span>';  
                    }
                    else
                    {
                        $status = '<a class="item-badge badge text-uppercase bg-secondary over-due" data-trnxid="'.$data->dr_trnx_id.'" data-date="'.$data->dr_order_date.'">Over Due</a>';   
                    }
                    return $status;
                })                
                ->addIndexColumn()    
                ->rawColumns(['action','status'])                   
                ->make(true); 
        } 
        else{   
            $allDrNotes = DebitNote::leftJoin('products','debit_notes.item_name','=','products.product_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units', 'debit_notes.unit_id','=','units.unit_id') 
                                ->leftJoin('suppliers','debit_notes.supplier_id','=','suppliers.supplier_id')
                                ->select(array('debit_notes.*','products.*','units.*','suppliers.*','brands.*'))
                                ->orderBy('dr_note_id','asc')
                                ->get();        
            $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('suppliers','brands.supplier_id','=','suppliers.supplier_id')
                            ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                            ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                            ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*','suppliers.*'))
                            ->orderBy('product_name','ASC')
                            ->get();
            $suppliers = Supplier::orderBy('supplier_name','ASC')->get(); 
            return view('portal.debit_note.index',['allDrNotes' => $allDrNotes,'products' => $products,'suppliers' => $suppliers]);
        }    
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        if(request()->ajax())
        {
            $openOrderchk = DebitNote::where('supplier_id',$request->supplier_id)->where('dr_status',0)->count();

            if($openOrderchk < 1)
            {
                $validator = \Validator::make($request->all(), [
                    'supplier_id' => 'required|not_in:0',
                    'order_date' => 'required|date|before:tomorrow',     
                    'item_name.*' => 'required|max:255',
                    'unit_id.*' => 'required|max:255',
                    'qty.*' => 'required|integer|not_in:0',
                    'unit_price.*' => 'required',
                    'amount.*' => 'required',
                    'payment_type' => 'required|not_in:0',
                    ],[
                      'order_date.before' => 'The date mustbe today or before.',
                      'item_name.*.required' => 'Item name required.',
                      'unit_id.*.required' => 'Unit Name required.',
                      'qty.*.required' => 'Quantity required.',
                      'qty.*.not_in' => 'Quantity required.',
                      'unit_price.*.required' => 'Unit price required.',
                      'amount.*.required' => 'Price required.',
                ]);
                if ($validator->fails())         
                {
                    return response()->json(['errors' => $validator->errors()]);
                }
            
                if($validator->passes())
                {
                    
                    $trnxId = strtotime("now");

                    $New_start_index = 0;          
                    $length = count($request->all()['unit_price']);
                  
                    $item_name = array_combine(range($New_start_index,  count($request->item_name) + ($New_start_index-1)),
                        array_values($request->item_name)); 

                    $unit_id = array_combine(range($New_start_index,  count($request->unit_id) + ($New_start_index-1)),
                        array_values($request->unit_id)); 

                    $qty = array_combine(range($New_start_index,  count($request->qty) + ($New_start_index-1)),
                        array_values($request->qty)); 
                   
                    $unit_price = array_combine(range($New_start_index,  count($request->unit_price) + ($New_start_index-1)),
                        array_values($request->unit_price)); 

                    $amount = array_combine(range($New_start_index,  count($request->amount) + ($New_start_index-1)),
                        array_values($request->amount)); 
                  
                    for($i=0; $i < $length; $i++)
                    {
                        $findProduct = Product::find($item_name[$i]);

                        if($findProduct->primary_unit == $unit_id[$i])
                        {
                            $primary_qty = $qty[$i];
                            $secondary_qty = $qty[$i] * $findProduct->no_of_pcs;
                        }
                        if($findProduct->secondary_unit == $unit_id[$i])
                        {
                            $primary_qty = (int)($qty[$i] / $findProduct->no_of_pcs);
                            $secondary_qty = $qty[$i];
                        }
                        $debitNote = new DebitNote;
                        $debitNote->dr_trnx_id = $trnxId; 
                        $debitNote->supplier_id = $request->supplier_id;
                        $debitNote->dr_order_date = Carbon::createFromFormat('d-m-Y', $request->order_date)->format('Y-m-d');            
                        $debitNote->item_name = Str::lower($item_name[$i]); // product_id are same
                        $debitNote->unit_id = Str::lower($unit_id[$i]);
                        $debitNote->dr_qty = $qty[$i];                
                        $debitNote->dr_primary_qty = $primary_qty;                
                        $debitNote->dr_secondary_qty = $secondary_qty;                
                        $debitNote->dr_unit_price = $unit_price[$i];
                        $debitNote->dr_primary_pp = $findProduct->primary_pp_for_stock;
                        $debitNote->dr_secondary_pp = $findProduct->secondary_pp_for_stock;
                        $debitNote->dr_amount = $amount[$i];
                        $debitNote->dr_payment_type = Str::lower($request->payment_type);
                        $debitNote->dr_delivery_charges = $request->delivery_charges;
                        $debitNote->dr_round_off = $request->round_off;
                        $debitNote->dr_gst_amount = $request->gst_amount;
                        $debitNote->dr_total = $request->total;
                        $debitNote->dr_received = $request->received;
                        $debitNote->dr_prev_balance = $request->prev_balance;
                        $debitNote->dr_balance = $request->balance;
                        $debitNote->dr_remarks = $request->remarks;
                        if($request->received <= 0)
                        {
                            $debitNote->dr_payment_status  = 0;
                        }
                        elseif($request->balance <= 0)
                        {
                            $debitNote->dr_payment_status  = 2;           
                        }
                        else
                        {
                            $debitNote->dr_payment_status  = 1;  
                        }
                        $debitNote->dr_status = 0;
                        $debitNote->save();
                    }

                    $supplier = Supplier::find($request->supplier_id); 
                    $supplier->balance = $request->balance;
                    $supplier->update();

                    $allDrNotes = DebitNote::leftJoin('products','debit_notes.item_name','=','products.product_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units', 'debit_notes.unit_id','=','units.unit_id') 
                                ->leftJoin('suppliers','debit_notes.supplier_id','=','suppliers.supplier_id')
                                ->select(array('debit_notes.*','products.*','units.*','suppliers.*','brands.*'))
                                ->orderBy('dr_note_id','asc')
                                ->get();                                          
                    $suppliers = Supplier::orderBy('supplier_name','ASC')->get(); 
                    $success = array('success' => "Dr. Note saved successfully.", 'allDrNotes' => $allDrNotes , 'suppliers'=> $suppliers );
                    return response()->json($success);

                }
            }
            else
            {
                $errors = array('errors'=> array('supplier_id' => array('0'=>"Order can't be completed. This supplier has an open order.")));
                return response()->json($errors);
            } 
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        if(request()->ajax())
        {   
            $validator = \Validator::make($request->all(), [
                'supplier_id' => 'required|not_in:0',
                'order_date' => 'required|date|before:tomorrow',     
                'item_name.*' => 'required|max:255',
                'unit_id.*' => 'required|max:255',
                'qty.*' => 'required|integer|not_in:0',
                'unit_price.*' => 'required',
                'amount.*' => 'required',
                'payment_type' => 'required|not_in:0',
                ],[
                  'order_date.before' => 'The date mustbe today or before.',
                  'item_name.*.required' => 'Item name required.',
                  'unit_id.*.required' => 'Unit Name required.',
                  'qty.*.required' => 'Quantity required.',
                  'qty.*.not_in' => 'Quantity required.',
                  'unit_price.*.required' => 'Unit price required.',
                  'amount.*.required' => 'Price required.',
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }
            if($validator->passes())
            {
                
                $trnxId = strtotime("now");

                $New_start_index = 0;          
                $length = count($request->all()['unit_price']);
              
                $item_name = array_combine(range($New_start_index,  count($request->item_name) + ($New_start_index-1)),
                    array_values($request->item_name)); 

                $unit_id = array_combine(range($New_start_index,  count($request->unit_id) + ($New_start_index-1)),
                    array_values($request->unit_id)); 

                $qty = array_combine(range($New_start_index,  count($request->qty) + ($New_start_index-1)),
                    array_values($request->qty)); 
               
                $unit_price = array_combine(range($New_start_index,  count($request->unit_price) + ($New_start_index-1)),
                    array_values($request->unit_price)); 

                $amount = array_combine(range($New_start_index,  count($request->amount) + ($New_start_index-1)),
                    array_values($request->amount)); 

                DebitNote::where('dr_trnx_id','=',$request->dr_trnx_id)->delete();  

                for($i=0; $i < $length; $i++)
                {
                    $findProduct = Product::find($item_name[$i]);

                    if($findProduct->primary_unit == $unit_id[$i])
                    {
                        $primary_qty = $qty[$i];
                        $secondary_qty = $qty[$i] * $findProduct->no_of_pcs;
                    }
                    if($findProduct->secondary_unit == $unit_id[$i])
                    {
                        $primary_qty = (int)($qty[$i] / $findProduct->no_of_pcs);
                        $secondary_qty = $qty[$i];
                    }

                    $debitNote = new DebitNote;
                    $debitNote->dr_trnx_id = $request->dr_trnx_id; 
                    $debitNote->supplier_id = $request->supplier_id;
                    $debitNote->dr_order_date = Carbon::createFromFormat('d-m-Y', $request->order_date)->format('Y-m-d');            
                    $debitNote->item_name = Str::lower($item_name[$i]); // product_id are same
                    $debitNote->unit_id = Str::lower($unit_id[$i]);
                    $debitNote->dr_qty = $qty[$i];                
                    $debitNote->dr_primary_qty = $primary_qty;                
                    $debitNote->dr_secondary_qty = $secondary_qty;                
                    $debitNote->dr_unit_price = $unit_price[$i];
                    $debitNote->dr_primary_pp = $findProduct->primary_pp_for_stock;
                    $debitNote->dr_secondary_pp = $findProduct->secondary_pp_for_stock;
                    $debitNote->dr_amount = $amount[$i];
                    $debitNote->dr_payment_type = Str::lower($request->payment_type);
                    $debitNote->dr_delivery_charges = $request->delivery_charges;
                    $debitNote->dr_round_off = $request->round_off;
                    $debitNote->dr_gst_amount = $request->gst_amount;
                    $debitNote->dr_total = $request->total;
                    $debitNote->dr_received = $request->received;
                    $debitNote->dr_prev_balance = $request->prev_balance;
                    $debitNote->dr_balance = $request->balance;
                    $debitNote->dr_remarks = $request->remarks;
                    if($request->received <= 0)
                    {
                        $debitNote->dr_payment_status  = 0;
                    }
                    elseif($request->balance <= 0)
                    {
                        $debitNote->dr_payment_status  = 2;           
                    }
                    else
                    {
                        $debitNote->dr_payment_status  = 1;  
                    }
                    $debitNote->dr_status = 0;
                    $debitNote->save();
                }

                $supplier = Supplier::find($request->supplier_id); 
                $supplier->balance = $request->balance;
                $supplier->update();

                $allDrNotes = DebitNote::leftJoin('products','debit_notes.item_name','=','products.product_id')
                            ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('units', 'debit_notes.unit_id','=','units.unit_id') 
                            ->leftJoin('suppliers','debit_notes.supplier_id','=','suppliers.supplier_id')
                            ->select(array('debit_notes.*','products.*','units.*','suppliers.*','brands.*'))
                            ->orderBy('dr_note_id','asc')
                            ->get();        
                $suppliers = Supplier::orderBy('supplier_name','ASC')->get(); 
                $success = array('success' => "Dr. Note updated successfully.", 'allDrNotes' => $allDrNotes, 'suppliers'=>$suppliers);
                return response()->json($success);

            }
        }
    }

    /**
     * Status the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function status(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'order_date' => 'date',
            'delivery_date' => 'required|date|before:tomorrow|after_or_equal:order_date',     
            ],[
            'delivery_date.before' => 'The date mustbe today or before.',
        ]);
        if ($validator->fails())         
        {
            return response()->json(['errors' => $validator->errors()]);
        }
        if($validator->passes())
        {   
            $trnxId = $request->dr_trnx_id; //here id refer for date because delete modal is common for all
            $data = DebitNote::where('dr_trnx_id', $trnxId)->get();
            /*
                Before status change product sholud be in stock
            */
            foreach($data as $d)
            {
                $findProduct = Product::find($d->item_name);

                $newStock = New Stock;
                $newStock->stock_type = '1R';
                $newStock->trnx_id  = $trnxId;
                $newStock->item_name  = Str::lower($d->item_name);
                $newStock->supplier_id  = $d->supplier_id;
                $newStock->order_date  = $d->dr_order_date;
                $newStock->delivery_date  = Carbon::createFromFormat('d-m-Y', $request->delivery_date)->format('Y-m-d');
                $newStock->qty = $d->dr_qty;            
                $newStock->primary_qty = $d->dr_primary_qty;            
                $newStock->secondary_qty = $d->dr_secondary_qty;
                $newStock->unit_id  = $d->unit_id;
                $newStock->unit_price  = $d->dr_unit_price;
                $newStock->amount  = $d->dr_amount;
                // this two column delted 
                // $newStock->in_hand_stock  = $newStock->in_hand_stock + $d->qty;
                // $newStock->stock_value  = $d->stock_value + ($d->qty*$d->unit_price);
                if($d->received <= 0)
                {
                    $newStock->stock_stat  = 0;
                }
                elseif($d->balance <= 0)
                {
                    $newStock->stock_stat  = 2;                    
                }
                else
                {
                    $newStock->stock_stat  = 1;  
                }
                $newStock->save();

                ////*********************
                if($findProduct)
                {
                    if($findProduct->secondary_unit == $d->unit_id)
                    { 
                        $prevStockValue = $findProduct->stock_value;
                        $nowSecondaryQty = $findProduct->in_hand_stock_second - $d->dr_qty; 
                        $findProduct->stock_value = $nowSecondaryQty * $findProduct->secondary_pp_for_stock;
                        $findProduct->in_hand_stock_primary = (int)($nowSecondaryQty/$findProduct->no_of_pcs);
                        $findProduct->in_hand_stock_second = $nowSecondaryQty;
                    }

                    if($findProduct->primary_unit == $d->unit_id)
                    {
                        $prevStockValue = $findProduct->stock_value;
                        $nowSecondaryQty = $findProduct->in_hand_stock_second - ($findProduct->no_of_pcs * $d->dr_qty);
                        $findProduct->stock_value = $nowSecondaryQty * $findProduct->secondary_pp_for_stock;
                        $findProduct->in_hand_stock_primary = (int)($nowSecondaryQty/$findProduct->no_of_pcs);
                        $findProduct->in_hand_stock_second = $nowSecondaryQty;
                    }  
                    $findProduct->update();
                }
            } 

            DebitNote::where('dr_trnx_id',$trnxId)->update(['dr_delivery_date' => Carbon::createFromFormat('d-m-Y', $request->delivery_date)->format('Y-m-d') ,'dr_status' => 1]);

            $allDrNotes = DebitNote::leftJoin('products','debit_notes.item_name','=','products.product_id')
                        ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                        ->leftJoin('units', 'debit_notes.unit_id','=','units.unit_id') 
                        ->leftJoin('suppliers','debit_notes.supplier_id','=','suppliers.supplier_id')
                        ->select(array('debit_notes.*','products.*','units.*','suppliers.*','brands.*'))
                        ->orderBy('dr_note_id','asc')
                        ->get();        
            $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                    ->leftJoin('suppliers','brands.supplier_id','=','suppliers.supplier_id')
                    ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                    ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                    ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*','suppliers.*'))
                    ->orderBy('product_name','ASC')
                    ->get();
            $suppliers = Supplier::orderBy('supplier_name','ASC')->get(); 
            $success = array('success' => "Dr. Note completed successfully.", 'allDrNotes' => $allDrNotes,'products' => $products, 'suppliers'=>$suppliers);
            return response()->json($success);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $trnxId = $request->id; //here id refer for date because delete modal is common for all
        $delData = DebitNote::where('dr_trnx_id', $trnxId)->where('dr_status',0)->first();

        $supplier = Supplier::find($delData->supplier_id);
        $supplier->balance = $delData->dr_prev_balance;
        $is_saved = $supplier->update();

        if($is_saved)
        {
            debitNote::where('dr_trnx_id','=',$trnxId)->delete(); 
        }

        $allDrNotes = DebitNote::leftJoin('products','debit_notes.item_name','=','products.product_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units', 'debit_notes.unit_id','=','units.unit_id') 
                                ->leftJoin('suppliers','debit_notes.supplier_id','=','suppliers.supplier_id')
                                ->select(array('debit_notes.*','products.*','units.*','suppliers.*','brands.*'))
                                ->orderBy('dr_note_id','asc')
                                ->get();        
        $suppliers = Supplier::orderBy('supplier_name','ASC')->get(); 
        $success = array('success' => "Dr. Note deleted successfully.",'allDrNotes' => $allDrNotes,'suppliers'=>$suppliers);
        return response()->json($success);
    }
}
