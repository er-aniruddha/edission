<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\CreditNote;
use App\Models\Portal\Product;
use App\Models\Portal\Unit;
use App\Models\Portal\Brand;
use App\Models\Portal\Customer;
use App\Models\Portal\Stock;
use App\Models\Portal\PaymentIn;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;

class CreditNoteController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                            ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                            ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*'))
                            ->where('pro_type','Purchasing')->where('product_stat',1)
                            ->orderBy('product_id','DESC')
                            ->get();
        $customers = Customer::orderBy('customer_id','DESC')->get();
        $creditNoteTable = CreditNote::leftJoin('products','credit_notes.item_name','=','products.product_id')
                                ->leftJoin('customers','credit_notes.customer_id','=','customers.customer_id')
                                ->leftJoin('units','credit_notes.unit_id','=','units.unit_id')
                                ->select(array('credit_notes.*','products.*','customers.*','units.*'))
                                ->orderBy('cr_order_date','desc')
                                ->get()->unique('cr_trnx_id'); 
        if(request()->ajax())
        {
          return datatables()->of($creditNoteTable)  
                ->addColumn('name', function($data){                  
                    $name = '<a href="'. route('customer.details',$data->customer_id).'" class="item-company ajax h-1x text-capitalize" data-pjax-state="">'.$data->f_name.' '.$data->s_name.'</a>
                            <div class="item-mail text-muted h-1x d-none d-sm-block">'.$data->shop_name.'</div>'; 
                  return $name;
                })         
                ->addColumn('action', function($data){      
                    if($data->cr_status == 1)
                    {
                        $action = '<div class="item-action dropdown">
                                    <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right bg-light" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                        <a class="dropdown-item view" href="#" data-trnxid="'.$data->cr_trnx_id.'">See detail </a>
                                    </div>
                                </div>'; 
                    }          
                    else
                    {
                        $action = '<div class="item-action dropdown">
                                    <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right bg-light" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                        <a class="dropdown-item view" href="#" data-trnxid="'.$data->cr_trnx_id.'">See detail </a>
                                        <a class="dropdown-item edit" data-trnxid="'.$data->cr_trnx_id.'" data-cid="'.$data->customer_id.'">Edit</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item delete" data-trnxid="'.$data->cr_trnx_id.'">Delete item</a>
                                    </div>
                                </div>'; 
                    }  
                    
                  return $action;
                })
                ->addColumn('status', function($data){
                    if( $data->cr_status == 1)
                    {
                        $status = '<span class="item-badge badge text-uppercase bg-success">Order Complete</span>';  
                    }
                    else
                    {
                        $status = '<a class="item-badge badge text-uppercase bg-secondary over-due" data-trnxid="'.$data->cr_trnx_id.'" data-date="'.$data->cr_order_date.'">Over Due</a>';   
                    }
                    return $status;
                })                
                ->addIndexColumn()    
                ->rawColumns(['action','name' ,'status'])                   
                ->make(true); 
        } 
        else{
            $creditNotes = CreditNote::leftJoin('products','credit_notes.item_name','=','products.product_id')
                                ->leftJoin('customers','credit_notes.customer_id','=','customers.customer_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units','credit_notes.unit_id','=','units.unit_id')
                                ->select(array('credit_notes.*','products.*','customers.*','units.*','brands.*'))  
                                ->orderBy('cr_note_id','asc')
                                ->get();             
            return view('portal.credit_note.index',['products'=>$products , 'customers' => $customers, 'creditNotes' => $creditNotes]);
        }    
    }

    public function create(Request $request)
    {
        if(request()->ajax())
        {    
            $openOrderchk = CreditNote::where('customer_id',$request->customer_id)->where('cr_status',0)->count();

            if($openOrderchk < 1)
            {
                $validator = \Validator::make($request->all(), [
                    'customer_id' => 'required|not_in:0',
                    'order_date' => 'required|date|before:tomorrow',       
                    'item_name.*' => 'required|max:255',
                    'unit_id.*' => 'required|max:255',
                    'qty.*' => 'required|integer|not_in:0',
                    'product_mrp.*' => 'required',
                    'amount.*' => 'required',
                    'payment_type' => 'required|not_in:0',
                ],[
                    'order_date.before' => 'The date mustbe today or before.',
                    'delivery_date.before' => 'The date mustbe today or before.',
                    'customer_id.required' => 'Select customer.',
                    'item_name.*.required' => 'Item name required.',
                    'unit_id.*.required' => 'Unit Name required.',
                    'qty.*.required' => 'Quantity required.',
                    'product_mrp.*.required' => 'MRP price required.',
                    'amount.*.required' => 'Price required.',
                ]);
                if ($validator->fails())         
                {
                    return response()->json(['errors' => $validator->errors()]);
                }
                if($validator->passes())
                {
                    
                    $crnId = 8000000000+strtotime("now");
                    $data = $request->all();
                    $New_start_index = 0;          
                    $length = count($data['unit_price']);
                  
                    $item_name = array_combine(range($New_start_index,  count($request->item_name) + ($New_start_index-1)),
                        array_values($request->item_name)); 
                    $unit_id = array_combine(range($New_start_index,  count($request->unit_id) + ($New_start_index-1)),
                        array_values($request->unit_id)); 
                    $qty = array_combine(range($New_start_index,  count($request->qty) + ($New_start_index-1)),
                        array_values($request->qty));                 
                    $unit_price = array_combine(range($New_start_index,  count($request->unit_price) + ($New_start_index-1)),
                        array_values($request->unit_price)); 
                    $amount = array_combine(range($New_start_index,  count($request->amount) + ($New_start_index-1)),
                        array_values($request->amount)); 
                  
                    for($i=0; $i < $length; $i++)
                    {  
                        $findProduct = Product::find($item_name[$i]);           

                        $creditNote = new CreditNote;
                        $creditNote->cr_order_date = Carbon::createFromFormat('d-m-Y', $request->order_date)->format('Y-m-d');                  
                        $creditNote->cr_trnx_id = $crnId; 
                        $creditNote->customer_id = $request->customer_id;     
                        $creditNote->item_name = $item_name[$i];
                        $creditNote->unit_id = $unit_id[$i];  
                        $creditNote->cr_qty = $qty[$i];                        
                        if($findProduct->primary_unit == $unit_id[$i])
                        {
                            $creditNote->cr_primary_qty = $qty[$i];
                            $creditNote->cr_secondary_qty = $qty[$i] * $findProduct->no_of_pcs;
                        }
                        if($findProduct->secondary_unit == $unit_id[$i])
                        {
                            $creditNote->cr_primary_qty = (int)($qty[$i] / $findProduct->no_of_pcs);
                            $creditNote->cr_secondary_qty = $qty[$i];
                        } 

                        $creditNote->cr_unit_price = $unit_price[$i];
                        $creditNote->cr_primary_pp = $findProduct->primary_pp_for_stock;
                        $creditNote->cr_secondary_pp = $findProduct->secondary_pp_for_stock;
                        $creditNote->cr_amount = $amount[$i];
                        $creditNote->cr_payment_type = $request->payment_type;
                        $creditNote->cr_delivery_charges = $request->delivery_charges;
                        $creditNote->cr_round_off = $request->round_off;
                        $creditNote->cr_gst_amount = $request->gst_amount;
                        $creditNote->cr_total = $request->total;
                        $creditNote->cr_paid = $request->paid;
                        $creditNote->cr_balance = $request->balance;
                        $creditNote->cr_prev_balance = $request->prev_balance;
                        $creditNote->cr_remarks = $request->remarks;
                        if($request->paid <= 0)
                        {
                            $creditNote->cr_payment_status  = 0;
                            $stockStatus = 0;
                        }
                        elseif($request->balance <= 0)
                        {
                            $creditNote->cr_payment_status  = 2;
                            $stockStatus = 2;           
                        }
                        else
                        {
                            $creditNote->cr_payment_status  = 1;
                            $stockStatus = 1;  
                        }
                        $creditNote->cr_status = 0;
                        $creditNote->save();
                        
                    } // for loop end
                    
                    $creditNotes = CreditNote::leftJoin('products','credit_notes.item_name','=','products.product_id')
                                    ->leftJoin('customers','credit_notes.customer_id','=','customers.customer_id')
                                    ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                    ->leftJoin('units','credit_notes.unit_id','=','units.unit_id')
                                    ->select(array('credit_notes.*','products.*','customers.*','units.*','brands.*'))  
                                    ->orderBy('cr_note_id','asc')
                                    ->get();    
                    $customers = Customer::orderBy('customer_id','DESC')->get();
                    $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                                ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                                ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*'))
                                ->orderBy('product_id','DESC')
                                ->get();
                    $success = array('success' => "Cr. Note created successfully.", 'creditNotes' => $creditNotes, 'customers' => $customers, 'products' => $products);
                    return response()->json($success);
                    
                }
            }
            else
            {
                $errors = array('errors'=> array('customer_id' => array('0'=>"Order can't be completed. This customer has an open order.")));
                return response()->json($errors);
            }
            
        }
    }

    public function update(Request $request)
    {
        if(request()->ajax())
        {          
            $validator = \Validator::make($request->all(), [
                'order_date' => 'required|date|before:tomorrow',       
                'item_name.*' => 'required|max:255',
                'unit_id.*' => 'required|max:255',
                'qty.*' => 'required|integer|not_in:0',
                'product_mrp.*' => 'required',
                'amount.*' => 'required',
                'payment_type' => 'required|not_in:0',
            ],[
                'order_date.before' => 'The date mustbe today or before.',
                'delivery_date.before' => 'The date mustbe today or before.',
                'customer_id.required' => 'Select customer.',
                'item_name.*.required' => 'Item name required.',
                'unit_id.*.required' => 'Unit Name required.',
                'qty.*.required' => 'Quantity required.',
                'product_mrp.*.required' => 'MRP price required.',
                'amount.*.required' => 'Price required.',
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }
            if($validator->passes())
            {
                $data = $request->all();
                $crnId = $request->cr_trnx_id;
                $crNoteDetails = CreditNote::where('cr_trnx_id',$crnId)->where('cr_status',0)->first();
                $customerId = $crNoteDetails->customer_id;
                $New_start_index = 0;          
                $length = count($data['unit_price']);
              
                $item_name = array_combine(range($New_start_index,  count($request->item_name) + ($New_start_index-1)),
                    array_values($request->item_name)); 
                $unit_id = array_combine(range($New_start_index,  count($request->unit_id) + ($New_start_index-1)),
                    array_values($request->unit_id)); 
                $qty = array_combine(range($New_start_index,  count($request->qty) + ($New_start_index-1)),
                    array_values($request->qty));                 
                $unit_price = array_combine(range($New_start_index,  count($request->unit_price) + ($New_start_index-1)),
                    array_values($request->unit_price)); 
                $amount = array_combine(range($New_start_index,  count($request->amount) + ($New_start_index-1)),
                    array_values($request->amount)); 
                
                CreditNote::where('cr_trnx_id',$crnId)->delete();

                for($i=0; $i < $length; $i++)
                {  
                    $findProduct = Product::find($item_name[$i]);           

                    $creditNote = new CreditNote;
                    $creditNote->cr_order_date = Carbon::createFromFormat('d-m-Y', $request->order_date)->format('Y-m-d');                  
                    $creditNote->cr_trnx_id = $crnId; 
                    $creditNote->customer_id = $customerId;     
                    $creditNote->item_name = $item_name[$i];
                    $creditNote->unit_id = $unit_id[$i];  
                    $creditNote->cr_qty = $qty[$i];                        
                    if($findProduct->primary_unit == $unit_id[$i])
                    {
                        $creditNote->cr_primary_qty = $qty[$i];
                        $creditNote->cr_secondary_qty = $qty[$i] * $findProduct->no_of_pcs;
                    }
                    if($findProduct->secondary_unit == $unit_id[$i])
                    {
                        $creditNote->cr_primary_qty = (int)($qty[$i] / $findProduct->no_of_pcs);
                        $creditNote->cr_secondary_qty = $qty[$i];
                    } 

                    $creditNote->cr_unit_price = $unit_price[$i];
                    $creditNote->cr_primary_pp = $findProduct->primary_pp_for_stock;
                    $creditNote->cr_secondary_pp = $findProduct->secondary_pp_for_stock;
                    $creditNote->cr_amount = $amount[$i];
                    $creditNote->cr_payment_type = $request->payment_type;
                    $creditNote->cr_delivery_charges = $request->delivery_charges;
                    $creditNote->cr_round_off = $request->round_off;
                    $creditNote->cr_gst_amount = $request->gst_amount;
                    $creditNote->cr_total = $request->total;
                    $creditNote->cr_paid = $request->paid;
                    $creditNote->cr_balance = $request->balance;
                    $creditNote->cr_prev_balance = $request->prev_balance;
                    $creditNote->cr_remarks = $request->remarks;
                    if($request->paid <= 0)
                    {
                        $creditNote->cr_payment_status  = 0;
                        $stockStatus = 0;
                    }
                    elseif($request->balance <= 0)
                    {
                        $creditNote->cr_payment_status  = 2;
                        $stockStatus = 2;           
                    }
                    else
                    {
                        $creditNote->cr_payment_status  = 1;
                        $stockStatus = 1;  
                    }
                    $creditNote->cr_status = 0;
                    $creditNote->save();
                    
                } // for loop end
                
                $creditNotes = CreditNote::leftJoin('products','credit_notes.item_name','=','products.product_id')
                                ->leftJoin('customers','credit_notes.customer_id','=','customers.customer_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units','credit_notes.unit_id','=','units.unit_id')
                                ->select(array('credit_notes.*','products.*','customers.*','units.*','brands.*'))  
                                ->orderBy('cr_note_id','asc')
                                ->get();    
                $customers = Customer::orderBy('customer_id','DESC')->get();
                $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                            ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                            ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*'))
                            ->orderBy('product_id','DESC')
                            ->get();
                $success = array('success' => "Cr. Note updated successfully.", 'creditNotes' => $creditNotes, 'customers' => $customers, 'products' => $products);
                return response()->json($success);
                
            }
            
        }
    }

    public function convert(Request $request)
    {
        if(request()->ajax())
        {         
            $validator = \Validator::make($request->all(), [
                'order_date' => 'date',
                'delivery_date' => 'required|date|before:tomorrow|after_or_equal:order_date',     
                ],[
                'delivery_date.before' => 'The date mustbe today or before.',
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }
            if($validator->passes())
            {               
                $data = CreditNote::where('cr_trnx_id',$request->cr_trnx_id)->where('cr_status',0)->get();
                $customerId = $data[0]['customer_id'];
                $deliveryDate = Carbon::createFromFormat('d-m-Y', $request->delivery_date)->format('Y-m-d');
             
                foreach($data as $d)
                {  
                    $findProduct = Product::find($d->item_name);     
                    if($findProduct->secondary_unit == $d->unit_id)
                    { 
                        $prevStockValue = $findProduct->stock_value;
                        $prevSecondaryStockQty = $findProduct->in_hand_stock_second;
                        $nowSecondaryQty = $d->cr_qty;
                        $newAmount = $nowSecondaryQty * $findProduct->secondary_pp;
                        $secondary_pp_for_stock = ($prevStockValue + $newAmount) / ($prevSecondaryStockQty + $nowSecondaryQty);
                        $primary_pp_for_stock = $secondary_pp_for_stock * $findProduct->no_of_pcs;
                  
                        $findProduct->primary_pp_for_stock = $primary_pp_for_stock;
                        $findProduct->secondary_pp_for_stock = $secondary_pp_for_stock;
                        $findProduct->in_hand_stock_primary = (int)( ($prevSecondaryStockQty + $nowSecondaryQty)/$findProduct->no_of_pcs );
                        $findProduct->in_hand_stock_second = $prevSecondaryStockQty + $nowSecondaryQty;
                        $findProduct->stock_value = $secondary_pp_for_stock * ($prevSecondaryStockQty + $nowSecondaryQty);

                    }
                    if($findProduct->primary_unit == $d->unit_id)
                    {
                        // all stock value calculation should be in secondary 
                        $prevStockValue = $findProduct->stock_value;
                        $prevSecondaryStockQty = $findProduct->in_hand_stock_second;
                        $nowSecondaryQty = $findProduct->no_of_pcs * $d->cr_qty; 
                        $newAmount = $nowSecondaryQty * $findProduct->secondary_pp;
                        $secondary_pp_for_stock = ($prevStockValue + $newAmount) / ($prevSecondaryStockQty + $nowSecondaryQty);
                        $primary_pp_for_stock = $secondary_pp_for_stock * $findProduct->no_of_pcs;

                        $findProduct->primary_pp_for_stock = $primary_pp_for_stock;
                        $findProduct->secondary_pp_for_stock = $secondary_pp_for_stock;
                        $findProduct->in_hand_stock_primary = (int)( ($prevSecondaryStockQty + $nowSecondaryQty)/$findProduct->no_of_pcs );
                        $findProduct->in_hand_stock_second = $prevSecondaryStockQty + $nowSecondaryQty;
                        $findProduct->stock_value = $secondary_pp_for_stock * ($prevSecondaryStockQty + $nowSecondaryQty);
                    }
                    // Product Stock qty calculation end                    
                    $findProduct->update();

                    $newStock = New Stock;
                    $newStock->stock_type = "2R";
                    $newStock->trnx_id  = $request->cr_trnx_id;  
                    $newStock->item_name  = $d->item_name;
                    $newStock->customer_id  = $customerId;     
                    $newStock->order_date  = $d->cr_order_date;   
                    $newStock->delivery_date  = $deliveryDate;       
                    $newStock->qty = $d->cr_qty;     
                    if($findProduct->primary_unit == $d->unit_id)
                    {
                        $newStock->primary_qty =  $d->cr_qty;
                        $newStock->secondary_qty =  $d->cr_qty * $findProduct->no_of_pcs;
                    }
                    if($findProduct->secondary_unit == $d->unit_id)
                    {
                        $newStock->primary_qty = (int)( $d->cr_qty / $findProduct->no_of_pcs);
                        $newStock->secondary_qty =  $d->cr_qty;
                    } 
                    $newStock->unit_id  = $d->unit_id;
                    $newStock->unit_price  = $d->cr_unit_price;
                    $newStock->amount  = $d->cr_amount;
                    $newStock->stock_stat  = $d->cr_payment_status;                
                    $newStock->save();
                } // for loop end
                
                $findCustomer = Customer::find($customerId);
                $findCustomer->balance = $request->balance;
                $findCustomer->update();

                CreditNote::where('cr_trnx_id',$request->cr_trnx_id)->update(['cr_delivery_date' => $deliveryDate, 'cr_status' => 1]);

                $creditNotes = CreditNote::leftJoin('products','credit_notes.item_name','=','products.product_id')
                                ->leftJoin('customers','credit_notes.customer_id','=','customers.customer_id')
                                ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                ->leftJoin('units','credit_notes.unit_id','=','units.unit_id')
                                ->select(array('credit_notes.*','products.*','customers.*','units.*','brands.*'))  
                                ->orderBy('cr_note_id','asc')
                                ->get();    
                $customers = Customer::orderBy('customer_id','DESC')->get();
                $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                            ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                            ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*'))
                            ->orderBy('product_id','DESC')
                            ->get();
                $success = array('success' => "Cr. Note converted successfully.", 'creditNotes' => $creditNotes, 'customers' => $customers, 'products' => $products);
                return response()->json($success);
                
            }
            
        }
    }

    public function destroy(Request $request)
    {
        $invId = $request->id;


        $is_delete = CreditNote::where('cr_trnx_id',$invId)->delete();

       if($is_delete)
       {
            $creditNotes = CreditNote::leftJoin('products','credit_notes.item_name','=','products.product_id')
                            ->leftJoin('customers','credit_notes.customer_id','=','customers.customer_id')
                            ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('units','credit_notes.unit_id','=','units.unit_id')
                            ->select(array('credit_notes.*','products.*','customers.*','units.*','brands.*'))  
                            ->orderBy('cr_note_id','asc')
                            ->get();    
            $customers = Customer::orderBy('customer_id','DESC')->get();
            $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                        ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                        ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                        ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*'))
                        ->orderBy('product_id','DESC')
                        ->get();
            $success = array('success' => "Cr. Note deleted successfully.", 'creditNotes' => $creditNotes, 'customers' => $customers, 'products' => $products);
            return response()->json($success);
       }
    }
   
}
