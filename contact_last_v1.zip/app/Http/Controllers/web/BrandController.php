<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Brand;
use App\Models\Portal\Product;
use App\Models\Portal\Supplier;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Validator;
use Image;  

class BrandController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $brands = Brand::join('suppliers','brands.supplier_id','suppliers.supplier_id')
                        ->select(array('suppliers.*','brands.*'))
                        ->orderBy('brand_id','DESC')->get();
    	if(request()->ajax())
        {
          return datatables()->of($brands)
                ->addColumn('image', function($data){
                    $image = '<img src="'.asset($data->brand_img).'" width="70" class="img-thumbnail" />';  
                    return $image;
                })
                ->addColumn('action', function($data){
                  $button = '<button type="button" name="view" id="'.$data->brand_id.'" data-name="'.$data->brand_name.'" data-desc="'.$data->brand_desc.'" data-company="'.$data->supplier_id.'" data-image="'.asset($data->brand_img).'" data-status="'.$data->brand_stat.'" class="view btn btn-outline-info  btn-sm">View</button>';
                  $button .= '&nbsp;';
                  $button .= '<button type="button" name="edit" id="'.$data->brand_id.'" data-name="'.$data->brand_name.'" data-desc="'.$data->brand_desc.'" data-company="'.$data->supplier_id.'" data-image="'.asset($data->brand_img).'" data-status="'.$data->brand_stat.'" class="edit btn btn-outline-primary btn-sm">Edit</button>';
                  $button .= '&nbsp;';
                  $button .= '<button type="button" data-id="'.$data->brand_id.'" data-name="'.$data->brand_name.'" data-url="' . route('brand.delete') .'"  class="delete btn btn-outline-danger btn-sm">Del</button>';
                  return $button;
                })
                ->addColumn('status', function($data){
                  if( $data->brand_stat == 1)
                  {
                    $status = '<a id="'.$data->brand_id.'" data-url="' . route('brand.status', $data->brand_id) .'" class="status badge badge-primary">Active</a>';  
                  }
                  else
                  {
                    $status = '<a id="'.$data->brand_id.'" data-url="' . route('brand.status', $data->brand_id) .'" class="status badge badge-secondary" style="color: #fff">Deactive</a>';   
                  }
                  return $status;
                })
                ->addIndexColumn()
                ->rawColumns(['action' , 'status','image'])
                ->make(true);       
                    
        }     
        else
        {
            $suppliers = Supplier::orderBy('supplier_name','ASC')->get();   
            return view('portal.brand.index',['suppliers' => $suppliers]);
        }
    }

    public function create(Request $request)
    {
    	if(request()->ajax())
        {
            $validator = \Validator::make($request->all(), [
            'brand_name' => 'required|max:255|unique:brands,brand_name',
            'brand_desc' => 'required|max:255',
            'supplier_id' => 'required|not_in:0',
            'image' => 'required|mimes:jpeg,png,jpg,gif,svg|max:2048', 
            ],[
                'image.required'=>'Image format should be in jpeg,png,jpg,gif,svg|max:2048',
                'image.upload'=>'Image format should be in jpeg,png,jpg,gif,svg|max:2048',                
            ]);

            if ($validator->fails())         
            {
            	return response()->json(['errors' => $validator->errors()]);
            }

            $brand = new Brand;
            $image = $request->file('image');
            if ($image){
                $image_name=Str::uuid();
                $ext=strtolower($image->getClientOriginalExtension());
                $image_full_name=$image_name.'.'.$ext;
                $upload_path='../img-file-manager/portal/brand/';
                $image_url=$upload_path.$image_full_name;
                $resize_image = Image::make($image->getRealPath());
                $success = $resize_image->resize(270, 240)->save($upload_path . $image_full_name);
                if($success){
                    $brand->brand_img=$image_url;
                }
            }
            $brand->brand_name = Str::lower($request->brand_name);
            $brand->brand_desc = Str::lower($request->brand_desc);
            $brand->supplier_id = Str::lower($request->supplier_id);
            $brand->brand_stat = $request->brand_stat;
            $is_saved = $brand->save();

            if($is_saved)
            {
                $success = array('success' => 'Brand saved successfully');
                return response()->json($success);
            }
        }
    }

    public function update(Request $request)
    {
        $image = $request->file('image');
        $brands = Brand::find($request->brand_id);       
         
        $validator = \Validator::make($request->all(), [
            'brand_name' => ['required','max:255',
                Rule::unique('brands')->ignore($brands->brand_name,'brand_name'),
            ],
            'brand_desc' => 'required|max:255',
            'supplier_id' => 'required|not_in:0',
            'brand_stat' => 'required'
        ]);
        if ($validator->fails())
        {          
            return response()->json(['errors' => $validator->errors()]);
        }
         
        if($validator->passes())
        {  
            if($image)
            { 
                $validator = \Validator::make($request->all(), [          
                    'image' => 'required|mimes:jpeg,png,jpg,gif,svg|max:2048|image'     
                ],[
                    'image.required'=>'Image format should be in jpeg,png,jpg,gif,svg',
                    'image.uploaded'=>'Image format should be in jpeg,png,jpg,gif,svg|max:2048', 
                ]); 

                if ($validator->fails())
                {          
                    return response()->json(['errors' => $validator->errors()]);
                }

                if(file_exists($brands->brand_img)){
                    unlink($brands->brand_img);
                }

                $image_name=Str::uuid();;
                $ext=strtolower($image->getClientOriginalExtension());
                $image_full_name=$image_name.'.'.$ext;
                $upload_path='../img-file-manager/portal/brand/';
                $image_url=$upload_path.$image_full_name;
                $success=$image->move($upload_path,$image_full_name);
                if($success){
                    $brands->brand_img = $image_url;
                }
            }
            
            $brands->brand_name = Str::lower($request->brand_name);
            $brands->brand_desc = Str::lower($request->brand_desc);
            $brands->supplier_id = Str::lower($request->supplier_id);
            $brands->brand_stat = 1;
            $is_saved = $brands->update();

            if($is_saved)
            {
                $success = array('success' => 'Brand updated successfully');
                return response()->json($success);   
            } 
            
        }
    }

    public function status($brand_id)
    {
        $brand = Brand::where('brand_id',$brand_id)->first();
        if($brand->brand_stat == 1)
        {
            Brand::where('brand_id',$brand_id)->update(['brand_stat' => 0]);
            $success = array('success' => 'Brand status change successfullly');
            return response()->json($success);
        }
        else
        {
            Brand::where('brand_id',$brand_id)->update(['brand_stat' => 1]);
            $success = array('success' => 'Brand status change successfullly');
            return response()->json($success);
        }

    }

    public function destroy(Request $request)
    {
        $brand = Brand::find($request->id);        
        $product = Product::where('brand_id',$request->id)->first();
        if($product)
        {
            $error = array('error' => "This brand can't be deleted.");
            return response()->json($error);
        }
        else
        {
            if(file_exists($brand->brand_img))
            {
                unlink($brand->brand_img);
                $brand->delete();
                $success = array('success' => 'Brand deleted successfullly');
                return response()->json($success);
            }
            else
            {
                $brand->delete();
                $success = array('success' => 'Brand deleted successfullly');
                return response()->json($success);
            }
        }
    }
}
