<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Product;
use App\Models\Portal\Stock;
use App\Models\Portal\Brand;
use App\Models\Portal\Unit;
use App\Models\Portal\Supplier;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;


class StockController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {    
        if(request()->ajax())
        {
            $startDate = $_GET['startDate']; 
            $endDate = $_GET['endDate'];
            $product_id = $_GET['productId'];

            $stocks = Stock::where('order_date', '>=', $startDate)
                            ->where('order_date', '<=', $endDate)
                            ->where('item_name', $product_id)
                            ->leftJoin('products','stocks.item_name','products.product_id')
                            ->leftJoin('units','stocks.unit_id','units.unit_id')
                            ->leftJoin('customers','stocks.customer_id','customers.customer_id')
                            ->leftJoin('suppliers','stocks.supplier_id','=','suppliers.supplier_id')
                            ->select(array('stocks.*','products.*','units.*','suppliers.*','customers.*'))
                            ->orderBy('stocks.stock_id','desc')->get();          
            return datatables()->of($stocks)       
                ->addColumn('transaction', function($data){
                    if($data->stock_type == 1){
                        $transaction = '<span class="item-amount text-sm text-color text-primary text-capitalize">CPO-'.$data->trnx_id.'</span>';
                    }
                    if($data->stock_type == '1R'){
                        $transaction = '<span class="item-amount text-sm text-color text-info text-capitalize">DRN-'.$data->trnx_id.'</span>';
                    }
                    if($data->stock_type == 2){
                        $transaction = '<span class="item-amount text-sm text-color text-danger text-capitalize">INV-'.$data->trnx_id.'</span>' ;                
                    }
                    if($data->stock_type == '2R'){
                        $transaction = '<span class="item-amount text-sm text-color text-warning text-capitalize">CRN-'.$data->trnx_id.'</span>';   
                    }        
                    return $transaction;
                })      
                ->addColumn('action', function($data){                  
                    $action = '<a class="pr-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye text-primary"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg></button>'; 
                    return $action;
                })
                ->rawColumns(['transaction','action'])      
                ->make(true); 
        }  
        else
        {
            $products = Product::join('brands','products.brand_id','brands.brand_id')
                            ->orderBy('in_hand_stock_primary', 'desc')
                            ->get();  
            return view('portal.stock.index',['products' => $products ]);        
        }       
    }

    public function product($id)
    {

    }

}
