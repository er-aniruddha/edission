<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\BankAccount;
use App\Models\Portal\BankTransaction;
use Illuminate\Support\Str;
use Validator;
use Carbon\Carbon;

class BankController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $banktrns = BankTransaction::leftJoin('bank_accounts','bank_transactions.baccount_id','bank_accounts.baccount_id')
                                    ->select(array('bank_transactions.*','bank_accounts.*','bank_transactions.date','bank_transactions.id as id','bank_transactions.remarks as remarks'))
                                    ->orderBy('bank_transactions.date','desc')->get();
        // $bankTrns = BankTransaction::where('baccount_id',"88594720-4d3b-4baa-a115-486ecf80b296")->sum('amount');
                                    // return response()->json($bankTrns);
        if(request()->ajax())
        {
          return datatables()->of($banktrns)
                ->editColumn('date', function ($data) {
                    return date('d-m-Y', strtotime($data->date));
                })
                ->addColumn('action', function($data){
                    if(  $data->trnx_type != 0)
                    {
                        $action = '<div class="item-action dropdown">
                                    <a href="#" data-toggle="dropdown" class="text-muted" aria-expanded="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" role="menu" x-placement="bottom-end" style="position: absolute; transform: translate3d(-144px, 19px, 0px); top: 0px; left: 0px; will-change: transform;">
                                        <a class="dropdown-item edit" data-id="'.$data->id.'" data-trnxid="'.$data->bank_trnx_id.'" data-name="'.$data->account_name.'" data-trnxtype="'.$data->trnx_type.'" data-bacid="'.$data->baccount_id.'" data-amount="'.abs($data->amount).'" data-date="'.$data->date.'" data-remarks="'.$data->remarks.'">Edit</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item delete" data-id="'.$data->id.'" data-trnxid="'.$data->bank_trnx_id.'">Delete</a>
                                    </div>
                                </div>'; 
                                return $action;
                    }
                    
                    
                })                
                ->addColumn('amount', function($data){
                    
                  return $data->amount.'/'.$data->trnx_type;
                })              
                
                ->addIndexColumn()
                ->rawColumns(['action','amount'])                
                ->make(true);       
                    
        }       
        else
        {
            $bankaccounts = BankAccount::orderBy('date','asc')->get();
            return view('portal.bank.index',['bankaccounts' => $bankaccounts]);
        }
    }

    public function create(Request $request)
    {
        $uuid = Str::uuid();
        if(request()->ajax())
        {
            if($request->date)
            {
              $date = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
              $validator_date = \Validator::make($date, [
                'date' => 'required|date|before:tomorrow',         
              ],[
                  'date.before' => 'The date mustbe today or before.',
                  'date.unique' => 'Can not add two item on same date',
              ]);
              if ($validator_date->fails())         
              {
                return response()->json(['errors' => $validator_date->errors()]);
              }
            }

            $validator = \Validator::make($request->all(), [
              'date' => 'required|date|before:tomorrow',         
              'account_name' => 'required',
              'opening_balance' => 'required|integer',
            ],[
                'date.before' => 'The date mustbe today or before.',
            ]);
            if ($validator->fails())         
            {
              return response()->json(['errors' => $validator->errors()]);
            }

            if($validator->passes())
            {
                $bank = new BankAccount;
                $bank->baccount_id = $uuid;
                $bank->account_name = Str::lower($request->account_name);
                $bank->opening_balance = $request->opening_balance;
                $bank->account_balance = $request->opening_balance;
                $bank->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
                $bank->remarks = $request->remarks;
                $is_save = $bank->save();

                $bankTrns = new BankTransaction;
                $bankTrns->bank_trnx_id = "BT-".(8000000000+strtotime("now"));
                $bankTrns->baccount_id = $uuid;
                $bankTrns->trnx_type = 0;
                $bankTrns->amount = $request->opening_balance;
                $bankTrns->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
                $bankTrns->remarks = $request->remarks;
                $is_save = $bankTrns->save();

                $bankaccounts = BankAccount::orderBy('account_name','desc')->get();
                $success = array('success' => 'Bank account created successfully.', 'bankaccounts' => $bankaccounts);
                return response()->json($success);
            }
            
        }
    }

    public function update(Request $request)
    {
        if(request()->ajax())
        {
            if($request->date)
            {
              $date = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
              $validator_date = \Validator::make($date, [
                'date' => 'required|date|before:tomorrow',         
              ],[
                  'date.before' => 'The date mustbe today or before.',
                  'date.unique' => 'Can not add two item on same date',
              ]);
              if ($validator_date->fails())         
              {
                return response()->json(['errors' => $validator_date->errors()]);
              }
            }

            $validator = \Validator::make($request->all(), [
              'date' => 'required|date|before:tomorrow',         
              'account_name' => 'required',
              'opening_balance' => 'required|integer',
            ],[
                'date.before' => 'The date mustbe today or before.',
            ]);
            if ($validator->fails())         
            {
              return response()->json(['errors' => $validator->errors()]);
            }

            if($validator->passes())
            {  
                $bankTrns = BankTransaction::where('baccount_id',$request->baccount_id)
                                            ->where('trnx_type', 0)
                                            ->update(['amount' => $request->opening_balance, 'date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d'), 'remarks' => $request->remarks]);

                $sumAmount = BankTransaction::where('baccount_id',$request->baccount_id)->sum('amount');

                $bank = BankAccount::where('baccount_id',$request->baccount_id)->first();   
                $bank->account_name = Str::lower($request->account_name);
                $bank->opening_balance = $request->opening_balance;
                $bank->account_balance = $sumAmount;
                $bank->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
                $bank->remarks = $request->remarks;
                $is_save = $bank->update();

                $bankaccounts = BankAccount::orderBy('date','asc')->get();
                $success = array('success' => 'Bank account update successfully.', 'bankaccounts' => $bankaccounts);
                return response()->json($success);
            }
            
        }
    }

   
}
