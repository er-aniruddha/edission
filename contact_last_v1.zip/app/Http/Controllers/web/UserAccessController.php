<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Image;  
use Illuminate\Support\Facades\Hash;

class UserAccessController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $users = User::orderBy('id','ASC')->get();
    	return view('portal.user.index',['users' => $users]);
    }

    public function chnagePermission(Request $request)
    {
        $validator = \Validator::make($request->all(), [       
            'user_permission' => 'required',
        ],[
            'user_permission.not_in' => 'Please select one permission.',
        ]);

        if ($validator->fails())
        {
        return response()->json(['errors' => $validator->errors()]);
        }

        $user = User::where('id',$request->user_id)->update(['user_permission' => $request->user_permission]);

        $success = array('success' => 'User permission changed successfully');

        return response()->json($success);
    }

    public function profile()
    {
        if(Auth::check())
        {
            $user = User::find(Auth::id());
            return view('portal.user.profile.userProfileIndex',['user' => $user]);
        }
    }

    public function profileUpdate(Request $request)
    {
        if(Auth::check())
        {
            $user = User::find(Auth::id());
    
            $image = $request->file('image');

            if($image)
            {
                $validator = \Validator::make($request->all(), [    
                    'f_name' => 'required|max:255',
                    's_name' => 'required|max:255',       
                    'f_name.required' => 'Please enter First name',
                    's_name.required' => 'Please enter Surname', 
                    'image' => 'required|mimes:jpeg,png,jpg,gif,svg|max:2048|image'     
                ],[
                    'image.required'=>'Image format should be in jpeg,png,jpg,gif,svg',
                    'image.uploaded'=>'Image format should be in jpeg,png,jpg,gif,svg|max:2048', 
                ]); 
                if ($validator->fails())
                {          
                    return response()->json(['errors' => $validator->errors()]);
                }

                if($validator->passes())
                {
                    if($image)
                    {  
                    
                        $image_name=Str::uuid();

                        $ext=strtolower($image->getClientOriginalExtension());

                        $image_full_name=$image_name.'.'.$ext;

                        $upload_path='../img-file-manager/myportal/users-img/';

                        $image_url = $upload_path.$image_full_name;

                        $resize_image = Image::make($image->getRealPath());

                        $success = $resize_image->resize(600, 600)->save($upload_path . $image_full_name);

                        if($success){
                            $user->user_img = $image_url;
                        }
                        $user->f_name = $request->f_name;
                        $user->s_name = $request->s_name;
                        $is_saved = $user->update();
                        return response()->json(['success' => 'Your information updated successfully.' , 'img_url' => $image_url]);             
                    }
                }            
            }
            else
            {
                $validator = \Validator::make($request->all(), [
                    'f_name' => 'required|max:255',
                    's_name' => 'required|max:255',  
                    ],[
                    'f_name.required' => 'Please enter First name',
                    's_name.required' => 'Please enter Surname',
                ]); 
                if ($validator->fails())
                {
                    return response()->json(['errors' => $validator->errors()]);
                }  
        
                $user->f_name = $request->f_name;
                $user->s_name = $request->s_name;
                $user->update();
        
                $success = array('success' => 'Your information updated successfully');  
                return response()->json($success);

            } //else end here            
        } //Auth Check end here
    } // Profile Update Function end here

    public function chnagePassword(Request $request)
    {
        $validator = \Validator::make($request->all(), [            
            'old_password' => 'required|min:6',
            'new_password' => 'required|min:8|string|confirmed',
        ],[
            'old_pin.required' => 'Please enter old password.',
            'new_pin.required' => 'Please enter new password.',
        ]);

        if ($validator->fails())
        {
            return response()->json(['errors' => $validator->errors()]);
        }

        $user = User::find(Auth::id());

        if(Hash::check($request->old_password, $user->password))
        {
            if($request->old_password == $request->new_password)
            {
                return response()->json(['error' => 'Old Password and New Password can not be same.']);   
            }

            $user->password = Hash::make($request['new_password']);
            $is_update = $user->update();

            if($is_update)
            {
                $success = array('success' => "Password has been chnaged successfully.");
                return response()->json($success);
            }
        }
        else
        {
            return response()->json(['error' => 'Old Password does not matched.']);
        }
    }

    public function remove(Request $request)
    {
        $user = User::find($request->del_id);

        if(file_exists($user->product_img))
        {
            unlink($user->product_img);
            $user->delete();
            $success = array('success' => 'User deleted successfully');
            return response()->json($success);
        }
        else
        {
            $user->delete();
            $success = array('success' => 'User deleted successfully');
            return response()->json($success);
        }
    }
}
