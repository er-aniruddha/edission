<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\LoanAccount;
use App\Models\Portal\LoanTransaction;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Validator;
use Carbon\Carbon;

class LoanController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $loanTrnx = LoanTransaction::leftJoin('loan_accounts','loan_transactions.loan_ac_id','loan_accounts.loan_ac_id')
                                    ->select(array('loan_transactions.*','loan_accounts.*'))
                                    ->orderBy('loan_transactions.id','desc')->get();
        
        if(request()->ajax())
        {
          return datatables()->of($loanTrnx)                               
                ->addColumn('status', function($data){
                    if($data->status == 0)
                    {
                        $status = '<span class="item-badge badge text-uppercase bg-secondary">Not Paid</span>';
                    }
                    if($data->status == 1)
                    {
                        $status = '<span class="item-badge badge text-uppercase bg-success">Paid</span>';                        
                    }
                    if($data->status == 2)
                    {
                        $status = '<span class="item-badge badge text-uppercase bg-danger">Paid (CLosed) </span>';                        
                    }
                    return $status;
                })              
                ->addColumn('action', function($data){    
                    if($data->status == 0)
                    {                       
                        $action = '<button type="button" data-trnxid="'.$data->loan_trnx_id.'" data-loanacid="'.$data->loan_ac_id.'" data-name="'.$data->account_name.'" data-billdate="'.$data->bill_date.'" data-paymentdate="'.$data->payment_date.'"  data-emi="'.$data->total_emi.'" data-loanacid="'.$data->loan_ac_id.'" class="paid btn btn-outline-danger  btn-sm">Paid</button>';
                    }
                    else
                    {
                        $action = '<button type="button" data-trnxid="'.$data->loan_trnx_id.'" data-name="'.$data->account_name.'" data-billdate="'.$data->bill_date.'" data-paymentdate="'.$data->payment_date.'" data-emi="'.$data->total_emi.'" data-paid="'.$data->paid_amount.'" data-paiddate="'.$data->paid_date.'" data-remarks="'.$data->trnx_remarks.'" class="view btn btn-outline-info  btn-sm">View</button>';
                    }
                    return $action;
                    
                }) 
                ->addIndexColumn()
                ->rawColumns(['action','status'])                
                ->make(true);       
                    
        }       
        else
        {
            $loanaccounts = LoanAccount::orderBy('date','asc')->get();
            return view('portal.loan.index',['loanaccounts' => $loanaccounts]);
        }
        
    }

    public function compute(Request $request)
    {
        if(request()->ajax())
        {
            $validator = \Validator::make($request->all(), [
                'date' => 'required|date|before:tomorrow',         
                'account_name' => 'required',
                'loan_amount' => 'required|numeric',
                'interest_rate' => 'required|numeric',
                'year' => 'required|integer',
                'month' => 'required|integer|not_in:0',
            ],[
                'date.before' => 'The date mustbe today or before.',
                'month.required' => 'The tenure field is required.',
                'month.not_in' => 'The tenure field is required.',
            ]);
            if ($validator->fails())         
            {
              return response()->json(['errors' => $validator->errors()]);
            }

            if($validator->passes())
            {
                $principal = $request->loan_amount; 
                $eRate = $request->interest_rate / (12*100);
                $time = $request->month;                 
      
                $emi = ($principal * $eRate * pow(1 + $eRate, $time)) / 
                  (pow(1 + $eRate, $time) - 1);

                $startDate = $request->date;
                
                $totalInt = 0;
                $totalPayment = 0;
                for($i=0; $i < $time; $i++)
                {
                    $principalPaid = $emi - ($principal * $eRate);
                    $monthlyInt = $principal * $eRate;
                    $principalPaid = $emi - $monthlyInt;
                    $endingBal = $principal - $principalPaid;
                    $billDate = Carbon::createFromFormat('d-m-Y', $request->date)->addMonth($i+1)->firstOfMonth();
                    $paymentDate = Carbon::createFromFormat('d-m-Y', $request->date)->addMonth($i+1)->firstOfMonth()->addDay(9);

                    
                    $totalInt = $totalInt + $monthlyInt;
                    $totalPayment = $totalPayment + $emi;

                    $loanTableData[$i] = array(
                        'month'=> $i+1,
                        'billDate' => $billDate,
                        'paymentDate'=> $paymentDate,
                        'interest'=>number_format($monthlyInt,2,'.',','),
                        'principalPaid'=> number_format($principalPaid,2,'.',','),
                        'totalPayment'=> number_format($emi,2,'.',','),
                        'endingBalance'=> number_format($endingBal,2,'.',','),
                    );
                    $principal = $endingBal;
                }

                $success = array('accountName' => $request->account_name,'loanAmount' => $request->loan_amount,'intRate' => $request->interest_rate,'month' => $request->month,'startDate' => $request->date, 'emi' => $emi,'totalInt' => $totalInt,'totalPayment' => $totalPayment,'loanTableData' => $loanTableData);

                return response()->json($success);
            }
            
        }
    }

    public function create(Request $request)
    {
        $uuid = Str::uuid();
        if(request()->ajax())
        {
            $validator = \Validator::make($request->all(), [
              'date' => 'required|date|before:tomorrow',         
              'account_name' => 'required|unique:loan_accounts,account_name',
              'loan_amount' => 'required|numeric',
              'interest_rate' => 'required|numeric',
              'year' => 'required|integer',
              'month' => 'required|integer|not_in:0',
            ],[
                'date.before' => 'The date mustbe today or before.',
                'month.required' => 'The tenure field is required.',
                'month.not_in' => 'The tenure field is required.',
            ]);
            if ($validator->fails())         
            {
              return response()->json(['errors' => $validator->errors()]);
            }

            if($validator->passes())
            {
                $principal = $request->loan_amount; 
                $eRate = $request->interest_rate / (12*100);
                $time = $request->month;                 
      
                $emi = ($principal * $eRate * pow(1 + $eRate, $time)) / 
                  (pow(1 + $eRate, $time) - 1);


                $loan = new LoanAccount;
                $loan->loan_ac_id = $uuid;
                $loan->account_name = Str::lower($request->account_name);
                $loan->loan_amount = $request->loan_amount;
                $loan->interest_rate = $request->interest_rate;
                $loan->year = $request->year;
                $loan->month = $request->month;
                $loan->emi = $emi;
                $loan->loan_balance = $request->loan_amount;
                $loan->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
                $loan->remarks = $request->remarks;
                $is_save = $loan->save();

                if($is_save)
                {
                    $loanaccounts = LoanAccount::orderBy('date','asc')->get();
                    $success = array('message' => 'Loan account created successfully.','loanaccounts'=> $loanaccounts);
                    return response()->json($success);
                }                
            }            
        }
    }

    public function edit(Request $request)
    {
        $loanAcTrnx = LoanTransaction::where('loan_ac_id',$request->loan_ac_id)->count();
        $loanAcDetails = LoanAccount::where('loan_ac_id',$request->loan_ac_id)->first();
        if(request()->ajax())
        {
            if($loanAcTrnx > 0)
            {
                $errors = array('errors'=> array('account_name' => array('0'=>"Edit can't be completed. Emi already generated.")));
                return response()->json($errors);
            }
            else
            {
                $validator = \Validator::make($request->all(), [
                    'date' => 'required|date|before:tomorrow',         
                    'account_name' => ['required','max:255',
                        Rule::unique('loan_accounts')->ignore($loanAcDetails->account_name,'account_name'),
                    ],
                    'loan_amount' => 'required|numeric',
                    'interest_rate' => 'required|numeric',
                    'year' => 'required|integer',
                    'month' => 'required|integer',
                ],[
                    'date.before' => 'The date mustbe today or before.',
                    'month.required' => 'The tenure field is required.',
                    'month.not_in' => 'The tenure field is required.',
                ]);
                if ($validator->fails())         
                {
                  return response()->json(['errors' => $validator->errors()]);
                }

                if($validator->passes())
                {
                    $principal = $request->loan_amount; 
                    $eRate = $request->interest_rate / (12*100);
                    $time = $request->month;                 
          
                    $emi = ($principal * $eRate * pow(1 + $eRate, $time)) / 
                      (pow(1 + $eRate, $time) - 1);


                    
                    $loanAcDetails->account_name = Str::lower($request->account_name);
                    $loanAcDetails->loan_amount = $request->loan_amount;
                    $loanAcDetails->interest_rate = $request->interest_rate;
                    $loanAcDetails->year = $request->year;
                    $loanAcDetails->month = $request->month;
                    $loanAcDetails->emi = $emi;
                    $loanAcDetails->loan_balance = $request->loan_amount;
                    $loanAcDetails->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
                    $loanAcDetails->remarks = $request->remarks;
                    $is_update = $loanAcDetails->update();

                    if($is_update)
                    {
                        $loanaccounts = LoanAccount::orderBy('date','asc')->get();
                        $success = array('message' => 'Loan account updated successfully.','loanaccounts'=> $loanaccounts);
                        return response()->json($success);
                    }                    
                }
            }            
        }
    }

    public function closeView(Request $request)
    {
        $loanAcDetails = LoanAccount::where('loan_ac_id',$request->loan_ac_id)->first();
        $requestAcTrnxCheck = LoanTransaction::where('loan_ac_id',$request->loan_ac_id)->where('status',0)->count();
        $hasAnyTrnx = LoanTransaction::where('loan_ac_id',$request->loan_ac_id)->count();
        $loanBalance = $loanAcDetails->loan_balance;
        $eDayRate = $loanAcDetails->interest_rate/(365*100);
        $dayInt = $loanBalance * $eDayRate;

        if($requestAcTrnxCheck > 0)
        {
            return response()->json(['errors' => 'You have to paid EMI first.']);
        }
        else
        {
            if($hasAnyTrnx <= 0)
            {
                    
                $startDay = Carbon::parse($loanAcDetails->date);
                $todayDate = Carbon::now();
                $dateDiff = $startDay->diffInDays($todayDate);
                $totalInt = $dayInt * $dateDiff;

                $totalCloseAmount = $loanBalance + $totalInt;
                
            }
            else
            {
                $startDay = new Carbon('first day of this month');
                $todayDate = Carbon::now();
                $dateDiff = $startDay->diffInDays($todayDate);
                $totalInt = $dayInt * $dateDiff;

                $totalCloseAmount = $loanBalance + $totalInt;
            }

            $success = array('totalCloseAmount' => $totalCloseAmount,'loanAcDetails'=> $loanAcDetails);
            return response($success);
        }
        
    }

    public function closeConfirm(Request $request)
    {

        $loanAcDetails = LoanAccount::where('loan_ac_id',$request->loan_ac_id)->first();
        $trnxId = 2000000000+strtotime("now"); 
        
        if(request()->ajax())
        {
            $validator = \Validator::make($request->all(), [
                'paid_amount' => 'required|numeric|min:'.$request->trnx_emi.'',
                'date' => 'required|date|before:tomorrow',  
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }
            if($validator->passes())
            {
                $newLoanTrnx = new LoanTransaction;

                $newLoanTrnx->loan_trnx_id = $trnxId;
                $newLoanTrnx->loan_ac_id = $request->loan_ac_id;
                $newLoanTrnx->bill_date = Carbon::createFromFormat('d-m-Y', $request->bill_date)->format('Y-m-d');
                $newLoanTrnx->payment_date = Carbon::createFromFormat('d-m-Y', $request->payment_date)->format('Y-m-d');
                $newLoanTrnx->prev_loan_balance = $loanAcDetails->loan_balance;
                $newLoanTrnx->interest_of_emi = $request->trnx_emi - $loanAcDetails->loan_balance;
                $newLoanTrnx->principal_of_emi = $loanAcDetails->loan_balance;
                $newLoanTrnx->total_emi = $request->trnx_emi;       
                $newLoanTrnx->paid_amount = $request->paid_amount;
                $newLoanTrnx->interest_paid = $request->trnx_emi - $loanAcDetails->loan_balance;
                $newLoanTrnx->principal_paid = $loanAcDetails->loan_balance;
                $newLoanTrnx->loan_balance_after_paid = 0;
                $newLoanTrnx->paid_date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
                $newLoanTrnx->status = '2';
                $newLoanTrnx->trnx_remarks = $request->trnx_remarks;
                $newLoanTrnx->save(); //loan_transaction update

                $loanAcDetails->loan_balance =0;
                $loanAcDetails->loan_status = 0;
                $loanAcDetails->update(); //loan_account update

                $loanaccounts = LoanAccount::orderBy('id','asc')->get();
                $success = array('message' => 'Loan cLosed successfully.','loanaccounts' => $loanaccounts);
                return response()->json($success);
            }
        }
    }
}
