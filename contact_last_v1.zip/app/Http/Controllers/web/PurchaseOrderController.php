<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Purchase;
use App\Models\Portal\Product;
use App\Models\Portal\Unit;
use App\Models\Portal\Supplier;
use App\Models\Portal\Stock;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Validator;

class PurchaseOrderController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        

        if(request()->ajax())
        {
            $startDate = $_GET['startDate']; 
            $endDate = $_GET['endDate'];
            $poUpDate = Purchase::where('order_date', '>=', $startDate)
                                ->where('order_date', '<=', $endDate)
                                ->leftJoin('products','purchases.item_name','=','products.product_id')
                                ->leftJoin('units','purchases.unit_id','=','units.unit_id')
                                ->leftJoin('suppliers','purchases.supplier_id','=','suppliers.supplier_id')
                                ->select(array('purchases.balance as PO_balance','purchases.*','products.*','units.*','suppliers.*'))
                                ->where('purchases.status',0)
                                ->orderBy('po_id','desc')
                                ->get()->unique('po_id');       
            return datatables()->of($poUpDate)
                ->editColumn('order_date', function ($data) {
                    return date('d-m-Y', strtotime($data->order_date));
                })
                ->editColumn('delivery_date', function ($data) {
                    if($data->delivery_date)
                    {
                        $deliveryDate = date('d-m-Y', strtotime($data->delivery_date));
                    }
                    else
                    {
                        $deliveryDate = '<span class="item-badge badge text-uppercase bg-warning">Not Deliverd</span>';  
                    }
                    return $deliveryDate;
                })
                ->addColumn('action', function($data){
                    $button = '<button type="button" data-poid="'.$data->po_id.'" data-status="'.$data->status.'" class="view btn btn-outline-info  btn-sm">View</button>';
                    $button .= '&nbsp;';
                    if($data->status == 0){
                        $button .= '<button type="button" data-poid="'.$data->po_id.'" data-status="'.$data->status.'" class="edit btn btn-outline-primary btn-sm">Edit</button>';
                        $button .= '&nbsp;';                  
                        $button .= '<button type="button" data-poid="'.$data->po_id.'" class="delete btn btn-outline-danger btn-sm">Del</button>';
                    
                    }
                  return $button;
                })
                ->addColumn('status', function($data){
                  if( $data->status == 1)
                  {
                    $status = '<span class="item-badge badge text-uppercase bg-success">Order Complete</span>';  
                  }
                  else
                  {
                    $status = '<a class="item-badge badge text-uppercase bg-secondary over-due" data-poid="'.$data->po_id.'">Over Due</a>';   
                  }
                  return $status;
                })
                ->addIndexColumn()
                ->rawColumns(['action' , 'status', 'order_date', 'delivery_date'])                
                ->make(true);       
                    
        } 
        else{
            $allPoItem = Purchase::leftJoin('products','purchases.item_name','=','products.product_id')
                            ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('units','purchases.unit_id','=','units.unit_id')
                            ->leftJoin('suppliers','purchases.supplier_id','=','suppliers.supplier_id')
                            ->select(array('purchases.balance as PO_balance','purchases.*','products.*','units.*','suppliers.*','brands.*'))
                            ->orderBy('purchase_id','asc')
                            ->get(); 
            $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('suppliers','brands.supplier_id','=','suppliers.supplier_id')
                            ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                            ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                            ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*','suppliers.*'))
                            ->orderBy('product_name','ASC')
                            ->get();            
            $suppliers = Supplier::orderBy('supplier_name','ASC')->get();
            return view('portal.purchase_order.index',['products'=>$products, 'allPoItem' => $allPoItem , 'suppliers' =>$suppliers]);
        }    
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        // $data =  $request->all();
        // return response()->json($data);

        if(request()->ajax())
        {
            $openOrderchk = Purchase::where('supplier_id',$request->supplier_id)->where('status',0)->count();

            if($openOrderchk < 1)
            {
                $validator = \Validator::make($request->all(), [
                    'supplier_id' => 'required|not_in:0',
                    'order_date' => 'required|date|before:tomorrow',     
                    'item_name.*' => 'required|max:255',
                    'unit_id.*' => 'required|max:255',
                    'qty.*' => 'required|integer|not_in:0',
                    'unit_price.*' => 'required',
                    'amount.*' => 'required',
                    'payment_type' => 'required|not_in:0',
                    ],[
                      'order_date.before' => 'The date mustbe today or before.',
                      'item_name.*.required' => 'Item name required.',
                      'unit_id.*.required' => 'Unit Name required.',
                      'qty.*.required' => 'Quantity required.',
                      'qty.*.not_in' => 'Quantity required.',
                      'unit_price.*.required' => 'Unit price required.',
                      'amount.*.required' => 'Price required.',
                ]);
                if ($validator->fails())         
                {
                    return response()->json(['errors' => $validator->errors()]);
                }
            
                if($validator->passes())
                {
                    
                    $poId = strtotime("now");
                    
                    $data = $request->all();
                    $New_start_index = 0;          
                    $length = count($data['unit_price']);
                  
                    $item_name = array_combine(range($New_start_index,  count($request->item_name) + ($New_start_index-1)),
                        array_values($request->item_name)); 

                    $unit_id = array_combine(range($New_start_index,  count($request->unit_id) + ($New_start_index-1)),
                        array_values($request->unit_id)); 

                    $qty = array_combine(range($New_start_index,  count($request->qty) + ($New_start_index-1)),
                        array_values($request->qty)); 
                   
                    $unit_price = array_combine(range($New_start_index,  count($request->unit_price) + ($New_start_index-1)),
                        array_values($request->unit_price)); 

                    $amount = array_combine(range($New_start_index,  count($request->amount) + ($New_start_index-1)),
                        array_values($request->amount)); 
                  
                    for($i=0; $i < $length; $i++)
                    {
                        $findProduct = Product::find($item_name[$i]);

                        if($findProduct->primary_unit == $unit_id[$i])
                        {
                            $primary_qty = $qty[$i];
                            $secondary_qty = $qty[$i] * $findProduct->no_of_pcs;
                        }
                        if($findProduct->secondary_unit == $unit_id[$i])
                        {
                            $primary_qty = (int)($qty[$i] / $findProduct->no_of_pcs);
                            $secondary_qty = $qty[$i];
                        }
                        $poOrder = new Purchase;
                        $poOrder->po_id = $poId; 
                        $poOrder->supplier_id = $request->supplier_id;
                        $poOrder->order_date = Carbon::createFromFormat('d-m-Y', $request->order_date)->format('Y-m-d');            
                        $poOrder->item_name = Str::lower($item_name[$i]); // product_id are same
                        $poOrder->unit_id = Str::lower($unit_id[$i]);
                        $poOrder->qty = $qty[$i];                
                        $poOrder->primary_qty = $primary_qty;                
                        $poOrder->secondary_qty = $secondary_qty;                
                        $poOrder->unit_price = $unit_price[$i];
                        $poOrder->amount = $amount[$i];
                        $poOrder->payment_type = Str::lower($request->payment_type);
                        $poOrder->delivery_charges = $request->delivery_charges;
                        $poOrder->round_off = $request->round_off;
                        $poOrder->gst_amount = $request->gst_amount;
                        $poOrder->total = $request->total;
                        $poOrder->advance = $request->advance;
                        $poOrder->prev_balance = $request->prev_balance;
                        $poOrder->balance = $request->balance;
                        $poOrder->remarks = $request->remarks;
                        if($request->advance <= 0)
                        {
                            $poOrder->payment_status  = 0;
                        }
                        elseif($request->balance <= 0)
                        {
                            $poOrder->payment_status  = 2;           
                        }
                        else
                        {
                            $poOrder->payment_status  = 1;  
                        }
                        $poOrder->status = 0;
                        $poOrder->save();
                    }

                    $supplier = Supplier::find($request->supplier_id); 
                    $newSupplierBalance = $request->balance;
                    $supplier->balance = $newSupplierBalance;
                    $supplier->update();

                    $allPoItem = Purchase::leftJoin('products','purchases.item_name','=','products.product_id')
                                            ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                            ->leftJoin('units','purchases.unit_id','=','units.unit_id')
                                            ->leftJoin('suppliers','purchases.supplier_id','=','suppliers.supplier_id')
                                            ->select(array('purchases.balance as PO_balance','purchases.*','products.*','units.*','suppliers.*','brands.*'))
                                            ->orderBy('purchase_id','asc')
                                            ->get(); 
                    $suppliers = Supplier::orderBy('supplier_name','ASC')->get();
                    $success = array('success' => "Order saved successfully.", 'allPoItem' => $allPoItem, 'suppliers' => $suppliers);
                    return response()->json($success);
                }
            }
            else
            {
                $errors = array('errors'=> array('supplier_id' => array('0'=>"Order can't be completed. This supplier has an open order.")));
                return response()->json($errors);
            } 
        }   
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($po_id)
    {
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {           
        if(request()->ajax())
        {           
            $validator = \Validator::make($request->all(), [
                'supplier_id' => 'required|not_in:0',
                'order_date' => 'required|date|before:tomorrow',     
                'item_name.*' => 'required|max:255',
                'unit_id.*' => 'required|max:255',
                'qty.*' => 'required|integer|not_in:0',
                'unit_price.*' => 'required',
                'amount.*' => 'required',
                'payment_type' => 'required|not_in:0',
                ],[
                  'order_date.before' => 'The date mustbe today or before.',
                  'item_name.*.required' => 'Item name required.',
                  'unit_id.*.required' => 'Unit Name required.',
                  'qty.*.required' => 'Quantity required.',
                  'unit_price.*.required' => 'Unit price required.',
                  'amount.*.required' => 'Price required.',
            ]);
            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }
            if($validator->passes())
            {

                $New_start_index = 0;          
                $length = count($request['unit_price']);

                $item_name = array_combine(range($New_start_index,  count($request->item_name) + ($New_start_index-1)),
                    array_values($request->item_name)); 

                $unit_id = array_combine(range($New_start_index,  count($request->unit_id) + ($New_start_index-1)),
                    array_values($request->unit_id)); 

                $qty = array_combine(range($New_start_index,  count($request->qty) + ($New_start_index-1)),
                    array_values($request->qty));

                $unit_price = array_combine(range($New_start_index,  count($request->unit_price) + ($New_start_index-1)),
                    array_values($request->unit_price)); 

                $amount = array_combine(range($New_start_index,  count($request->amount) + ($New_start_index-1)),
                    array_values($request->amount)); 

                Purchase::where('po_id','=',$request->po_id)->delete();  

                for($i=0; $i < $length; $i++)
                {
                    $findProduct = Product::find($item_name[$i]);

                    if($findProduct->primary_unit == $unit_id[$i])
                    {
                        $primary_qty = $qty[$i];
                        $secondary_qty = $qty[$i] * $findProduct->no_of_pcs;
                    }
                    if($findProduct->secondary_unit == $unit_id[$i])
                    {
                        $primary_qty = $qty[$i] / $findProduct->no_of_pcs;
                        $secondary_qty = $qty[$i];
                    }
                    $poupdate = new Purchase;
                    $poupdate->po_id = $request->po_id;
                    $poupdate->supplier_id = Str::lower($request->supplier_id);
                    $poupdate->order_date = Carbon::createFromFormat('d-m-Y', $request->order_date)->format('Y-m-d');         
                    $poupdate->item_name = Str::lower($item_name[$i]); // product_id are same
                    $poupdate->unit_id = Str::lower($unit_id[$i]);
                    $poupdate->qty = $qty[$i];                
                    $poupdate->primary_qty = $primary_qty;                
                    $poupdate->secondary_qty = $secondary_qty;                
                    $poupdate->unit_price = $unit_price[$i];
                    $poupdate->amount = $amount[$i];
                    $poupdate->payment_type = Str::lower($request->payment_type);
                    $poupdate->delivery_charges = $request->delivery_charges;
                    $poupdate->round_off = $request->round_off;
                    $poupdate->gst_amount = $request->gst_amount;
                    $poupdate->total = $request->total;
                    $poupdate->advance = $request->advance;
                    $poupdate->prev_balance = $request->prev_balance;
                    $poupdate->balance = $request->balance;
                    $poupdate->remarks = $request->remarks;
                    if($request->advance <= 0)
                    {
                        $poupdate->payment_status  = 0;
                    }
                    elseif($request->balance <= 0)
                    {
                        $poupdate->payment_status  = 2;           
                    }
                    else
                    {
                        $poupdate->payment_status  = 1;  
                    }
                    $poupdate->status = 0;
                    $poupdate->save();               
                }     
                
                $supplier = Supplier::find($request->supplier_id);
                $newSupplierBalance = $request->balance;
                $supplier->balance = $newSupplierBalance;
                $supplier->update();

                $allPoItem = Purchase::leftJoin('products','purchases.item_name','=','products.product_id')
                                        ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                        ->leftJoin('units','purchases.unit_id','=','units.unit_id')
                                        ->leftJoin('suppliers','purchases.supplier_id','=','suppliers.supplier_id')
                                        ->select(array('purchases.balance as PO_balance','purchases.*','products.*','units.*','suppliers.*','brands.*'))
                                        ->orderBy('purchase_id','asc')
                                        ->get(); 
                $suppliers = Supplier::orderBy('supplier_name','ASC')->get();
                $success = array('success' => "Order updated successfully.", 'allPoItem' => $allPoItem , 'suppliers'=>$suppliers);
                return response()->json($success);

            } 
            
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $po_id = $request->id; //here id refer for date because delete modal is common for all
        $delData = Purchase::where('po_id', $po_id)->where('status',0)->first();
        
        $supplier = Supplier::find($delData->supplier_id);
        $supplier->balance = $delData->dr_prev_balance;
        $is_saved = $supplier->update();

        if($is_saved)
        {
            Purchase::where('po_id','=',$po_id)->delete(); 
        }

        $suppliers = Supplier::orderBy('supplier_name','ASC')->get();
        $allPoItem = Purchase::leftJoin('products','purchases.item_name','=','products.product_id')
                                    ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                    ->leftJoin('units','purchases.unit_id','=','units.unit_id')
                                    ->leftJoin('suppliers','purchases.supplier_id','=','suppliers.supplier_id')
                                    ->select(array('purchases.balance as PO_balance','purchases.*','products.*','units.*','suppliers.*','brands.*'))
                                    ->orderBy('purchase_id','asc')
                                    ->get(); 
        $success = array('success' => "Order deleted successfully.", 'suppliers' => $suppliers, 'allPoItem' => $allPoItem);
        return response()->json($success);
    }

    public function status(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'order_date' => 'date',
            'delivery_date' => 'required|date|before:tomorrow|after_or_equal:order_date',     
            ],[
            'delivery_date.before' => 'The date mustbe today or before.',
        ]);
        if ($validator->fails())         
        {
            return response()->json(['errors' => $validator->errors()]);
        }
        if($validator->passes())
        {
            $deliveryDate = Carbon::createFromFormat('d-m-Y', $request->delivery_date)->format('Y-m-d');      
            $po_id = $request->po_id; //here id refer for date because delete modal is common for all
            $data = Purchase::where('po_id', $po_id)->get();
            /*
                Before status change product sholud be in stock
            */
            foreach($data as $d)
            {
                $findProduct = Product::find($d->item_name);

                $newStock = New Stock;
                $newStock->stock_type = 1;
                $newStock->trnx_id  = $po_id;
                $newStock->item_name  = Str::lower($d->item_name);
                $newStock->supplier_id  = $d->supplier_id;
                $newStock->order_date  = $d->order_date;
                $newStock->delivery_date  = $deliveryDate;
                $newStock->qty = $d->qty;            
                $newStock->primary_qty = $d->primary_qty;            
                $newStock->secondary_qty = $d->secondary_qty;
                $newStock->unit_id  = $d->unit_id;
                $newStock->unit_price  = $d->unit_price;
                $newStock->amount  = $d->amount;
                // this two column delted 
                // $newStock->in_hand_stock  = $newStock->in_hand_stock + $d->qty;
                // $newStock->stock_value  = $d->stock_value + ($d->qty*$d->unit_price);
                if($d->advance <= 0)
                {
                    $newStock->stock_stat  = 0;
                }
                elseif($d->balance <= 0)
                {
                    $newStock->stock_stat  = 2;                    
                }
                else
                {
                    $newStock->stock_stat  = 1;  
                }
                $newStock->save();

                if($findProduct)
                {
                    if($findProduct->primary_unit == $d->unit_id)
                    { 
                        // all stock value calculation should be in secondary 
                        $prevStockValue = $findProduct->stock_value;
                        $prevSecondaryStockQty = $findProduct->in_hand_stock_second;
                        $nowSecondaryQty = $findProduct->no_of_pcs * $d->primary_qty; // or  $d->qty
                        $secondary_pp_for_stock = ($prevStockValue + $d->amount) / ($prevSecondaryStockQty + $nowSecondaryQty);
                        $primary_pp_for_stock = $secondary_pp_for_stock * $findProduct->no_of_pcs;

                        $findProduct->primary_pp = $d->unit_price;
                        $findProduct->secondary_pp = $d->unit_price / $findProduct->no_of_pcs;
                        $findProduct->primary_pp_for_stock = $primary_pp_for_stock;
                        $findProduct->secondary_pp_for_stock = $secondary_pp_for_stock;
                        $findProduct->stock_value = $secondary_pp_for_stock * ($prevSecondaryStockQty + $nowSecondaryQty);
                    }
                    if($findProduct->secondary_unit == $d->unit_id)
                    {
                        $prevStockValue = $findProduct->stock_value;
                        $prevSecondaryStockQty = $findProduct->in_hand_stock_second;
                        $nowSecondaryQty = $d->secondary_qty; // or  $d->qty
                        $secondary_pp_for_stock = ($prevStockValue + $d->amount) / ($prevSecondaryStockQty + $nowSecondaryQty);
                        $primary_pp_for_stock = $secondary_pp_for_stock * $findProduct->no_of_pcs;

                        $findProduct->primary_pp = $d->unit_price * $findProduct->no_of_pcs;
                        $findProduct->secondary_pp = $d->unit_price;
                        $findProduct->primary_pp_for_stock = $primary_pp_for_stock;
                        $findProduct->secondary_pp_for_stock = $secondary_pp_for_stock;
                        $findProduct->stock_value = $secondary_pp_for_stock * ($prevSecondaryStockQty + $nowSecondaryQty);

                    }                   

                    // Product Stock qty calculation  start
                    $stockSecond = $findProduct->in_hand_stock_second + $d->secondary_qty;
                    $findProduct->in_hand_stock_primary = (int)($stockSecond/$findProduct->no_of_pcs);
                    $findProduct->in_hand_stock_second = $stockSecond;
                    // Product Stock qty calculation end
                    $findProduct->update();
                }

            } 
            Purchase::where('po_id',$po_id)->update(['delivery_date' => $deliveryDate ,'status' => 1]);
            $allPoItem = Purchase::leftJoin('products','purchases.item_name','=','products.product_id')
                                    ->leftJoin('brands','products.brand_id','=','brands.brand_id')
                                    ->leftJoin('units','purchases.unit_id','=','units.unit_id')
                                    ->leftJoin('suppliers','purchases.supplier_id','=','suppliers.supplier_id')
                                    ->select(array('purchases.balance as PO_balance','purchases.*','products.*','units.*','suppliers.*','brands.*'))
                                    ->orderBy('purchase_id','asc')
                                    ->get();      
            $suppliers = Supplier::orderBy('supplier_name','ASC')->get();
            $products = Product::leftJoin('brands','products.brand_id','=','brands.brand_id')
                            ->leftJoin('suppliers','brands.supplier_id','=','suppliers.supplier_id')
                            ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                            ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                            ->select(array('products.*','p.unit_id as p_unit_id','p.unit_name as p_unit_name','s.unit_id as s_unit_id','s.unit_name as s_unit_name','brands.*','suppliers.*'))
                            ->orderBy('product_name','ASC')
                            ->get(); 
            $success = array('success' => "Item updated successfully.", 'allPoItem' => $allPoItem,'suppliers' => $suppliers,'products' => $products);
            return response()->json($success);
        }

        
    }

    public function dateRange()
    {
        $startDate = $_GET['startDate']; 
        $endDate = $_GET['endDate'];
        // $x = Carbon::now()->subDays(30);
        $purchases = Purchase::where('order_date', '>=', $startDate)->where('order_date', '<=', $endDate)->where('status',0)->get()->unique('po_id');     
        $total = 0;
        foreach ($purchases as $purchase) {
            $total = $total+ $purchase->total;
        }
        return response()->json($total);
    }
}
