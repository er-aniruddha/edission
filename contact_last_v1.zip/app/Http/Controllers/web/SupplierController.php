<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Supplier;
use App\Models\Portal\Brand;
use App\Models\Portal\Purchase;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Validator;
use Image;  

class SupplierController extends Controller
{
    /*
     * Index page
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        if(request()->ajax())
        {
          return datatables()->of(Supplier::orderBy('supplier_id','DESC')->get())
                ->addColumn('action', function($data){
                  $button = '<button type="button" name="view" id="'.$data->supplier_id.'" data-name="'.$data->supplier_name.'" data-address="'.$data->supplier_address.'" data-status="'.$data->supplier_stat.'" class="view btn btn-outline-info  btn-sm">View</button>';
                  $button .= '&nbsp;';
                  $button .= '<button type="button" name="edit" id="'.$data->supplier_id.'" data-name="'.$data->supplier_name.'" data-address="'.$data->supplier_address.'" data-status="'.$data->supplier_stat.'" class="edit btn btn-outline-primary btn-sm">Edit</button>';
                  $button .= '&nbsp;';
                  $button .= '<button type="button" id="'.$data->supplier_id.'" data-name="'.$data->supplier_name.'" class="delete btn btn-outline-danger btn-sm">Del</button>';
                  return $button;
                })
                ->addColumn('status', function($data){
                  if( $data->supplier_stat == 1)
                  {
                    $status = '<a id="'.$data->supplier_id.'" data-url="' . route('supplier.status', $data->supplier_id) .'" class="status badge badge-primary text-uppercase" style="color: #fff">Active</a>';  
                  }
                  else
                  {
                    $status = '<a id="'.$data->supplier_id.'" data-url="' . route('supplier.status', $data->supplier_id) .'" class="status badge badge-secondary text-uppercase" style="color: #fff">Deactive</a>';   
                  }
                  return $status;
                })
                ->addIndexColumn()
                ->rawColumns(['action' , 'status'])
                ->make(true);       
                    
        }        
        return view('portal.supplier.index');
    }

    /*
     * Create
     */
    public function create(Request $request)
    {
        // return response()->json($request->all());
        if(request()->ajax())
        {
            $validator = \Validator::make($request->all(), [
            'supplier_name' => 'required|max:255|unique:suppliers,supplier_name',
            'supplier_address' => 'required|max:255',
            ]);

            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }

            $supplier = new Supplier;            
            $supplier->supplier_name = Str::lower($request->supplier_name);
            $supplier->supplier_address = Str::lower($request->supplier_address);
            $supplier->supplier_stat = $request->supplier_stat;
            $is_saved = $supplier->save();

            if($is_saved)
            {
                $success = array('success' => 'Supplier added successfully.');
                return response()->json($success);
            }
        }
    }

    /*
     * Edit
     */
    public function update(Request $request)
    {
        $supplier = Supplier::find($request->supplier_id);

        if(request()->ajax())
        {
            $validator = \Validator::make($request->all(), [
                'supplier_name' => ['required','max:255',
                    Rule::unique('suppliers')->ignore($supplier->supplier_name,'supplier_name'),
                ],                
                'supplier_address' => 'required|max:255',
            ]);

            if ($validator->fails())         
            {
                return response()->json(['errors' => $validator->errors()]);
            }

            if($validator->passes())
            {   
                $supplier->supplier_name = Str::lower($request->supplier_name);
                $supplier->supplier_address = Str::lower($request->supplier_address);
                $supplier->supplier_stat = $request->supplier_stat;
                $is_saved = $supplier->update();

                if($is_saved)
                {
                    $success = array('success' => 'Supplier updated successfully.');
                    return response()->json($success);
                }
            }
            
        }
    }


    /*
     * Change Status
     */
    public function status($supplier_id)
    {
        $supplier = Supplier::find($supplier_id);
        if($supplier->supplier_stat == 1)
        {
            Supplier::where('supplier_id',$supplier_id)->update(['supplier_stat' => 0]);
            $success = array('success' => 'Supplier status change successfullly');
            return response()->json($success);
        }
        else
        {
            Supplier::where('supplier_id',$supplier_id)->update(['supplier_stat' => 1]);
            $success = array('success' => 'Supplier status change successfullly');
            return response()->json($success);
        }
    }

    /*
     * Remove Supplier
     */
    public function destroy(Request $request)
    {
        $supplier = Supplier::find($request->id);
        $supplierInSale = Purchase::where('supplier_id', $request->id)->first();
        $brand = Brand::where('supplier_id', $request->id)->first();
        if($supplierInSale || $brand)
        {
            $error = array('error' => "This supplier can't be deleted.");
            return response()->json($error);
        }
        else
        {
            $supplier->delete();
            $success = array('success' => "Supplier deleted successfullly.");
            return response()->json($success);
        }
    }
}
