<?php

namespace App\Http\Controllers\api\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Providers\RouteServiceProvider;
use App\Models\User;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class RegisterController extends Controller
{
    public function register(Request $request)
    {
        $data = $request->all();
        $validator = Validator::make($request->all(), [ 
            'f_name' => ['required', 'string', 'max:255'],
            's_name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        if ($validator->fails()) { 
            return response()->json(['error'=>$validator->errors()], 401);            
        }
        
        if($validator->passes())
        {
            $input = $request->all(); 
            $input['password'] = Hash::make($input['password']); 
            $user = User::create($input); 

            $success['token'] =  $user->createToken('authToken')->accessToken; 
            $success['f_name'] =  $user->f_name;

            return response()->json(['success'=>$success],200); 
           
        }
        
    }    
}
