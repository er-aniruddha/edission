<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portal\Expense;
use Illuminate\Support\Str;
use Validator;
use Carbon\Carbon;

class ExpenseController extends Controller
{
  public function __construct()
  {
    $this->middleware('auth:api');
  }

  public function index()
  {      
    $expenses = Expense::orderBy('date','DESC')->get();
    
    return response()->json($expenses);
  }

  public function create(Request $request)
  {
    if($request->date)
    {
      $date = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
      $validator_date = \Validator::make($date, [
        'date' => 'required|date|before:tomorrow|unique:expenses,date',         
      ],[
          'date.before' => 'The date mustbe today or before.',
          'date.unique' => 'Can not add two item on same date',
      ]);
      if ($validator_date->fails())         
      {
        return response()->json(['errors' => $validator_date->errors()]);
      }
    }

    $validator = \Validator::make($request->all(), [
      'date' => 'required|date|before:tomorrow',         
      'fuel' => 'required',
      'travelling' => 'required',
      'transport' => 'required',
      'tiffin' => 'required',
      'room_rent' => 'required',
      'salary' => 'required',
      'extra_exp' => 'required',
      'total' => 'required|not_in:0',
      'remarks' => 'required', 
    ],[
        'date.before' => 'The date mustbe today or before.',
    ]);
    if ($validator->fails())         
    {
      return response()->json(['errors' => $validator->errors()]);
    }
    
    if($validator->passes())
    {
      //$stock = $request->all();
      $expense = new Expense;
      $expense->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
      $expense->fuel = $request->fuel;
      $expense->travelling = $request->travelling;                
      $expense->transport = $request->transport;
      $expense->tiffin = $request->tiffin;
      $expense->room_rent = $request->room_rent;
      $expense->salary = $request->salary;
      $expense->extra_exp = $request->extra_exp;
      $expense->total = $request->total;
      $expense->remarks = $request->remarks;
      $is_save = $expense->save();

      if($is_save)
      {
        $success = array('success' => 'OK', 'message' => 'Save Successfully');
        return response()->json($success);
      } 
    } 
  }

  public function update(Request $request)
  {  
    
    $expense = Expense::find($request->expense_id);
    if($request->date)
    {
      $reqDate = ['date' => Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d')];
      if($expense->date != Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d'))
      {
        $validator_date = \Validator::make($reqDate, [
          'date' => 'required|date|before:tomorrow|unique:expenses,date',         
        ],[
            'date.before' => 'The date mustbe today or before.',
            'date.unique' => 'Can not add two item on same date',
        ]);
        if ($validator_date->fails())         
        {
          return response()->json(['errors' => $validator_date->errors()]);
        }
      }
    } 
    $validator = \Validator::make($request->all(), [
      'fuel' => 'required',
      'travelling' => 'required',
      'transport' => 'required',
      'tiffin' => 'required',
      'room_rent' => 'required',
      'salary' => 'required',
      'extra_exp' => 'required',
      'total' => 'required|not_in:0',
      'remarks' => 'required', 
    ]);

    if ($validator->fails())         
    {
      return response()->json(['errors' => $validator->errors()]);
    }
    if($validator->passes())
    {
      $expense = Expense::find($request->expense_id);
      $expense->date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
      $expense->fuel = $request->fuel;
      $expense->travelling = $request->travelling;                
      $expense->transport = $request->transport;
      $expense->tiffin = $request->tiffin;
      $expense->room_rent = $request->room_rent;
      $expense->salary = $request->salary;
      $expense->extra_exp = $request->extra_exp;
      $expense->total = $request->total;
      $expense->remarks = $request->remarks;
      $is_save = $expense->update();

      if($is_save)
      {
        $success = array('success' => 'OK', 'message' => $request->date.' Update Successfully');
        return response()->json($success);
      }
    } 
  }

  public function destroy($id)
  {
    $data = Expense::find($id);
    $date = Carbon::createFromFormat('Y-m-d', $data->date)->format('d-m-Y');
    $is_delete = $data->delete();
    if($is_delete)
    {
      $success = array('success' => $date.' Expense deleted successfullly');
      return response()->json($success);
    }
  }

  public function details()
  {
    $oneYear = Carbon::now()->subDays(365);
    $oneMonth = Carbon::now()->subDays(30);
    $sevenDays = Carbon::now()->subDays(7);

    $oneYearExpense = Expense::where('date','>=',$oneYear)->sum('total');
    $oneMonthExpense = Expense::where('date','>=',$oneMonth)->sum('total');
    $sevenDaysExpense = Expense::where('date','>=',$sevenDays)->sum('total');

    $data = array('oneYearExpense' => $oneYearExpense, 'oneMonthExpense' => $oneMonthExpense, 'sevenDaysExpense' => $sevenDaysExpense);

    return response()->json($data);
  }

  public function dateRange()
  {
    $startDate = $_GET['startDate']; 
    $endDate = $_GET['endDate'];
    // $x = Carbon::now()->subDays(30);
    $expense = Expense::where('date', '>=', $startDate)->where('date', '<=', $endDate)->get();
    $totalExpense = Expense::where('date', '>=', $startDate)->where('date', '<=', $endDate)->sum('total');

    $data = array('expense' => $expense, 'totalExpense' => $totalExpense);

    return response()->json($data);
  }
}
