<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Portal\CustomerRoute;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class CustomerRouteController extends Controller
{
    public function index()
    {
        $route = CustomerRoute::orderBy('route_name','ASC')->get();
        return response()->json($route);
    }
}
