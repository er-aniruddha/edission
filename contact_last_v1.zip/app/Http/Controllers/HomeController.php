<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Portal\Customer;
use App\Models\Portal\BankAccount;
use App\Models\Portal\BankTransaction;
use App\Models\Portal\LoanAccount;
use App\Models\Portal\LoanTransaction;
use App\Models\Portal\Expense;
use App\Models\Portal\PaymentIn;
use App\Models\Portal\Purchase;
use App\Models\Portal\Product;
use App\Models\Portal\Sale;
use App\Models\Portal\Stock;
use App\Models\Portal\CreditNote;
use App\Models\Portal\Supplier;
use App\Models\Portal\PaymentOut;
use App\Models\User;
use Carbon\Carbon;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    { 
        if(request()->ajax())
        {
            $startDate = $_GET['startDate']; 
            $endDate = $_GET['endDate'];
            
            /* Sale Calculation start*/
            $sales = Sale::where("sale_status","=",1)->get()->unique('sale_trnx_id');
            $totalSale = 0;
            foreach ($sales as $sale) {
                $totalSale = $totalSale+ $sale->sale_total;
            }
            /* Sale Calculation end*/
            
            /* Cr. Note Calculation start*/
            $crnote = CreditNote::where("cr_status","=",1)->get()->unique('cr_trnx_id');
            $totalCrNote = 0;
            foreach ($crnote as $cn) {
                $totalCrNote = $totalCrNote+ $cn->cr_total;
            }
            /* Cr. Note Calculation end*/

            /* Purchase Calculation start*/
            $purchase = Purchase::where("status","=",1)->get()->unique('po_id');
            $totalPurchase = 0;
            foreach ($purchase as $p) {
                $totalPurchase = $totalPurchase+ $p->total;
            }
            /* Purchase Calculation end*/
            
            /* Purchase Order Calculation start*/
            $purchaseOrder = Purchase::where("status","=",0)->get()->unique('po_id');
            $totalPurchaseOrder = 0;
            foreach ($purchaseOrder as $po) {
                $totalPurchaseOrder = $totalPurchaseOrder+ $po->total;
            }
            /* Purchase Order Calculation end*/

            $totalDue = Customer::sum('balance');
            $totalPay = Supplier::sum('balance');
            $totalStockValue = Product::sum('stock_value');
            $bankAccountBal = BankAccount::sum('account_balance');
            $loanAmount = LoanAccount::sum('loan_amount');
            $emiPaid = LoanTransaction::where('status',1)->sum('paid_amount');
            $totalExpense = Expense::sum('total');

            $cashInHand = $bankAccountBal + $loanAmount - $emiPaid +  $totalSale - $totalCrNote - $totalPurchase - $totalPurchaseOrder - $totalDue - $totalExpense + $totalPay;
            
            $bankAccounts = BankAccount::orderBy('account_name','desc')->get(); 

            $success = array('totalDue' => $totalDue, 'totalPay' => $totalPay,'totalStockValue' => $totalStockValue, 'bankAccountBal' => $bankAccountBal ,'cashInHand' => $cashInHand, 'bankAccounts'=>$bankAccounts, 'totalCrNote' => $totalCrNote);
            return response()->json($success);
        }   
        else
        {
            $user = User::find(Auth::id());
            $lowStocks = Product::orderBy('product_name','desc')
                                ->leftJoin('units as p', 'products.primary_unit','=','p.unit_id') 
                                ->leftJoin('units as s', 'products.secondary_unit','=','s.unit_id')
                                ->select(array('products.*','products.in_hand_stock_primary','products.in_hand_stock_second','p.unit_name as primary_unit_name','s.unit_name as secondary_unit_name',))
                                ->where('pro_type','Purchasing')
                                ->where('products.in_hand_stock_primary','<',5)->paginate(2);           
            return view('portal.dashboard.index',['user' => $user, 'lowStocks' => $lowStocks]);
        }   
        
    }

    public function error()
    {
        return view('portal.layouts.error');
    }

    public function commingSoon($value='')
    {
        return view('portal.layouts.comingsoon');
    }
}
