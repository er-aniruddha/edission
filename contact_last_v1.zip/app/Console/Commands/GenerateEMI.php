<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Portal\LoanAccount;
use App\Models\Portal\LoanTransaction;
use Illuminate\Support\Str;
use Validator;
use Carbon\Carbon;

class GenerateEMI extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'generate:emi';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {   
        // $currentDate = Carbon::now()->format('Y-m-d');
        $allLoanAc = LoanAccount::where('loan_status',1)->orderBy('id','asc')->get();
        $currentDate = Carbon::now()->toDateString();
        $firstDayOfMonth = Carbon::now()->startOfMonth()->toDateString();

        $trnxId = 2000000000+strtotime("now"); 
        $i = 0;
        if($currentDate == $firstDayOfMonth)
        {
            if(count($allLoanAc) != 0)
            {
                foreach ($allLoanAc as $eachAc) 
                {
                    $hasAnyDuePaid = LoanTransaction::where('loan_ac_id',$eachAc->loan_ac_id)->where('status',0)->count();                    

                    if($hasAnyDuePaid == 0)
                    {
                        $trnxCount = LoanTransaction::where('loan_ac_id',$eachAc->loan_ac_id)->where('status',1)->count();
                        $billDate = Carbon::parse($eachAc->date)->addMonth($trnxCount+1)->firstOfMonth(); 
                        $paymentDate = Carbon::parse($eachAc->date)->addMonth($trnxCount+1)->firstOfMonth()->addDay(9); 
                        $loanBalance = $eachAc->loan_balance; 
                        $eRate = $eachAc->interest_rate / (12*100);
                            
                        $monthlyInt = $loanBalance * $eRate;
                        $principalOnEmi = $eachAc->emi - $monthlyInt;          

                        $newLoanTrnx = new LoanTransaction;
                        $newLoanTrnx->loan_trnx_id = $trnxId+(++$i);
                        $newLoanTrnx->loan_ac_id = $eachAc->loan_ac_id;
                        $newLoanTrnx->bill_date = $billDate;
                        $newLoanTrnx->payment_date = $paymentDate;
                        $newLoanTrnx->prev_loan_balance = $eachAc->loan_balance;
                        $newLoanTrnx->interest_of_emi = $monthlyInt;
                        $newLoanTrnx->principal_of_emi = $principalOnEmi;
                        $newLoanTrnx->total_emi = $eachAc->emi;
                        $newLoanTrnx->status = 0;
                        $newLoanTrnx->save();
                    }                    

                    // \Log::info($newLoanTrnx);
                    
                }
            } // loan transaction end
            else
            {
                return 0;
            }
        }  //Check date end
        else
        {
            return 0;
        }      
    }
}
