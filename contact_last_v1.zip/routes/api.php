<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\api\Auth\ConfirmPasswordController;
use App\Http\Controllers\api\Auth\ForgotPasswordController;
use App\Http\Controllers\api\Auth\LoginController;
use App\Http\Controllers\api\Auth\RegisterController;
use App\Http\Controllers\api\Auth\ResetPasswordController;
use App\Http\Controllers\api\BrandController;
use App\Http\Controllers\api\CustomerController;
use App\Http\Controllers\api\CustomerRouteController;
use App\Http\Controllers\api\ProductController;
use App\Http\Controllers\api\SupplierController;
use App\Http\Controllers\api\SaleOrderController;
use App\Http\Controllers\api\UnitController;
use App\Http\Controllers\api\ExpenseController;
use App\Http\Controllers\api\PaymentInController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
/* Auth Routes here*/
Route::post('/login',[LoginController::class, 'login'])->name('api.login');
Route::post('/register',[RegisterController::class, 'register'])->name('api.register');
Route::post('/password/forgot',[ForgotPasswordController::class, 'getResetToken'])->name('api.forgot');
Route::post('/password/reset',[ResetPasswordController::class, 'reset'])->name('api.reset');
Route::post('/password/confirm',[ConfirmPasswordController::class, 'confirm'])->name('api.confirm');
Route::get('email/verify/{token}', [VerificationController::class, 'verify'])->name('api.verify');

/* Customer Routes here*/
Route::get('/customer',[CustomerController::class, 'index'])->name('api.customer.index');
Route::post('/customer/create',[CustomerController::class, 'create'])->name('api.customer.create');
Route::get('/customer/profile/{customer_id}',[CustomerController::class, 'profile'])->name('api.customer.profile');
Route::get('/customer/data_table/transaction/{customer_id}', [CustomerController::class, 'data_table_transaction'])->name('api.customer.data.table.transaction');
Route::post('/customer/profile/update',[CustomerController::class, 'update'])->name('api.customer.update');
Route::get('/customer/delete/{customer_id}',[CustomerController::class, 'destroy'])->name('api.customer.destroy');

/* Route Routes here*/
Route::get('/route',[CustomerRouteController::class, 'index'])->name('api.route.index');

/* Product Routes here*/
Route::get('/product',[ProductController::class, 'index'])->name('api.product.index');

/* Order && Sales route are here*/
Route::get('/sale/order', [SaleOrderController::class, 'index'])->name('api.sale.order.index');
Route::post('/sale/order/create', [SaleOrderController::class, 'create'])->name('api.sale.order.create');
Route::get('/sale/order/show/{sale_trnx_id}', [SaleOrderController::class, 'show'])->name('api.sale.order.show');
Route::post('/sale/order/update', [SaleOrderController::class, 'update'])->name('api.sale.order.update');
Route::post('/sale/order/convert', [SaleOrderController::class, 'convert'])->name('api.sale.order.convert');
Route::get('/sale/order/delete/{sale_trnx_id}', [SaleOrderController::class, 'destroy'])->name('api.sale.order.delete');

// Route::get('/order/list',[SaleController::class, 'orderList'])->name('api.sale.order.list');
// Route::get('/order/details/{invoice_id}',[SaleController::class, 'ordderDetails'])->name('api.sale.order.details');
// Route::post('/sale/confirm',[SaleController::class, 'saleConfirm'])->name('api.sale.confirm');

//Expenses Route are here
Route::get('/expense',[ExpenseController::class, 'index'])->name('api.expense.index');
Route::post('/expense/create',[ExpenseController::class, 'create'])->name('api.expense.create');
Route::post('/expense/update',[ExpenseController::class, 'update'])->name('api.expense.update');
Route::get('/expense/delete/{expense_id}',[ExpenseController::class, 'destroy'])->name('api.expense.delete');
Route::get('/expense/details',[ExpenseController::class, 'details'])->name('api.expense.details');
Route::get('/expense/date/range', [ExpenseController::class, 'dateRange'])->name('api.expense.date.range');

// Payment-In Controller
Route::post('/payment-in/create',[PaymentInController::class, 'create'])->name('payment.in.create');